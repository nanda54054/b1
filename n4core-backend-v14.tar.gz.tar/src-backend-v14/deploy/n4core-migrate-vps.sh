#!/usr/bin/env bash
#
# ============================================================================
#  N4 Core VPN — VPS အသစ်ကို ရွှေ့ခြင်း (Migration)
# ============================================================================
#  VPS အသစ် ဝယ်ပြီး အကုန်ရွှေ့ချင်ချိန် သုံးရန်။ ၂ ဆင့် ပါတယ်။
#
#  ┌─ ဆင့် ၁: VPS အဟောင်း မှာ run ──────────────────────────────────┐
#  │   sudo ./n4core-migrate-vps.sh export                          │
#  │   → /root/n4core-migrate-<ရက်စွဲ>.tar.gz.enc ရမယ်               │
#  │   → ဒီ file ကို VPS အသစ်ဆီ scp နဲ့ ပို့ပါ                        │
#  └────────────────────────────────────────────────────────────────┘
#
#  ┌─ ဆင့် ၂: VPS အသစ် မှာ run ─────────────────────────────────────┐
#  │   sudo ./n4core-migrate-vps.sh import n4core-migrate-XXX.tar.gz.enc │
#  │   → PHP/MySQL/nginx တင် + code ဖြည် + DB ပြန်သွင်း              │
#  │   → ပြီးရင်:  sudo ./n4core-domain.sh <domain အသစ်> --ssl        │
#  └────────────────────────────────────────────────────────────────┘
#
#  အခြား command များ
#     sudo ./n4core-migrate-vps.sh check      လက်ရှိ VPS ကို စစ်
#     sudo ./n4core-migrate-vps.sh --help     ဒီစာ
#
#  ⚠️  Export file ထဲ config.php (secret key များ) + DB dump ပါဝင်တယ်။
#      encryption_key နဲ့ AES-256 encrypt လုပ်ထားတယ်။ password မမေ့ပါနဲ့။
# ============================================================================

set -uo pipefail

APP_DIR="${N4_APP_DIR:-/var/www/n4core}"
STAMP="$(date +%F-%H%M%S)"

if [ -t 1 ]; then
  R=$'\e[31m'; G=$'\e[32m'; Y=$'\e[33m'; B=$'\e[34m'; C=$'\e[36m'; W=$'\e[1m'; N=$'\e[0m'
else
  R=""; G=""; Y=""; B=""; C=""; W=""; N=""
fi

say()  { printf '%s\n' "$*"; }
ok()   { printf '%s✅ %s%s\n' "$G" "$*" "$N"; }
warn() { printf '%s⚠️  %s%s\n' "$Y" "$*" "$N"; }
err()  { printf '%s❌ %s%s\n' "$R" "$*" "$N" >&2; }
step() { printf '\n%s%s▸ %s%s\n' "$W" "$B" "$*" "$N"; }
info() { printf '   %s\n' "$*"; }
hr()   { printf '%s────────────────────────────────────────────────────────────%s\n' "$C" "$N"; }
die()  { err "$*"; exit 1; }

need_root() { [ "$(id -u)" = "0" ] || die "root အနေနဲ့ run ရမယ်:  sudo $0 $*"; }

# trap က function ရဲ့ `local` variable ကို EXIT အချိန် မမြင်တာမို့ (subshell
# ကျော်ပြီး unbound error ဖြစ်တယ်) cleanup path ကို global မှာ ထားတယ်။
WORKDIR=""
cleanup() { [ -n "${WORKDIR:-}" ] && rm -rf "$WORKDIR"; }
trap cleanup EXIT

cfg() {
  php -r '
    $f = $argv[2] ?? "";
    if (!is_file($f)) { echo ""; exit; }
    $c = require $f; $k = explode(".", $argv[1]); $v = $c;
    foreach ($k as $p) { if (!is_array($v) || !array_key_exists($p,$v)) { echo ""; exit; } $v = $v[$p]; }
    echo is_bool($v) ? ($v?"true":"false") : (is_array($v) ? implode(",",$v) : (string)$v);
  ' "$1" "${2:-$APP_DIR/config/config.php}" 2>/dev/null
}

# ============================================================================
#  CHECK — လက်ရှိ VPS အခြေအနေ
# ============================================================================
cmd_check() {
  hr
  printf '%s N4 Core — VPS အခြေအနေ စစ်ဆေးချက်%s\n' "$W" "$N"
  hr

  local pass=0 fail=0
  t() {
    if eval "$2" >/dev/null 2>&1; then
      printf '   %s✅%s %-32s %s\n' "$G" "$N" "$1" "${3:-}"; pass=$((pass+1))
    else
      printf '   %s❌%s %-32s %s\n' "$R" "$N" "$1" "${4:-မရှိ}"; fail=$((fail+1))
    fi
  }

  t "App directory"  "[ -d '$APP_DIR' ]"                      "$APP_DIR"
  t "config.php"     "[ -f '$APP_DIR/config/config.php' ]"
  t "PHP CLI"        "command -v php"                          "$(php -r 'echo PHP_VERSION;' 2>/dev/null)"
  t "MySQL client"   "command -v mysql || command -v mariadb"
  t "nginx"          "command -v nginx"                        "$(nginx -v 2>&1 | grep -oP '[\d.]+' | head -1)"
  t "tar"            "command -v tar"
  t "openssl"        "command -v openssl"
  t "curl"           "command -v curl"

  echo
  if [ -f "$APP_DIR/config/config.php" ]; then
    local dbh dbn dbu
    dbh="$(cfg db.host)"; dbn="$(cfg db.name)"; dbu="$(cfg db.user)"
    info "DB target : ${dbu}@${dbh}/${dbn}"
    if mysql -h "$dbh" -u "$dbu" -p"$(cfg db.pass)" -e 'SELECT 1' "$dbn" >/dev/null 2>&1; then
      local tbl
      tbl="$(mysql -N -h "$dbh" -u "$dbu" -p"$(cfg db.pass)" -e \
            "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='$dbn'" 2>/dev/null)"
      ok "DB ချိတ်ရ — table ${tbl} ခု"
      pass=$((pass+1))
    else
      err "DB ချိတ်လို့မရ — config/config.php ထဲ db.pass စစ်ပါ"
      fail=$((fail+1))
    fi

    info "Storage   : $APP_DIR/storage  ($(du -sh "$APP_DIR/storage" 2>/dev/null | cut -f1 || echo '?'))"
    info "Code size : $(du -sh --exclude=storage "$APP_DIR" 2>/dev/null | cut -f1 || echo '?')"
    info "Timezone  : $(cfg app.timezone)"
    info "TG owner  : $(cfg telegram.owner_id)"
  fi

  echo
  hr
  [ "$fail" = 0 ] && ok "စစ်ဆေးချက် ${pass} ခု အားလုံး အောင်မြင် — export လုပ်လို့ရပါတယ်" \
                 || warn "အောင်: ${pass}   မအောင်: ${fail}"
  hr
}

# ============================================================================
#  EXPORT — VPS အဟောင်း မှာ run
# ============================================================================
cmd_export() {
  need_root export
  [ -d "$APP_DIR" ] || die "App directory မတွေ့: $APP_DIR"
  [ -f "$APP_DIR/config/config.php" ] || die "config/config.php မတွေ့"

  hr
  printf '%s N4 Core — VPS ကနေ ထုတ်ခြင်း (EXPORT)%s\n' "$W" "$N"
  hr

  local dbh dbp dbn dbu dbpass enckey
  dbh="$(cfg db.host)"; dbp="$(cfg db.port)"; dbn="$(cfg db.name)"
  dbu="$(cfg db.user)"; dbpass="$(cfg db.pass)"
  enckey="$(cfg security.encryption_key)"

  [ -n "$dbn" ] || die "config.php ကနေ DB name ဖတ်လို့မရ"
  [ -n "$enckey" ] || die "config.php ကနေ encryption_key ဖတ်လို့မရ"

  info "DB        : ${dbu}@${dbh}:${dbp}/${dbn}"
  info "App dir   : ${APP_DIR}"
  echo

  local work out
  WORKDIR="$(mktemp -d /tmp/n4core-export-XXXXXX)"
  work="$WORKDIR"
  out="/root/n4core-migrate-${STAMP}.tar.gz"

  # ---- ၁။ DB dump ----
  step "၁/၅  Database dump ယူခြင်း"
  local mysqldump_bin=""
  for b in mysqldump mariadb-dump; do command -v "$b" >/dev/null 2>&1 && { mysqldump_bin="$b"; break; }; done

  if [ -n "$mysqldump_bin" ]; then
    if "$mysqldump_bin" -h "$dbh" -P "${dbp:-3306}" -u "$dbu" -p"$dbpass" \
         --single-transaction --routines --triggers --events \
         --default-character-set=utf8mb4 --add-drop-table \
         "$dbn" > "$work/database.sql" 2>"$work/dump.err"; then
      ok "Dump ရပြီး — $(du -h "$work/database.sql" | cut -f1), table $(grep -c '^CREATE TABLE' "$work/database.sql") ခု"
    else
      err "mysqldump မအောင်မြင်:"
      sed 's/^/     /' "$work/dump.err" >&2
      die "DB dump မရပါ"
    fi
  else
    # mysqldump မရှိရင် PHP နဲ့ dump (Backup::create ရဲ့ လမ်း)
    warn "mysqldump မရှိ — PHP နဲ့ dump လုပ်နေတယ်…"
    if sudo -u www-data php "$APP_DIR/bin/cron.php" --backup-db-only >/dev/null 2>&1; then
      warn "bin/cron.php နဲ့ ယူထားတဲ့ archive ကို storage/backups ထဲ ရှာပါ"
    fi
    die "mysqldump တင်ပါ:  apt install mysql-client   (သို့) mariadb-client"
  fi

  # ---- ၂။ Code + storage ----
  step "၂/၅  Code နှင့် storage စုစည်းခြင်း"
  mkdir -p "$work/app"
  # dl/ (download folder) နဲ့ .git ကို မထည့် — မလိုအပ်ဘဲ ကြီးတယ်
  tar -cf - -C "$APP_DIR" \
      --exclude='./dl' --exclude='./.git' --exclude='./storage/cache' \
      --exclude='./storage/tmp' . 2>/dev/null | tar -xf - -C "$work/app"
  ok "Code ကူးပြီး — $(du -sh "$work/app" | cut -f1)"
  info "Backup archive $(ls -1 "$work/app/storage/backups" 2>/dev/null | wc -l) ခု ပါဝင်"

  # ---- ၃။ Metadata ----
  step "၃/၅  Metadata ရေးခြင်း"
  cat > "$work/MANIFEST.txt" <<META
N4 Core VPN — VPS Migration Package
====================================
ထုတ်သည့်အချိန်   : $(date '+%Y-%m-%d %H:%M:%S %Z')
ထုတ်သည့် hostname : $(hostname)
ထုတ်သည့် IP       : $(curl -s --max-time 6 ifconfig.me 2>/dev/null || echo '?')
App directory     : ${APP_DIR}
PHP version       : $(php -r 'echo PHP_VERSION;')
MySQL/MariaDB     : $(mysql --version 2>/dev/null | head -1 || echo '?')
nginx             : $(command -v nginx >/dev/null 2>&1 && nginx -v 2>&1 | tr -d '\n' || echo '?')
Database          : ${dbn}
DB table အရေအတွက်  : $(grep -c '^CREATE TABLE' "$work/database.sql")
Timezone          : $(cfg app.timezone)
Telegram owner    : $(cfg telegram.owner_id)
လက်ရှိ domain      : $(grep -m1 -oP 'server_name\s+\K[^;]+' /etc/nginx/sites-available/n4core.conf 2>/dev/null | awk '{print $1}' || echo '?')

VPS အသစ်မှာ ပြန်သွင်းရန်:
  sudo ./n4core-migrate-vps.sh import <ဒီ file>
ပြီးလျှင်:
  sudo ./n4core-domain.sh <domain အသစ်> --ssl
META
  ok "MANIFEST.txt ရေးပြီး"

  # ---- ၄။ Archive ----
  step "၄/၅  Archive ဖန်တီးခြင်း"
  tar -czf "$out" -C "$work" MANIFEST.txt database.sql app
  ok "Archive: $(du -h "$out" | cut -f1)"

  # ---- ၅။ Encrypt ----
  step "၅/၅  Encrypt လုပ်ခြင်း (AES-256-CBC)"
  # encryption_key က base64 32-byte ဖြစ်တာမို့ ဒါကို password အဖြစ် သုံးတယ်။
  # -pbkdf2 က brute-force ကို ခက်စေတယ်။
  if openssl enc -aes-256-cbc -pbkdf2 -iter 200000 -salt \
       -in "$out" -out "${out}.enc" -pass "pass:${enckey}" 2>/dev/null; then
    shred -u "$out" 2>/dev/null || rm -f "$out"
    chmod 600 "${out}.enc"
    ok "Encrypt ပြီး"
  else
    warn "Encrypt မရ — encrypt မလုပ်ဘဲ ထားလိုက်ပါတယ် (⚠️ secret ပါဝင်တယ်!)"
    chmod 600 "$out"
    mv "$out" "${out}.PLAIN"
  fi

  local final="${out}.enc"
  [ -f "$final" ] || final="${out}.PLAIN"

  echo
  hr
  printf '%s ✅ Export ပြီးပါပြီ%s\n' "$G$W" "$N"
  hr
  info "File   : ${final}"
  info "Size   : $(du -h "$final" | cut -f1)"
  info "SHA256 : $(sha256sum "$final" | cut -d' ' -f1)"
  echo
  printf '%sVPS အသစ်ဆီ ပို့ရန်%s (VPS အသစ်ရဲ့ IP ကို အစားထိုးပါ):\n' "$W" "$N"
  echo
  printf '%s   scp %s root@VPS_အသစ်_IP:/root/%s\n' "$C" "$final" "$N"
  echo
  printf '%sVPS အသစ်မှာ ပြန်သွင်းရန်%s:\n' "$W" "$N"
  echo
  printf '%s   ssh root@VPS_အသစ်_IP%s\n' "$C" "$N"
  printf '%s   # migrate script ကိုပါ ပို့ရမယ်:%s\n' "$C" "$N"
  printf '%s   #   scp %s/deploy/n4core-migrate-vps.sh root@VPS_အသစ်_IP:/root/%s\n' "$C" "$APP_DIR" "$N"
  printf '%s   chmod +x /root/n4core-migrate-vps.sh%s\n' "$C" "$N"
  printf '%s   sudo /root/n4core-migrate-vps.sh import /root/%s%s\n' "$C" "$(basename "$final")" "$N"
  echo
  printf '%s   Decrypt key (encryption_key) ကို မေးမယ် — ဒီမှာ ကြည့်ပါ:%s\n' "$W" "$N"
  printf '%s   grep encryption_key %s/config/config.php%s\n' "$C" "$APP_DIR" "$N"
  echo
  warn "ဒီ file ထဲ secret key နဲ့ DB အားလုံး ပါဝင်တယ် — မဖြန့်ပါနဲ့။"
  warn "ရွှေ့ပြီးရင် VPS ၂ ခု ကနေ ဖျက်ပါ:  shred -u ${final}"
  hr
  echo
}

# ============================================================================
#  IMPORT — VPS အသစ် မှာ run
# ============================================================================
cmd_import() {
  need_root import "$1"
  local pkg="${1:-}"
  [ -n "$pkg" ] || die "Package file ထည့်ပါ:  sudo $0 import /root/n4core-migrate-XXX.tar.gz.enc"
  [ -f "$pkg" ]  || die "File မတွေ့: $pkg"

  hr
  printf '%s N4 Core — VPS အသစ်ကို သွင်းခြင်း (IMPORT)%s\n' "$W" "$N"
  hr
  info "Package : $pkg  ($(du -h "$pkg" | cut -f1))"
  info "Target  : $APP_DIR"
  echo

  if [ -d "$APP_DIR" ] && [ -n "$(ls -A "$APP_DIR" 2>/dev/null)" ]; then
    warn "$APP_DIR ထဲ file ရှိပြီးသား — ${APP_DIR}.old-${STAMP} အဖြစ် ရွှေ့မယ်"
  fi

  printf '%sဆက်လုပ်မလား? [y/N] %s' "$W" "$N"
  read -r reply
  case "$reply" in [yY]|[yY][eE][sS]) ;; *) say "ရပ်လိုက်ပါတယ်။"; exit 0 ;; esac

  local work
  WORKDIR="$(mktemp -d /tmp/n4core-import-XXXXXX)"
  work="$WORKDIR"

  # ---- ၁။ Package ဖြေ ----
  step "၁/၈  Package ဖြေခြင်း"
  local tarball="$work/pkg.tar.gz"

  if [ "${pkg##*.}" = "enc" ]; then
    printf '   %sencryption_key ထည့်ပါ%s (VPS အဟောင်း config.php ထဲက security.encryption_key):\n' "$W" "$N"
    printf '   Key: '
    read -rs ENCKEY
    echo
    [ -n "$ENCKEY" ] || die "Key ဗလာ မဖြစ်ရ"

    if ! openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 \
           -in "$pkg" -out "$tarball" -pass "pass:${ENCKEY}" 2>/dev/null; then
      die "Decrypt မရပါ — key မှားနေတယ် (VPS အဟောင်းမှာ: grep encryption_key config/config.php)"
    fi
    ok "Decrypt ပြီး"
  else
    cp "$pkg" "$tarball"
    ok "Plain package — decrypt မလို"
  fi

  tar -xzf "$tarball" -C "$work" || die "Archive ဖြေလို့မရ"
  [ -f "$work/database.sql" ] || die "database.sql မပါဝင်ပါ — package မှားနေတယ်"
  [ -d "$work/app" ]          || die "app/ မပါဝင်ပါ"
  ok "Package ဖြေပြီး"

  if [ -f "$work/MANIFEST.txt" ]; then
    echo
    printf '%s   ── MANIFEST ──%s\n' "$C" "$N"
    sed 's/^/   /' "$work/MANIFEST.txt"
    echo
  fi

  # ---- ၂။ Package များ တင် ----
  step "၂/၈  လိုအပ်သော package များ တင်ခြင်း"
  export DEBIAN_FRONTEND=noninteractive

  local need=()
  command -v nginx   >/dev/null 2>&1 || need+=(nginx)
  command -v php     >/dev/null 2>&1 || need+=(php-fpm php-cli php-mysql php-mbstring php-curl php-zip php-xml)
  command -v mysql   >/dev/null 2>&1 || need+=(mariadb-server mariadb-client)
  command -v openssl >/dev/null 2>&1 || need+=(openssl)
  command -v curl    >/dev/null 2>&1 || need+=(curl)

  if [ "${#need[@]}" -gt 0 ]; then
    info "တင်မယ်: ${need[*]}"
    apt-get update -qq
    apt-get install -y -qq "${need[@]}" || die "Package တင်လို့မရ"
    ok "Package များ တင်ပြီး"
  else
    ok "လိုအပ်သမျှ ရှိပြီးသား"
  fi

  # PHP extension စစ်
  local missing=""
  for ext in pdo_mysql mbstring curl json openssl; do
    php -m 2>/dev/null | grep -qix "$ext" || missing="$missing $ext"
  done
  if [ -n "$missing" ]; then
    warn "PHP extension လိုအပ်:$missing"
    local pv; pv="$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')"
    for ext in $missing; do
      apt-get install -y -qq "php${pv}-${ext#pdo_}" 2>/dev/null || true
    done
  fi
  ok "PHP $(php -r 'echo PHP_VERSION;') — extension အားလုံး ရှိ"

  # ---- ၃။ Code ထည့် ----
  step "၃/၈  Code ထည့်ခြင်း"
  if [ -d "$APP_DIR" ] && [ -n "$(ls -A "$APP_DIR" 2>/dev/null)" ]; then
    mv "$APP_DIR" "${APP_DIR}.old-${STAMP}"
    info "အဟောင်း → ${APP_DIR}.old-${STAMP}"
  fi
  mkdir -p "$(dirname "$APP_DIR")"
  mv "$work/app" "$APP_DIR"
  ok "Code ထည့်ပြီး — $(du -sh "$APP_DIR" | cut -f1)"
  # app/ ရွှေ့ပြီးသွားပြီ — cleanup က ဒါကို မဖျက်မိစေရန် အတည်ပြု
  [ -d "$APP_DIR/core" ] || die "Code ရွှေ့ရင် ပြဿနာ တင်ပါတယ်"

  # ---- ၄။ Database ----
  step "၄/၈  Database သွင်းခြင်း"
  local dbh dbp dbn dbu dbpass
  dbh="$(cfg db.host)"; dbp="$(cfg db.port)"; dbn="$(cfg db.name)"
  dbu="$(cfg db.user)"; dbpass="$(cfg db.pass)"
  [ -n "$dbn" ] || die "config.php ကနေ DB name ဖတ်လို့မရ"

  info "DB: ${dbu}@${dbh}:${dbp:-3306}/${dbn}"

  # MariaDB တက်နေမတက်နေ
  systemctl is-active mariadb >/dev/null 2>&1 || systemctl start mariadb 2>/dev/null || \
    systemctl start mysql 2>/dev/null || true
  sleep 2

  # DB နဲ့ user ဖန်တီး (root socket auth နဲ့)
  if mysql -e 'SELECT 1' >/dev/null 2>&1; then
    mysql <<SQLEOF
CREATE DATABASE IF NOT EXISTS \`${dbn}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '${dbu}'@'localhost' IDENTIFIED BY '${dbpass}';
CREATE USER IF NOT EXISTS '${dbu}'@'127.0.0.1' IDENTIFIED BY '${dbpass}';
ALTER USER '${dbu}'@'localhost' IDENTIFIED BY '${dbpass}';
ALTER USER '${dbu}'@'127.0.0.1' IDENTIFIED BY '${dbpass}';
GRANT ALL PRIVILEGES ON \`${dbn}\`.* TO '${dbu}'@'localhost';
GRANT ALL PRIVILEGES ON \`${dbn}\`.* TO '${dbu}'@'127.0.0.1';
FLUSH PRIVILEGES;
SQLEOF
    ok "DB နှင့် user ဖန်တီးပြီး"
  else
    warn "MySQL root ကို socket နဲ့ ဝင်လို့မရ — DB/user ကို လက်နဲ့ ဖန်တီးပါ"
    info "   sudo mysql -u root -p"
    info "   CREATE DATABASE ${dbn} CHARACTER SET utf8mb4;"
    info "   CREATE USER '${dbu}'@'localhost' IDENTIFIED BY '<pass>';"
    info "   GRANT ALL ON ${dbn}.* TO '${dbu}'@'localhost';"
  fi

  # Dump သွင်း
  if mysql -h "$dbh" -P "${dbp:-3306}" -u "$dbu" -p"$dbpass" "$dbn" < "$work/database.sql" 2>"$work/imp.err"; then
    local tbl
    tbl="$(mysql -N -h "$dbh" -u "$dbu" -p"$dbpass" -e \
          "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='$dbn'" 2>/dev/null)"
    ok "DB သွင်းပြီး — table ${tbl} ခု"
  else
    err "DB သွင်းလို့မရ:"
    sed 's/^/     /' "$work/imp.err" | head -10 >&2
    die "လက်နဲ့ စမ်းပါ: mysql -u $dbu -p $dbn < $work/database.sql"
  fi

  # ---- ၅။ Permission ----
  step "၅/၈  File permission သတ်မှတ်ခြင်း"
  id www-data >/dev/null 2>&1 || useradd -r -s /usr/sbin/nologin www-data
  chown -R www-data:www-data "$APP_DIR"
  find "$APP_DIR" -type d -exec chmod 750 {} \;
  find "$APP_DIR" -type f -exec chmod 640 {} \;
  chmod 770 "$APP_DIR/storage" 2>/dev/null || true
  find "$APP_DIR/storage" -type d -exec chmod 770 {} \; 2>/dev/null || true
  chmod 750 "$APP_DIR/bin"/*.php 2>/dev/null || true
  chmod 400 "$APP_DIR/config/config.php"
  chown www-data:www-data "$APP_DIR/config/config.php"
  ok "Permission သတ်မှတ်ပြီး (config.php = 400, storage = 770)"

  # ---- ၆။ systemd unit ----
  step "၆/၈  Backup timer နှင့် Bot service တင်ခြင်း"
  if [ -d "$APP_DIR/deploy/systemd" ]; then
    for u in "$APP_DIR"/deploy/systemd/*.service "$APP_DIR"/deploy/systemd/*.timer; do
      [ -f "$u" ] || continue
      # APP_DIR ကို အမှန်နဲ့ အစားထိုးပြီး ကူး
      sed "s#/var/www/n4core#${APP_DIR}#g" "$u" > "/etc/systemd/system/$(basename "$u")"
      info "→ /etc/systemd/system/$(basename "$u")"
    done
    systemctl daemon-reload
    systemctl enable --now n4core-backup.timer 2>/dev/null && ok "Backup timer တက်ပြီး" \
      || warn "Backup timer မတက် — systemctl status n4core-backup.timer နဲ့ စစ်ပါ"
  else
    warn "deploy/systemd မတွေ့ — timer ကို လက်နဲ့ တင်ပါ"
  fi

  # ---- ၇။ nginx ----
  step "၇/၈  nginx ခေတ္တ vhost တင်ခြင်း"
  local fpmsock=""
  for s in /run/php/php*-fpm.sock; do [ -S "$s" ] && { fpmsock="$s"; break; }; done
  if [ -z "$fpmsock" ]; then
    local pv; pv="$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')"
    systemctl start "php${pv}-fpm" 2>/dev/null || true
    sleep 2
    for s in /run/php/php*-fpm.sock; do [ -S "$s" ] && { fpmsock="$s"; break; }; done
  fi

  if [ -n "$fpmsock" ]; then
    cat > /etc/nginx/sites-available/n4core.conf <<NGEOF
# N4 Core — ခေတ္တ vhost (IP နဲ့ စမ်းရန်)
# Domain အသစ် သတ်မှတ်ရန်:  sudo ${APP_DIR}/deploy/n4core-domain.sh <domain> --ssl
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;

    location /.well-known/acme-challenge/ { root /var/www/html; }

    root ${APP_DIR};
    index index.php index.html;
    client_max_body_size 8m;
    server_tokens off;

    add_header X-Content-Type-Options nosniff always;
    add_header X-Frame-Options SAMEORIGIN always;

    location ~ ^/(config|core|sql|storage|bin|deploy|docs|dl)/ { deny all; return 404; }
    location ~ \.(sql|log|enc|gz|md|sh|ini|bak|tar)\$          { deny all; return 404; }

    location /admin/ { try_files \$uri \$uri/ /admin/index.html; }
    location /api/   { try_files \$uri =404; }

    location ~ \.php\$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:${fpmsock};
        fastcgi_read_timeout 180;
    }
    location = / { return 302 /admin/; }
}
NGEOF
    rm -f /etc/nginx/sites-enabled/default
    ln -sfn /etc/nginx/sites-available/n4core.conf /etc/nginx/sites-enabled/n4core.conf
    if nginx -t 2>&1 | sed 's/^/     /'; then
      systemctl reload nginx 2>/dev/null || systemctl restart nginx
      ok "nginx တက်ပြီး (php-fpm: $fpmsock)"
    else
      err "nginx config မှားနေတယ်"
    fi
  else
    warn "php-fpm socket မတွေ့ — nginx ကို လက်နဲ့ ချိန်ပါ"
  fi

  # ---- ၈။ စစ်ဆေး ----
  step "၈/၈  စစ်ဆေးခြင်း"
  local ip
  ip="$(curl -s --max-time 6 ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')"

  local pass=0 fail=0
  c() {
    local got
    got="$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "http://127.0.0.1$2" 2>/dev/null || echo 000)"
    if printf '%s' "$3" | grep -qw "$got"; then
      printf '   %s✅%s %-30s %s\n' "$G" "$N" "$1" "$got"; pass=$((pass+1))
    else
      printf '   %s❌%s %-30s %s (%s ဖြစ်ရမယ်)\n' "$R" "$N" "$1" "$got" "$3"; fail=$((fail+1))
    fi
  }
  c "Admin dashboard"      "/admin/"                 "200"
  c "Public API"           "/api/public/plans.php"   "200"
  c "config.php ပိတ်မှု"    "/config/config.php"      "403 404"
  c "core/ ပိတ်မှု"         "/core/Auth.php"          "403 404"

  local body
  body="$(curl -s --max-time 10 http://127.0.0.1/api/public/plans.php 2>/dev/null || true)"
  if printf '%s' "$body" | grep -q '"ok":true'; then
    printf '   %s✅%s %-30s {"ok":true...}\n' "$G" "$N" "API JSON"; pass=$((pass+1))
  else
    printf '   %s❌%s %-30s %s\n' "$R" "$N" "API JSON" "$(printf '%s' "$body" | head -c 60)"; fail=$((fail+1))
  fi

  # DB ထဲ data
  echo
  info "Database ထဲ:"
  mysql -N -h "$dbh" -u "$dbu" -p"$dbpass" "$dbn" -e "
    SELECT CONCAT('     Servers      : ', COUNT(*)) FROM servers
    UNION ALL SELECT CONCAT('     VIP accounts : ', COUNT(*)) FROM vip_accounts
    UNION ALL SELECT CONCAT('     Admins       : ', COUNT(*)) FROM admin_users
    UNION ALL SELECT CONCAT('     Regions      : ', COUNT(*)) FROM locations
    UNION ALL SELECT CONCAT('     Price plans  : ', COUNT(*)) FROM plans;" 2>/dev/null \
    || info "     (ဖတ်လို့မရ)"

  echo
  hr
  if [ "$fail" = 0 ]; then
    printf '%s ✅ Import ပြီးပါပြီ — စစ်ဆေးချက် %s ခု အောင်မြင်%s\n' "$G$W" "$pass" "$N"
  else
    printf '%s ⚠️  Import ပြီး — အောင်: %s  မအောင်: %s%s\n' "$Y$W" "$pass" "$fail" "$N"
  fi
  hr
  echo
  printf '%sနောက်ဆက်တွဲ လုပ်ရမည်များ%s\n' "$W" "$N"
  echo
  say "  ၁။ DNS ကို ဒီ VPS ဆီ ညွှန်ပါ"
  say "     A record →  ${ip}"
  echo
  say "  ၂။ DNS ရောက်ပြီးလျှင် domain + SSL သတ်မှတ်ပါ"
  printf '%s     sudo %s/deploy/n4core-domain.sh <domain> --ssl%s\n' "$C" "$APP_DIR" "$N"
  echo
  say "  ၃။ ဒီ script က GitHub config အသစ်ကို ပြပေးမယ် — အဲဒါ ပြောင်းပါ"
  echo
  say "  ၄။ ခေတ္တ IP နဲ့ စမ်းကြည့်လို့ရတယ်"
  printf '%s     http://%s/admin/%s\n' "$C" "$ip" "$N"
  echo
  warn "DNS ပြောင်းပြီး SSL ရမချင်း Telegram webhook အလုပ်မလုပ်ပါ"
  info "ခေတ္တ long-polling နဲ့ bot ကို သွားနိုင်တယ်:  systemctl start n4core-bot"
  echo
  info "အဟောင်း code: ${APP_DIR}.old-${STAMP}  (တစ်ပတ်လောက် ကြာပြီးမှ ဖျက်ပါ)"
  hr
  echo
}

# ============================================================================
#  Dispatch
# ============================================================================
case "${1:-}" in
  check)          shift; cmd_check "$@" ;;
  export)         shift; cmd_export "$@" ;;
  import)         shift; cmd_import "$@" ;;
  -h|--help|help|'') sed -n '3,30p' "$0" | sed 's/^# \{0,1\}//' ;;
  *)              die "မသိသော command: $1   (check | export | import)" ;;
esac
