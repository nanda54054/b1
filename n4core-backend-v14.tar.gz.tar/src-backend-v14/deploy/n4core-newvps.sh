#!/usr/bin/env bash
# =====================================================================
#  N4 Core VPN — VPS အသစ်သို့ ပြောင်းရွှေ့ခြင်း (တစ်ချက်နှိပ်)
# =====================================================================
#
#  လိုတာ ၂ ခုပဲ —  domain  နဲ့  backup ဖိုင်
#
#    bash deploy/n4core-newvps.sh yourdomain.com /root/n4core-full-XXXX.tar.gz.enc
#
#  Script က အောက်ပါအတိုင်း အလိုအလျောက် လုပ်သွားပါမယ် —
#
#    ၁။ Panel အသစ် တင်တယ်
#    ၂။ Panel တက်မတက် စစ်တယ်
#    ၃။ Backup ကို ဖွင့်ပြီး ရှိသမျှ အကုန် ပြန်ထည့်တယ်
#       (database + files + key ၃ ခုလုံး — key တွေက backup ထဲမှာ ပါပြီးသား)
#    ၄။ ဒေတာ တကယ်ဝင်မဝင် ရေတွက်ပြတယ်
#
#  Key က ၁ ခုပဲ လိုတယ် —  encryption_key
#  (backup ဖိုင်ကို ဖွင့်ဖို့။ ကျန် pepper နဲ့ app_secret က ဖိုင်ထဲမှာ ပါပြီးသား)
#
# =====================================================================
set -euo pipefail

R=$'\e[31m'; G=$'\e[32m'; Y=$'\e[33m'; B=$'\e[36m'; BD=$'\e[1m'; N=$'\e[0m'

step() { echo; echo "${B}${BD}▸ $*${N}"; }
good() { echo "  ${G}✓${N} $*"; }
warn() { echo "  ${Y}!${N} $*"; }
die()  { echo; echo "${R}${BD}✗ $*${N}" >&2; exit 1; }

DOMAIN="${1:-}"
BKFILE="${2:-}"
OLD_KEY="${3:-}"

if [ -z "$DOMAIN" ] || [ -z "$BKFILE" ]; then
  cat <<USAGE

  ${BD}N4 Core VPN — VPS ပြောင်းရွှေ့ခြင်း${N}
  ═══════════════════════════════════════════════════

    bash deploy/n4core-newvps.sh <domain> <backup-file> [encryption_key]

  ဥပမာ
    bash deploy/n4core-newvps.sh core.nandaxr.tech \\
         /root/n4core-full-20260901-174904.tar.gz.enc

  encryption_key မထည့်ရင် အလယ်မှာ တောင်းပါလိမ့်မယ်။
  ${BD}n4core-full-*${N} ဖိုင်ကို သုံးပါ — dashboard တစ်ခုလုံး ပါပါတယ်။

USAGE
  exit 1
fi

[ "$(id -u)" = "0" ] || die "root အနေနဲ့ run ပါ  (sudo bash ...)"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$(dirname "$SCRIPT_DIR")"
APP_DIR="/var/www/n4core"

# ---- မလုပ်ခင် အရင်စစ် ------------------------------------------------
step "မလုပ်ခင် စစ်ဆေးနေတယ်"

[ -f "$BKFILE" ] || die "Backup ဖိုင် မတွေ့ပါ: $BKFILE"
[ -s "$BKFILE" ] || die "Backup ဖိုင် ဗလာဖြစ်နေတယ်: $BKFILE"
good "Backup ဖိုင် တွေ့ပြီ ($(du -h "$BKFILE" | cut -f1))"

[ -f "$SCRIPT_DIR/n4core-install.sh" ] || die "n4core-install.sh မတွေ့ပါ"
[ -f "$SRC_DIR/bin/restore.php" ]      || die "bin/restore.php မတွေ့ပါ"
good "လိုအပ်တဲ့ script တွေ ပြည့်စုံပါတယ်"

# N4CBK001 = encrypt လုပ်ထားတဲ့ archive ရဲ့ အမှတ်အသား။
# encrypt လုပ်ထားမှ key တောင်းတယ် — မလုပ်ထားရင် ဘာမှ မမေးဘူး။
MAGIC="$(head -c 8 "$BKFILE" 2>/dev/null || true)"
if [ "$MAGIC" = "N4CBK001" ]; then
  good "Encrypted backup"
  if [ -z "$OLD_KEY" ]; then
    echo
    echo "  ${BD}encryption_key တစ်ခုတည်း လိုပါတယ်${N} — backup ဖိုင်ကို ဖွင့်ဖို့ပါ။"
    echo "  VPS အဟောင်းမှာ:  ${BD}grep encryption_key $APP_DIR/config/config.php${N}"
    echo
    read -rp "  encryption_key : " OLD_KEY
  fi
  [ -n "$OLD_KEY" ] || die "encryption_key မပါဘဲ backup ကို ဖွင့်လို့ မရပါ"
  KEYARG="--key=$OLD_KEY"
else
  warn "Encrypt မလုပ်ထားတဲ့ backup — key မလိုပါ"
  KEYARG=""
fi

# ---- ၁။ Panel တင် ---------------------------------------------------
step "၁/၅ — Panel ကို တင်နေတယ် (ကြာနိုင်ပါတယ်)"

if ! bash "$SCRIPT_DIR/n4core-install.sh" "$DOMAIN"; then
  die "Panel တင်တာ မအောင်မြင်ပါ — အထက်က error ကို ကြည့်ပါ"
fi
good "Panel တင်ပြီးပါပြီ"

# ---- ၂။ Panel တက်မတက် စစ် -------------------------------------------
step "၂/၅ — Panel တက်လာမလား စစ်နေတယ်"

[ -d "$APP_DIR" ] || die "$APP_DIR မတွေ့ပါ — install မအောင်မြင်ဘူးထင်တယ်"

HEALTH=""
for i in 1 2 3 4 5; do
  HEALTH="$(curl -s -o /dev/null -w '%{http_code}' \
    "https://$DOMAIN/api/public/locations.php" 2>/dev/null || true)"
  [ "$HEALTH" = "000" ] && HEALTH="$(curl -s -o /dev/null -w '%{http_code}' \
    "http://$DOMAIN/api/public/locations.php" 2>/dev/null || true)"
  case "$HEALTH" in
    200|401|403) break ;;
  esac
  echo "  ... ခဏစောင့်နေတယ် ($i/5)"
  sleep 4
done

case "$HEALTH" in
  200|401|403) good "Panel တုံ့ပြန်နေပြီ (HTTP $HEALTH)" ;;
  *) warn "API က HTTP $HEALTH ပြန်တယ် — DNS မရောက်သေးလို့ ဖြစ်နိုင်တယ်"
     warn "Restore ကတော့ ဆက်လုပ်လို့ ရပါတယ် (database က local ဖြစ်လို့)" ;;
esac

# ---- ၃။ ရှိသမျှ အကုန် ပြန်ထည့် --------------------------------------
step "၃/၅ — Backup ထဲက ရှိသမျှ အကုန် ပြန်ထည့်နေတယ်"

# အရင်ဆုံး ဖွင့်ကြည့်ရုံ စစ်တယ်။ key မှားရင် ဒီမှာတင် ရပ်တယ် —
# ဒေတာဘေ့စ်ကို လက်တောင် မတို့ရသေးဘူး။
echo "  ဖိုင်ကို အရင်စစ်နေတယ် (dry run)..."
if ! php "$APP_DIR/bin/restore.php" "$BKFILE" $KEYARG --dry-run; then
  die "Backup ဖိုင် ဖွင့်လို့ မရပါ — encryption_key မှားနေလား ပြန်စစ်ပါ"
fi
good "Backup ဖိုင် မှန်ကန်ပါတယ်"

echo
echo "  အခု တကယ် ထည့်တော့မယ်..."
if ! php "$APP_DIR/bin/restore.php" "$BKFILE" $KEYARG --yes; then
  die "Restore မအောင်မြင်ပါ"
fi

# restore.php က config.php ထဲ key + bot token ထည့်လိုက်ပြီမို့
# permission ပြန်ချိန်ပြီး PHP ကို ပြန် reload လုပ်ပေးတယ်။
chown -R www-data:www-data "$APP_DIR" 2>/dev/null || true
chmod 640 "$APP_DIR/config/config.php" 2>/dev/null || true
systemctl reload "php$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')-fpm" 2>/dev/null \
  || systemctl reload php-fpm 2>/dev/null || true

# ---- Telegram bot ----------------------------------------------------
# Token က backup ထဲကနေ ဝင်လာပြီးမှ ဒီအဆင့်ကို လုပ်ရတယ် — အစောက
# လုပ်ရင် token မရှိသေးလို့ ဘာမှ မဖြစ်ဘူး။
step "၄/၅ — Telegram bot ကို ပြန်ချိတ်နေတယ်"

# bootstrap.php နဲ့ setup_webhook.php က relative path မို့ တင်ထားတဲ့
# panel ထဲကနေ run ရမယ် — bundle folder ထဲက config က live မဟုတ်ဘူး။
cd "$APP_DIR" || die "$APP_DIR ထဲ ဝင်လို့ မရပါ"

BOT_OK=0
if php -r '
require_once "core/bootstrap.php";
exit(Telegram::enabled() ? 0 : 1);
' >/dev/null 2>&1; then
  good "Bot token တွေ့ပြီ"

  # Telegram က bot token တစ်ခုကို webhook တစ်ခုပဲ မှတ်ထားတာမို့ VPS
  # အဟောင်းရဲ့ webhook က ကျန်နေတယ်။ ဒါကို အသစ်နဲ့ ဖျက်လိုက်တာက
  # အဟောင်းကို အလိုအလျောက် ပြုတ်စေတယ်။
  if php bin/setup_webhook.php "https://$DOMAIN" >/tmp/n4bot.out 2>&1; then
    good "Webhook အသစ် တင်ပြီး (VPS အဟောင်းရဲ့ webhook ပြုတ်သွားပြီ)"
    BOT_OK=1
  else
    warn "Webhook တင်လို့ မရပါ — polling mode နဲ့ စမ်းမယ်"

    # Webhook မရရင် long-polling service နဲ့ အလုပ်လုပ်စေတယ်။
    # webhook နဲ့ polling က တစ်ချိန်တည်း မရတာမို့ အရင် ဖျက်ရတယ်။
    php bin/setup_webhook.php --delete >/dev/null 2>&1 || true

    SVC="$APP_DIR/deploy/systemd/n4core-bot.service"
    [ -f "$SVC" ] || SVC="$SRC_DIR/deploy/systemd/n4core-bot.service"
    if [ -f "$SVC" ]; then
      cp "$SVC" /etc/systemd/system/ 2>/dev/null
      systemctl daemon-reload 2>/dev/null
      if systemctl enable --now n4core-bot >/dev/null 2>&1; then
        sleep 3
        if systemctl is-active --quiet n4core-bot; then
          good "Bot service စပြီး (polling mode)"
          BOT_OK=1
        else
          warn "Bot service စလို့ မရပါ — journalctl -u n4core-bot နဲ့ ကြည့်ပါ"
        fi
      fi
    fi
  fi
else
  warn "Bot token မတွေ့ပါ — backup ထဲမှာ မပါဘူးထင်တယ်"
  warn "Panel → Settings → Telegram မှာ ကိုယ်တိုင် ထည့်ပါ"
fi

# ---- ၄။ အတည်ပြု ------------------------------------------------------
step "၅/၅ — ဒေတာ ဝင်မဝင် စစ်နေတယ်"

cd "$APP_DIR"
COUNTS="$(php -r '
require_once "core/bootstrap.php";
try {
  printf("%d %d %d",
    (int) Db::value("SELECT COUNT(*) FROM vip_accounts"),
    (int) Db::value("SELECT COUNT(*) FROM servers"),
    (int) Db::value("SELECT COUNT(*) FROM admin_users"));
} catch (Throwable $e) { echo "-1 -1 -1"; }
' 2>/dev/null || echo "-1 -1 -1")"

read -r VIPS SERVERS ADMINS <<<"$COUNTS"

if [ "$VIPS" = "-1" ]; then
  warn "ရေတွက်လို့ မရပါ — panel ထဲဝင်ပြီး ကိုယ်တိုင် စစ်ကြည့်ပါ"
else
  good "VIP accounts : $VIPS"
  good "Servers      : $SERVERS"
  good "Admins       : $ADMINS"
  if [ "$VIPS" = "0" ] && [ "$SERVERS" = "0" ]; then
    warn "နှစ်ခုလုံး ၀ ဖြစ်နေတယ် — backup ဖိုင် မှားနေလား ပြန်စစ်ပါ"
  fi
fi

# ---- ပြီးပြီ ---------------------------------------------------------
if [ "$BOT_OK" = "1" ]; then
  BOT_LINE="${G}✓ ချိတ်ပြီး${N} — bot မှာ ${BD}/start${N} ရိုက်ပြီး စမ်းပါ"
else
  BOT_LINE="${Y}! မချိတ်ရသေးပါ${N} — အောက်က 'Bot မရရင်' ကို ကြည့်ပါ"
fi

cat <<DONE

${G}${BD}═══════════════════════════════════════════════════${N}
${G}${BD}  ✓ ပြောင်းရွှေ့ခြင်း အောင်မြင်ပါပြီ${N}
${G}${BD}═══════════════════════════════════════════════════${N}

  Panel     : ${BD}https://$DOMAIN/admin/${N}
  VIP       : $VIPS · Servers: $SERVERS · Admins: $ADMINS
  Telegram  : $BOT_LINE

  ${BD}Login${N}
    Password ${BD}အဟောင်း${N} အတိုင်းပဲ ဝင်ပါ။ backup ထဲက key တွေ
    ပါလာပြီးသားမို့ ပြောင်းစရာ မလိုပါ။

  ${BD}နောက်ထပ် လုပ်ရမယ့်အဆင့်${N}
    ၁။ Panel ထဲဝင်ပြီး Servers နဲ့ VIP Accounts ပြည့်စုံလား ကြည့်ပါ
    ၂။ VIP access code တစ်ခု ဖွင့်ကြည့်ပါ။ ဖတ်လို့ရရင် အားလုံး မှန်ပါပြီ
    ၃။ App ကနေ တကယ် login ဝင်ကြည့်ပါ
    ၄။ ${Y}အားလုံး အဆင်ပြေမှ${N} VPS အဟောင်းကို ဖျက်ပါ

  ${BD}Bot မရရင်${N}
    cd $APP_DIR
    php bin/setup_webhook.php --info              # အခုအခြေအနေ
    php bin/setup_webhook.php https://$DOMAIN     # ပြန်တင်
    systemctl status n4core-bot                   # polling mode စစ်

  ${BD}Backup အလိုအလျောက်${N}
    ည ၁၂ နာရီတိုင်း ဖိုင် ၂ မျိုး ထွက်ပါမယ် —
      • n4core-full-*.enc  (dashboard တစ်ခုလုံး)
      • n4core-db-*.enc    (database သီးသန့်)
    သိမ်းရာနေရာ: $APP_DIR/storage/backups/

DONE
