#!/usr/bin/env bash
# =============================================================================
#  N4 Core VPN — v2.3 apply (one bash)
# -----------------------------------------------------------------------------
#  ဒီ script တစ်ခုတည်းနဲ့ v2.3 အပြောင်းအလဲ အကုန် VPS ပေါ်တင်ပါတယ်:
#
#    1. Mobile dashboard density (card size သေးသွားတာ)
#    2. VIP create ပြီးရင် ပြေစာ (receipt) — save image + copy text
#    3. Collected price field (schema + API + form)
#    4. Expired account auto-delete (cron, grace 1 day, default OFF)
#    5. Admin "Delete Exp" button (API action + UI)
#    6. Session timeout 720min / 168hr (live config)
#
#  လုပ်ဆောင်ပုံ:
#    - ဖိုင်တွေကို SRC ကနေ APP_DIR ကို ကူးတယ် (ကူးမတင်ခင် backup ယူတယ်)
#    - php -l နဲ့ syntax စစ်တယ် — မှားရင် backup ကို auto rollback
#    - DB migration (--receipt-price) ကို run တယ်
#    - php-fpm reload တယ်
#
#  v2.3.1 — core/DeviceAuth.php + core/RateLimiter.php ကို FILES ထဲ ထည့်လိုက်တယ်။
#  အရင် စာရင်းထဲ မပါခဲ့လို့ cert-pinning / debuggable-refusing logic တွေ
#  VPS ပေါ် တခါမှ မရောက်ခဲ့ဘူး — anti-tamper layer တခုလုံး အလုပ်မလုပ်ဘဲ ရှိနေတယ်။
#
#  မထိတဲ့အရာများ (တမင်တကာ):
#    - config/config.php ထဲ secrets/keys/DB/telegram — session ၂ လိုင်းပဲ ထိတယ်
#    - .htaccess , core/Auth.php , API auth layer
#    - မရှိသေးတဲ့ data — migration က ဘာမှ မဖျက်ဘူး၊ auto-purge က OFF
#
#  Usage:
#      sudo bash n4core-apply-v23.sh                 # auto-detect
#      sudo bash n4core-apply-v23.sh --src /path/to/n4core-backend-v2
#      sudo bash n4core-apply-v23.sh --app-dir /var/www/n4core
#      sudo bash n4core-apply-v23.sh --no-migrate    # DB မထိဘူး
#      sudo bash n4core-apply-v23.sh --dry-run       # စစ်ကြည့်ရုံ
# =============================================================================
set -uo pipefail

RED=$'\033[31m'; GRN=$'\033[32m'; YLW=$'\033[33m'; CYN=$'\033[36m'; DIM=$'\033[2m'; RST=$'\033[0m'
ok()   { echo "  ${GRN}✅${RST} $*"; }
info() { echo "  ${CYN}•${RST}  $*"; }
warn() { echo "  ${YLW}⚠${RST}  $*"; }
err()  { echo "  ${RED}❌${RST} $*" >&2; }
head1(){ echo; echo "${CYN}▸ $*${RST}"; }

APP_DIR="${N4_APP_DIR:-}"
SRC_DIR=""
DO_MIGRATE=1
DRY=0

while [ $# -gt 0 ]; do
  case "$1" in
    --src)        shift; SRC_DIR="${1:-}" ;;
    --app-dir)    shift; APP_DIR="${1:-}" ;;
    --no-migrate) DO_MIGRATE=0 ;;
    --dry-run)    DRY=1 ;;
    -h|--help)    sed -n '2,30p' "$0"; exit 0 ;;
    *) err "မသိတဲ့ option: $1"; exit 1 ;;
  esac
  shift
done

echo
echo "${CYN}══════════════════════════════════════════════════${RST}"
echo "${CYN}  N4 Core VPN — v2.3 apply${RST}"
echo "${CYN}══════════════════════════════════════════════════${RST}"

# ---------------------------------------------------------------- SRC ရှာ
head1 "SRC ရှာနေတယ်"
if [ -z "$SRC_DIR" ]; then
  # ဒီ script က deploy/ ထဲမှာ ရှိတယ် — parent က SRC
  SRC_DIR="$(cd "$(dirname "$0")/.." 2>/dev/null && pwd)"
fi
SRC_DIR="${SRC_DIR%/}"
if [ ! -f "$SRC_DIR/core/bootstrap.php" ]; then
  err "SRC မှားနေတယ်: $SRC_DIR"
  info "--src /path/to/n4core-backend-v2 နဲ့ ပေးပါ"
  exit 1
fi
ok "SRC: $SRC_DIR"

# ------------------------------------------------------------ APP_DIR ရှာ
head1 "APP_DIR ရှာနေတယ်"
if [ -z "$APP_DIR" ]; then
  for c in /var/www/n4core /var/www/n4core_backend_v2 /var/www/html/n4core \
           /var/www/html /srv/n4core /opt/n4core; do
    if [ -f "$c/core/bootstrap.php" ] && [ -f "$c/config/config.php" ]; then
      APP_DIR="$c"; break
    fi
  done
fi
if [ -z "$APP_DIR" ]; then
  while IFS= read -r f; do
    d="$(dirname "$(dirname "$f")")"
    if [ -f "$d/config/config.php" ]; then APP_DIR="$d"; break; fi
  done < <(find /var/www /srv /opt -maxdepth 4 -type f -path '*/core/bootstrap.php' 2>/dev/null)
fi
if [ -z "$APP_DIR" ] || [ ! -f "$APP_DIR/config/config.php" ]; then
  err "APP_DIR ရှာမတွေ့ဘူး — --app-dir /var/www/n4core နဲ့ ပေးပါ"
  exit 1
fi
APP_DIR="${APP_DIR%/}"
ok "APP_DIR: $APP_DIR"

if [ "$SRC_DIR" = "$APP_DIR" ]; then
  err "SRC နဲ့ APP_DIR တူနေတယ် — SRC ကို သီးသန့် unzip ပြီး run ပါ"
  exit 1
fi

# --------------------------------------------------------- တင်မယ့် ဖိုင်စာရင်း
# v2.3 မှာ ပြောင်းတဲ့ဖိုင်ချည်းပဲ။ config/config.php နဲ့ .htaccess ကို
# လုံးဝ မထိဘူး (site-specific ဖိုင်တွေ ဖြစ်လို့)။
#
# v2.3.1 — core/DeviceAuth.php ကို ထည့်လိုက်တယ်။ အရင် စာရင်းထဲ မပါခဲ့လို့
# cert-pinning / debuggable-refusing logic တွေ VPS ပေါ် တခါမှ မရောက်ခဲ့ဘူး၊
# ဒါကြောင့် anti-tamper layer တခုလုံး အလုပ်မလုပ်ဘဲ ဖြစ်နေတယ်။
FILES=(
  # ---- DeviceAuth.php နဲ့ သူခေါ်တဲ့ core class အားလုံး ----------------
  #
  # DeviceAuth.php အသစ်က Notifier::securityAlert() ကို ခေါ်တယ်။ အဲ့ method
  # က Notifier.php အသစ်ထဲမှာပဲ ရှိတယ်။ အရင်က DeviceAuth.php ပဲ တင်ပြီး
  # Notifier.php မတင်ခဲ့လို့ VPS ပေါ်မှာ —
  #
  #     PHP Fatal error: Call to undefined method Notifier::securityAlert()
  #
  # ဖြစ်ပြီး register_device.php က HTTP 500 ပြန်တယ်။ App မှာ
  # "could not verify itself with the server" ပြတယ်။ Device auth ပိတ်ရင်
  # ဒီလမ်းကြောင်း မဖြတ်တော့လို့ ပြန်ကောင်းသွားတယ် — ဒါက အဲ့ဒီ လက္ခဏာပဲ။
  #
  # ဒါကြောင့် DeviceAuth.php ခေါ်တဲ့ class အားလုံးကို တစုတည်း တင်တယ်။
  # ဗားရှင်း ကွဲနေတာ (version skew) က ဒီပြဿနာရဲ့ အရင်းအမြစ်။
  "core/DeviceAuth.php"
  "core/RateLimiter.php"
  "core/Notifier.php"
  "core/Audit.php"
  "core/Logger.php"
  "core/Request.php"
  "core/Response.php"
  "core/Db.php"
  "core/Config.php"
  "core/Auth.php"
  "core/bootstrap.php"
  "api/public/register_device.php"
  "admin/index.html"
  "admin/assets/css/app.css"
  "admin/assets/css/mobile.css"
  "admin/assets/js/core.js"
  "admin/assets/js/app.js"
  "admin/assets/js/mobile.js"
  "admin/assets/js/receipt.js"
  "api/admin/accounts.php"
  "api/admin/account_devices.php"
  "core/Crypto.php"
  "bin/cron.php"
  "bin/migrate.php"
  "sql/schema_v2.sql"
  "sql/migrate_v22_to_v23.sql"
  # app_devices + app_nonces table ဒီ SQL ထဲမှာပဲ ရှိတယ် (schema_v2.sql ထဲ
  # မပါဘူး)။ ဒီဖိုင် မတင်ရင် `migrate.php --device-auth` က
  # "missing sql/migrate_v21_to_v22.sql" ဆိုပြီး ရပ်တယ်၊ table မဖန်တီးဘူး။
  # အဲ့ဒါဆို signature မှန်တဲ့ device တွေ register လုပ်တဲ့အခါ INSERT က
  # "Table 'app_devices' doesn't exist" နဲ့ crash ဖြစ်ပြီး HTTP 500 ပြန်တယ်။
  # App မှာ "could not verify itself with the server" ပြတယ်။
  "sql/migrate_v21_to_v22.sql"
  # migrate_v21_to_v22.sql က CREATE TABLE IF NOT EXISTS သုံးတယ်။ ဒါကြောင့်
  # ဟောင်းနေတဲ့ app_devices table ရှိပြီးသားဆိုရင် လုံးဝ မထိဘူး — column
  # တွေ လွတ်နေတာကို မဖြည့်ဘူး၊ ဒါပေမဲ့ "✅ app_devices ready" တော့ ပြတယ်။
  # VPS log ထဲမှာ တွေ့ရတာ —
  #     Unknown column 'cert_sha256' in 'INSERT INTO'  (register → 500)
  #     Unknown column 'banned' in 'SELECT'            (signed request → 500)
  # ဒါကြောင့် server list မပေါ်တာ။ ဒီဖိုင်က မရှိတဲ့ column တွေကိုပဲ ဖြည့်တယ်
  # (information_schema နဲ့ စစ်ထားလို့ ၂ ခါ run လည်း ဘာမှ မဖြစ်ဘူး၊
  # register ထားပြီးသား device တွေလည်း မပျက်ဘူး)။
  "sql/repair_app_devices.sql"
  # Rate-limit block တွေကို ကြည့်ဖို့ / ရှင်းဖို့။ ဆာဗာဘက် အမှားကြောင့်
  # register မရဘဲ app က ထပ်ခါထပ်ခါ ကြိုးစားရင် device_reg (5/hr) နဲ့
  # device_reg_id (8/hr) bucket တွေ ပြည့်ပြီး ၁ နာရီ ပိတ်ခံရတယ်။ အမှား
  # ပြင်ပြီးရင်တောင် အဲ့ block က ကျန်နေလို့ app က အရင်အတိုင်း
  # "could not verify itself" ပဲ ပြတယ် — fix မအောင်မြင်သလို ထင်ရတယ်။
  "bin/unblock.php"
  # တကယ့် device register + signed request ကို ဖုန်းလုပ်တဲ့အတိုင်း စမ်းပြီး
  # ဘယ်အဆင့်မှာ ကျတာလဲ တိတိကျကျ ပြတဲ့ selftest။ ဒီအထိ ဖြစ်ခဲ့တဲ့ အမှား
  # ၃ မျိုး (Notifier fatal / column လွတ် / rate-limit block) အားလုံးက
  # ဖုန်းပေါ်မှာ တူတူ မြင်ရတယ် — ဒါပေမဲ့ deploy script က "✅ ပြီးပါပြီ"
  # ပဲ ပြခဲ့တယ်။ ဖိုင်ကူးပြီးလား၊ table ရှိလားပဲ စစ်ခဲ့လို့။ ဒီဖိုင်က
  # အဲ့ဒီ ခန့်မှန်းရတဲ့ loop ကို ရပ်ပေးတယ်။
  "bin/selftest.php"
  "api/admin/devices.php"
  "n4core.sh"
  "deploy/n4core-update.sh"
  "deploy/n4core-newvps.sh"
  "deploy/n4core-secure.sh"
  "deploy/n4core-fixall.sh"
  "deploy/n4core-rescue.sh"
  "deploy/n4core-go.sh"
)

head1 "SRC ထဲ ဖိုင်တွေ စစ်နေတယ်"
MISS=0
for f in "${FILES[@]}"; do
  [ -f "$SRC_DIR/$f" ] || { err "SRC ထဲမရှိ: $f"; MISS=1; }
done
[ "$MISS" -eq 0 ] || { err "SRC မပြည့်စုံဘူး — ရပ်လိုက်တယ်"; exit 1; }
ok "${#FILES[@]} ဖိုင် အားလုံး ရှိတယ်"

# ------------------------------------------------------ PHP syntax အရင်စစ်
head1 "PHP syntax စစ်နေတယ် (တင်မတင်ခင်)"
PHPBIN="$(command -v php || true)"
if [ -n "$PHPBIN" ]; then
  BAD=0
  for f in "${FILES[@]}"; do
    case "$f" in *.php)
      if ! out="$("$PHPBIN" -l "$SRC_DIR/$f" 2>&1)"; then
        err "$f — $out"; BAD=1
      fi ;;
    esac
  done
  [ "$BAD" -eq 0 ] || { err "syntax error ရှိတယ် — ဘာမှ မတင်ဘူး"; exit 1; }
  ok "PHP ဖိုင်အားလုံး syntax OK"
else
  warn "php command မရှိ — syntax check ကို ခုန်လိုက်တယ်"
fi

if [ "$DRY" -eq 1 ]; then
  head1 "DRY RUN — တင်မယ့်ဖိုင်များ"
  for f in "${FILES[@]}"; do echo "     $f"; done
  echo
  info "config/config.php: admin_idle_minutes → 720 , admin_absolute_hours → 168"
  [ "$DO_MIGRATE" -eq 1 ] && info "migration: php bin/migrate.php --device-auth --receipt-price"
  echo; ok "dry run ပြီး — ဘာမှ မပြောင်းထားဘူး"; exit 0
fi

# ------------------------------------------------------------------ Backup
head1 "Backup ယူနေတယ်"
STAMP="$(date +%Y%m%d-%H%M%S)"
# /root က root အတွက်။ sudo မဟုတ်ဘဲ run ရင် /root မရလို့ fallback ထားတယ် —
# backup မယူဘဲ ဖိုင်တင်တာ လုံးဝ မလုပ်ဘူး။
BK=""
for base in /root /var/backups "$HOME" /tmp; do
  [ -n "$base" ] || continue
  cand="$base/n4core-v23-backup-$STAMP"
  if mkdir -p "$cand" 2>/dev/null; then BK="$cand"; break; fi
done
[ -n "$BK" ] || { err "backup dir မဖန်တီးနိုင်ဘူး — sudo နဲ့ run ပါ"; exit 1; }
for f in "${FILES[@]}"; do
  if [ -f "$APP_DIR/$f" ]; then
    mkdir -p "$BK/$(dirname "$f")"
    cp -p "$APP_DIR/$f" "$BK/$f"
  fi
done
cp -p "$APP_DIR/config/config.php" "$BK/config.php.bak" 2>/dev/null
ok "backup: $BK"

rollback() {
  warn "rollback ပြန်လုပ်နေတယ်…"
  ( cd "$BK" && find . -type f ! -name 'config.php.bak' \
      -exec sh -c 'mkdir -p "$0/$(dirname "$1")"; cp -p "$1" "$0/$1"' "$APP_DIR" {} \; )
  [ -f "$BK/config.php.bak" ] && cp -p "$BK/config.php.bak" "$APP_DIR/config/config.php"
  warn "rollback ပြီး — အရင်အတိုင်း ပြန်ရောက်သွားတယ်"
}

# ---------------------------------------------------------------- ဖိုင်တင်
head1 "ဖိုင်တွေ တင်နေတယ်"
OWNER="$(stat -c '%U:%G' "$APP_DIR/core/bootstrap.php" 2>/dev/null || echo 'www-data:www-data')"
N=0
for f in "${FILES[@]}"; do
  mkdir -p "$APP_DIR/$(dirname "$f")"
  if ! cp -f "$SRC_DIR/$f" "$APP_DIR/$f"; then
    err "ကူးလို့မရ: $f"; rollback; exit 1
  fi
  chown "$OWNER" "$APP_DIR/$f" 2>/dev/null
  case "$f" in *.sh) chmod 755 "$APP_DIR/$f" ;; *) chmod 644 "$APP_DIR/$f" ;; esac
  N=$((N+1))
done
ok "$N ဖိုင် တင်ပြီး (owner $OWNER)"

# တင်ပြီးမှ ထပ်စစ် — ကူးရင်း truncate ဖြစ်တာမျိုး ဖမ်းလို့
if [ -n "$PHPBIN" ]; then
  BAD=0
  for f in "${FILES[@]}"; do
    case "$f" in *.php)
      "$PHPBIN" -l "$APP_DIR/$f" >/dev/null 2>&1 || { err "တင်ပြီးမှ syntax error: $f"; BAD=1; } ;;
    esac
  done
  if [ "$BAD" -ne 0 ]; then rollback; exit 1; fi
  ok "တင်ပြီး syntax ပြန်စစ် OK"
fi

# ------------------------------------------------------- config session ၂ လိုင်း
# secrets/keys/DB/telegram ကို လုံးဝ မထိဘူး — ဒီ ၂ ခုပဲ။
head1 "Session timeout ပြင်နေတယ်"
CFG="$APP_DIR/config/config.php"
CHANGED=0
if grep -q "admin_idle_minutes" "$CFG"; then
  cur="$(grep -o "'admin_idle_minutes'[^,]*" "$CFG" | grep -o '[0-9]\+' | head -1)"
  if [ "${cur:-0}" != "720" ]; then
    sed -i "s/\('admin_idle_minutes'\s*=>\s*\)[0-9]\+/\1720/" "$CFG" && CHANGED=1
    ok "admin_idle_minutes: ${cur:-?} → 720"
  else
    info "admin_idle_minutes ရှိပြီးသား 720"
  fi
else
  warn "admin_idle_minutes မတွေ့ဘူး — လက်နဲ့ ထည့်ပါ"
fi
if grep -q "admin_absolute_hours" "$CFG"; then
  cur="$(grep -o "'admin_absolute_hours'[^,]*" "$CFG" | grep -o '[0-9]\+' | head -1)"
  if [ "${cur:-0}" != "168" ]; then
    sed -i "s/\('admin_absolute_hours'\s*=>\s*\)[0-9]\+/\1168/" "$CFG" && CHANGED=1
    ok "admin_absolute_hours: ${cur:-?} → 168"
  else
    info "admin_absolute_hours ရှိပြီးသား 168"
  fi
else
  warn "admin_absolute_hours မတွေ့ဘူး — လက်နဲ့ ထည့်ပါ"
fi
if [ -n "$PHPBIN" ] && ! "$PHPBIN" -l "$CFG" >/dev/null 2>&1; then
  err "config.php syntax ပျက်သွားတယ် — ပြန်ထည့်တယ်"
  cp -p "$BK/config.php.bak" "$CFG"
  exit 1
fi
[ "$CHANGED" -eq 1 ] && ok "config.php OK (secrets မထိထားဘူး)"

# --------------------------------------------------------------- Migration
if [ "$DO_MIGRATE" -eq 1 ]; then
  head1 "DB migration (app_devices + price column + purge settings)"
  # --device-auth က app_devices / app_nonces table ကို ဖန်တီးတယ်။
  # ဒီ table မရှိရင် signature မှန်တဲ့ device က register လုပ်တဲ့အခါ
  # INSERT INTO app_devices က crash ဖြစ်ပြီး HTTP 500 ပြန်တယ် —
  # App မှာ "could not verify itself with the server" ပြပြီး server မပေါ်ဘူး။
  # အရင်က --receipt-price ပဲ run ခဲ့လို့ table မဖန်တီးခဲ့ဘူး။
  if [ -z "$PHPBIN" ]; then
    warn "php မရှိ — migration ခုန်လိုက်တယ်။ ကိုယ်တိုင် run ပါ:"
    echo "     cd $APP_DIR && php bin/migrate.php --device-auth --receipt-price"
  else
    MIG_FAIL=0
    if ( cd "$APP_DIR" && "$PHPBIN" bin/migrate.php --device-auth ); then
      ok "app_devices / app_nonces table အသင့်"
    else
      err "device-auth migration မအောင်မြင်ဘူး — device register မရဘူး"
      MIG_FAIL=1
    fi
    if ( cd "$APP_DIR" && "$PHPBIN" bin/migrate.php --receipt-price ); then
      ok "receipt-price migration ပြီး"
    else
      err "receipt-price migration မအောင်မြင်ဘူး"
      MIG_FAIL=1
    fi
    if [ "$MIG_FAIL" -eq 1 ]; then
      warn "ဖိုင်တွေတော့ တင်ပြီးသား။ DB ကို လက်နဲ့ ပြန် run ပါ:"
      echo "     cd $APP_DIR && php bin/migrate.php --device-auth --receipt-price"
    fi
  fi
else
  warn "--no-migrate — DB မထိဘူး။ price field က DB မရှိရင် အလုပ်မလုပ်ဘူး"
fi

# ---------------------------------------------------------------- fpm reload
head1 "PHP-FPM reload"
DONE=0
for svc in php8.4-fpm php8.3-fpm php8.2-fpm php8.1-fpm php-fpm; do
  if systemctl is-active --quiet "$svc" 2>/dev/null; then
    systemctl reload "$svc" 2>/dev/null || systemctl restart "$svc" 2>/dev/null
    ok "$svc reload ပြီး"; DONE=1
  fi
done
if systemctl is-active --quiet nginx 2>/dev/null; then
  nginx -t >/dev/null 2>&1 && systemctl reload nginx && ok "nginx reload ပြီး"
elif systemctl is-active --quiet apache2 2>/dev/null; then
  apache2ctl configtest >/dev/null 2>&1 && systemctl reload apache2 && ok "apache2 reload ပြီး"
fi
[ "$DONE" -eq 0 ] && info "fpm service မတွေ့ဘူး (mod_php ဖြစ်နိုင်တယ်) — ပြဿနာမရှိ"

# ------------------------------------------------------------------ အတည်ပြု
head1 "အတည်ပြုစစ်နေတယ်"
[ -f "$APP_DIR/admin/assets/js/receipt.js" ] && ok "receipt.js ရောက်ပြီ" || err "receipt.js မရှိ"
grep -q "receipt.js" "$APP_DIR/admin/index.html" && ok "index.html က receipt.js load တယ်" || err "index.html မှာ script tag မရှိ"
grep -q "acc-purge" "$APP_DIR/admin/index.html" && ok "Delete Exp button ရှိတယ်" || err "Delete Exp button မရှိ"
grep -q "purge_expired" "$APP_DIR/api/admin/accounts.php" && ok "purge_expired API ရှိတယ်" || err "purge API မရှိ"
grep -q "vip_auto_purge_expired" "$APP_DIR/bin/cron.php" && ok "cron auto-purge ရှိတယ်" || err "cron မရှိ"
grep -q "rcp-row" "$APP_DIR/admin/assets/css/app.css" && ok "receipt CSS ရှိတယ်" || err "receipt CSS မရှိ"
grep -q "numericCode" "$APP_DIR/core/Crypto.php" && ok "6-digit code ရှိတယ်" || err "Crypto::numericCode မရှိ"
grep -q "numericCode" "$APP_DIR/api/admin/accounts.php" && ok "accounts.php က 6-digit သုံးတယ်" || err "accounts.php မပြောင်းရသေး"
grep -q "data-price-auto" "$APP_DIR/admin/assets/js/app.js" && ok "Auto price ရှိတယ်" || err "Auto price မရှိ"
grep -q "n4_split_sql" "$APP_DIR/bin/migrate.php" && ok "migrate SQL splitter ပြင်ပြီး" || err "migrate.php မပြင်ရသေး"

# v2.3.1 security fix — ဒါတွေက ဒီ apply ရဲ့ အဓိကရည်ရွယ်ချက်
grep -q "registrationKey" "$APP_DIR/core/DeviceAuth.php" && ok "DeviceAuth.php အသစ် ရောက်ပြီ (anti-tamper)" || err "DeviceAuth.php မရောက်ဘူး"
grep -q "device_reg_global" "$APP_DIR/core/DeviceAuth.php" && ok "Rate-limit fix ရောက်ပြီ" || err "rate-limit fix မရောက်ဘူး"
grep -q "purge_plain_codes" "$APP_DIR/bin/migrate.php" && ok "Plaintext code purge ရောက်ပြီ" || err "purge sweep မရောက်ဘူး"
[ -f "$APP_DIR/deploy/n4core-secure.sh" ] && ok "n4core-secure.sh ရောက်ပြီ" || err "n4core-secure.sh မရောက်ဘူး"
[ -f "$APP_DIR/deploy/n4core-rescue.sh" ] && ok "n4core-rescue.sh ရောက်ပြီ" || err "n4core-rescue.sh မရောက်ဘူး"

# cron က တကယ် run နေလား
if crontab -l 2>/dev/null | grep -q "cron.php" || \
   grep -rq "cron.php" /etc/cron.d/ 2>/dev/null; then
  ok "cron entry ရှိတယ် (auto-delete အလုပ်လုပ်နိုင်တယ်)"
else
  warn "cron entry မတွေ့ဘူး — auto-delete အလုပ်မလုပ်ဘူး။ ထည့်ပါ:"
  echo "     ( crontab -l 2>/dev/null; echo '*/5 * * * * php $APP_DIR/bin/cron.php >/dev/null 2>&1' ) | crontab -"
fi

echo
echo "${GRN}══════════════════════════════════════════════════${RST}"
echo "${GRN}  ✅ v2.3 တင်ပြီးပါပြီ${RST}"
echo "${GRN}══════════════════════════════════════════════════${RST}"
echo
echo "  ${CYN}ပြောင်းသွားတာ:${RST}"
echo "    • Mobile card size သေးသွားတယ် (Ctrl+Shift+R / cache ဖျက်ပြီး ကြည့်ပါ)"
echo "    • ပြေစာ ဒီဇိုင်း အသစ် (dark premium card) — Save image / Copy text"
echo "    • Password က ဂဏန်း ၆ လုံး ဖြစ်သွားပြီ (မှတ်ရလွယ်)"
echo "    • Price က Plan စျေးနှုန်းကနေ Auto တက်တယ် — AUTO button နဲ့ ပြန်တွက်"
echo "    • VIP Accounts toolbar မှာ ${RED}✕ Delete Exp${RST} button"
echo "    • Session 12 နာရီ → 30 ရက် (idle 720 min)"
echo "    • ${BD:-}Security fix${RST}: DeviceAuth.php အသစ် + rate limit + code purge"
echo
echo "  ${YLW}နောက်တဆင့် — Security hardening ကို ဆက်လုပ်ပါ:${RST}"
echo "    ${DIM}sudo bash $APP_DIR/deploy/n4core-secure.sh --check${RST}   (စစ်ရုံ)"
echo "    ${DIM}sudo bash $APP_DIR/deploy/n4core-fixall.sh --no-pin${RST}  (အကုန်တင်)"
echo
echo "  ${YLW}Auto-delete က ပိတ်ထားတယ် (default OFF)။${RST}"
echo "  Expired ပြီး 1 ရက်နေရင် အလိုအလျောက် ဖျက်ချင်ရင် ဒီလိုင်း run ပါ:"
echo "    ${DIM}cd $APP_DIR && php -r 'require \"core/bootstrap.php\"; Config::putSetting(\"vip_auto_purge_expired\",\"1\"); echo \"ON\\n\";'${RST}"
echo "  ဒါမှမဟုတ် MySQL မှာ:"
echo "    ${DIM}UPDATE settings SET svalue='1' WHERE skey='vip_auto_purge_expired';${RST}"
echo "  Grace ရက် ပြောင်းချင်ရင် (default 1):"
echo "    ${DIM}UPDATE settings SET svalue='2' WHERE skey='vip_purge_grace_days';${RST}"
echo
echo "  ${CYN}မထိထားတာ:${RST} config secrets / API keys / DeviceAuth / .htaccess / auth layer"
echo "  ${CYN}Backup:${RST} $BK"
echo "  ပြဿနာရှိရင် ပြန်ရွှေ့: ${DIM}cp -r $BK/admin $BK/api $BK/bin $BK/sql $APP_DIR/${RST}"
echo
