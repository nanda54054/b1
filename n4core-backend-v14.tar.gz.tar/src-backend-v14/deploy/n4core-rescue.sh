#!/usr/bin/env bash
# =============================================================================
#  N4 Core VPN — RESCUE (VPS ပျက်သွားရင် ပြန်တင်တဲ့ script)
# =============================================================================
#
#  ⚡ VPS ပျက်သွားပြီ။ Backup zip တော့ ရှိတယ်။ ဘာလုပ်ရမလဲ?
#     ဒီ command တခုပဲ ရိုက်ပါ —
#
#       sudo bash deploy/n4core-rescue.sh core.nandaxr.tech /root/n4core-full-XXXX.tar.gz.enc
#
#     ပြီးပါပြီ။ ကျန်တာ အကုန် script က လုပ်သွားမယ်။
#
# -----------------------------------------------------------------------------
#  လုပ်သွားမယ့်အဆင့် ၅ ဆင့် —
#
#    ၁။ Panel အသစ် တင်တယ်     (nginx + php + mariadb + SSL)
#    ၂။ Backup ကို ဖွင့်ပြီး data အကုန် ပြန်ထည့်တယ်
#       (VIP · servers · admins · settings · telegram token · key ၃ ခု)
#    ၃။ Security fix အကုန် တင်တယ်  (audit ကနေ ထွက်လာတာ ၆ ချက်)
#    ၄။ Telegram bot ပြန်ချိတ်တယ်
#    ၅။ ဒေတာ တကယ်ဝင်မဝင် ရေတွက်ပြတယ်
#
# -----------------------------------------------------------------------------
#  လိုအပ်တာ ၃ ခုပဲ —
#
#    ၁။ VPS အသစ် (Ubuntu 22.04/24.04 or Debian 12, root အခွင့်)
#    ၂။ Domain က VPS အသစ်ကို ညွှန်ထားပြီးသား (A record)
#    ၃։ Backup ဖိုင် —  n4core-full-*.tar.gz.enc  ကို ဦးစားပေး ပါ
#       (dashboard တစ်ခုလုံး ပါတယ်။ n4core-db-* က database သီးသန့်ပဲ)
#
#  Backup က encrypt လုပ်ထားရင် encryption_key တောင်းလိမ့်မယ်။
#  ဒါက VPS အဟောင်းရဲ့ config.php ထဲမှာ ရှိတယ် —
#       grep encryption_key /var/www/n4core/config/config.php
#  ရှာမရရင် backup ထဲက KEYS.txt ကို ကြည့်ပါ။
#
# -----------------------------------------------------------------------------
#  USAGE
#      sudo bash deploy/n4core-rescue.sh <domain> <backup-file>
#      sudo bash deploy/n4core-rescue.sh <domain> <backup-file> <encryption_key>
#      sudo bash deploy/n4core-rescue.sh <domain> <backup-file> --no-pin
#      sudo bash deploy/n4core-rescue.sh --check      # ရှိပြီးသား VPS ကို စစ်ရုံ
# =============================================================================
set -uo pipefail

RED=$'\033[31m'; GRN=$'\033[32m'; YLW=$'\033[33m'; CYN=$'\033[36m'
DIM=$'\033[2m'; BD=$'\033[1m'; RST=$'\033[0m'
ok()   { echo "  ${GRN}✅${RST} $*"; }
info() { echo "  ${CYN}•${RST}  $*"; }
warn() { echo "  ${YLW}⚠${RST}  $*"; }
err()  { echo "  ${RED}❌${RST} $*" >&2; }
head1(){ echo; echo "${CYN}${BD}━━━ $* ━━━${RST}"; }
die()  { echo; err "$*"; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$(dirname "$SCRIPT_DIR")"
APP_DIR="/var/www/n4core"

DOMAIN=""
BKFILE=""
ENC_KEY=""
NO_PIN=0
CHECK_ONLY=0
CERT_HASH="1490631129b09f523c3caa339617b6de1b404015827fee6fd1e8d44b0824fdfe"

while [ $# -gt 0 ]; do
  case "$1" in
    --check)   CHECK_ONLY=1 ;;
    --no-pin)  NO_PIN=1 ;;
    --cert)    shift; CERT_HASH="${1:-}" ;;
    -h|--help) sed -n '2,44p' "$0"; exit 0 ;;
    *)
      if   [ -z "$DOMAIN" ]; then DOMAIN="$1"
      elif [ -z "$BKFILE" ]; then BKFILE="$1"
      elif [ -z "$ENC_KEY" ]; then ENC_KEY="$1"
      else err "argument အလွန်များ: $1"; exit 1; fi
      ;;
  esac
  shift
done

echo
echo "${CYN}══════════════════════════════════════════════════${RST}"
echo "${CYN}${BD}  N4 Core VPN — RESCUE${RST}"
echo "${CYN}══════════════════════════════════════════════════${RST}"

[ "$(id -u)" -eq 0 ] || die "root နဲ့ run ပါ:  sudo bash $0 ..."

# ==================================================== --check mode
if [ "$CHECK_ONLY" -eq 1 ]; then
  head1 "ရှိပြီးသား VPS ကို စစ်နေတယ်"
  [ -f "$APP_DIR/config/config.php" ] || die "config.php မတွေ့ပါ — panel မတင်ရသေးဘူး"
  bash "$SCRIPT_DIR/n4core-secure.sh" --check --app-dir "$APP_DIR"
  exit $?
fi

# ==================================================== usage guard
if [ -z "$DOMAIN" ] || [ -z "$BKFILE" ]; then
  cat <<USAGE

  ${BD}VPS ပျက်သွားပြီလား? ဒီ command တခုပဲ ရိုက်ပါ —${RST}

    ${CYN}sudo bash deploy/n4core-rescue.sh <domain> <backup-file>${RST}

  ${BD}ဥပမာ${RST}
    sudo bash deploy/n4core-rescue.sh core.nandaxr.tech \\
         /root/n4core-full-20260901-174904.tar.gz.enc

  ${BD}Backup ဖိုင် ဘယ်ကရမလဲ${RST}
    ကိုယ့်စက်ထဲက ဖိုင်ကို VPS အသစ်ကို တင်ပါ —
      ${DIM}scp n4core-full-XXXX.tar.gz.enc root@<VPS-IP>:/root/${RST}

    ${BD}n4core-full-*${RST} ကို ဦးစားပေး ပါ (dashboard တစ်ခုလုံး ပါတယ်)။
    ${BD}n4core-db-*${RST} က database သီးသန့်ပဲ။

  ${BD}encryption_key${RST}
    Backup က encrypt လုပ်ထားရင် အလယ်မှာ တောင်းပါလိမ့်မယ်။
    ကြိုထည့်ချင်ရင် တတိယ argument အနေနဲ့ ထည့်ပါ။

  ${BD}ရှိပြီးသား VPS ကို စစ်ရုံ${RST}
    ${DIM}sudo bash deploy/n4core-rescue.sh --check${RST}

USAGE
  exit 1
fi

# ==================================================== ၀။ အရင်စစ်
head1 "၀/၅ — မလုပ်ခင် စစ်နေတယ်"

[ -f "$BKFILE" ] || die "Backup ဖိုင် မတွေ့ပါ: $BKFILE"
[ -s "$BKFILE" ] || die "Backup ဖိုင် ဗလာဖြစ်နေတယ်: $BKFILE"
ok "Backup ဖိုင် တွေ့ပြီ ($(du -h "$BKFILE" | cut -f1))"

case "$(basename "$BKFILE")" in
  n4core-full-*) ok "full backup — dashboard တစ်ခုလုံး ပါတယ်" ;;
  n4core-db-*)   warn "database သီးသန့် backup — ဖိုင်တွေ မပါဘူး (data တော့ ရမယ်)" ;;
  *)             warn "ဖိုင်နာမည် မမှတ်မိဘူး — ဆက်စမ်းမယ်" ;;
esac

for f in n4core-install.sh n4core-secure.sh; do
  [ -f "$SCRIPT_DIR/$f" ] || die "$f မတွေ့ပါ — SRC မပြည့်စုံဘူး"
done
[ -f "$SRC_DIR/bin/restore.php" ] || die "bin/restore.php မတွေ့ပါ"
ok "လိုအပ်တဲ့ script တွေ ပြည့်စုံပါတယ်"

# security fix တွေ SRC ထဲ ပါမပါ
if grep -q "registrationKey" "$SRC_DIR/core/DeviceAuth.php" 2>/dev/null; then
  ok "SRC ထဲ security fix ပါတယ်"
else
  warn "SRC က အဟောင်း ဖြစ်နိုင်တယ် — restore တော့ ရမယ်"
fi

# DNS ညွှန်မညွှန်
MYIP="$(curl -s -m 8 ifconfig.me 2>/dev/null || echo '')"
DNSIP="$(getent hosts "$DOMAIN" 2>/dev/null | awk '{print $1}' | head -1 || echo '')"
if [ -n "$MYIP" ] && [ -n "$DNSIP" ]; then
  if [ "$MYIP" = "$DNSIP" ]; then
    ok "DNS မှန်တယ် ($DOMAIN → $MYIP)"
  else
    warn "DNS က တခြား IP ညွှန်နေတယ် ($DOMAIN → $DNSIP, ဒီ VPS → $MYIP)"
    warn "  SSL ထုတ်တာ မရနိုင်ဘူး။ A record ပြောင်းပြီးမှ ပြန် run တာ ကောင်းတယ်။"
    echo
    read -rp "  ဆက်လုပ်မလား? (yes/no): " GO
    [ "$GO" = "yes" ] || die "ရပ်လိုက်တယ်။ DNS ပြင်ပြီး ပြန် run ပါ။"
  fi
fi

# encrypt လုပ်ထားလား — N4CBK001 က magic
MAGIC="$(head -c 8 "$BKFILE" 2>/dev/null || true)"
KEYARG=""
if [ "$MAGIC" = "N4CBK001" ]; then
  ok "Encrypted backup"
  if [ -z "$ENC_KEY" ]; then
    echo
    echo "  ${BD}encryption_key လိုပါတယ်${RST} — backup ဖိုင်ကို ဖွင့်ဖို့ပါ။"
    echo "  VPS အဟောင်းမှာ:  ${DIM}grep encryption_key $APP_DIR/config/config.php${RST}"
    echo "  ဒါမှမဟုတ် backup ထဲက KEYS.txt မှာ ရှိတယ်။"
    echo
    read -rp "  encryption_key : " ENC_KEY
  fi
  [ -n "$ENC_KEY" ] || die "encryption_key မပါဘဲ backup ကို ဖွင့်လို့ မရပါ"
  KEYARG="--key=$ENC_KEY"
else
  info "Encrypt မလုပ်ထားဘူး — key မလိုပါ"
fi

# ==================================================== ၁။ PANEL တင်
head1 "၁/၅ — Panel တင်နေတယ် (၅-၁၀ မိနစ် ကြာနိုင်တယ်)"

if [ -f "$APP_DIR/config/config.php" ]; then
  warn "Panel ရှိပြီးသား ဖြစ်နေတယ်"
  cp -p "$APP_DIR/config/config.php" "/root/n4core-preexisting-config-$(date +%s).bak" 2>/dev/null \
    && info "အရင် config ကို /root/ မှာ သိမ်းထားတယ်"
  echo
  echo "  ${YLW}ဆက်လုပ်ရင် ရှိပြီးသား data ကို backup ထဲက data နဲ့ အစားထိုးမယ်။${RST}"
  read -rp "  ဆက်လုပ်မလား? (yes/no): " GO
  [ "$GO" = "yes" ] || die "ရပ်လိုက်တယ်"
  info "install ခုန်လိုက်တယ် (ရှိပြီးသားမို့) — restore ကို တိုက်ရိုက် လုပ်မယ်"
else
  if ! bash "$SCRIPT_DIR/n4core-install.sh" "$DOMAIN"; then
    die "Panel တင်တာ မအောင်မြင်ပါ — အထက်က error ကို ကြည့်ပါ"
  fi
  ok "Panel တင်ပြီးပါပြီ"
fi

[ -d "$APP_DIR" ] || die "$APP_DIR မတွေ့ပါ — install မအောင်မြင်ဘူး"

# ==================================================== ၂။ RESTORE
head1 "၂/၅ — Backup ကနေ data ပြန်ထည့်နေတယ်"

# dry-run အရင် — key မှားရင် ဒီမှာတင် ရပ်တယ်။ DB ကို လက်တောင် မတို့ရသေးဘူး။
info "ဖိုင်ကို အရင်စစ်နေတယ် (dry run)…"
if ! php "$APP_DIR/bin/restore.php" "$BKFILE" $KEYARG --dry-run; then
  die "Backup ဖိုင် ဖွင့်လို့ မရပါ — encryption_key မှားနေလား ပြန်စစ်ပါ"
fi
ok "Backup ဖိုင် မှန်ကန်ပါတယ်"

echo
info "အခု တကယ် ထည့်တော့မယ်…"
if ! php "$APP_DIR/bin/restore.php" "$BKFILE" $KEYARG --yes; then
  die "Restore မအောင်မြင်ပါ"
fi
ok "Data ပြန်ဝင်ပြီး"

# restore က config.php ထဲ key တွေ ထည့်လိုက်ပြီမို့ permission ပြန်ချိန်
chown -R www-data:www-data "$APP_DIR" 2>/dev/null || true
chmod 640 "$APP_DIR/config/config.php" 2>/dev/null || true
systemctl reload "php$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')-fpm" 2>/dev/null \
  || systemctl reload php-fpm 2>/dev/null || true

# ==================================================== ၃။ SECURITY FIX
head1 "၃/၅ — Security fix တင်နေတယ်"

# Backup က အဟောင်း ဖြစ်နိုင်တာမို့ restore ပြီးမှ ဖိုင်တွေ ပြန်တင်ရတယ်။
# (restore က backup ထဲက ဖိုင်အဟောင်းတွေနဲ့ overwrite လုပ်နိုင်တယ်)
if [ -f "$SCRIPT_DIR/n4core-apply-v23.sh" ]; then
  if bash "$SCRIPT_DIR/n4core-apply-v23.sh" --src "$SRC_DIR" --app-dir "$APP_DIR"; then
    ok "ဖိုင်တွေ အသစ် ပြန်တင်ပြီး"
  else
    warn "apply မအောင်မြင် — restore ကတော့ ရပြီးသား"
  fi
fi

SECARGS=( --app-dir "$APP_DIR" )
if [ "$NO_PIN" -eq 1 ]; then
  warn "--no-pin — cert pin မဖွင့်ဘူး"
else
  SECARGS+=( "$CERT_HASH" )
fi

if bash "$SCRIPT_DIR/n4core-secure.sh" "${SECARGS[@]}"; then
  ok "Security fix အကုန် တင်ပြီး"
else
  warn "Security fix မှာ အချက်တချို့ မရ — panel တော့ အလုပ်လုပ်နေမယ်"
fi

# ==================================================== ၄။ TELEGRAM BOT
head1 "၄/၅ — Telegram bot ပြန်ချိတ်နေတယ်"

cd "$APP_DIR" || die "$APP_DIR ထဲ ဝင်လို့ မရပါ"
BOT_OK=0

if php -r 'require_once "core/bootstrap.php"; exit(Telegram::enabled() ? 0 : 1);' >/dev/null 2>&1; then
  ok "Bot token တွေ့ပြီ (backup ထဲက ပါလာတယ်)"

  # Telegram က token တခုကို webhook တခုပဲ မှတ်တာမို့ အသစ်တင်လိုက်ရင်
  # VPS အဟောင်းရဲ့ webhook က အလိုအလျောက် ပြုတ်သွားတယ်။
  if php bin/setup_webhook.php "https://$DOMAIN" >/tmp/n4bot.out 2>&1; then
    ok "Webhook အသစ် တင်ပြီး"
    BOT_OK=1
  else
    warn "Webhook မရ — polling mode စမ်းမယ်"
    php bin/setup_webhook.php --delete >/dev/null 2>&1 || true
    SVC="$APP_DIR/deploy/systemd/n4core-bot.service"
    [ -f "$SVC" ] || SVC="$SRC_DIR/deploy/systemd/n4core-bot.service"
    if [ -f "$SVC" ]; then
      cp "$SVC" /etc/systemd/system/ 2>/dev/null
      systemctl daemon-reload 2>/dev/null
      if systemctl enable --now n4core-bot >/dev/null 2>&1; then
        sleep 3
        systemctl is-active --quiet n4core-bot \
          && { ok "Bot service စပြီး (polling)"; BOT_OK=1; } \
          || warn "Bot service စလို့မရ — journalctl -u n4core-bot"
      fi
    fi
  fi
else
  warn "Bot token မတွေ့ပါ — Panel → Settings → Telegram မှာ ထည့်ပါ"
fi

# ==================================================== ၅။ အတည်ပြု
head1 "၅/၅ — ဒေတာ ဝင်မဝင် စစ်နေတယ်"

COUNTS="$(php -r '
require_once "core/bootstrap.php";
try {
  printf("%d %d %d",
    (int) Db::value("SELECT COUNT(*) FROM vip_accounts"),
    (int) Db::value("SELECT COUNT(*) FROM servers"),
    (int) Db::value("SELECT COUNT(*) FROM admin_users"));
} catch (Throwable $e) { echo "-1 -1 -1"; }
' 2>/dev/null || echo "-1 -1 -1")"
read -r VIPS SERVERS ADMINS <<<"$COUNTS"

if [ "$VIPS" = "-1" ]; then
  warn "ရေတွက်လို့ မရပါ — panel ထဲဝင်ပြီး ကိုယ်တိုင် စစ်ပါ"
else
  ok "VIP accounts : $VIPS"
  ok "Servers      : $SERVERS"
  ok "Admins       : $ADMINS"
  [ "$VIPS" = "0" ] && [ "$SERVERS" = "0" ] \
    && warn "နှစ်ခုလုံး ၀ — backup ဖိုင် မှားနေလား ပြန်စစ်ပါ"
fi

# app က တကယ် အလုပ်လုပ်နေလား
SRV="$(curl -s -m 10 -o /dev/null -w '%{http_code}' \
  "https://$DOMAIN/api/public/locations.php" 2>/dev/null || echo "000")"
case "$SRV" in
  200|401|403) ok "API တုံ့ပြန်နေတယ် (HTTP $SRV) — app အလုပ်လုပ်နိုင်ပြီ" ;;
  000)         warn "API မတုံ့ပြန်ဘူး — DNS/SSL စစ်ပါ" ;;
  *)           warn "API HTTP $SRV" ;;
esac

# ==================================================== ပြီးပြီ
if [ "$BOT_OK" = "1" ]; then
  BOT_LINE="${GRN}✓ ချိတ်ပြီး${RST} — bot မှာ ${BD}/start${RST} ရိုက်ပြီး စမ်းပါ"
else
  BOT_LINE="${YLW}! မချိတ်ရသေးဘူး${RST}"
fi

cat <<DONE

${GRN}${BD}═══════════════════════════════════════════════════${RST}
${GRN}${BD}  ✅ RESCUE အောင်မြင်ပါပြီ${RST}
${GRN}${BD}═══════════════════════════════════════════════════${RST}

  Panel     : ${BD}https://$DOMAIN/admin/${RST}
  VIP       : $VIPS · Servers: $SERVERS · Admins: $ADMINS
  Telegram  : $BOT_LINE

  ${BD}Login${RST}
    Password ${BD}အဟောင်း${RST} အတိုင်းပဲ ဝင်ပါ။ key တွေ ပါလာပြီးသားမို့
    ပြောင်းစရာ မလိုပါ။

  ${BD}နောက်ထပ် လုပ်ရမယ့်အဆင့်${RST}
    ၁။ Panel ထဲဝင်ပြီး Servers နဲ့ VIP Accounts ပြည့်စုံလား ကြည့်ပါ
    ၂။ VIP access code တခု ဖွင့်ကြည့်ပါ — ဖတ်လို့ရရင် အားလုံး မှန်ပါပြီ
    ၃။ App ကနေ တကယ် login ဝင်ကြည့်ပါ
    ၄။ ${YLW}အားလုံး အဆင်ပြေမှ${RST} VPS အဟောင်းကို ဖျက်ပါ

  ${BD}Security ပြန်စစ်ချင်ရင်${RST}
    ${DIM}sudo bash deploy/n4core-rescue.sh --check${RST}

  ${BD}Backup အလိုအလျောက်${RST}
    ည ၁၂ နာရီတိုင်း ဖိုင် ၂ မျိုး ထွက်မယ် —
      • n4core-full-*.enc  (dashboard တစ်ခုလုံး)  ← ဒါကို သိမ်းပါ
      • n4core-db-*.enc    (database သီးသန့်)
    သိမ်းရာနေရာ: $APP_DIR/storage/backups/

  ${YLW}${BD}အရေးကြီး —${RST} backup ဖိုင်ကို ${BD}ကိုယ့်စက်ထဲ${RST} ပါ ဆွဲထားပါ။
  VPS ပေါ်တင် ရှိရင် VPS ပျက်တဲ့အခါ backup လည်း ပါပျက်သွားမယ်။
    ${DIM}scp root@$DOMAIN:$APP_DIR/storage/backups/n4core-full-*.enc .${RST}

DONE
