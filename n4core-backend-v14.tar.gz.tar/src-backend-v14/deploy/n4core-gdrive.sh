#!/usr/bin/env bash
# =====================================================================
#  N4 Core VPN — Google Drive ကနေ VPS အသစ်သို့ (တစ်ချက်ထဲ)
# =====================================================================
#
#  Termius ကနေ VPS ဝင်ပြီး ဒီ script ကို paste လုပ်ရုံပါ။
#  လိုအပ်တာ ၄ ခုကို တစ်ခုချင်း တောင်းပါလိမ့်မယ် —
#
#    ၁။ Domain                       (ဥပမာ core.nandaxr.tech)
#    ၂။ Code zip ရဲ့ gdrive link
#    ၃။ Backup .enc ရဲ့ gdrive link
#    ၄။ encryption_key               (bot မှာ /keys)
#
#  gdrive မှာ ဖိုင်နှစ်ခုကို  Share -> Anyone with the link  လုပ်ထားရမယ်။
#
# =====================================================================
set -uo pipefail

R=$'\e[31m'; G=$'\e[32m'; Y=$'\e[33m'; B=$'\e[36m'; BD=$'\e[1m'; N=$'\e[0m'

step() { echo; echo "${B}${BD}▸ $*${N}"; }
good() { echo "  ${G}✓${N} $*"; }
warn() { echo "  ${Y}!${N} $*"; }
die()  { echo; echo "${R}${BD}✗ $*${N}" >&2; exit 1; }

WORK="/root/n4core-setup"

cat <<BANNER

${B}${BD}═══════════════════════════════════════════════════${N}
${B}${BD}  N4 Core VPN — VPS အသစ် တင်ခြင်း${N}
${B}${BD}═══════════════════════════════════════════════════${N}

  လိုအပ်တာ ၄ ခုကို တောင်းပါလိမ့်မယ်။
  တစ်ခုချင်း paste ပြီး Enter နှိပ်ပါ။

BANNER

[ "$(id -u)" = "0" ] || die "root အနေနဲ့ run ပါ  (sudo -i ပြီးမှ ပြန်စမ်းပါ)"

# ---- ၀။ လိုအပ်တာ တောင်း --------------------------------------------
step "၀/၆ — အချက်အလက် တောင်းနေတယ်"

read -rp "  ၁) Domain           : " DOMAIN
[ -n "${DOMAIN:-}" ] || die "Domain မထည့်ထားပါ"
# http:// https:// နဲ့ အဆုံး / တွေ ဖြုတ်ပေးတယ် — copy လုပ်တဲ့အခါ ပါလာလို့။
DOMAIN="$(printf '%s' "$DOMAIN" | sed -E 's#^https?://##; s#/.*$##; s/[[:space:]]//g')"
good "Domain: $DOMAIN"

read -rp "  ၂) Code zip link    : " CODE_LINK
[ -n "${CODE_LINK:-}" ] || die "Code link မထည့်ထားပါ"

read -rp "  ၃) Backup .enc link : " BK_LINK
[ -n "${BK_LINK:-}" ] || die "Backup link မထည့်ထားပါ"

echo
echo "  ၄) encryption_key   (bot မှာ ${BD}/keys${N} ရိုက်ရင် ရမယ်)"
read -rp "     : " ENC_KEY
ENC_KEY="$(printf '%s' "$ENC_KEY" | tr -d '[:space:]')"
[ -n "$ENC_KEY" ] || die "encryption_key မထည့်ထားပါ"
good "Key လက်ခံပြီ (${#ENC_KEY} လုံး)"

# ---- ၁။ လိုအပ်တဲ့ tool တွေ တင် --------------------------------------
step "၁/၆ — လိုအပ်တဲ့ tool တွေ တင်နေတယ်"

export DEBIAN_FRONTEND=noninteractive
apt-get update -qq >/dev/null 2>&1 || warn "apt update ကို ကျော်လိုက်တယ်"
apt-get install -y -qq curl wget tar unzip ca-certificates >/dev/null 2>&1 \
  || die "curl/wget တင်လို့ မရပါ"
good "curl · wget · tar အသင့်ဖြစ်ပြီ"

mkdir -p "$WORK" || die "$WORK မဖန်တီးလို့ မရပါ"
cd "$WORK" || die "$WORK ထဲ ဝင်လို့ မရပါ"

# ---- gdrive download function ---------------------------------------
# gdrive link ပုံစံ ၃ မျိုးလုံးကနေ file id ကို ဆွဲထုတ်တယ် —
#   /file/d/<ID>/view      ?id=<ID>      id သီးသန့်
gdid() {
  local s="$1" id=""
  id="$(printf '%s' "$s" | grep -oE '/d/[A-Za-z0-9_-]{10,}' | head -1 | sed 's|/d/||')"
  [ -n "$id" ] || id="$(printf '%s' "$s" | grep -oE '[?&]id=[A-Za-z0-9_-]{10,}' | head -1 | sed 's/^[?&]id=//')"
  [ -n "$id" ] || id="$(printf '%s' "$s" | grep -oE '^[A-Za-z0-9_-]{20,}$')"
  printf '%s' "$id"
}

# ဖိုင်ကြီးရင် gdrive က "virus scan" warning page ပြတယ်။ အဲ့ဒါကို
# ဖြတ်ဖို့ confirm token ကို cookie ကနေ ဆွဲယူပြီး ထပ်ခေါ်ရတယ်။
gdl() {
  local link="$1" out="$2" id cookie html token
  id="$(gdid "$link")"

  if [ -z "$id" ]; then
    # gdrive link မဟုတ်ရင် သာမန် URL အနေနဲ့ စမ်းတယ်
    echo "  gdrive link မဟုတ်ပါ — URL အတိုင်း download စမ်းနေတယ်"
    curl -fsSL --retry 3 -o "$out" "$link" || return 1
    return 0
  fi

  echo "  File ID: $id"
  cookie="$(mktemp)"

  # ပထမအကြိမ် — ဖိုင်ငယ်ရင် ဒီတစ်ခါနဲ့ ရပြီ
  curl -sL -c "$cookie" -o "$out" \
    "https://drive.google.com/uc?export=download&id=${id}" 2>/dev/null

  # HTML ပြန်လာရင် warning page ဖြစ်တယ် — token နဲ့ ထပ်ခေါ်ရမယ်
  if head -c 200 "$out" 2>/dev/null | grep -qi '<!DOCTYPE html\|<html'; then
    echo "  gdrive warning page ကို ဖြတ်နေတယ်..."
    html="$(cat "$out")"
    token="$(printf '%s' "$html" | grep -oE 'confirm=[A-Za-z0-9_-]+' | head -1 | cut -d= -f2)"
    [ -n "$token" ] || token="$(awk '/download_warning/ {print $NF}' "$cookie" | head -1)"

    if [ -n "$token" ]; then
      curl -sL -b "$cookie" -o "$out" \
        "https://drive.google.com/uc?export=download&confirm=${token}&id=${id}" 2>/dev/null
    else
      # အသစ်ပုံစံ endpoint — token မရရင် ဒါနဲ့ စမ်းတယ်
      curl -sL -b "$cookie" -o "$out" \
        "https://drive.usercontent.google.com/download?id=${id}&export=download&confirm=t" 2>/dev/null
    fi
  fi

  rm -f "$cookie"

  # တကယ် ဖိုင်ရလား စစ်တယ် — HTML ပြန်လာနေရင် share setting မှားနေတာ
  if head -c 200 "$out" 2>/dev/null | grep -qi '<!DOCTYPE html\|<html'; then
    rm -f "$out"
    return 1
  fi
  [ -s "$out" ] || return 1
  return 0
}

# ---- ၂။ Code download ------------------------------------------------
step "၂/၆ — Code ကို download နေတယ်"

if ! gdl "$CODE_LINK" "$WORK/code.tar.gz"; then
  die "Code download မရပါ။

  ဒါတွေ စစ်ပါ —
    • gdrive မှာ ${BD}Share -> Anyone with the link${N} လုပ်ထားလား
    • Link ကို အစအဆုံး ကူးမိလား

  ဒါမှမဟုတ် ဖုန်း/ကွန်ပျူတာကနေ တိုက်ရိုက် တင်ပါ —
    ${BD}scp code.tar.gz root@$(hostname -I 2>/dev/null | awk '{print $1}'):$WORK/code.tar.gz${N}"
fi
good "Code ရပြီ ($(du -h "$WORK/code.tar.gz" | cut -f1))"

# ---- ၃။ Backup download ----------------------------------------------
step "၃/၆ — Backup ကို download နေတယ်"

if ! gdl "$BK_LINK" "$WORK/backup.enc"; then
  die "Backup download မရပါ။ gdrive share setting ကို စစ်ပါ။"
fi
good "Backup ရပြီ ($(du -h "$WORK/backup.enc" | cut -f1))"

# N4CBK001 = encrypt လုပ်ထားတဲ့ backup ရဲ့ အမှတ်အသား။
# ဒီမှာ စစ်လိုက်တာက ဖိုင်မှားတင်မိတာကို panel တင်ပြီးမှ သိရတာထက်
# အများကြီး ကောင်းတယ် — အချိန် ၁၅ မိနစ် သက်သာတယ်။
MAGIC="$(head -c 8 "$WORK/backup.enc" 2>/dev/null || true)"
if [ "$MAGIC" = "N4CBK001" ]; then
  good "Backup ဖိုင် အမှတ်အသား မှန်ပါတယ်"
else
  warn "N4CBK001 အမှတ်အသား မတွေ့ပါ (encrypt မလုပ်ထားတဲ့ ဖိုင် ဖြစ်နိုင်တယ်)"
  read -rp "  ဆက်လုပ်မလား? [y/N] " _c
  case "${_c:-N}" in y|Y) ;; *) die "ရပ်လိုက်ပါတယ် — ဖိုင်ကို ပြန်စစ်ပါ" ;; esac
fi

# ---- ၄။ Code ဖြေ -----------------------------------------------------
step "၄/၆ — Code ကို ဖြေနေတယ်"

tar -xzf "$WORK/code.tar.gz" -C "$WORK" 2>/dev/null \
  || unzip -oq "$WORK/code.tar.gz" -d "$WORK" 2>/dev/null \
  || die "Code ဖိုင် ဖြေလို့ မရပါ (tar.gz ဒါမှမဟုတ် zip ဖြစ်ရမယ်)"

# folder အမည် ဘာဖြစ်ဖြစ် ကိစ္စမရှိအောင် newvps.sh ကို ရှာယူတယ် —
# ProjectBackup က backend/n4core-backend-v2/ လို nested ဖြစ်နိုင်တာမို့။
NEWVPS="$(find "$WORK" -type f -name 'n4core-newvps.sh' 2>/dev/null | head -1)"
[ -n "$NEWVPS" ] || die "n4core-newvps.sh မတွေ့ပါ — code zip မှားနေလား စစ်ပါ"

SRC="$(cd "$(dirname "$NEWVPS")/.." && pwd)"
good "Code ဖြေပြီ: $SRC"

chmod +x "$SRC"/deploy/*.sh 2>/dev/null || true

# ---- ၅။ Panel တင် + Restore -----------------------------------------
step "၅/၆ — Panel တင်ပြီး Backup ပြန်ထည့်နေတယ် (၅-၁၅ မိနစ် ကြာနိုင်)"
echo "  ${Y}ဒီအဆင့်မှာ စောင့်ပေးပါ။ ဘာမှ နှိပ်စရာ မလိုပါ။${N}"

cd "$SRC" || die "$SRC ထဲ ဝင်လို့ မရပါ"

if ! bash deploy/n4core-newvps.sh "$DOMAIN" "$WORK/backup.enc" "$ENC_KEY"; then
  die "တင်တာ မအောင်မြင်ပါ — အထက်က error message ကို ကြည့်ပါ"
fi

# ---- ၆။ သန့်ရှင်းရေး -------------------------------------------------
step "၆/၆ — သန့်ရှင်းရေး"

# backup ဖိုင်နဲ့ zip က /root ထဲ ကျန်နေရင် key နဲ့တွဲပြီး ဒေတာအားလုံး
# ပြန်ဖွင့်လို့ရတာမို့ ဖျက်ပေးတယ်။ panel ထဲက backup ကို ဆက်သုံးပါ။
read -rp "  Download ဖိုင်တွေ ဖျက်မလား? (အကြံပြုတယ်) [Y/n] " _d
case "${_d:-Y}" in
  n|N) warn "ဖိုင်တွေ $WORK ထဲ ကျန်နေပါတယ် — ကိုယ်တိုင် ဖျက်ပါ" ;;
  *)   rm -rf "$WORK/code.tar.gz" "$WORK/backup.enc"
       good "Download ဖိုင်တွေ ဖျက်ပြီး" ;;
esac

cat <<DONE

${G}${BD}═══════════════════════════════════════════════════${N}
${G}${BD}  ✓ အားလုံး ပြီးပါပြီ${N}
${G}${BD}═══════════════════════════════════════════════════${N}

  Panel : ${BD}https://$DOMAIN/admin/${N}

  ${BD}Login${N}
    Password ${BD}အဟောင်း${N} အတိုင်းပဲ ဝင်ပါ။

  ${BD}စစ်ရမယ့်အချက်${N}
    ၁။ Servers နဲ့ VIP Accounts ပြည့်စုံလား
    ၂။ VIP access code တစ်ခု ဖွင့်ကြည့်ပါ — ဖတ်လို့ရရင် အားလုံး မှန်ပါပြီ
    ၃။ App ကနေ တကယ် login ဝင်ကြည့်ပါ
    ၄။ ${Y}အားလုံး အဆင်ပြေမှ${N} VPS အဟောင်းကို ဖျက်ပါ

  ${BD}Backup${N}
    ည ၁၂ နာရီတိုင်း အလိုအလျောက် ထုတ်ပြီး Telegram ပို့ပါမယ်။

DONE
