#!/usr/bin/env bash
#
# ============================================================================
#  N4 Core VPN — VPS အဟောင်းက Backup ယူတဲ့ script
# ============================================================================
#  VPS အဟောင်းကို မဖျက်ခင် ဒါကို အရင် run ပါ။
#
#  USAGE
#     sudo ./n4core-backup.sh
#
#  ထွက်လာမယ့်ဖိုင် — /root/n4core-backup-<ရက်စွဲ>.tar.gz
#  အထဲမှာ:  db.sql  (data အားလုံး)
#           config.php  (encryption_key အပါအဝင်)
#           KEYS.txt    (VPS အသစ်မှာ ထည့်ရမယ့် တန်ဖိုးတွေ)
# ============================================================================

set -uo pipefail

APP_DIR="${N4_APP_DIR:-/var/www/n4core}"
STAMP="$(date +%F-%H%M%S)"
WORK="/root/n4core-backup-${STAMP}"
OUT="/root/n4core-backup-${STAMP}.tar.gz"

if [ -t 1 ]; then
  R=$'\e[31m'; G=$'\e[32m'; Y=$'\e[33m'; B=$'\e[36m'; BD=$'\e[1m'; N=$'\e[0m'
else
  R=""; G=""; Y=""; B=""; BD=""; N=""
fi
step() { echo; echo "${B}${BD}▸ $*${N}"; }
good() { echo "  ${G}✅ $*${N}"; }
warn() { echo "  ${Y}⚠️  $*${N}"; }
die()  { echo "  ${R}❌ $*${N}"; exit 1; }

[ "$(id -u)" -eq 0 ] || die "root နဲ့ run ပါ:  sudo $0"
[ -f "$APP_DIR/config/config.php" ] \
  || die "config.php မတွေ့ပါ: $APP_DIR/config/config.php
     တခြားနေရာမှာဆိုရင်:  N4_APP_DIR=/path/to/n4core sudo $0"

mkdir -p "$WORK"

# ---------------------------------------------------------------- DB
step "1/3 — Database dump ယူနေတယ်"
DB_NAME="$(php -r '$c=@include $argv[1]; echo is_array($c)?($c["db"]["name"]??""):"";' "$APP_DIR/config/config.php")"
DB_USER="$(php -r '$c=@include $argv[1]; echo is_array($c)?($c["db"]["user"]??""):"";' "$APP_DIR/config/config.php")"
DB_PASS="$(php -r '$c=@include $argv[1]; echo is_array($c)?($c["db"]["pass"]??""):"";' "$APP_DIR/config/config.php")"
[ -n "$DB_NAME" ] || die "config.php ထဲက DB name မဖတ်နိုင်ပါ"

# --single-transaction က table lock မချဘဲ ကူးတယ် — service ဆက်ရပ်နေစရာမလို
mysqldump --single-transaction --routines --default-character-set=utf8mb4 \
  -u"$DB_USER" -p"$DB_PASS" "$DB_NAME" > "$WORK/db.sql" 2>"$WORK/.err" \
  || { sed 's/^/     /' "$WORK/.err" | head -3; die "mysqldump မအောင်မြင်ပါ"; }
rm -f "$WORK/.err"

# dump မှန်မမှန် စစ်တယ် — ဗလာဖိုင်ကို "အောင်မြင်" လို့ မပြောမိအောင်
grep -q "CREATE TABLE" "$WORK/db.sql" || die "Dump ထဲ table မပါပါ — မယူရသေးဘူး"

VIPS="$(mysql -N -B -u"$DB_USER" -p"$DB_PASS" -e "SELECT COUNT(*) FROM \`$DB_NAME\`.vip_accounts" 2>/dev/null || echo '?')"
SRVS="$(mysql -N -B -u"$DB_USER" -p"$DB_PASS" -e "SELECT COUNT(*) FROM \`$DB_NAME\`.servers" 2>/dev/null || echo '?')"
ADMS="$(mysql -N -B -u"$DB_USER" -p"$DB_PASS" -e "SELECT COUNT(*) FROM \`$DB_NAME\`.admin_users" 2>/dev/null || echo '?')"
good "Dump ရပြီး — VIP $VIPS ခု · server $SRVS ခု · admin $ADMS ယောက်"

# ---------------------------------------------------------------- CONFIG
step "2/3 — Config နဲ့ key တွေ ကူးနေတယ်"
cp "$APP_DIR/config/config.php" "$WORK/config.php"

ENC_KEY="$(php -r '$c=@include $argv[1]; echo is_array($c)?($c["security"]["encryption_key"]??""):"";' "$APP_DIR/config/config.php")"
{
  echo "N4 Core VPN — VPS အဟောင်းက key တွေ"
  echo "ယူတဲ့ရက် : $(date)"
  echo "VPS အဟောင်း IP : $(curl -s -m 5 ifconfig.me 2>/dev/null || echo 'မသိ')"
  echo "=================================================="
  echo
  echo "VPS အသစ်မှာ installer က မေးရင် ဒီတန်ဖိုးကို ထည့်ပါ:"
  echo
  echo "encryption_key = $ENC_KEY"
  echo
  echo "⚠️ ဒါမပါရင် VIP access code တွေ ပြန်မဖတ်နိုင်တော့ပါ။"
  echo
  echo "Data အခြေအနေ: VIP $VIPS ခု · server $SRVS ခု · admin $ADMS ယောက်"
} > "$WORK/KEYS.txt"
good "encryption_key သိမ်းပြီး"

# ---------------------------------------------------------------- PACK
step "3/3 — ထုပ်နေတယ်"
tar -czf "$OUT" -C "$(dirname "$WORK")" "$(basename "$WORK")" \
  || die "tar မအောင်မြင်ပါ"
chmod 600 "$OUT"
rm -rf "$WORK"
SIZE="$(du -h "$OUT" | cut -f1)"
good "ပြီးပါပြီ — $OUT ($SIZE)"

echo
echo "${G}${BD}════════════════════════════════════════════════${N}"
echo "${G}${BD}  ✅ Backup ရပြီးပါပြီ${N}"
echo "${G}${BD}════════════════════════════════════════════════${N}"
echo
echo "  ဖိုင် : ${BD}$OUT${N}"
echo "  Data : VIP $VIPS ခု · server $SRVS ခု · admin $ADMS ယောက်"
echo
echo "${BD}နောက်တစ်ဆင့် — ကိုယ့်စက်ကို ဒေါင်းပါ${N}"
echo
echo "    scp root@$(curl -s -m 5 ifconfig.me 2>/dev/null || echo 'OLD_VPS_IP'):$OUT ."
echo
echo "  ${Y}ဒီဖိုင် ကိုယ့်စက်ရောက်မှ VPS အဟောင်းကို ဖျက်ပါ။${N}"
echo
