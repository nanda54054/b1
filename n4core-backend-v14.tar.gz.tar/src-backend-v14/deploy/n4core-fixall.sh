#!/usr/bin/env bash
# =============================================================================
#  N4 Core VPN — ALL FIX (one click)
# -----------------------------------------------------------------------------
#  VPS ရှိပြီးသား၊ အလုပ်လုပ်နေတဲ့ အခြေအနေမှာ security fix အကုန် တင်ပေးတယ်။
#
#  လုပ်သွားမယ့်အဆင့် —
#    ၁။ Backup ယူတယ် (config + DB) — မှားရင် ပြန်ရုပ်လို့ ရအောင်
#    ၂။ ဖိုင်တွေ တင်တယ်  → n4core-apply-v23.sh
#       (core/DeviceAuth.php + core/RateLimiter.php အသစ် ဒီအဆင့်မှာ ရောက်တယ်)
#    ၃။ Security hardening → n4core-secure.sh
#       (cert pin + HSTS + rate limit + plaintext code ဖျက်)
#    ၄။ အားလုံး တကယ်ရမရ ပြန်စစ်တယ်
#
#  USAGE
#      sudo bash deploy/n4core-fixall.sh
#      sudo bash deploy/n4core-fixall.sh <cert-sha256>
#      sudo bash deploy/n4core-fixall.sh <cert-sha256> <play-cert-sha256>
#      sudo bash deploy/n4core-fixall.sh --no-pin      # cert pin မဖွင့်ဘူး
#
#  ⚠️ အရေးကြီး —
#     cert pin ဖွင့်ရင် pin မကိုက်တဲ့ APK အားလုံး register မရတော့ဘူး။
#     ဒါကြောင့် App build 8 ကို အရင် ဖြန့်ပြီးမှ pin ဖွင့်ပါ။
#     မသေချာရင် --no-pin နဲ့ run ပါ — ကျန်တာ အကုန် ရမယ်။
# =============================================================================
set -uo pipefail

RED=$'\033[31m'; GRN=$'\033[32m'; YLW=$'\033[33m'; CYN=$'\033[36m'
DIM=$'\033[2m'; BD=$'\033[1m'; RST=$'\033[0m'
ok()   { echo "  ${GRN}✅${RST} $*"; }
info() { echo "  ${CYN}•${RST}  $*"; }
warn() { echo "  ${YLW}⚠${RST}  $*"; }
err()  { echo "  ${RED}❌${RST} $*" >&2; }
head1(){ echo; echo "${CYN}${BD}━━━ $* ━━━${RST}"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$(dirname "$SCRIPT_DIR")"
APP_DIR="${N4_APP_DIR:-/var/www/n4core}"
NO_PIN=0
HASH1=""
HASH2=""

while [ $# -gt 0 ]; do
  case "$1" in
    --no-pin)  NO_PIN=1 ;;
    --app-dir) shift; APP_DIR="${1:-}" ;;
    -h|--help) sed -n '2,28p' "$0"; exit 0 ;;
    *)
      if   [ -z "$HASH1" ]; then HASH1="$1"
      elif [ -z "$HASH2" ]; then HASH2="$1"
      else err "argument အလွန်များ: $1"; exit 1; fi
      ;;
  esac
  shift
done
APP_DIR="${APP_DIR%/}"

echo
echo "${CYN}══════════════════════════════════════════════════${RST}"
echo "${CYN}${BD}  N4 Core VPN — ALL FIX (security)${RST}"
echo "${CYN}══════════════════════════════════════════════════${RST}"
echo

[ "$(id -u)" -eq 0 ] || { err "root နဲ့ run ပါ:  sudo bash $0"; exit 1; }
[ -f "$APP_DIR/config/config.php" ] || {
  err "config.php မတွေ့ပါ: $APP_DIR/config/config.php"
  echo "     VPS မှာ panel မတင်ရသေးရင် ဒါကို သုံးပါ:"
  echo "     ${DIM}sudo bash deploy/n4core-rescue.sh <domain> <backup-file>${RST}"
  exit 1
}
[ -f "$SCRIPT_DIR/n4core-apply-v23.sh" ] || { err "n4core-apply-v23.sh မတွေ့ပါ"; exit 1; }
[ -f "$SCRIPT_DIR/n4core-secure.sh" ]    || { err "n4core-secure.sh မတွေ့ပါ"; exit 1; }

# SRC ထဲ fix ဖိုင်တွေ တကယ် ပါမပါ အရင်စစ် — ပါမှ ဆက်လုပ်တာ အကျိုးရှိတယ်
head1 "SRC စစ်နေတယ်"
MISS=0
for f in core/DeviceAuth.php core/RateLimiter.php bin/migrate.php; do
  [ -f "$SRC_DIR/$f" ] || { err "SRC ထဲ မရှိ: $f"; MISS=1; }
done
[ "$MISS" -eq 0 ] || { err "SRC မပြည့်စုံဘူး — zip ကို ပြန် extract ပါ"; exit 1; }

grep -q "registrationKey" "$SRC_DIR/core/DeviceAuth.php" \
  && ok "DeviceAuth.php အသစ် (cert-derived key ပါတယ်)" \
  || { err "DeviceAuth.php က အဟောင်း — SRC မှားနေတယ်"; exit 1; }
grep -q "device_reg_global" "$SRC_DIR/core/DeviceAuth.php" \
  && ok "Rate-limit fix ပါတယ်" \
  || warn "rate-limit fix မပါဘူး — SRC အဟောင်း ဖြစ်နိုင်တယ်"
grep -q "purge_plain_codes" "$SRC_DIR/bin/migrate.php" \
  && ok "Plaintext code purge ပါတယ်" \
  || warn "purge sweep မပါဘူး"
ok "SRC: $SRC_DIR"
ok "APP: $APP_DIR"

# ============================================================ ၁။ BACKUP
head1 "၁/၄ — Backup ယူနေတယ်"
BK="/root/n4core-fixall-$(date +%F-%H%M%S)"
mkdir -p "$BK" || { err "backup dir မဖန်တီးနိုင်ဘူး"; exit 1; }
cp -p "$APP_DIR/config/config.php" "$BK/config.php.bak"
ok "config.php → $BK/config.php.bak"

PHPBIN="$(command -v php || true)"
if [ -n "$PHPBIN" ] && command -v mysqldump >/dev/null 2>&1; then
  DBN="$("$PHPBIN" -r '$c=@include $argv[1]; echo is_array($c)?($c["db"]["name"]??""):"";' "$APP_DIR/config/config.php" 2>/dev/null)"
  DBU="$("$PHPBIN" -r '$c=@include $argv[1]; echo is_array($c)?($c["db"]["user"]??""):"";' "$APP_DIR/config/config.php" 2>/dev/null)"
  DBP="$("$PHPBIN" -r '$c=@include $argv[1]; echo is_array($c)?($c["db"]["pass"]??""):"";' "$APP_DIR/config/config.php" 2>/dev/null)"
  if [ -n "$DBN" ] && mysqldump --single-transaction --default-character-set=utf8mb4 \
       -u"$DBU" -p"$DBP" "$DBN" > "$BK/db.sql" 2>/dev/null \
     && grep -q "CREATE TABLE" "$BK/db.sql"; then
    chmod 600 "$BK/db.sql"
    ok "DB dump → $BK/db.sql ($(du -h "$BK/db.sql" | cut -f1))"
  else
    rm -f "$BK/db.sql"
    warn "DB dump မရ — ဖိုင် backup ကတော့ ရပြီးသား"
  fi
else
  warn "mysqldump မရှိ — DB backup ခုန်လိုက်တယ်"
fi

# ============================================================ ၂။ APPLY
head1 "၂/၄ — ဖိုင်တွေ တင်နေတယ်"
if bash "$SCRIPT_DIR/n4core-apply-v23.sh" --src "$SRC_DIR" --app-dir "$APP_DIR"; then
  ok "apply ပြီး"
else
  err "apply မအောင်မြင်ဘူး — apply script ကိုယ်တိုင် rollback လုပ်ပြီးသား"
  echo "     ${DIM}config.php ပြန်ရုပ်ချင်ရင်: cp $BK/config.php.bak $APP_DIR/config/config.php${RST}"
  exit 1
fi

# DeviceAuth တကယ်ရောက်မရောက် — ဒါက ဒီ script ရဲ့ အဓိကရည်ရွယ်ချက်
if grep -q "registrationKey" "$APP_DIR/core/DeviceAuth.php" 2>/dev/null; then
  ok "DeviceAuth.php အသစ် VPS ပေါ် ရောက်ပြီ"
else
  err "DeviceAuth.php မရောက်ဘူး — apply script ရဲ့ FILES စာရင်း စစ်ပါ"
  exit 1
fi

# ---- ပြင်ပြီးမှ ကျန်နေတဲ့ rate-limit block ကို ရှင်းတယ် ----------------
#
# ဆာဗာဘက် အမှားကြောင့် register မရဘဲ ရှိနေတုန်း app က ထပ်ခါထပ်ခါ
# ကြိုးစားတယ်။ အဲ့ဒါက limiter ကို ဖြည့်တယ် —
#
#     device_reg     ၅ ကြိမ်/နာရီ  →  ၁ နာရီ ပိတ်  (IP အလိုက်)
#     device_reg_id  ၈ ကြိမ်/နာရီ  →  ၁ နာရီ ပိတ်  (device အလိုက်)
#
# အမှားကို ပြင်ပြီးရင်တောင် အဲ့ block က ကျန်နေသေးတယ်။ App မှာ အရင်
# အတိုင်း "could not verify itself" ပဲ ပြတော့ ပြင်တာ မအောင်မြင်သလို
# ထင်ရပြီး ဆာဗာကို ထပ်ပြင်မိတယ် — တကယ်က ဆာဗာ ကောင်းနေပြီးသား။
#
# ဒါကြောင့် ဖိုင်တင်ပြီးတိုင်း registration block ကို ရှင်းတယ်။ limiter
# က နောက်တခါ request ဝင်ရင် သုညကနေ ပြန်ရေတွက်တာမို့ ဘာမှ မလျော့ဘူး။
# admin_login စတဲ့ တခြား bucket တွေကို မထိဘူး။
if [ -n "$PHPBIN" ] && [ -f "$APP_DIR/bin/unblock.php" ]; then
  if ( cd "$APP_DIR" && "$PHPBIN" bin/unblock.php --device-reg ); then
    ok "registration rate-limit block ရှင်းပြီး"
  else
    warn "unblock မရ — လက်နဲ့: cd $APP_DIR && php bin/unblock.php --device-reg"
  fi
fi

# ============================================================ ၃။ SECURE
head1 "၃/၄ — Security hardening"
SECARGS=( --app-dir "$APP_DIR" )
if [ "$NO_PIN" -eq 1 ]; then
  warn "--no-pin — cert pin မဖွင့်ဘူး (App အသစ် မဖြန့်ရသေးရင် ဒါ မှန်တယ်)"
elif [ -n "$HASH1" ]; then
  SECARGS+=( "$HASH1" )
  [ -n "$HASH2" ] && SECARGS+=( "$HASH2" )
fi

if bash "$SCRIPT_DIR/n4core-secure.sh" "${SECARGS[@]}"; then
  ok "hardening ပြီး"
else
  warn "hardening မှာ အချက်တချို့ မရ — အထက်က မှတ်ချက်တွေ ကြည့်ပါ"
  warn "ဖိုင်တွေတော့ တင်ပြီးသား ဖြစ်တာမို့ app က အလုပ်လုပ်နေမယ်"
fi

# ============================================================ ၄။ VERIFY
head1 "၄/၄ — အနှစ်ချုပ်"

DOMAIN=""
if [ -n "$PHPBIN" ]; then
  DOMAIN="$("$PHPBIN" -r '
    $c = @include $argv[1];
    if (!is_array($c)) { exit; }
    $u = (string)($c["app"]["base_url"] ?? $c["app"]["url"] ?? "");
    echo $u !== "" ? parse_url($u, PHP_URL_HOST) : "";
  ' "$APP_DIR/config/config.php" 2>/dev/null || true)"
fi

# config.php ထဲ base_url / url key က မရှိဘူး၊ config.sample.php ထဲမှာလည်း
# မပါဘူး — ဒါကြောင့် အပေါ် PHP က အမြဲ အလွတ် ပြန်တယ်။ n4core-secure.sh
# မှာ ဒါကို ပြင်ခဲ့ပြီးပေမယ့် ဒီဖိုင်မှာ ကျန်နေတယ်၊ အဲ့ဒါဆို အောက်က
# "app က တကယ် အလုပ်လုပ်နေလား" စစ်ချက် — ဒီ script တခုလုံးထဲက အရေး
# အကြီးဆုံးအပိုင်း — အမြဲ ခုန်ကျော်ခံနေတယ်။ HTTP 500 ဖြစ်နေတာကို
# မတွေ့ရဘဲ "✅ ALL FIX ပြီးပါပြီ" ပြခဲ့တာ ဒါကြောင့်ပဲ။
if [ -z "$DOMAIN" ] && [ -n "${N4_DOMAIN:-}" ]; then
  DOMAIN="$N4_DOMAIN"
fi
if [ -z "$DOMAIN" ]; then
  # APP_DIR ကို root အဖြစ် ထားတဲ့ nginx vhost ထဲက server_name
  for nf in /etc/nginx/sites-enabled/* /etc/nginx/sites-available/* \
            /etc/nginx/conf.d/*.conf; do
    [ -f "$nf" ] || continue
    grep -q "$APP_DIR" "$nf" 2>/dev/null || continue
    DOMAIN="$(grep -hoE '^[[:space:]]*server_name[[:space:]]+[^;]+' "$nf" 2>/dev/null \
             | head -1 | awk '{print $2}' | tr -d ' ')"
    case "$DOMAIN" in ""|_|localhost) DOMAIN="" ;; esac
    [ -n "$DOMAIN" ] && break
  done
fi
if [ -z "$DOMAIN" ]; then
  DOMAIN="$(grep -rhoE '^[[:space:]]*server_name[[:space:]]+[^;]+' \
            /etc/nginx/sites-enabled/ /etc/nginx/conf.d/ 2>/dev/null \
            | awk '{print $2}' | grep -E '^[a-z0-9.-]+\.[a-z]{2,}$' \
            | grep -v localhost | head -1)"
fi

# =============================================================== SELFTEST
#
# ဒါက တခုလုံးထဲက အရေးအကြီးဆုံး အပိုင်း။
#
# အရင်က ဒီနေရာမှာ locations.php ကို HTTP code ပဲ ကြည့်ခဲ့တယ်၊ 401 ကို
# "ok" လို့ သတ်မှတ်ခဲ့တယ်။ ဒါပေမဲ့ device auth ပျက်နေရင်လည်း 401 ပဲ
# ပြန်တယ် — ဒါကြောင့် server ပျက်နေတဲ့အခါတိုင်း ဒီ script က
# "✅ API တုံ့ပြန်နေတယ် — app အလုပ်လုပ်နေမယ်" ဆိုပြီး အစိမ်းပြခဲ့တယ်။
# ဖုန်းမှာ မရဘဲ script က ok ပြတဲ့ loop က ဒါကနေ လာတယ်။
#
# အခု တကယ့် register + signed request ကို ဖုန်းလုပ်တဲ့အတိုင်း စမ်းတယ်။
SELFTEST_RC=0
if [ -n "$PHPBIN" ] && [ -f "$APP_DIR/bin/selftest.php" ] && [ -n "$DOMAIN" ]; then
  head1 "စစ်ဆေးမှု — တကယ့် device register စမ်းနေတယ်"
  set +e
  ( cd "$APP_DIR" && N4_DOMAIN="$DOMAIN" "$PHPBIN" bin/selftest.php "$DOMAIN" )
  SELFTEST_RC=$?
  set -e
  if [ "$SELFTEST_RC" -ne 0 ]; then
    echo "     ${DIM}ပြန်ရုပ်: cp $BK/config.php.bak $APP_DIR/config/config.php${RST}"
  fi
elif [ -n "$DOMAIN" ]; then
  SRV="$(curl -s -m 10 -o /dev/null -w '%{http_code}' \
    "https://$DOMAIN/api/public/locations.php" 2>/dev/null || echo "000")"
  info "API HTTP $SRV (selftest.php မရှိလို့ အပြည့်အစုံ မစစ်နိုင်ဘူး)"
else
  warn "domain မရှာနိုင် — selftest ခုန်မယ်"
  warn "  → sudo N4_DOMAIN=core.nandaxr.tech bash $0"
fi

echo
if [ "$SELFTEST_RC" -eq 0 ]; then
  echo "${GRN}══════════════════════════════════════════════════${RST}"
  echo "${GRN}${BD}  ✅ ALL FIX ပြီးပါပြီ${RST}"
  echo "${GRN}══════════════════════════════════════════════════${RST}"
else
  # အမှား ရှိရင် အစိမ်း မပြဘူး — ဒါက အရင် ပြဿနာရဲ့ အရင်းအမြစ်။
  echo "${RED}══════════════════════════════════════════════════${RST}"
  echo "${RED}${BD}  ❌ ဖိုင်တွေ တင်ပြီး — ဒါပေမဲ့ server မအောင်သေးဘူး${RST}"
  echo "${RED}══════════════════════════════════════════════════${RST}"
  echo
  echo "  အပေါ်က ❌ ကို ပြင်ပြီး ဒါ ပြန် run ပါ:"
  echo "    ${DIM}cd $APP_DIR && sudo php bin/selftest.php${RST}"
fi
echo
echo "  ${BD}Backup${RST} : $BK"
echo "  ${BD}ပြန်ရုပ်${RST} : ${DIM}cp $BK/config.php.bak $APP_DIR/config/config.php${RST}"
[ -f "$BK/db.sql" ] && echo "            ${DIM}mysql -u<user> -p<pass> <db> < $BK/db.sql${RST}"
echo
echo "  ${BD}ပြန်စစ်ချင်ရင်${RST}"
echo "    ${DIM}sudo bash $SCRIPT_DIR/n4core-secure.sh --check${RST}"
echo
if [ "$NO_PIN" -eq 1 ] || [ -z "$HASH1" ]; then
  echo "  ${YLW}Cert pin မဖွင့်ရသေးဘူး။${RST} App build 8 ဖြန့်ပြီးရင် ဒါ run ပါ:"
  echo "    ${DIM}sudo bash $SCRIPT_DIR/n4core-secure.sh 1490631129b09f523c3caa339617b6de1b404015827fee6fd1e8d44b0824fdfe${RST}"
  echo
fi

# selftest ကျရင် exit code နဲ့ ပြန်ပြောရမယ်။ ဒါမလုပ်ရင် ဒီ script က ❌ ပြပြီးမှ
# exit 0 ပြန်တယ်၊ ဒါဆို ခေါ်တဲ့ n4core-go.sh က "✅ GO ပြီးပါပြီ" ဆိုပြီး
# အပေါ်မှာ ပြခဲ့တဲ့ အမှားကို ဖုံးလိုက်တယ် — အစိမ်းလိမ်တဲ့ ပြဿနာ အတိအကျ
# ပြန်ဖြစ်တာ။
exit "$SELFTEST_RC"
