#!/usr/bin/env bash
#
# ============================================================================
#  N4 Core VPN — Domain / VPS Switcher
# ============================================================================
#  Domain အသစ် ဒါမှမဟုတ် VPS အသစ် ပြောင်းချိန် လိုအပ်တဲ့ အလုပ်အားလုံးကို
#  တစ်ခါတည်း လုပ်ပေးတယ်။ Flutter app source ကို လုံးဝ မထိပါ။
#
#  USAGE
#     sudo ./n4core-domain.sh core.newdomain.com
#     sudo ./n4core-domain.sh core.newdomain.com --ssl        (certbot ပါ ထုတ်)
#     sudo ./n4core-domain.sh core.newdomain.com --dry-run    (စမ်းကြည့်ရုံ)
#     sudo ./n4core-domain.sh --show                          (လက်ရှိအခြေအနေ)
#
#  ဘာလုပ်သလဲ
#     1. nginx vhost အသစ် ရေး (server_name + SSL + php-fpm socket auto-detect)
#     2. config/config.php ထဲ cors.allowed_origins ပြောင်း
#     3. Telegram webhook ကို domain အသစ်နဲ့ ပြန် register
#     4. GitHub n4core-config.json မှာ ထည့်ရမယ့် JSON ကို ပြပေး
#     5. Health check အကုန် ပြန်စစ်
#
#  လုပ်တာမှန်သမျှ backup အရင်ယူတယ် — /root/n4core-domain-backup-<ရက်စွဲ>/
# ============================================================================

set -uo pipefail

# ---------------------------------------------------------------- ဆေးဆို
APP_DIR="${N4_APP_DIR:-/var/www/n4core}"
NGINX_SITE="/etc/nginx/sites-available/n4core.conf"
NGINX_LINK="/etc/nginx/sites-enabled/n4core.conf"
STAMP="$(date +%F-%H%M%S)"
BACKUP_DIR="/root/n4core-domain-backup-${STAMP}"

DRY_RUN=0
DO_SSL=0
SHOW_ONLY=0
NEW_DOMAIN=""

# ---------------------------------------------------------------- အရောင်
if [ -t 1 ]; then
  R=$'\e[31m'; G=$'\e[32m'; Y=$'\e[33m'; B=$'\e[34m'; C=$'\e[36m'; W=$'\e[1m'; N=$'\e[0m'
else
  R=""; G=""; Y=""; B=""; C=""; W=""; N=""
fi

say()  { printf '%s\n' "$*"; }
ok()   { printf '%s✅ %s%s\n' "$G" "$*" "$N"; }
warn() { printf '%s⚠️  %s%s\n' "$Y" "$*" "$N"; }
err()  { printf '%s❌ %s%s\n' "$R" "$*" "$N" >&2; }
step() { printf '\n%s%s▸ %s%s\n' "$W" "$B" "$*" "$N"; }
info() { printf '   %s\n' "$*"; }

die() { err "$*"; exit 1; }

hr() { printf '%s────────────────────────────────────────────────────────────%s\n' "$C" "$N"; }

run() {
  if [ "$DRY_RUN" = 1 ]; then
    printf '   %s[dry-run]%s %s\n' "$Y" "$N" "$*"
    return 0
  fi
  "$@"
}

# ---------------------------------------------------------------- arg ဖတ်
while [ $# -gt 0 ]; do
  case "$1" in
    --ssl)      DO_SSL=1 ;;
    --dry-run)  DRY_RUN=1 ;;
    --show)     SHOW_ONLY=1 ;;
    --app-dir)  shift; APP_DIR="${1:-}" ;;
    -h|--help)  sed -n '3,30p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    -*)         die "မသိသော option: $1  (--help ကြည့်ပါ)" ;;
    *)          NEW_DOMAIN="$1" ;;
  esac
  shift
done

# ---------------------------------------------------------------- စစ်ဆေး
[ "$(id -u)" = "0" ] || die "root အနေနဲ့ run ရမယ်:  sudo $0 ..."
[ -d "$APP_DIR" ]    || die "App directory မတွေ့: $APP_DIR   (--app-dir နဲ့ သတ်မှတ်ပါ)"
[ -f "$APP_DIR/config/config.php" ] || die "config/config.php မတွေ့ — install အရင်လုပ်ပါ"

# php-fpm socket ကို အလိုအလျောက် ရှာ
detect_fpm_socket() {
  local s
  # အသုံးပြုနေတဲ့ socket ကို အရင်ကြည့်
  for s in /run/php/php*-fpm.sock; do
    [ -S "$s" ] && { printf '%s' "$s"; return 0; }
  done
  # မတွေ့ရင် PHP version ကနေ မှန်း
  local v
  v="$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null || true)"
  [ -n "$v" ] && printf '/run/php/php%s-fpm.sock' "$v" && return 0
  return 1
}

# config.php ကနေ တန်ဖိုးဖတ် (PHP ကိုယ်တိုင် ဖတ်ခိုင်း — regex မလုံခြုံ)
cfg() {
  php -r '
    $c = require "'"$APP_DIR"'/config/config.php";
    $k = explode(".", $argv[1]); $v = $c;
    foreach ($k as $p) { if (!is_array($v) || !array_key_exists($p,$v)) { echo ""; exit; } $v = $v[$p]; }
    if (is_bool($v)) { echo $v ? "true" : "false"; }
    elseif (is_array($v)) { echo implode(",", $v); }
    else { echo (string) $v; }
  ' "$1" 2>/dev/null
}

FPM_SOCK="$(detect_fpm_socket || true)"
PHP_VER="$(php -r 'echo PHP_VERSION;' 2>/dev/null || echo '?')"

# ---------------------------------------------------------------- --show
current_domain() {
  local d=""
  if [ -f "$NGINX_SITE" ]; then
    d="$(grep -m1 -oP 'server_name\s+\K[^;]+' "$NGINX_SITE" 2>/dev/null | awk '{print $1}')"
  fi
  printf '%s' "$d"
  [ -n "$d" ]
}

# systemctl is-active က inactive ဖြစ်ရင် စာရေးပြီး exit code မှားထွက်တာမို့
# output တစ်ခုတည်း ရအောင် ဒီ wrapper ကို သုံးတယ်။
svc_state() {
  local st
  st="$(systemctl is-active "$1" 2>/dev/null)"
  printf '%s' "${st:-unknown}"
}

# ဗလာ ဖြစ်ရင် အစားထိုးစာ ပြပေးရန်
or_else() { [ -n "$1" ] && printf '%s' "$1" || printf '%s' "$2"; }

show_state() {
  hr
  printf '%s N4 Core — လက်ရှိအခြေအနေ%s\n' "$W" "$N"
  hr
  info "App directory   : $APP_DIR"
  info "PHP version     : $PHP_VER"
  info "PHP-FPM socket  : ${FPM_SOCK:-${R}မတွေ့${N}}"
  info "လက်ရှိ domain    : $(or_else "$(current_domain)" 'မသတ်မှတ်ရသေး')"
  info "Brand           : $(cfg app.brand)"
  info "Timezone        : $(cfg app.timezone)"
  info "DB              : $(cfg db.user)@$(cfg db.host):$(cfg db.port)/$(cfg db.name)"
  info "Telegram owner  : $(cfg telegram.owner_id)"
  info "CORS origins    : $(or_else "$(cfg cors.allowed_origins)" '(same-origin သာ)')"
  echo
  info "nginx vhost     : $([ -f "$NGINX_SITE" ] && echo "$NGINX_SITE" || echo 'မရှိ')"
  info "nginx enabled   : $([ -L "$NGINX_LINK" ] && echo 'yes' || echo 'no')"
  info "nginx service   : $(svc_state nginx)"
  info "php-fpm service : $(svc_state "php${PHP_VER%.*}-fpm")"
  echo
  if [ -x "$APP_DIR/bin/setup_webhook.php" ] || [ -f "$APP_DIR/bin/setup_webhook.php" ]; then
    info "Telegram webhook:"
    sudo -u www-data php "$APP_DIR/bin/setup_webhook.php" --info 2>/dev/null \
      | grep -E 'Bot|Webhook|Pending|Last error' | sed 's/^/     /' || info "     (ဖတ်လို့မရ)"
  fi
  hr
}

if [ "$SHOW_ONLY" = 1 ]; then
  show_state
  exit 0
fi

[ -n "$NEW_DOMAIN" ] || { show_state; echo; die "Domain အသစ် ထည့်ပါ:  sudo $0 core.newdomain.com"; }

# domain ပုံစံ စစ်
case "$NEW_DOMAIN" in
  http://*|https://*) NEW_DOMAIN="${NEW_DOMAIN#*://}"; NEW_DOMAIN="${NEW_DOMAIN%%/*}" ;;
esac
printf '%s' "$NEW_DOMAIN" | grep -qE '^[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$' \
  || die "Domain ပုံစံ မမှန်: $NEW_DOMAIN"

OLD_DOMAIN="$(current_domain)" || OLD_DOMAIN=""

# ============================================================================
#  အတည်ပြုချက်
# ============================================================================
hr
printf '%s N4 Core VPN — Domain ပြောင်းခြင်း%s\n' "$W" "$N"
hr
info "လက်ရှိ domain : ${OLD_DOMAIN:-（မရှိ）}"
printf '   %sdomain အသစ်   : %s%s\n' "$G$W" "$NEW_DOMAIN" "$N"
info "App directory : $APP_DIR"
info "PHP-FPM       : ${FPM_SOCK:-မတွေ့}"
info "SSL (certbot) : $([ "$DO_SSL" = 1 ] && echo 'ထုတ်မယ်' || echo 'မထုတ်ဘူး (--ssl ထည့်ရင် ထုတ်မယ်)')"
[ "$DRY_RUN" = 1 ] && printf '   %sMODE          : DRY RUN — ဘာမှ တကယ် မပြောင်းပါ%s\n' "$Y$W" "$N"
hr

if [ "$DRY_RUN" = 0 ]; then
  printf '%sဆက်လုပ်မလား? [y/N] %s' "$W" "$N"
  read -r reply
  case "$reply" in [yY]|[yY][eE][sS]) ;; *) say "ရပ်လိုက်ပါတယ်။"; exit 0 ;; esac
fi

[ -n "$FPM_SOCK" ] || die "php-fpm socket မတွေ့ပါ။ 'systemctl status php*-fpm' နဲ့ စစ်ပါ။"

# ============================================================================
#  ၁။ Backup
# ============================================================================
step "၁/၇  လက်ရှိ setting များ backup ယူခြင်း"
run mkdir -p "$BACKUP_DIR"
[ -f "$NGINX_SITE" ] && run cp -a "$NGINX_SITE" "$BACKUP_DIR/n4core.conf"
run cp -a "$APP_DIR/config/config.php" "$BACKUP_DIR/config.php"
run chmod 600 "$BACKUP_DIR"/* 2>/dev/null || true
ok "Backup: $BACKUP_DIR"
info "ပြန်လိုရင်:  cp $BACKUP_DIR/n4core.conf $NGINX_SITE && systemctl reload nginx"

# ============================================================================
#  ၂။ nginx vhost အသစ် ရေး
# ============================================================================
step "၂/၇  nginx vhost ရေးခြင်း"

SSL_DIR="/etc/letsencrypt/live/${NEW_DOMAIN}"
HAS_CERT=0
[ -f "${SSL_DIR}/fullchain.pem" ] && HAS_CERT=1

write_vhost() {
  local tmp
  tmp="$(mktemp)"

  if [ "$HAS_CERT" = 1 ]; then
    # ---- HTTPS ပါတဲ့ ပုံစံ ----
    cat > "$tmp" <<EOF
# N4 Core VPN — nginx vhost
# n4core-domain.sh က ${STAMP} မှာ ထုတ်ပေးထားသည်။ လက်နဲ့ ပြင်ရင် စာမပျက်ရန် သတိထားပါ။

server {
    listen 80;
    listen [::]:80;
    server_name ${NEW_DOMAIN};

    # certbot ရဲ့ renew challenge ကို HTTP မှာ ဖြေရမယ်
    location /.well-known/acme-challenge/ { root /var/www/html; }

    location / { return 301 https://\$host\$request_uri; }
}

server {
    listen 443 ssl;
    listen [::]:443 ssl;
    http2 on;
    server_name ${NEW_DOMAIN};

    ssl_certificate     ${SSL_DIR}/fullchain.pem;
    ssl_certificate_key ${SSL_DIR}/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 1d;

    root ${APP_DIR};
    index index.php index.html;

    client_max_body_size 8m;
    server_tokens off;

    add_header X-Content-Type-Options nosniff always;
    add_header X-Frame-Options SAMEORIGIN always;
    add_header Referrer-Policy no-referrer always;
    add_header Strict-Transport-Security "max-age=31536000" always;

    # ---- HARD BLOCK: source / secret / dump / backup များ မထုတ်ရ ----
    location ~ ^/(config|core|sql|storage|bin|deploy|docs|dl)/ { deny all; return 404; }
    location ~ \.(sql|log|enc|gz|md|sh|ini|bak|tar)\$          { deny all; return 404; }

    # ---- Admin dashboard (static) ----
    location /admin/ { try_files \$uri \$uri/ /admin/index.html; }

    # ---- API ----
    location /api/ { try_files \$uri =404; }

    location ~ \.php\$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:${FPM_SOCK};
        fastcgi_read_timeout 180;
    }

    location = / { return 302 /admin/; }
}
EOF
  else
    # ---- HTTP သာ (certbot မရသေးချိန် ခေတ္တ) ----
    cat > "$tmp" <<EOF
# N4 Core VPN — nginx vhost (HTTP only — certbot မရသေး)
# n4core-domain.sh က ${STAMP} မှာ ထုတ်ပေးထားသည်။
# SSL ရပြီးလျှင်:  sudo $0 ${NEW_DOMAIN} --ssl

server {
    listen 80;
    listen [::]:80;
    server_name ${NEW_DOMAIN};

    location /.well-known/acme-challenge/ { root /var/www/html; }

    root ${APP_DIR};
    index index.php index.html;

    client_max_body_size 8m;
    server_tokens off;

    add_header X-Content-Type-Options nosniff always;
    add_header X-Frame-Options SAMEORIGIN always;
    add_header Referrer-Policy no-referrer always;

    location ~ ^/(config|core|sql|storage|bin|deploy|docs|dl)/ { deny all; return 404; }
    location ~ \.(sql|log|enc|gz|md|sh|ini|bak|tar)\$          { deny all; return 404; }

    location /admin/ { try_files \$uri \$uri/ /admin/index.html; }
    location /api/   { try_files \$uri =404; }

    location ~ \.php\$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:${FPM_SOCK};
        fastcgi_read_timeout 180;
    }

    location = / { return 302 /admin/; }
}
EOF
  fi

  if [ "$DRY_RUN" = 1 ]; then
    printf '   %s[dry-run]%s vhost အောက်ပါအတိုင်း ရေးမည် → %s\n' "$Y" "$N" "$NGINX_SITE"
    sed 's/^/     /' "$tmp" | head -20
    info "     … (စာလုံး $(wc -l < "$tmp") ကြောင်း)"
    rm -f "$tmp"
    return 0
  fi

  install -m 0644 "$tmp" "$NGINX_SITE"
  rm -f "$tmp"
}

write_vhost
[ "$HAS_CERT" = 1 ] && ok "vhost ရေးပြီး (HTTPS + HTTP redirect)" || warn "vhost ရေးပြီး (HTTP သာ — SSL မရသေး)"

# ---- ထပ်နေတဲ့ vhost တွေ ရှင်း (conflicting server name error ကာကွယ်) ----
step "၂b   ထပ်နေသော vhost များ စစ်ခြင်း"
CONFLICT=0
for f in /etc/nginx/sites-enabled/*; do
  [ -e "$f" ] || continue
  [ "$(readlink -f "$f")" = "$(readlink -f "$NGINX_SITE")" ] && continue
  if grep -qE "server_name[[:space:]]+.*\b${NEW_DOMAIN}\b" "$f" 2>/dev/null; then
    warn "ထပ်နေသည်: $f  ($NEW_DOMAIN ကို ဒီမှာလည်း သတ်မှတ်ထား)"
    run mv "$f" "${f}.disabled-${STAMP}"
    info "→ ${f}.disabled-${STAMP} အဖြစ် ပိတ်လိုက်ပါတယ်"
    CONFLICT=1
  fi
done
# default vhost က port 80 ကို ကိုင်နေရင် သတိပေး
if [ -L /etc/nginx/sites-enabled/default ] || [ -f /etc/nginx/sites-enabled/default ]; then
  warn "nginx 'default' vhost ရှိနေတယ် — ပြဿနာဖြစ်ရင် ဒါကို ပိတ်ပါ:"
  info "   sudo rm /etc/nginx/sites-enabled/default && sudo systemctl reload nginx"
fi
[ "$CONFLICT" = 0 ] && ok "ထပ်နေတာ မရှိပါ"

# ---- symlink ----
if [ ! -L "$NGINX_LINK" ]; then
  run ln -sfn "$NGINX_SITE" "$NGINX_LINK"
  ok "sites-enabled ထဲ link ထည့်ပြီး"
else
  ok "sites-enabled ထဲ link ရှိပြီးသား"
fi

# ============================================================================
#  ၃။ config.php ထဲ CORS origin ပြောင်း
# ============================================================================
step "၃/၇  config.php ထဲ CORS origin ပြောင်းခြင်း"

SCHEME="http"
[ "$HAS_CERT" = 1 ] && SCHEME="https"
NEW_ORIGIN="${SCHEME}://${NEW_DOMAIN}"

if [ "$DRY_RUN" = 1 ]; then
  printf '   %s[dry-run]%s cors.allowed_origins → %s\n' "$Y" "$N" "$NEW_ORIGIN"
else
  php <<PHPEOF
<?php
\$file = '${APP_DIR}/config/config.php';
\$src  = file_get_contents(\$file);
\$new  = '${NEW_ORIGIN}';

// allowed_origins array ကို ရှာပြီး domain အသစ်နဲ့ အစားထိုး။
// Comment တွေ format တွေ မပျက်အောင် targeted replace သာ လုပ်တယ်။
\$pattern = "/('allowed_origins'\s*=>\s*\[)(.*?)(\])/s";
if (preg_match(\$pattern, \$src)) {
    \$src = preg_replace_callback(\$pattern, function (\$m) use (\$new) {
        return \$m[1] . "\n            '" . \$new . "',\n        " . \$m[3];
    }, \$src, 1);
    file_put_contents(\$file, \$src);
    echo "   allowed_origins → {\$new}\n";
} else {
    echo "   ⚠️  allowed_origins မတွေ့ — လက်နဲ့ ပြင်ပါ\n";
}

// syntax မပျက်သေးဘူးဆိုတာ အတည်ပြု
\$chk = shell_exec('php -l ' . escapeshellarg(\$file) . ' 2>&1');
if (!str_contains((string) \$chk, 'No syntax errors')) {
    fwrite(STDERR, "   ❌ config.php syntax ပျက်သွားပြီ! backup ကနေ ပြန်ယူပါ\n");
    exit(1);
}
PHPEOF
  [ $? -eq 0 ] || die "config.php ပြင်ရင် ပြဿနာ တင်ပါတယ်။ ပြန်ယူ: cp $BACKUP_DIR/config.php $APP_DIR/config/config.php"
fi
ok "CORS origin သတ်မှတ်ပြီး: $NEW_ORIGIN"

# ============================================================================
#  ၄။ SSL (certbot)
# ============================================================================
step "၄/၇  SSL certificate"

if [ "$DO_SSL" = 1 ] && [ "$HAS_CERT" = 0 ]; then
  if ! command -v certbot >/dev/null 2>&1; then
    warn "certbot မရှိပါ — တင်နေတယ်…"
    run apt-get update -qq
    run apt-get install -y -qq certbot python3-certbot-nginx
  fi

  # HTTP vhost အရင် တင်ထားရမယ် (challenge ဖြေရန်)
  run nginx -t && run systemctl reload nginx

  info "certbot run နေတယ်…"
  if run certbot --nginx -d "$NEW_DOMAIN" --non-interactive --agree-tos \
        --register-unsafely-without-email --redirect; then
    ok "SSL ရပြီး"
    HAS_CERT=1
    # certbot က vhost ကို ပြင်တာမို့ ကိုယ်ရေးတဲ့ ပုံစံနဲ့ ပြန်ရေး (တစ်သတ်မတ်တည်း ဖြစ်ရန်)
    write_vhost
    ok "vhost ကို HTTPS ပုံစံနဲ့ ပြန်ရေးပြီး"
    # CORS ကို https ဖြစ်အောင် ပြန်ပြောင်း
    NEW_ORIGIN="https://${NEW_DOMAIN}"
  else
    warn "certbot မအောင်မြင်ပါ — DNS က VPS ကို ညွှန်ပြီးလား စစ်ပါ"
    info "   dig +short $NEW_DOMAIN     ← VPS IP ထွက်ရမယ်"
  fi
elif [ "$HAS_CERT" = 1 ]; then
  EXP="$(openssl x509 -enddate -noout -in "${SSL_DIR}/fullchain.pem" 2>/dev/null | cut -d= -f2 || echo '?')"
  ok "SSL ရှိပြီးသား (သက်တမ်း: $EXP)"
else
  warn "SSL မရသေး — HTTP သာ အလုပ်လုပ်မယ်"
  info "   Telegram webhook က HTTPS မဖြစ်မနေ လိုတယ်။ SSL ထုတ်ရန်:"
  info "   sudo $0 $NEW_DOMAIN --ssl"
fi

# ============================================================================
#  ၅။ nginx test + reload
# ============================================================================
step "၅/၇  nginx စစ်ပြီး reload"

if [ "$DRY_RUN" = 1 ]; then
  printf '   %s[dry-run]%s nginx -t && systemctl reload nginx\n' "$Y" "$N"
else
  if ! nginx -t 2>&1 | sed 's/^/     /'; then
    err "nginx config မှားနေတယ် — reload မလုပ်ဘူး"
    info "ပြန်ယူ: cp $BACKUP_DIR/n4core.conf $NGINX_SITE && systemctl reload nginx"
    exit 1
  fi
  # port 80 ကို တခြားတစ်ခု ကိုင်နေရင် reload မလုံလောက် — restart လုပ်
  systemctl reload nginx 2>/dev/null || systemctl restart nginx
  sleep 1
  if [ "$(systemctl is-active nginx)" = "active" ]; then
    ok "nginx လည်ပတ်နေပါတယ်"
  else
    err "nginx မတက်ပါ"
    journalctl -u nginx -n 15 --no-pager | sed 's/^/     /'
    exit 1
  fi
fi

# php-fpm လည်း reload (config.php ပြောင်းထားတာမို့ opcache ရှင်းရန်)
FPM_SVC="php$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')-fpm"
run systemctl reload "$FPM_SVC" 2>/dev/null || warn "$FPM_SVC reload မရ (service နာမည် စစ်ပါ)"
ok "PHP-FPM reload ပြီး"

# ============================================================================
#  ၆။ Telegram webhook ပြန် register
# ============================================================================
step "၆/၇  Telegram webhook ပြန်သတ်မှတ်ခြင်း"

if [ "$HAS_CERT" = 1 ]; then
  if [ "$DRY_RUN" = 1 ]; then
    printf '   %s[dry-run]%s php bin/setup_webhook.php https://%s\n' "$Y" "$N" "$NEW_DOMAIN"
  else
    if sudo -u www-data php "$APP_DIR/bin/setup_webhook.php" "https://${NEW_DOMAIN}" 2>&1 | sed 's/^/     /'; then
      ok "Webhook သတ်မှတ်ပြီး"
    else
      warn "Webhook မသတ်မှတ်နိုင်ပါ — အောက်ပါအတိုင်း လက်နဲ့ စမ်းပါ:"
      info "   cd $APP_DIR && sudo -u www-data php bin/setup_webhook.php https://${NEW_DOMAIN}"
    fi
  fi
else
  warn "SSL မရသေးတဲ့အတွက် webhook မသတ်မှတ်နိုင်ပါ (Telegram က HTTPS မဖြစ်မနေ လိုတယ်)"
  info "   ခေတ္တ long-polling နဲ့ သွားနိုင်တယ်:  sudo systemctl start n4core-bot"
fi

# ============================================================================
#  ၇။ Health check
# ============================================================================
step "၇/၇  အလုံးစုံ စစ်ဆေးခြင်း"

if [ "$DRY_RUN" = 1 ]; then
  printf '   %s[dry-run]%s health check များ ကျော်လိုက်ပါတယ်\n' "$Y" "$N"
else
  BASE="${SCHEME}://${NEW_DOMAIN}"
  [ "$HAS_CERT" = 1 ] && BASE="https://${NEW_DOMAIN}"
  PASS=0; FAIL=0

  chk() {
    local label="$1" url="$2" want="$3"
    local got
    got="$(curl -s -o /dev/null -w '%{http_code}' --max-time 12 "$url" 2>/dev/null || echo '000')"
    if printf '%s' "$want" | grep -qw "$got"; then
      printf '   %s✅%s %-34s %s\n' "$G" "$N" "$label" "$got"
      PASS=$((PASS+1))
    else
      printf '   %s❌%s %-34s %s (%s ဖြစ်ရမယ်)\n' "$R" "$N" "$label" "$got" "$want"
      FAIL=$((FAIL+1))
    fi
  }

  chk "Admin dashboard"        "$BASE/admin/"                    "200"
  chk "Public API (plans)"     "$BASE/api/public/plans.php"      "200"
  chk "Root redirect"          "$BASE/"                          "302 301"
  chk "config.php ပိတ်ထားမှု"   "$BASE/config/config.php"         "403 404"
  chk "core/ ပိတ်ထားမှု"        "$BASE/core/Auth.php"             "403 404"
  chk "storage/ ပိတ်ထားမှု"     "$BASE/storage/"                  "403 404"
  chk "sql/ ပိတ်ထားမှု"         "$BASE/sql/schema_v2.sql"         "403 404"

  # API က JSON မှန်မမှန်
  BODY="$(curl -s --max-time 12 "$BASE/api/public/plans.php" 2>/dev/null || true)"
  if printf '%s' "$BODY" | grep -q '"ok":true'; then
    printf '   %s✅%s %-34s {"ok":true...}\n' "$G" "$N" "API JSON envelope"
    PASS=$((PASS+1))
  else
    printf '   %s❌%s %-34s %s\n' "$R" "$N" "API JSON envelope" "$(printf '%s' "$BODY" | head -c 80)"
    FAIL=$((FAIL+1))
  fi

  echo
  if [ "$FAIL" = 0 ]; then
    ok "စစ်ဆေးချက် $PASS ခု အားလုံး အောင်မြင်"
  else
    warn "အောင်: $PASS   မအောင်: $FAIL"
  fi
fi

# ============================================================================
#  နိဂုံး — GitHub config ပြောင်းရန် ပြပေး
# ============================================================================
echo
hr
printf '%s ✅ Domain ပြောင်းခြင်း ပြီးပါပြီ%s\n' "$G$W" "$N"
hr
info "Domain    : ${NEW_DOMAIN}"
info "Dashboard : ${SCHEME}://${NEW_DOMAIN}/admin/"
info "API base  : ${SCHEME}://${NEW_DOMAIN}/api"
info "Backup    : ${BACKUP_DIR}"
echo
printf '%s⚠️  နောက်ဆုံး တစ်ဆင့် — App အလုပ်လုပ်ရန် မဖြစ်မနေ လုပ်ရမည်%s\n' "$Y$W" "$N"
echo
say "   GitHub repo ထဲရှိ  n4core-config.json  ကို အောက်ပါအတိုင်း ပြောင်းပါ:"
echo
printf '%s' "$C"
cat <<JSONEOF
   {
     "api_base_url": "${SCHEME}://${NEW_DOMAIN}/api",
     "maintenance": false,
     "message": ""
   }
JSONEOF
printf '%s' "$N"
echo
say "   App က ဒီ file ကို ဖတ်ပြီး API ကို ရှာတယ်။ ဒါပြောင်းလိုက်ရင်"
say "   ${W}app update တင်စရာ မလိုဘဲ${N} အသစ်တဲ့ server ကို အလိုအလျောက် သွားမယ်။"
echo
hr
say " အခြား အသုံးဝင်သော command များ"
hr
say "   လက်ရှိအခြေအနေ ကြည့်   :  sudo $0 --show"
say "   စမ်းကြည့်ရုံ (မပြောင်း) :  sudo $0 <domain> --dry-run"
say "   SSL ထုတ်               :  sudo $0 <domain> --ssl"
say "   Backup ပြန်ယူ          :  cp ${BACKUP_DIR}/n4core.conf ${NGINX_SITE} && systemctl reload nginx"
hr
echo
