#!/usr/bin/env bash
# =============================================================================
#  N4 Core VPN — GO (တစ်ချက်နှိပ်)
# -----------------------------------------------------------------------------
#  Google Drive ကနေ SRC ဆွဲ → ဖြေ → VPS ပေါ်တင် → security fix → reload
#
#  ⚡ VPS ပေါ်မှာ ဒီ command တခုပဲ ရိုက်ပါ —
#
#       bash n4core-go.sh
#
#     ပြီးပါပြီ။ ID က script ထဲ ထည့်ထားပြီးသား ဖြစ်တယ်။
#
# -----------------------------------------------------------------------------
#  လုပ်သွားမယ့်အဆင့် —
#    ၁။ Gdrive ကနေ SRC ဆွဲတယ်
#    ၂။ ဖြေတယ် (tar/zip အလိုအလျောက် ခွဲခြားတယ်)
#    ၃။ SRC ထဲ fix တွေ တကယ်ပါမပါ စစ်တယ်   ← မပါရင် ဒီမှာတင် ရပ်တယ်
#    ၄။ ဖိုင်တွေ VPS ပေါ်တင်တယ်            (n4core-apply-v23.sh)
#    ၅။ Security hardening လုပ်တယ်         (n4core-fixall.sh)
#
#  USAGE
#      bash n4core-go.sh                      # အကုန် အလိုအလျောက်
#      bash n4core-go.sh --files-only         # ဖိုင်ပဲတင်၊ hardening မလုပ်
#      bash n4core-go.sh --pin <cert-sha256>  # cert pin ပါ ဖွင့်တယ်
#      bash n4core-go.sh --id <GDRIVE_ID>     # တခြား ID သုံးမယ်
#      bash n4core-go.sh --file /root/src.tar.gz   # local ဖိုင်ဆိုရင်
#      bash n4core-go.sh --dry-run            # စမ်းကြည့်ရုံ
#
#  ⚠️ Cert pin —
#     default က ပိတ်ထားတယ်။ pin ဖွင့်လိုက်ရင် pin မကိုက်တဲ့ APK အားလုံး
#     register မရတော့ဘူး။ App build 8 ကို သုံးစွဲသူတွေ ရောက်ပြီးမှ
#     --pin နဲ့ ပြန် run ပါ။
# =============================================================================
set -uo pipefail

# ---------------------------------------------------------------------------
# Gdrive file ID — upload အသစ်တိုင်း ဒီတန်ဖိုးကို ပြောင်းပါ။
# link က  https://drive.google.com/file/d/<ID>/view  ဆိုရင် <ID> အပိုင်းပဲ။
# ---------------------------------------------------------------------------
GD_ID="1v9GKIo8KR2M2mD5QkR9tatUnFr5BDa_W"      # backend v2.3.1 (security fix ၆ ချက်)

RED=$'\033[31m'; GRN=$'\033[32m'; YLW=$'\033[33m'; CYN=$'\033[36m'
DIM=$'\033[2m'; BD=$'\033[1m'; RST=$'\033[0m'
ok(){   echo "  ${GRN}✅${RST} $*"; }
info(){ echo "  ${CYN}•${RST}  $*"; }
warn(){ echo "  ${YLW}⚠${RST}  $*"; }
err(){  echo "  ${RED}❌${RST} $*" >&2; }
head1(){ echo; echo "${CYN}${BD}▸ $*${RST}"; }

PASS=(); LOCAL=""; FILES_ONLY=0; PIN=""; DRY=0
while [ $# -gt 0 ]; do
  case "$1" in
    --file)        shift; LOCAL="${1:-}" ;;
    --id)          shift; GD_ID="${1:-}" ;;
    --pin)         shift; PIN="${1:-}" ;;
    --files-only)  FILES_ONLY=1 ;;
    --dry-run)     DRY=1; PASS+=("--dry-run") ;;
    -h|--help)     sed -n '3,32p' "$0" | sed 's/^#\{0,1\} \{0,1\}//'; exit 0 ;;
    *) PASS+=("$1") ;;
  esac
  shift
done

echo
echo "${CYN}══════════════════════════════════════════════════${RST}"
echo "${CYN}${BD}  N4 Core VPN — GO${RST}"
echo "${CYN}══════════════════════════════════════════════════${RST}"

if [ "$(id -u)" -ne 0 ] && [ "$DRY" -eq 0 ]; then
  err "root နဲ့ run ပါ:  sudo bash $0"
  exit 1
fi

WORK="$(mktemp -d /tmp/n4go.XXXXXX)" || { err "temp dir မရဘူး"; exit 1; }
trap 'rm -rf "$WORK"' EXIT
AR="$WORK/src.bin"

# ------------------------------------------------------------------ ဆွဲယူ
if [ -n "$LOCAL" ]; then
  head1 "Local ဖိုင် သုံးမယ်"
  [ -f "$LOCAL" ] || { err "မတွေ့ဘူး: $LOCAL"; exit 1; }
  cp "$LOCAL" "$AR"; ok "$(du -h "$AR" | cut -f1)"
else
  [ -n "$GD_ID" ] || { err "--id <GDRIVE_FILE_ID> ပေးပါ"; exit 1; }
  head1 "Google Drive ကနေ ဆွဲနေတယ်"
  command -v curl >/dev/null 2>&1 || { err "curl မရှိ — apt install -y curl"; exit 1; }
  info "ID: $GD_ID"

  # usercontent endpoint + confirm=t က virus-scan page ကို ကျော်တယ်။
  # drive.google.com/uc နဲ့ဆို ဖိုင်ကြီးတဲ့အခါ HTML ပြန်လာတယ်။
  curl -sL --retry 3 --connect-timeout 25 -o "$AR" \
    "https://drive.usercontent.google.com/download?id=${GD_ID}&export=download&confirm=t"

  [ -s "$AR" ] || {
    err "download မရဘူး"
    info "link ကို 'Anyone with the link' ဖွင့်ပါ"
    exit 1
  }

  # HTML ပြန်လာရင် (login / quota / permission page) ဖမ်းတယ် —
  # ဒါကို မဖမ်းရင် အောက်မှာ \"tar မဟုတ်ဘူး\" လို့ပဲ ပြပြီး ဘာမှားလဲ မသိရဘူး။
  if head -c 512 "$AR" | grep -qi '<html\|<!doctype'; then
    err "Gdrive က HTML ပြန်ပေးတယ် — ဖိုင် မရဘူး"
    info "အကြောင်းရင်း ၂ မျိုး ဖြစ်နိုင်တယ် —"
    info "  ၁။ link က 'Anyone with the link' မဖွင့်ထားဘူး"
    info "  ၂။ ID မှားနေတယ်"
    info "ကိုယ့်စက်ကနေ တင်ချင်ရင်:"
    echo  "     ${DIM}scp src-backend.tar.gz root@<VPS-IP>:/root/${RST}"
    echo  "     ${DIM}bash $0 --file /root/src-backend.tar.gz${RST}"
    exit 1
  fi
  ok "ဆွဲပြီး — $(du -h "$AR" | cut -f1)"
fi

# --------------------------------------------------------------- ဖြေမယ်
head1 "ဖြေနေတယ်"
EX="$WORK/x"; mkdir -p "$EX"
extracted=0
for c in "tar -xzf" "tar -xf" "tar -xjf" "tar -xJf"; do
  if $c "$AR" -C "$EX" 2>/dev/null; then extracted=1; break; fi
done
if [ "$extracted" -ne 1 ]; then
  command -v unzip >/dev/null 2>&1 || \
    (apt-get install -y unzip >/dev/null 2>&1 || yum install -y unzip >/dev/null 2>&1)
  unzip -qo "$AR" -d "$EX" 2>/dev/null && extracted=1
fi
[ "$extracted" -eq 1 ] || { err "ဖြေလို့မရဘူး (tar/zip မဟုတ်ဘူး)"; exit 1; }
ok "ဖြေပြီး"

# ------------------------------------------------- SRC root ရှာ (nested ရော)
head1 "SRC root ရှာနေတယ်"
SRC=""
while IFS= read -r f; do
  d="$(dirname "$(dirname "$f")")"
  # apply script ပါတဲ့ tree ကို ဦးစားပေး
  if [ -f "$d/deploy/n4core-apply-v23.sh" ]; then SRC="$d"; break; fi
  [ -z "$SRC" ] && SRC="$d"
done < <(find "$EX" -maxdepth 6 -type f -path '*/core/bootstrap.php' 2>/dev/null)
[ -n "$SRC" ] || { err "SRC မတွေ့ဘူး — archive မှားနေတယ်"; exit 1; }
ok "SRC: ${SRC#"$EX"/}"

APPLY="$SRC/deploy/n4core-apply-v23.sh"
[ -f "$APPLY" ] || { err "deploy/n4core-apply-v23.sh မပါဘူး"; exit 1; }

# --------------------------------------------- SRC ထဲ fix တွေ တကယ်ပါမပါ စစ်
# ဒါက အရေးကြီးတယ် — SRC အဟောင်း တင်လိုက်ရင် anti-tamper ပြန်ပျက်သွားမယ်။
# အဟောင်း/အသစ် ဝေဝါးတာကို ဒီမှာတင် ဖမ်းပြီး ရပ်တာက နောက်မှ debug ရတာထက်
# သက်သာတယ်။
head1 "SRC ထဲ security fix ပါမပါ စစ်နေတယ်"
BAD=0

if grep -q "registrationKey" "$SRC/core/DeviceAuth.php" 2>/dev/null; then
  ok "DeviceAuth.php အသစ် (cert-derived key)"
else
  err "DeviceAuth.php က အဟောင်း"; BAD=1
fi

if grep -q "device_reg_global" "$SRC/core/DeviceAuth.php" 2>/dev/null; then
  ok "Rate-limit fix"
else
  err "rate-limit fix မပါဘူး"; BAD=1
fi

if grep -q "purge_plain_codes" "$SRC/bin/migrate.php" 2>/dev/null; then
  ok "Plaintext code purge"
else
  err "code purge မပါဘူး"; BAD=1
fi

if grep -q '"core/DeviceAuth.php"' "$APPLY" 2>/dev/null; then
  ok "apply script ရဲ့ FILES ထဲ DeviceAuth.php ပါတယ်"
else
  err "FILES ထဲ DeviceAuth.php မပါဘူး — တင်လည်း VPS ပေါ် မရောက်ဘူး"; BAD=1
fi

for s in n4core-secure.sh n4core-fixall.sh n4core-rescue.sh; do
  [ -f "$SRC/deploy/$s" ] && ok "$s" || { err "$s မပါဘူး"; BAD=1; }
done

if [ "$BAD" -ne 0 ]; then
  echo
  err "SRC က အဟောင်း ဖြစ်နေတယ် — ရပ်လိုက်တယ်"
  info "Gdrive ပေါ် ${BD}src-backend-v8${RST} ကို တင်ပြီး ID ပြောင်းပါ"
  exit 1
fi
ok "fix အားလုံး ပါတယ် — ဆက်လုပ်လို့ ရပြီ"

chmod +x "$SRC"/deploy/*.sh 2>/dev/null
APP_DIR="${N4_APP_DIR:-/var/www/n4core}"
APP_DIR="${APP_DIR%/}"

# --------------------------------------------------- dry-run / files-only
# ဒီ ၂ မျိုးဆိုရင် apply script ကို တိုက်ရိုက် ခေါ်တယ် (backup/hardening မလုပ်)
if [ "$DRY" -eq 1 ] || [ "$FILES_ONLY" -eq 1 ]; then
  head1 "ဖိုင်တွေ VPS ပေါ် တင်နေတယ်"
  bash "$APPLY" --src "$SRC" ${PASS+"${PASS[@]}"}
  rc=$?
  if [ $rc -ne 0 ]; then
    echo; err "တင်တဲ့အဆင့်မှာ မအောင်မြင်ဘူး (exit $rc)"
    info "ဖိုင်တွေက auto rollback ပြန်ဖြစ်ပြီးသား။"
    exit $rc
  fi
  echo
  if [ "$DRY" -eq 1 ]; then
    ok "--dry-run — ဘာမှ မပြောင်းထားဘူး"
  else
    warn "--files-only — hardening မလုပ်ဘူး"
    info "ဆက်လုပ်ချင်ရင်:  ${DIM}sudo bash $APP_DIR/deploy/n4core-fixall.sh --no-pin${RST}"
  fi
  exit 0
fi

# ------------------------------------------- backup → apply → hardening
# n4core-fixall.sh က backup (config + DB) ယူပြီးမှ apply လုပ်၊ ပြီးမှ
# hardening လုပ်တယ်။ ဒါကြောင့် apply ကို ဒီမှာ ကိုယ်တိုင် မခေါ်ဘူး —
# ခေါ်ရင် ၂ ခါ တင်ဖြစ်သွားပြီး backup လည်း လွတ်သွားမယ်။
head1 "Backup → တင် → Security hardening"
FIXALL="$SRC/deploy/n4core-fixall.sh"

if [ -n "$PIN" ]; then
  PIN="$(printf '%s' "$PIN" | tr -d '[:space:]:' | tr 'A-F' 'a-f')"
  if ! printf '%s' "$PIN" | grep -qE '^[a-f0-9]{64}$'; then
    err "cert hash က hex ၆၄ လုံး ဖြစ်ရမယ် (အခု ${#PIN} လုံး)"
    warn "pin မဖွင့်ဘဲ ဆက်လုပ်မယ်"
    bash "$FIXALL" --app-dir "$APP_DIR" --no-pin
  else
    info "Cert pin ဖွင့်မယ် — ${PIN:0:24}…"
    bash "$FIXALL" --app-dir "$APP_DIR" "$PIN"
  fi
else
  info "Cert pin မဖွင့်ဘူး (default) — App build 8 ဖြန့်ပြီးမှ ဖွင့်ပါ"
  bash "$FIXALL" --app-dir "$APP_DIR" --no-pin
fi
rc=$?

echo
echo "${GRN}══════════════════════════════════════════════════${RST}"
if [ $rc -eq 0 ]; then
  echo "${GRN}${BD}  ✅ GO ပြီးပါပြီ — server စစ်ပြီး အောင်တယ်${RST}"
else
  # fixall က selftest ရဲ့ exit code ကို ပြန်ပေးတယ်။ ဒါကြောင့် ဒီနေရာ
  # ရောက်တာက "ဖိုင်တင်တာ မအောင်" မဟုတ်ဘူး — ဖိုင်တွေ တင်ပြီးသား ဖြစ်နိုင်
  # တယ်၊ ဒါပေမဲ့ တကယ့် device register စမ်းတဲ့အခါ ကျတယ်။ အဲ့ဒါက ဖုန်းမှာ
  # မရဘူး ဆိုတာ တိတိကျကျ ဆိုလိုတယ်၊ ဒါကြောင့် အစိမ်း မပြဘူး။
  echo "${RED}${BD}  ❌ server စစ်တာ မအောင်ဘူး — ဖုန်းမှာ မရနိုင်ဘူး${RST}"
fi
echo "${GRN}══════════════════════════════════════════════════${RST}"
echo
echo "  ${BD}ပြန်စစ်ချင်ရင်${RST}"
echo "    ${DIM}sudo bash $APP_DIR/deploy/n4core-secure.sh --check${RST}"
echo "    ${DIM}sudo n4core${RST}  → ၁၁ (Security စစ်ရုံ)"
echo
if [ -z "$PIN" ]; then
  echo "  ${YLW}Cert pin မဖွင့်ရသေးဘူး။${RST} App build 8 ဖြန့်ပြီးရင်:"
  echo "    ${DIM}sudo bash $0 --pin 1490631129b09f523c3caa339617b6de1b404015827fee6fd1e8d44b0824fdfe${RST}"
  echo
fi
exit $rc
