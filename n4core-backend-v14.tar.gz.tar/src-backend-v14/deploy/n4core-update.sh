#!/usr/bin/env bash
#
# ============================================================================
#  N4 Core VPN — In-place Update (VPS ပေါ်က code ကို အသစ်ပြောင်းခြင်း)
# ============================================================================
#  ရှိပြီးသား VPS ပေါ်မှာ code အသစ်ကို တင်တယ်။ Database, config/config.php,
#  storage/ (backup archive တွေ) ကို လုံးဝ မထိပါ။
#
#  n4core-migrate-vps.sh နဲ့ ဘာကွာလဲ
#     migrate = VPS အဟောင်း → VPS အသစ် ရွှေ့တာ (DB dump ပါ ယူတယ်)
#     update  = VPS တစ်ခုတည်းမှာ code ကို အသစ်ပြောင်းတာ (DB မထိ)   ← ဒီ script
#
#  USAGE
#     sudo ./n4core-update.sh <update-package.tar.gz>
#     sudo ./n4core-update.sh <package> --dry-run     (ဘာပြောင်းမလဲ ပြရုံ)
#     sudo ./n4core-update.sh --rollback              (နောက်ဆုံး update ကို ပြန်ရုပ်)
#     sudo ./n4core-update.sh --check                 (လက်ရှိအခြေအနေ)
#     sudo ./n4core-update.sh --enable-device-auth    (device-auth ကို ဖွင့်)
#
#  အရေးကြီး — device-auth က ပုံမှန်အားဖြင့် "ပိတ်" ထားတယ်
#     Code တင်တာနဲ့ device-auth ဖွင့်လိုက်ရင် လက်ရှိ app အဟောင်းအားလုံး
#     ချက်ချင်း 401 ဖြစ်ကုန်တယ် (သူတို့ signature မပို့တာမို့)။ ဒါကြောင့်
#     အစီအစဉ်က:
#        ၁. ဒီ script နဲ့ code တင်       (device-auth = ပိတ်၊ app အဟောင်း ဆက်အလုပ်လုပ်)
#        ၂. secret ကို ယူပြီး APK အသစ် ဆောက်
#        ၃. APK အသစ်ကို စမ်း — အလုပ်လုပ်တာ တွေ့ရင်
#        ၄. sudo ./n4core-update.sh --enable-device-auth
#     အဆင့် ၁ မှာတင် ဖွင့်ချင်ရင် --enable-now ထည့်ပါ (အကြံမပြုပါ)။
#
#  ဘာလုပ်သလဲ
#     1. App directory ကို auto-detect (မတွေ့ရင် ရပ်တယ် — မှန်းမကြံပါ)
#     2. ပြောင်းမယ့် file တွေကို အရင် backup   → /root/n4core-update-<ရက်စွဲ>/
#     3. Package ထဲက file တွေ တင် (config/config.php ကို ကျော်)
#     4. config.php ထဲ key အသစ်တွေ ရှိမရှိ စစ် — မရှိရင် ထည့်ပေး
#     5. bin/setup_device_auth.php run (secret + DB table)
#     6. Ownership / permission ပြန်သတ်မှတ်
#     7. HTTP နဲ့ ပြန်စစ် — မအောင်ရင် rollback လုပ်ရမယ့် command ပြ
#
#  လုပ်တာမှန်သမျှ backup အရင်ယူတယ် — မအောင်ရင် --rollback နဲ့ ပြန်ရလို့ရတယ်။
# ============================================================================

set -uo pipefail

# ---------------------------------------------------------------- ဆေးဆို
STAMP="$(date +%F-%H%M%S)"
BACKUP_ROOT="/root"
DRY_RUN=0
DO_ROLLBACK=0
CHECK_ONLY=0
ENABLE_DA=0        # --enable-device-auth : device-auth ကို ဖွင့်ရုံသက်သက်
ENABLE_NOW=0       # --enable-now         : update လုပ်ရင်းနဲ့ တခါတည်း ဖွင့်
ASSUME_YES=0       # --yes                : မေးခွန်း မမေးဘဲ ဆက်လုပ်
PKG=""
APP_DIR="${N4_APP_DIR:-}"

# ---------------------------------------------------------------- အရောင်
if [ -t 1 ]; then
  R=$'\e[31m'; G=$'\e[32m'; Y=$'\e[33m'; B=$'\e[34m'; C=$'\e[36m'; W=$'\e[1m'; N=$'\e[0m'
else
  R=""; G=""; Y=""; B=""; C=""; W=""; N=""
fi

say()  { printf '%s\n' "$*"; }
ok()   { printf '%s✅ %s%s\n' "$G" "$*" "$N"; }
warn() { printf '%s⚠️  %s%s\n' "$Y" "$*" "$N"; }
err()  { printf '%s❌ %s%s\n' "$R" "$*" "$N" >&2; }
step() { printf '\n%s%s▸ %s%s\n' "$W" "$B" "$*" "$N"; }
info() { printf '   %s\n' "$*"; }
die()  { err "$*"; exit 1; }
hr()   { printf '%s────────────────────────────────────────────────────────────%s\n' "$C" "$N"; }

need_root() { [ "$(id -u)" = "0" ] || die "root အနေနဲ့ run ရမယ်:  sudo $0 $*"; }

WORKDIR=""
cleanup() { [ -n "${WORKDIR:-}" ] && [ -d "${WORKDIR:-}" ] && rm -rf "$WORKDIR"; }
trap cleanup EXIT

run() {
  if [ "$DRY_RUN" = 1 ]; then
    printf '   %s[dry-run]%s %s\n' "$Y" "$N" "$*"
    return 0
  fi
  "$@"
}

# --yes ပေးထားရင် မမေးဘဲ ဆက်တယ်။ pipe ကနေ run တဲ့အခါ (yes y | ...) stdin
# ပိတ်သွားရင် read က တစ်ခါတည်း fail ဖြစ်တာမို့ default က "မလုပ်" ဖြစ်တယ်။
confirm() {
  if [ "$ASSUME_YES" = 1 ]; then
    printf '%s%s [y/N] y  (--yes)%s\n' "$W" "$1" "$N"
    return 0
  fi
  printf '%s%s [y/N] %s' "$W" "$1" "$N"
  local reply=""
  read -r reply || reply=""
  case "$reply" in [yY]|[yY][eE][sS]) return 0 ;; *) return 1 ;; esac
}

# ---------------------------------------------------------------- arg ဖတ်
while [ $# -gt 0 ]; do
  case "$1" in
    --dry-run)  DRY_RUN=1 ;;
    --rollback) DO_ROLLBACK=1 ;;
    --check)    CHECK_ONLY=1 ;;
    --enable-device-auth) ENABLE_DA=1 ;;
    --enable-now)         ENABLE_NOW=1 ;;
    -y|--yes)   ASSUME_YES=1 ;;
    --app-dir)  shift; APP_DIR="${1:-}" ;;
    -h|--help)  sed -n '2,39p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    -*)         die "မသိတဲ့ option: $1  (--help ကြည့်ပါ)" ;;
    *)          PKG="$1" ;;
  esac
  shift
done

# ============================================================================
#  App directory ရှာခြင်း
# ============================================================================
# INSTALL.md, nginx conf, systemd unit အားလုံး /var/www/n4core ကို ရည်ညွှန်းတယ်။
# ဒါပေမဲ့ လက်တွေ့ VPS မှာ တခြား path ဖြစ်နိုင်တာမို့ မှန်းမကြံဘဲ ရှာတယ်။
# ရှာလို့ မတွေ့ရင် ရပ်တယ် — path မှားပြီး file တွေ ကွဲကုန်တာက အဆိုးဆုံး။
detect_app_dir() {
  if [ -n "$APP_DIR" ]; then
    [ -f "$APP_DIR/core/bootstrap.php" ] \
      || die "--app-dir ပေးထားတဲ့ '$APP_DIR' ထဲ core/bootstrap.php မတွေ့"
    return 0
  fi

  local cands=()

  # ၁။ nginx vhost ထဲက root
  local ngroot
  for conf in /etc/nginx/sites-enabled/*.conf /etc/nginx/sites-enabled/* \
              /etc/nginx/conf.d/*.conf; do
    [ -f "$conf" ] || continue
    while read -r ngroot; do
      [ -n "$ngroot" ] && cands+=("$ngroot")
    done < <(grep -hoP '^\s*root\s+\K[^;]+' "$conf" 2>/dev/null | tr -d ' ')
  done

  # ၂။ Apache DocumentRoot
  for conf in /etc/apache2/sites-enabled/*.conf; do
    [ -f "$conf" ] || continue
    while read -r ngroot; do
      [ -n "$ngroot" ] && cands+=("$ngroot")
    done < <(grep -hoP '^\s*DocumentRoot\s+\K\S+' "$conf" 2>/dev/null | tr -d '"')
  done

  # ၃။ systemd unit ထဲက path
  for u in /etc/systemd/system/n4core-*.service /etc/systemd/system/n4core-*.timer; do
    [ -f "$u" ] || continue
    while read -r ngroot; do
      [ -n "$ngroot" ] && cands+=("$ngroot")
    done < <(grep -hoP '/\S*?(?=/bin/(cron|bot)\.php)' "$u" 2>/dev/null)
  done

  # ၄။ cron
  if [ -f /etc/cron.d/n4core ]; then
    while read -r ngroot; do
      [ -n "$ngroot" ] && cands+=("$ngroot")
    done < <(grep -hoP '/\S*?(?=/bin/cron\.php)' /etc/cron.d/n4core 2>/dev/null)
  fi

  # ၅။ ပုံမှန် path များ
  cands+=(/var/www/n4core /var/www/n4core_backend_v2 /var/www/html/n4core)

  # ၆။ /var/www အောက် ရှာ (နောက်ဆုံး လမ်း)
  while read -r ngroot; do
    [ -n "$ngroot" ] && cands+=("$(dirname "$(dirname "$ngroot")")")
  done < <(find /var/www /srv /opt -maxdepth 4 -type f -path '*/core/bootstrap.php' 2>/dev/null)

  # အတည်ပြု — core/bootstrap.php ရော config/config.php ရော ရှိမှ N4 Core
  local seen=" " c
  for c in "${cands[@]}"; do
    c="${c%/}"
    case "$seen" in *" $c "*) continue ;; esac
    seen="$seen$c "
    if [ -f "$c/core/bootstrap.php" ] && [ -f "$c/config/config.php" ]; then
      APP_DIR="$c"
      return 0
    fi
  done

  err "N4 Core app directory ရှာလို့ မတွေ့ပါ။"
  echo
  info "ဒီနေရာတွေမှာ ရှာခဲ့တယ်:"
  info "  nginx root / Apache DocumentRoot / systemd unit / cron"
  info "  /var/www/n4core , /var/www/n4core_backend_v2 , /var/www/html/n4core"
  echo
  info "လက်နဲ့ ပေးပါ:"
  printf '   %ssudo %s <package> --app-dir /သင့်/path%s\n' "$C" "$0" "$N"
  echo
  info "ရှာနည်း:"
  printf '   %sfind /var/www /srv /opt -name bootstrap.php -path "*/core/*" 2>/dev/null%s\n' "$C" "$N"
  exit 1
}

# ============================================================================
#  cfg — config.php ထဲက key တစ်ခု ဖတ်
# ============================================================================
cfg() {
  php -r '
    $f = $argv[2];
    if (!is_file($f)) { echo ""; exit; }
    $c = require $f; $k = explode(".", $argv[1]); $v = $c;
    foreach ($k as $p) { if (!is_array($v) || !array_key_exists($p,$v)) { echo ""; exit; } $v = $v[$p]; }
    echo is_bool($v) ? ($v?"true":"false") : (is_array($v) ? "(array)" : (string)$v);
  ' "$1" "${2:-$APP_DIR/config/config.php}" 2>/dev/null
}

# config.php ထဲ key ရှိမရှိ (တန်ဖိုး မကြည့်)
cfg_has() {
  php -r '
    $f = $argv[2];
    if (!is_file($f)) { exit(1); }
    $c = require $f; $k = explode(".", $argv[1]); $v = $c;
    foreach ($k as $p) { if (!is_array($v) || !array_key_exists($p,$v)) { exit(1); } $v = $v[$p]; }
    exit(0);
  ' "$1" "${2:-$APP_DIR/config/config.php}" 2>/dev/null
}

# ============================================================================
#  CHECK
# ============================================================================
cmd_check() {
  detect_app_dir
  hr
  printf '%s N4 Core — Update အခြေအနေ စစ်ဆေးချက်%s\n' "$W" "$N"
  hr
  info "App dir : $APP_DIR"
  echo

  local pass=0 fail=0
  t() {
    if eval "$2" >/dev/null 2>&1; then
      printf '   %s✅%s %-34s %s\n' "$G" "$N" "$1" "${3:-}"; pass=$((pass+1))
    else
      printf '   %s❌%s %-34s %s\n' "$R" "$N" "$1" "${4:-မရှိ}"; fail=$((fail+1))
    fi
  }

  t "core/bootstrap.php"  "[ -f '$APP_DIR/core/bootstrap.php' ]"
  t "config/config.php"   "[ -f '$APP_DIR/config/config.php' ]"
  t "PHP CLI"             "command -v php"        "$(php -r 'echo PHP_VERSION;' 2>/dev/null)"
  t "tar"                 "command -v tar"
  t "curl"                "command -v curl"

  echo
  printf '   %sDevice-auth အခြေအနေ%s\n' "$W" "$N"
  t "core/DeviceAuth.php" "[ -f '$APP_DIR/core/DeviceAuth.php' ]"           "တင်ပြီး"  "တင်ရမယ်"
  t "register_device.php" "[ -f '$APP_DIR/api/public/register_device.php' ]" "တင်ပြီး"  "တင်ရမယ်"
  t "config key: app_bootstrap_secret" "cfg_has security.app_bootstrap_secret" "ရှိ" "ထည့်ရမယ်"
  t "config key: require_device_auth"  "cfg_has security.require_device_auth"  "ရှိ" "ထည့်ရမယ်"

  local dauth; dauth="$(cfg security.require_device_auth)"
  info "require_device_auth = ${dauth:-(မရှိ)}"

  echo
  printf '   %sBackup ရှိသလား%s\n' "$W" "$N"
  local n; n="$(ls -1d "$BACKUP_ROOT"/n4core-update-* 2>/dev/null | wc -l)"
  if [ "$n" -gt 0 ]; then
    ok "Update backup ${n} ခု ရှိ — နောက်ဆုံး: $(ls -1dt "$BACKUP_ROOT"/n4core-update-* 2>/dev/null | head -1)"
  else
    info "Update backup မရှိသေး (ဒါက ပထမအခေါက်ဖြစ်နိုင်တယ်)"
  fi

  echo
  hr
  [ "$fail" = 0 ] && ok "စစ်ဆေးချက် ${pass} ခု အားလုံး အောင်မြင်" \
                 || warn "အောင်: ${pass}   မအောင်: ${fail}"
  hr
}

# ============================================================================
#  ROLLBACK
# ============================================================================
cmd_rollback() {
  need_root --rollback
  detect_app_dir

  local latest
  latest="$(ls -1dt "$BACKUP_ROOT"/n4core-update-*/ 2>/dev/null | head -1)"
  [ -n "$latest" ] || die "Rollback backup မတွေ့ပါ ($BACKUP_ROOT/n4core-update-*)"
  latest="${latest%/}"

  [ -f "$latest/MANIFEST.txt" ] || die "$latest ထဲ MANIFEST.txt မပါ — backup မပြည့်စုံ"

  hr
  printf '%s N4 Core — Update ကို ပြန်ရုပ်ခြင်း (ROLLBACK)%s\n' "$W" "$N"
  hr
  info "Backup  : $latest"
  info "App dir : $APP_DIR"
  echo
  sed 's/^/   /' "$latest/MANIFEST.txt"
  echo

  confirm "ဆက်လုပ်မလား?" || { say "ရပ်လိုက်ပါတယ်။"; exit 0; }

  step "File များ ပြန်ထည့်ခြင်း"
  local n=0
  # backup ထဲ files/ အောက်က တည်ဆောက်မှုကို အတိအကျ ပြန်ကူး
  if [ -d "$latest/files" ]; then
    while IFS= read -r rel; do
      run mkdir -p "$APP_DIR/$(dirname "$rel")"
      run cp -p "$latest/files/$rel" "$APP_DIR/$rel"
      info "← $rel"
      n=$((n+1))
    done < <(cd "$latest/files" && find . -type f | sed 's|^\./||')
  fi

  # update လုပ်ချိန် အသစ်ထည့်ခဲ့တဲ့ file တွေကို ဖျက်
  if [ -f "$latest/ADDED.txt" ]; then
    while IFS= read -r rel; do
      [ -n "$rel" ] || continue
      if [ -f "$APP_DIR/$rel" ]; then
        run rm -f "$APP_DIR/$rel"
        info "✕ $rel (update ကထည့်ခဲ့တာ)"
      fi
    done < "$latest/ADDED.txt"
  fi

  ok "File ${n} ခု ပြန်ထည့်ပြီး"

  step "Permission ပြန်သတ်မှတ်ခြင်း"
  fix_perms
  ok "ပြီး"

  step "စစ်ဆေးခြင်း"
  verify_http

  echo
  hr
  ok "Rollback ပြီးပါပြီ"
  warn "Database ကို မထိပါ — device-auth table တွေ ရှိနေမယ် (ဘာမှ မထိခိုက်ပါ)"
  hr
}

# ============================================================================
#  Permission
# ============================================================================
fix_perms() {
  local owner="www-data"
  id www-data >/dev/null 2>&1 || owner="$(stat -c '%U' "$APP_DIR/core/bootstrap.php" 2>/dev/null || echo root)"

  run chown -R "${owner}:${owner}" "$APP_DIR" 2>/dev/null || true
  run find "$APP_DIR" -type d -exec chmod 750 {} \; 2>/dev/null || true
  run find "$APP_DIR" -type f -exec chmod 640 {} \; 2>/dev/null || true
  run chmod 770 "$APP_DIR/storage" 2>/dev/null || true
  run find "$APP_DIR/storage" -type d -exec chmod 770 {} \; 2>/dev/null || true
  run chmod 750 "$APP_DIR"/bin/*.php 2>/dev/null || true
  run chmod 750 "$APP_DIR"/deploy/*.sh 2>/dev/null || true
  # n4core.sh is the single menu the operator actually types; it lives at the
  # app root, not under deploy/, so the glob above does not reach it.
  run chmod 750 "$APP_DIR"/n4core.sh 2>/dev/null || true
  # ...and give it a name the operator can actually type. Without this the
  # only way in is the full path, which is exactly the friction the single
  # menu was meant to remove.
  if [ -f "$APP_DIR/n4core.sh" ] && [ -d /usr/local/bin ]; then
    run ln -sfn "$APP_DIR/n4core.sh" /usr/local/bin/n4core 2>/dev/null || true
  fi
  # config.php က 400 — www-data ဖတ်ရုံ။ chown ကို ရှေးရွေးမလုပ်ရ။
  run chown "${owner}:${owner}" "$APP_DIR/config/config.php" 2>/dev/null || true
  run chmod 400 "$APP_DIR/config/config.php" 2>/dev/null || true
}

# ============================================================================
#  HTTP စစ်ဆေးခြင်း
# ============================================================================
verify_http() {
  local pass=0 fail=0

  # An nginx vhost matched by server_name only answers correctly when the
  # Host header matches. Hitting the bare IP lands on the default vhost, so
  # pull the first server_name out of the site config and send it along.
  local VHOST=""
  VHOST="$(grep -rhoP '^\s*server_name\s+\K[^;]+' /etc/nginx/sites-enabled/ 2>/dev/null \
    | tr ' ' '\n' | grep -v '^_$' | grep -v '^\*' | head -1)"
  [ -n "$VHOST" ] && info "vhost: $VHOST"
  c() {
    local got
    # -L follows redirects and -k accepts the self-referential certificate we
    # get when hitting 127.0.0.1 by IP. Without them an nginx that redirects
    # http -> https answers 301 to every probe, which looks like a failure
    # even though the site is fine.
    got="$(curl -sLk -o /dev/null -w '%{http_code}' --max-time 12 \
      ${VHOST:+-H "Host: $VHOST"} "http://127.0.0.1$2" 2>/dev/null || echo 000)"
    if printf '%s' "$3" | grep -qw "$got"; then
      printf '   %s✅%s %-32s %s\n' "$G" "$N" "$1" "$got"; pass=$((pass+1))
    else
      printf '   %s❌%s %-32s %s (%s ဖြစ်ရမယ်)\n' "$R" "$N" "$1" "$got" "$3"; fail=$((fail+1))
    fi
  }

  c "Admin dashboard"        "/admin/"                        "200"
  c "config.php ပိတ်မှု"      "/config/config.php"             "403 404"
  c "core/ ပိတ်မှု"           "/core/DeviceAuth.php"           "403 404"

  # device-auth ဖွင့်ထားရင် signature မပါတဲ့ request က 401 ဖြစ်ရမယ်။
  # မဖွင့်ရင် 200 ဖြစ်ရမယ်။ ဒါကို အခြေအနေအလိုက် စစ်တယ်။
  local dauth; dauth="$(cfg security.require_device_auth)"
  if [ "$dauth" = "true" ]; then
    c "Sign မပါ → 401 ဖြစ်ရမယ်"  "/api/public/plans.php"      "401"
    printf '   %sℹ%s  device-auth ဖွင့်ထားတယ် — app က signed request ပို့ရမယ်\n' "$C" "$N"
  else
    c "Public API (device-auth ပိတ်)" "/api/public/plans.php"   "200"
    printf '   %sℹ%s  device-auth ပိတ်ထားတယ် (မှန်ပါတယ်) — app အဟောင်း ဆက်အလုပ်လုပ်နေမယ်\n' "$C" "$N"
  fi

  echo
  if [ "$fail" = 0 ]; then
    ok "စစ်ဆေးချက် ${pass} ခု အားလုံး အောင်မြင်"
    return 0
  fi
  err "မအောင်: ${fail} ခု"
  return 1
}

# ============================================================================
#  UPDATE
# ============================================================================
cmd_update() {
  need_root "$PKG"
  [ -n "$PKG" ] || die "Package ထည့်ပါ:  sudo $0 n4core-update-XXX.tar.gz"
  [ -f "$PKG" ] || die "File မတွေ့: $PKG"

  detect_app_dir

  hr
  printf '%s N4 Core — Code အသစ်ပြောင်းခြင်း (IN-PLACE UPDATE)%s\n' "$W" "$N"
  hr
  info "Package : $PKG  ($(du -h "$PKG" | cut -f1))"
  info "App dir : $APP_DIR   $([ -n "${N4_APP_DIR:-}" ] && echo '(N4_APP_DIR)' || echo '(auto-detect)')"
  info "PHP     : $(php -r 'echo PHP_VERSION;' 2>/dev/null)"
  [ "$DRY_RUN" = 1 ] && warn "DRY-RUN — ဘာမှ မပြောင်းပါ"
  echo

  # ---- ၁။ Package ဖြေ ----
  step "၁/၇  Package ဖြေခြင်း"
  WORKDIR="$(mktemp -d /tmp/n4core-update-XXXXXX)"
  local src="$WORKDIR/src"
  mkdir -p "$src"
  tar -xzf "$PKG" -C "$src" || die "Archive ဖြေလို့မရ"

  # tarball ထဲ ./core/... ဒါမှမဟုတ် n4core-.../core/... ဖြစ်နိုင်တာမို့ root ရှာ
  local root="$src"
  if [ ! -d "$src/core" ]; then
    root="$(find "$src" -maxdepth 2 -type d -name core 2>/dev/null | head -1)"
    [ -n "$root" ] || die "Package ထဲ core/ မတွေ့ — package မှားနေတယ်"
    root="$(dirname "$root")"
  fi
  ok "ဖြေပြီး — $(cd "$root" && find . -type f | wc -l) file"

  if [ -f "$root/UPDATE-MANIFEST.txt" ]; then
    echo
    printf '%s   ── Package အကြောင်း ──%s\n' "$C" "$N"
    sed 's/^/   /' "$root/UPDATE-MANIFEST.txt"
    echo
  fi

  # ---- ၂။ ဘာပြောင်းမလဲ တွက် ----
  step "၂/၇  ပြောင်းလဲမှု တွက်ချက်ခြင်း"
  local list_new="$WORKDIR/new.txt" list_mod="$WORKDIR/mod.txt" list_same="$WORKDIR/same.txt"
  : > "$list_new"; : > "$list_mod"; : > "$list_same"

  while IFS= read -r rel; do
    # config/config.php ကို လုံးဝ မထိ — live secret ပါဝင်တယ်
    case "$rel" in
      config/config.php) continue ;;
      UPDATE-MANIFEST.txt) continue ;;
    esac
    if [ ! -f "$APP_DIR/$rel" ]; then
      echo "$rel" >> "$list_new"
    elif cmp -s "$root/$rel" "$APP_DIR/$rel"; then
      echo "$rel" >> "$list_same"
    else
      echo "$rel" >> "$list_mod"
    fi
  done < <(cd "$root" && find . -type f | sed 's|^\./||' | sort)

  local n_new n_mod n_same
  n_new="$(wc -l < "$list_new")"; n_mod="$(wc -l < "$list_mod")"; n_same="$(wc -l < "$list_same")"
  info "အသစ်ထည့်မယ် : ${n_new}"
  info "ပြောင်းမယ်   : ${n_mod}"
  info "မပြောင်း     : ${n_same}"
  echo
  if [ "$n_new" -gt 0 ]; then
    printf '   %sအသစ်%s\n' "$G" "$N"; sed 's/^/     + /' "$list_new"
  fi
  if [ "$n_mod" -gt 0 ]; then
    printf '   %sပြောင်းမယ်%s\n' "$Y" "$N"; sed 's/^/     ~ /' "$list_mod"
  fi

  if [ "$n_new" = 0 ] && [ "$n_mod" = 0 ]; then
    echo
    ok "ပြောင်းစရာ မရှိပါ — VPS က အသစ်ဖြစ်နေပြီ"
    exit 0
  fi

  if [ "$DRY_RUN" = 1 ]; then
    echo
    hr
    ok "Dry-run ပြီးပါပြီ — ဘာမှ မပြောင်းခဲ့ပါ"
    info "အမှန်တကယ် လုပ်ရန်:  sudo $0 $PKG"
    hr
    exit 0
  fi

  echo
  confirm "ဆက်လုပ်မလား?" || { say "ရပ်လိုက်ပါတယ်။"; exit 0; }

  # ---- ၃။ Backup ----
  step "၃/၇  Backup ယူခြင်း"
  local bdir="$BACKUP_ROOT/n4core-update-${STAMP}"
  mkdir -p "$bdir/files"

  # ပြောင်းမယ့် file တွေရဲ့ အဟောင်းကို သိမ်း
  local n=0
  while IFS= read -r rel; do
    [ -n "$rel" ] || continue
    mkdir -p "$bdir/files/$(dirname "$rel")"
    cp -p "$APP_DIR/$rel" "$bdir/files/$rel"
    n=$((n+1))
  done < "$list_mod"

  # အသစ်ထည့်မယ့် file စာရင်း — rollback အခါ ဖျက်ရမယ်
  cp "$list_new" "$bdir/ADDED.txt"

  # config.php ကို သီးသန့် သိမ်း (ကျွန်တော် မထိပေမဲ့ key ထည့်နိုင်တာမို့)
  cp -p "$APP_DIR/config/config.php" "$bdir/config.php.bak"
  chmod 400 "$bdir/config.php.bak"

  cat > "$bdir/MANIFEST.txt" <<META
N4 Core VPN — Update Backup
============================
အချိန်        : $(date '+%Y-%m-%d %H:%M:%S %Z')
App directory : ${APP_DIR}
Package       : $(basename "$PKG")
Package SHA256: $(sha256sum "$PKG" | cut -d' ' -f1)
PHP           : $(php -r 'echo PHP_VERSION;')
ပြောင်းခဲ့တာ    : ${n_mod} file
အသစ်ထည့်ခဲ့တာ  : ${n_new} file

ပြန်ရုပ်ရန်:
  sudo ${APP_DIR}/deploy/n4core-update.sh --rollback
META

  chmod 700 "$bdir"
  ok "Backup: $bdir  (file ${n} ခု + config.php)"

  # ---- ၄။ File တင် ----
  step "၄/၇  File အသစ် တင်ခြင်း"
  n=0
  while IFS= read -r rel; do
    [ -n "$rel" ] || continue
    mkdir -p "$APP_DIR/$(dirname "$rel")"
    cp "$root/$rel" "$APP_DIR/$rel"
    n=$((n+1))
  done < <(cat "$list_new" "$list_mod")
  ok "File ${n} ခု တင်ပြီး"

  # PHP syntax စစ် — ပျက်တဲ့ file တင်ပြီး site ကွဲတာ မဖြစ်စေရ
  local bad=0
  while IFS= read -r rel; do
    case "$rel" in *.php) ;; *) continue ;; esac
    if ! php -l "$APP_DIR/$rel" >/dev/null 2>&1; then
      err "Syntax error: $rel"
      bad=$((bad+1))
    fi
  done < <(cat "$list_new" "$list_mod")

  if [ "$bad" -gt 0 ]; then
    err "PHP syntax error ${bad} ခု — ချက်ချင်း ပြန်ရုပ်နေတယ်"
    while IFS= read -r rel; do
      [ -n "$rel" ] && cp -p "$bdir/files/$rel" "$APP_DIR/$rel" 2>/dev/null
    done < "$list_mod"
    while IFS= read -r rel; do
      [ -n "$rel" ] && rm -f "$APP_DIR/$rel"
    done < "$list_new"
    die "Update ရပ်လိုက်ပါတယ် — VPS က အရင်အတိုင်း ဖြစ်နေတယ်"
  fi
  ok "PHP syntax အားလုံး အောင်မြင်"

  # ---- ၅။ config.php ထဲ key အသစ် ----
  step "၅/၇  config.php ထဲ key အသစ် စစ်ခြင်း"
  local cfgfile="$APP_DIR/config/config.php"
  local need_keys=0

  if ! cfg_has security.app_bootstrap_secret; then
    warn "security.app_bootstrap_secret မရှိ — ထည့်နေတယ်"
    # 'security' => [ ရဲ့ နောက်တစ်လိုင်းမှာ ထည့်တယ်။
    # sed နဲ့ မလုပ်ဘဲ PHP နဲ့ လုပ်တာက quote/escape ပြဿနာ မရှိ။
    chmod 600 "$cfgfile"
    php -r '
      $f = $argv[1];
      $s = file_get_contents($f);
      if (strpos($s, "app_bootstrap_secret") !== false) { echo "already\n"; exit(0); }
      $add = "\n        // Device registration bootstrap secret (app --dart-define နဲ့ တွဲရမယ်)\n"
           . "        \x27app_bootstrap_secret\x27 => \x27CHANGE_ME\x27,\n"
           . "        \x27require_device_auth\x27  => false,\n";
      $n = preg_replace(
        "/(\x27security\x27\s*=>\s*\[)/",
        "$1" . $add,
        $s,
        1,
        $cnt
      );
      if (!$cnt) { fwrite(STDERR, "security block မတွေ့\n"); exit(1); }
      file_put_contents($f, $n);
      echo "added\n";
    ' "$cfgfile" || die "config.php ထဲ key ထည့်လို့မရ — လက်နဲ့ ထည့်ပါ (backup: $bdir/config.php.bak)"
    need_keys=1
  fi

  if ! cfg_has security.require_device_auth; then
    chmod 600 "$cfgfile"
    php -r '
      $f = $argv[1]; $s = file_get_contents($f);
      if (strpos($s, "require_device_auth") !== false) { exit(0); }
      $n = preg_replace(
        "/(\x27app_bootstrap_secret\x27\s*=>[^\n]*\n)/",
        "$1        \x27require_device_auth\x27  => false,\n",
        $s, 1, $cnt
      );
      if ($cnt) file_put_contents($f, $n);
    ' "$cfgfile" || true
    need_keys=1
  fi

  # rate_limits ထဲ device-auth key တွေ
  if ! cfg_has rate_limits.device_register; then
    warn "rate_limits.device_register မရှိ — ထည့်နေတယ်"
    chmod 600 "$cfgfile"
    php -r '
      $f = $argv[1]; $s = file_get_contents($f);
      if (strpos($s, "device_register") !== false) { exit(0); }
      $add = "\n        \x27device_register\x27 => [\x27limit\x27 => 5,   \x27window\x27 => 3600],\n"
           . "        \x27config_read\x27     => [\x27limit\x27 => 120, \x27window\x27 => 3600],\n";
      $n = preg_replace("/(\x27rate_limits\x27\s*=>\s*\[)/", "$1" . $add, $s, 1, $cnt);
      if ($cnt) file_put_contents($f, $n);
    ' "$cfgfile" || true
    need_keys=1
  fi

  if [ "$need_keys" = 1 ]; then
    php -l "$cfgfile" >/dev/null 2>&1 \
      || { cp -p "$bdir/config.php.bak" "$cfgfile"; die "config.php ပျက်သွားတယ် — backup ကနေ ပြန်ထည့်ပြီး ရပ်လိုက်တယ်"; }
    ok "config.php ထဲ key အသစ် ထည့်ပြီး (syntax အောင်မြင်)"
  else
    ok "config.php ထဲ key အားလုံး ရှိပြီးသား"
  fi

  # ---- ၆။ setup_device_auth ----
  step "၆/၇  Device-auth secret နှင့် DB table"

  # --secret-only က secret ရေးတယ်၊ table ဆောက်တယ်၊ ဒါပေမဲ့ require_device_auth
  # ကို မထိဘူး။ ဒါ အရမ်းအရေးကြီးတယ် — code တင်တာနဲ့ enforcement ဖွင့်လိုက်ရင်
  # လက်ရှိ ထည့်ထားပြီးသား app အားလုံး ချက်ချင်း 401 ဖြစ်ကုန်တယ် (သူတို့
  # signature မပို့တာမို့)။ APK အသစ် စမ်းပြီးမှ --enable-device-auth နဲ့ ဖွင့်ရမယ်။
  local da_flag="--secret-only"
  if [ "$ENABLE_NOW" = 1 ]; then
    da_flag=""
    warn "--enable-now ပေးထားတယ် — device-auth ကို ချက်ချင်း ဖွင့်မယ်"
    warn "လက်ရှိ app အဟောင်းအားလုံး 401 ဖြစ်ကုန်မယ်"
  fi

  if [ -f "$APP_DIR/bin/setup_device_auth.php" ]; then
    chmod 640 "$cfgfile"
    # shellcheck disable=SC2086
    if (cd "$APP_DIR" && php bin/setup_device_auth.php $da_flag 2>&1 | sed 's/^/   /'); then
      ok "setup_device_auth.php အောင်မြင်"
    else
      err "setup_device_auth.php မအောင်မြင်"
      warn "Code က တင်ပြီးသား — အောက်ပါ command နဲ့ လက်နဲ့ လုပ်ပါ:"
      printf '   %scd %s && sudo php bin/setup_device_auth.php %s%s\n' \
        "$C" "$APP_DIR" "$da_flag" "$N"
    fi
  else
    warn "bin/setup_device_auth.php မပါဝင်ပါ — package မှားနေလား စစ်ပါ"
  fi

  # ---- ၇။ Permission + စစ်ဆေး ----
  step "၇/၇  Permission နှင့် စစ်ဆေးခြင်း"
  fix_perms
  ok "Permission သတ်မှတ်ပြီး (config.php = 400, storage = 770)"

  # opcache ရှိရင် ရှင်း — မဟုတ်ရင် code အဟောင်း ဆက်သုံးနေမယ်
  if php -r 'exit(function_exists("opcache_reset") ? 0 : 1);' 2>/dev/null; then
    for svc in php8.4-fpm php8.3-fpm php8.2-fpm php8.1-fpm php-fpm; do
      if systemctl is-active "$svc" >/dev/null 2>&1; then
        systemctl reload "$svc" 2>/dev/null && info "opcache ရှင်းပြီး ($svc reload)"
        break
      fi
    done
  fi

  echo
  verify_http
  local vres=$?

  echo
  hr
  if [ "$vres" = 0 ]; then
    printf '%s ✅ Update ပြီးပါပြီ%s\n' "$G$W" "$N"
  else
    printf '%s ⚠️  Update တင်ပြီး ဒါပေမဲ့ စစ်ဆေးချက် မအောင်%s\n' "$Y$W" "$N"
  fi
  hr
  info "App dir : $APP_DIR"
  info "Backup  : $bdir"
  echo
  printf '%sပြန်ရုပ်လိုရင်%s\n' "$W" "$N"
  printf '%s   sudo %s/deploy/n4core-update.sh --rollback%s\n' "$C" "$APP_DIR" "$N"
  echo
  printf '%sနောက်တစ်ဆင့် — APK ဆောက်ရန် secret%s\n' "$W" "$N"
  printf '%s   sudo grep app_bootstrap_secret %s/config/config.php%s\n' "$C" "$APP_DIR" "$N"
  echo
  printf '%s   flutter build apk --release \\%s\n' "$C" "$N"
  printf '%s     --dart-define=N4_BOOTSTRAP_SECRET=<အပေါ်က secret>%s\n' "$C" "$N"
  echo
  local dauth; dauth="$(cfg security.require_device_auth)"
  if [ "$dauth" != "true" ]; then
    warn "require_device_auth = false ဖြစ်နေတယ်။"
    info "APK အသစ် တင်ပြီး၊ app က အလုပ်လုပ်တာ အတည်ပြုပြီးမှ ဒါကို run ပါ:"
    printf '   %ssudo %s/deploy/n4core-update.sh --enable-device-auth%s\n' "$C" "$APP_DIR" "$N"
  fi
  hr
  echo
}

# ============================================================================
#  Device-auth ကို ဖွင့်ခြင်း (ခွဲထားတဲ့ အဆင့်)
# ============================================================================
# ဒါက update နဲ့ ခွဲထားတယ်။ အကြောင်းရင်းက — code တင်တာနဲ့ enforcement ဖွင့်တာက
# သီးသန့် ဆုံးဖြတ်ချက် ၂ ခု ဖြစ်သင့်တယ်။ code တင်တာက ဘယ်သူ့မှ မထိခိုက်ဘူး၊
# enforcement ဖွင့်တာက signature မပို့တဲ့ app အားလုံးကို ချက်ချင်း ပိတ်လိုက်တယ်။
cmd_enable_device_auth() {
  need_root --enable-device-auth
  detect_app_dir

  local cfgfile="$APP_DIR/config/config.php"
  hr
  printf '%s N4 Core — Device-auth ကို ဖွင့်ခြင်း%s\n' "$W" "$N"
  hr
  info "App dir : $APP_DIR"

  cfg_has security.app_bootstrap_secret \
    || die "app_bootstrap_secret မရှိ — အရင် update လုပ်ပါ"

  local sec; sec="$(cfg security.app_bootstrap_secret)"
  case "$sec" in
    ''|CHANGE_ME*) die "app_bootstrap_secret က မသတ်မှတ်ရသေးဘူး — 'cd $APP_DIR && sudo php bin/setup_device_auth.php --secret-only' အရင် run ပါ" ;;
  esac

  local cur; cur="$(cfg security.require_device_auth)"
  if [ "$cur" = "true" ]; then
    ok "require_device_auth က true ဖြစ်နေပြီးသား — ဘာမှ လုပ်စရာ မရှိ"
    exit 0
  fi

  echo
  printf '%sဖွင့်ပြီးရင် ဘာဖြစ်မလဲ%s\n' "$W" "$N"
  info "• Signature ပါတဲ့ app (secret အတူတူနဲ့ ဆောက်ထားတာ) → အလုပ်လုပ်မယ်"
  info "• Signature မပါတဲ့ app အဟောင်းအားလုံး → 401၊ ဘာမှ အလုပ်မလုပ်မယ်"
  echo
  warn "APK အသစ်ကို စမ်းပြီး အလုပ်လုပ်တာ တွေ့ပြီးမှ ဖွင့်ပါ။"
  echo

  confirm "အခု ဖွင့်မလား?" || { say "ရပ်လိုက်ပါတယ်။"; exit 0; }

  cp -p "$cfgfile" "${cfgfile}.bak-before-enable-${STAMP}"
  chmod 600 "$cfgfile"
  php -r '
    $f = $argv[1]; $s = file_get_contents($f);
    $n = preg_replace("/(\x27require_device_auth\x27\s*=>\s*)false/", "$1true", $s, 1, $cnt);
    if (!$cnt) { fwrite(STDERR, "require_device_auth => false မတွေ့\n"); exit(1); }
    file_put_contents($f, $n);
  ' "$cfgfile" || die "config.php ပြင်လို့မရ (backup: ${cfgfile}.bak-before-enable-${STAMP})"

  php -l "$cfgfile" >/dev/null 2>&1 || {
    cp -p "${cfgfile}.bak-before-enable-${STAMP}" "$cfgfile"
    die "config.php ပျက်သွားတယ် — ပြန်ထည့်ပြီး ရပ်လိုက်တယ်"
  }

  fix_perms
  ok "require_device_auth = true"

  for svc in php8.4-fpm php8.3-fpm php8.2-fpm php8.1-fpm php-fpm; do
    systemctl is-active "$svc" >/dev/null 2>&1 && { systemctl reload "$svc" 2>/dev/null; break; }
  done

  echo
  verify_http
  echo
  hr
  ok "ပြီးပါပြီ — device-auth ဖွင့်ထားပြီ"
  info "ပြန်ပိတ်ချင်ရင်: config.php ထဲ require_device_auth => false ပြန်ပြောင်းပါ"
  hr
}

# ============================================================================
#  Router
# ============================================================================
if [ "$CHECK_ONLY" = 1 ]; then
  cmd_check
elif [ "$DO_ROLLBACK" = 1 ]; then
  cmd_rollback
elif [ "$ENABLE_DA" = 1 ]; then
  cmd_enable_device_auth
else
  [ -n "$PKG" ] || die "Package မပေးထားပါ။  --help ကြည့်ပါ"
  cmd_update
fi
