#!/usr/bin/env bash
# =============================================================================
#  N4 Core VPN — Security hardening (one bash)
# -----------------------------------------------------------------------------
#  Security audit ကနေ ထွက်လာတဲ့ အချက်တွေကို VPS ပေါ်မှာ အလိုအလျောက် ပြင်ပေးတယ်။
#  ဒါက apply script ပြီးမှ run ရမယ့် script ပါ (ဖိုင်တွေ အသစ် ရောက်နေရမယ်)။
#
#    ၁။ Cert pinning ဖွင့်တယ်      — security.expected_cert_sha256
#    ၂။ HSTS header ထည့်တယ်       — nginx / apache
#    ၃။ Rate-limit profile ၂ ခု   — device_reg_id + device_reg_global
#    ၄။ Plaintext access_code ဖျက် — migrate.php --hash-codes
#    ၅။ အားလုံး တကယ်ရမရ ပြန်စစ်တယ် (live HTTP probe)
#
#  မထိတဲ့အရာများ:
#    - DB data (migration က code column ကိုပဲ blank လုပ်တယ်၊ hash ကို မထိဘူး)
#    - encryption_key / pepper / app_secret / DB / telegram
#    - TLS cert / domain config
#
#  USAGE
#      sudo bash deploy/n4core-secure.sh <cert-sha256>
#      sudo bash deploy/n4core-secure.sh <cert-sha256> <play-cert-sha256>
#      sudo bash deploy/n4core-secure.sh --check          # စစ်ရုံ၊ မပြင်ဘူး
#
#  cert-sha256 ဘယ်ကရမလဲ —
#      APK: apksigner verify --print-certs app-release.apk
#      Play: Play Console → Test and release → Setup → App signing
#      (colon ပါလည်း ရတယ်၊ script က ဖယ်ပေးတယ်)
# =============================================================================
set -uo pipefail

RED=$'\033[31m'; GRN=$'\033[32m'; YLW=$'\033[33m'; CYN=$'\033[36m'
DIM=$'\033[2m'; BD=$'\033[1m'; RST=$'\033[0m'
ok()   { echo "  ${GRN}✅${RST} $*"; }
info() { echo "  ${CYN}•${RST}  $*"; }
warn() { echo "  ${YLW}⚠${RST}  $*"; }
err()  { echo "  ${RED}❌${RST} $*" >&2; }
head1(){ echo; echo "${CYN}${BD}▸ $*${RST}"; }

APP_DIR="${N4_APP_DIR:-/var/www/n4core}"
CHECK_ONLY=0
HASH1=""
HASH2=""

while [ $# -gt 0 ]; do
  case "$1" in
    --check)   CHECK_ONLY=1 ;;
    --app-dir) shift; APP_DIR="${1:-}" ;;
    -h|--help) sed -n '2,30p' "$0"; exit 0 ;;
    *)
      if   [ -z "$HASH1" ]; then HASH1="$1"
      elif [ -z "$HASH2" ]; then HASH2="$1"
      else err "argument အလွန်များ: $1"; exit 1; fi
      ;;
  esac
  shift
done

APP_DIR="${APP_DIR%/}"
CFG="$APP_DIR/config/config.php"

echo
echo "${CYN}══════════════════════════════════════════════════${RST}"
echo "${CYN}${BD}  N4 Core VPN — Security hardening${RST}"
echo "${CYN}══════════════════════════════════════════════════${RST}"

[ "$(id -u)" -eq 0 ] || { err "root နဲ့ run ပါ:  sudo bash $0 ..."; exit 1; }
[ -f "$CFG" ] || { err "config.php မတွေ့ပါ: $CFG
     တခြားနေရာဆိုရင်:  sudo bash $0 --app-dir /path/to/n4core ..."; exit 1; }
ok "APP_DIR: $APP_DIR"

PHPBIN="$(command -v php || true)"
[ -n "$PHPBIN" ] || { err "php မတွေ့ပါ"; exit 1; }

# hash တွေကို normalise — colon ဖယ်၊ အက္ခရာအသေးလုပ်
norm_hash() {
  printf '%s' "$1" | tr -d '[:space:]:' | tr 'A-F' 'a-f'
}
HASH1="$(norm_hash "$HASH1")"
HASH2="$(norm_hash "$HASH2")"

for h in "$HASH1" "$HASH2"; do
  if [ -n "$h" ] && ! printf '%s' "$h" | grep -qE '^[a-f0-9]{64}$'; then
    err "cert hash က hex ၆၄ လုံး ဖြစ်ရမယ် (အခု ${#h} လုံး): $h"
    exit 1
  fi
done

# ---------------------------------------------------------------- DOMAIN ရှာ
DOMAIN="$("$PHPBIN" -r '
$c = @include $argv[1];
if (!is_array($c)) { exit; }
$u = (string)($c["app"]["base_url"] ?? $c["app"]["url"] ?? "");
echo $u !== "" ? parse_url($u, PHP_URL_HOST) : "";
' "$CFG" 2>/dev/null || true)"
# config.php ထဲ base_url / url key က မရှိဘူး (config.sample.php ထဲမှာလည်း
# မပါဘူး) — ဒါကြောင့် အပေါ် PHP က အမြဲ အလွတ် ပြန်တယ်။ အဲ့ဒါဆို live probe
# တခုလုံး ခုန်ကျော်ခဲ့တယ်၊ register_device.php က HTTP 500 ဖြစ်နေတာကို
# မတွေ့ရဘဲ "✅ ပြီးပါပြီ" ပြခဲ့တယ်။ ဒါကြောင့် nginx / env ကနေ ရှာတယ်။
if [ -z "$DOMAIN" ] && [ -n "${N4_DOMAIN:-}" ]; then
  DOMAIN="$N4_DOMAIN"
fi
if [ -z "$DOMAIN" ]; then
  # nginx vhost ထဲက server_name — APP_DIR ကို root အဖြစ် ထားတဲ့ block ကို ရှာ
  for nf in /etc/nginx/sites-enabled/* /etc/nginx/sites-available/* \
            /etc/nginx/conf.d/*.conf; do
    [ -f "$nf" ] || continue
    grep -q "$APP_DIR" "$nf" 2>/dev/null || continue
    DOMAIN="$(grep -hoE '^[[:space:]]*server_name[[:space:]]+[^;]+' "$nf" 2>/dev/null \
             | head -1 | awk '{print $2}' | tr -d ' ')"
    case "$DOMAIN" in ""|_|localhost) DOMAIN="" ;; esac
    [ -n "$DOMAIN" ] && break
  done
fi
if [ -z "$DOMAIN" ]; then
  # ဘာမှ မရရင် nginx အားလုံးထဲက ပထမဆုံး တကယ့် domain
  DOMAIN="$(grep -rhoE '^[[:space:]]*server_name[[:space:]]+[^;]+' \
            /etc/nginx/sites-enabled/ /etc/nginx/conf.d/ 2>/dev/null \
            | awk '{print $2}' | grep -E '^[a-z0-9.-]+\.[a-z]{2,}$' \
            | grep -v localhost | head -1)"
fi
if [ -n "$DOMAIN" ]; then
  info "Domain: $DOMAIN"
else
  warn "domain မရှာနိုင် — live probe ခုန်မယ်"
  warn "  → probe run ချင်ရင်:  sudo N4_DOMAIN=core.nandaxr.tech bash $0 --check"
fi

# =============================================================== BACKUP
if [ "$CHECK_ONLY" -eq 0 ]; then
  head1 "config.php backup ယူနေတယ်"
  BK="/root/n4core-secure-backup-$(date +%F-%H%M%S)"
  mkdir -p "$BK" || { err "backup dir မဖန်တီးနိုင်ဘူး"; exit 1; }
  cp -p "$CFG" "$BK/config.php.bak"
  ok "backup: $BK/config.php.bak"

  restore_cfg() {
    warn "config.php ကို ပြန်ထည့်နေတယ်…"
    cp -p "$BK/config.php.bak" "$CFG"
    warn "အရင်အတိုင်း ပြန်ရောက်သွားပြီ"
  }
fi

# =========================================================== ၁။ CERT PIN
head1 "၁/၅ — Cert pinning"

CUR_PIN="$("$PHPBIN" -r '
$c = @include $argv[1];
$v = is_array($c) ? ($c["security"]["expected_cert_sha256"] ?? "") : "";
echo is_array($v) ? implode(",", $v) : (string)$v;
' "$CFG" 2>/dev/null || true)"

if [ -z "$HASH1" ] && [ "$CHECK_ONLY" -eq 0 ]; then
  if [ -n "$CUR_PIN" ]; then
    info "cert hash မထည့်ထားဘူး — ရှိပြီးသားကို မထိဘူး: ${CUR_PIN:0:16}…"
  else
    warn "cert hash မထည့်ထားဘူး၊ config ထဲမှာလည်း မရှိဘူး"
    warn "  → anti-tamper က cert မစစ်နိုင်ဘူး (debuggable စစ်တာတော့ အလုပ်လုပ်မယ်)"
    warn "  ထည့်ချင်ရင်:  sudo bash $0 <cert-sha256>"
  fi
elif [ -n "$HASH1" ]; then
  # PHP နဲ့ ရေးတယ် — sed နဲ့ array ရေးရင် quote အမှား ဖြစ်လွယ်လို့။
  if [ -n "$HASH2" ]; then
    NEWVAL="['$HASH1', '$HASH2']"
    PINDESC="၂ ခု (direct + Play)"
  else
    NEWVAL="'$HASH1'"
    PINDESC="၁ ခု"
  fi

  if [ "$CHECK_ONLY" -eq 1 ]; then
    info "(--check) ပြင်မှာမဟုတ်ဘူး"
  else
    # PHP script ကို ဖိုင်နဲ့ ရေးတယ် — bash single-quote ထဲ PHP regex
    # (quote အမျိုးမျိုး ပါတဲ့) ထည့်ရင် ကျိုးလို့။
    PINPHP="$(mktemp /tmp/n4pin.XXXXXX.php)"
    cat > "$PINPHP" <<'PHPEOF'
<?php
$file = $argv[1];
$new  = $argv[2];
$src  = file_get_contents($file);
if ($src === false) { fwrite(STDERR, "read failed\n"); exit(1); }

// ရှိပြီးသား လိုင်းကို အစားထိုးတယ် (string ဒါမှမဟုတ် array ၂ မျိုးလုံး ဖမ်းတယ်)
$q   = '["\']';
$pat = '/(' . $q . 'expected_cert_sha256' . $q . '\s*=>\s*)(\[[^\]]*\]|' . $q . '[^"\']*' . $q . ')/';

if (preg_match($pat, $src)) {
    $out = preg_replace($pat, '${1}' . $new, $src, 1);
} else {
    // မရှိရင် security block ရဲ့ ထိပ်မှာ ထည့်တယ်
    $pat2 = '/(' . $q . 'security' . $q . '\s*=>\s*\[)/';
    if (!preg_match($pat2, $src)) { fwrite(STDERR, "security block not found\n"); exit(1); }
    $out = preg_replace($pat2, '${1}' . "\n        'expected_cert_sha256' => " . $new . ',', $src, 1);
}
if ($out === null) { fwrite(STDERR, "regex failed\n"); exit(1); }
// $out === $src ဆိုတာ = ထည့်ချင်တဲ့ hash က ရှိပြီးသားနဲ့ တူတယ်။
// အရင်က ဒါကို exit(1) "no change written" လုပ်ခဲ့လို့ script က
// "config.php ရေးလို့မရ" ဆိုပြီး rollback + exit 1 လုပ်ခဲ့တယ် —
// တနည်း ၂ ခါ run ရင် hardening တခုလုံး ရပ်သွားတာ။ ဒါ error မဟုတ်ဘူး။
if ($out === $src) { exit(3); }
if (file_put_contents($file, $out) === false) { fwrite(STDERR, "write failed\n"); exit(1); }
PHPEOF
    set +e
    "$PHPBIN" "$PINPHP" "$CFG" "$NEWVAL"
    PINRC=$?
    set -e
    rm -f "$PINPHP"
    if [ "$PINRC" -eq 3 ]; then
      ok "cert pin ရှိပြီးသား — အတူတူပဲ (မထိဘူး)"
    elif [ "$PINRC" -ne 0 ]; then
      err "config.php ရေးလို့မရ"; restore_cfg; exit 1
    fi

    if ! "$PHPBIN" -l "$CFG" >/dev/null 2>&1; then
      err "config.php syntax ပျက်သွားတယ်"
      restore_cfg
      exit 1
    fi
    ok "cert pin ထည့်ပြီး — $PINDESC"
    info "${DIM}${HASH1:0:24}…${RST}"
    [ -n "$HASH2" ] && info "${DIM}${HASH2:0:24}…${RST}"
  fi
fi

# ==================================================== ၂။ RATE-LIMIT PROFILE
head1 "၂/၅ — Rate-limit profile (device_reg_id + device_reg_global)"

HAS_ID="$(grep -c "device_reg_id" "$CFG" 2>/dev/null || echo 0)"

if [ "$HAS_ID" -gt 0 ]; then
  info "ရှိပြီးသား — မထိဘူး"
elif [ "$CHECK_ONLY" -eq 1 ]; then
  warn "မရှိဘူး — IP ချိန်းပြီး registration ကျော်လို့ ရနေတယ်"
else
  RLPHP="$(mktemp /tmp/n4rl.XXXXXX.php)"
  cat > "$RLPHP" <<'PHPEOF'
<?php
$file = $argv[1];
$src  = file_get_contents($file);
if ($src === false) { exit(1); }

$q   = '["\']';
$pat = '/(' . $q . 'device_reg' . $q . '\s*=>\s*\[[^\]]*\],?)/';
if (!preg_match($pat, $src)) { fwrite(STDERR, "device_reg profile not found\n"); exit(1); }

$add = "\n        'device_reg_id'     => ['limit' => 8,   'window' => 3600, 'block' => 3600],"
     . "\n        'device_reg_global' => ['limit' => 200, 'window' => 3600, 'block' => 600],";

$out = preg_replace($pat, '${1}' . $add, $src, 1);
if ($out === null || $out === $src) { exit(1); }
if (file_put_contents($file, $out) === false) { exit(1); }
PHPEOF
  "$PHPBIN" "$RLPHP" "$CFG" \
    || warn "profile ထည့်လို့မရ — profile မရှိရင် limiter က auto-off ဖြစ်တာမို့ service မကျိုးဘူး"
  rm -f "$RLPHP"

  if ! "$PHPBIN" -l "$CFG" >/dev/null 2>&1; then
    err "config.php syntax ပျက်သွားတယ်"
    restore_cfg
    exit 1
  fi
  grep -q "device_reg_id" "$CFG" && ok "profile ၂ ခု ထည့်ပြီး" || warn "ထည့်လို့မရ — လက်နဲ့ ထည့်ပါ"
fi

# ============================================================== ၃။ HSTS
head1 "၃/၅ — HSTS header"

HSTS_LINE='add_header Strict-Transport-Security "max-age=31536000" always;'
HSTS_DONE=0

# nginx
if command -v nginx >/dev/null 2>&1; then
  NGCONF=""
  for c in "/etc/nginx/sites-available/n4core" \
           "/etc/nginx/sites-available/$DOMAIN" \
           "/etc/nginx/conf.d/n4core.conf" \
           "/etc/nginx/conf.d/$DOMAIN.conf"; do
    [ -f "$c" ] && { NGCONF="$c"; break; }
  done
  # မတွေ့ရင် n4core ပါတဲ့ conf ကို ရှာ
  if [ -z "$NGCONF" ]; then
    NGCONF="$(grep -rls "n4core" /etc/nginx/sites-available/ /etc/nginx/conf.d/ 2>/dev/null | head -1 || true)"
  fi

  if [ -z "$NGCONF" ]; then
    warn "nginx conf မတွေ့ဘူး — လက်နဲ့ ထည့်ပါ"
  elif grep -q "Strict-Transport-Security" "$NGCONF"; then
    ok "nginx မှာ HSTS ရှိပြီးသား ($NGCONF)"
    HSTS_DONE=1
  elif [ "$CHECK_ONLY" -eq 1 ]; then
    warn "nginx မှာ HSTS မရှိဘူး ($NGCONF)"
  else
    cp -p "$NGCONF" "$BK/$(basename "$NGCONF").bak"
    # TLS server block ထဲ ထည့်တယ် — 443 listen လိုင်းပြီးမှ
    NGPHP="$(mktemp /tmp/n4hsts.XXXXXX.php)"
    cat > "$NGPHP" <<'PHPEOF'
<?php
$f    = $argv[1];
$line = $argv[2];
$s    = file_get_contents($f);
if ($s === false) { exit(1); }

// ssl / 443 ပါတဲ့ server block ကို ဦးစားပေးတယ် — HSTS က HTTPS မှာပဲ အလုပ်လုပ်လို့
if (preg_match('/(listen[^\n;]*443[^\n;]*;[^\n]*\n)/', $s, $m)) {
    $out = str_replace($m[1], $m[1] . '    ' . $line . "\n", $s);
} elseif (preg_match('/(server_name[^\n;]*;[^\n]*\n)/', $s, $m)) {
    $out = str_replace($m[1], $m[1] . '    ' . $line . "\n", $s);
} else {
    exit(1);
}
if (file_put_contents($f, $out) === false) { exit(1); }
PHPEOF
    if "$PHPBIN" "$NGPHP" "$NGCONF" "$HSTS_LINE"; then
      rm -f "$NGPHP"
      if nginx -t >/dev/null 2>&1; then
        systemctl reload nginx 2>/dev/null || nginx -s reload 2>/dev/null
        ok "nginx HSTS ထည့်ပြီး + reload ပြီး ($NGCONF)"
        HSTS_DONE=1
      else
        err "nginx -t မအောင်မြင် — conf ပြန်ထည့်တယ်"
        cp -p "$BK/$(basename "$NGCONF").bak" "$NGCONF"
        nginx -t >/dev/null 2>&1 && warn "ပြန်ကောင်းသွားပြီ"
      fi
    else
      rm -f "$NGPHP"
      warn "nginx conf ထဲ ထည့်လို့မရ — လက်နဲ့ ဒီလိုင်း ထည့်ပါ:"
      echo "     ${DIM}$HSTS_LINE${RST}"
    fi
  fi
fi

# apache
if [ "$HSTS_DONE" -eq 0 ] && command -v apache2ctl >/dev/null 2>&1; then
  APCONF="$(grep -rls "n4core" /etc/apache2/sites-available/ 2>/dev/null | head -1 || true)"
  if [ -n "$APCONF" ] && grep -q "Strict-Transport-Security" "$APCONF"; then
    ok "apache မှာ HSTS ရှိပြီးသား"
    HSTS_DONE=1
  elif [ -n "$APCONF" ] && [ "$CHECK_ONLY" -eq 0 ]; then
    cp -p "$APCONF" "$BK/$(basename "$APCONF").bak"
    a2enmod headers >/dev/null 2>&1 || true
    printf '\n    Header always set Strict-Transport-Security "max-age=31536000"\n' >> "$APCONF"
    if apache2ctl configtest >/dev/null 2>&1; then
      systemctl reload apache2 2>/dev/null
      ok "apache HSTS ထည့်ပြီး + reload ပြီး"
      HSTS_DONE=1
    else
      err "configtest မအောင်မြင် — ပြန်ထည့်တယ်"
      cp -p "$BK/$(basename "$APCONF").bak" "$APCONF"
    fi
  fi
fi

[ "$HSTS_DONE" -eq 0 ] && [ "$CHECK_ONLY" -eq 0 ] && \
  warn "HSTS မထည့်နိုင်ဘူး — web server conf ကို လက်နဲ့ ပြင်ပါ"

# ================================================= ၄။ PLAINTEXT CODE ဖျက်
head1 "၄/၅ — Plaintext VIP access code ဖျက်နေတယ်"

if [ "$CHECK_ONLY" -eq 1 ]; then
  LEFT="$( cd "$APP_DIR" && "$PHPBIN" -r '
    require_once "core/bootstrap.php";
    try {
      $r = Db::one("SELECT COUNT(*) c FROM vip_accounts WHERE access_code <> \"\"");
      echo (int)($r["c"] ?? 0);
    } catch (Throwable $e) { echo "?"; }
  ' 2>/dev/null || echo "?" )"
  if [ "$LEFT" = "0" ]; then
    ok "plaintext code မကျန်ဘူး"
  else
    warn "plaintext code $LEFT ခု ကျန်နေတယ် — migrate.php --hash-codes run ပါ"
  fi
else
  if ( cd "$APP_DIR" && "$PHPBIN" bin/migrate.php --hash-codes ); then
    ok "migration ပြီး"
  else
    warn "migration မအောင်မြင် — DB ကို လက်နဲ့ စစ်ပါ:"
    echo "     ${DIM}cd $APP_DIR && php bin/migrate.php --hash-codes${RST}"
  fi
fi

# ======================================================== ၅။ ပြန်စစ်
head1 "၅/၅ — အတည်ပြု စစ်နေတယ်"

# --- ဖိုင် ရောက်မရောက်
if grep -q "registrationKey" "$APP_DIR/core/DeviceAuth.php" 2>/dev/null; then
  ok "DeviceAuth.php အသစ် ရောက်ပြီ (cert-derived key ပါတယ်)"
else
  err "DeviceAuth.php အသစ် မရောက်ဘူး — apply script အရင် run ပါ!"
  echo "     ${DIM}sudo bash deploy/n4core-apply-v23.sh${RST}"
fi

# --- config health check (migrate.php က verdict ရိုက်ပြတယ်)
( cd "$APP_DIR" && "$PHPBIN" bin/migrate.php --device-auth 2>&1 | sed 's/^/  /' ) || true

# --- live HTTP probe
SEC_FAIL=0
if [ -n "$DOMAIN" ]; then
  echo
  info "Live probe — https://$DOMAIN"

  HSTS_HDR="$(curl -sI -m 10 "https://$DOMAIN/admin/" 2>/dev/null \
              | grep -ci "strict-transport-security" || true)"
  [ "${HSTS_HDR:-0}" -gt 0 ] && ok "HSTS header ပြန်လာတယ်" || warn "HSTS header မပြန်လာဘူး"

  # tampered device က register လုပ်လို့ ရလား — ရရင် anti-tamper အလုပ်မလုပ်တာ
  PROBE="$(curl -s -m 10 -o /dev/null -w '%{http_code}' \
    -X POST "https://$DOMAIN/api/public/register_device.php" \
    -H 'Content-Type: application/json' \
    -d '{"device_id":"n4-secure-probe-0000","timestamp":1,"signature":"deadbeef",
         "platform":"android","app_version":"0.0.0",
         "integrity":{"package_name":"com.evil.clone","debuggable":true,
                      "instrumented":true,"su_paths":12,"signer_count":5,
                      "cert_sha256":"","available":true}}' 2>/dev/null || echo "000")"

  case "$PROBE" in
    200) err "tampered device က HTTP 200 ရနေတယ် — anti-tamper အလုပ်မလုပ်ဘူး!"
         echo "     ${DIM}DeviceAuth.php အသစ် ရောက်မရောက် ပြန်စစ်ပါ${RST}" ;;
    401|400|403|422|429) ok "tampered device ပိတ်ထားတယ် (HTTP $PROBE)" ;;
    # 500 ကို အရင် '*)' case နဲ့ info အဖြစ် လွှတ်ပေးခဲ့တယ် — အဲ့ဒါ မှားတယ်။
    # 500 ဆိုတာ endpoint က crash ဖြစ်နေတာ။ App က 200 မဟုတ်တာ အားလုံးကို
    # "could not verify itself with the server" လို့ ပြတာမို့ device တိုင်း
    # server မရတော့ဘူး။ ဒါကို ဒီမှာတင် ဖမ်းရမယ်။
    500|502|503)
         err "register_device.php က HTTP $PROBE — endpoint crash ဖြစ်နေတယ်!"
         echo "     ${DIM}App မှာ 'could not verify itself' ပြမယ်။ Device တိုင်း server မရဘူး။${RST}"
         echo "     ${DIM}အများအားဖြင့် core class ဗားရှင်း ကွဲနေတာ (version skew) ကြောင့်။${RST}"
         echo "     ${DIM}PHP error log ကြည့်ပါ:${RST}"
         echo "     ${DIM}  tail -50 /var/log/php*-fpm.log /var/log/nginx/error.log 2>/dev/null | grep -i 'undefined\\|fatal'${RST}"
         echo "     ${DIM}ဖြေရှင်းရန် — core ဖိုင်အားလုံး ပြန်တင်ပါ (apply script က အခု အကုန် တင်တယ်)${RST}"
         SEC_FAIL=1 ;;
    000) warn "probe မရ — DNS/TLS ကြောင့် ဖြစ်နိုင်တယ်" ;;
    *)   warn "probe HTTP $PROBE — မမျှော်လင့်ထားတဲ့ တုံ့ပြန်မှု" ;;
  esac

  # အရေးအကြီးဆုံး စစ်ချက် — device auth ဖွင့်ထားတဲ့ /public/ endpoint က
  # တကယ် အလုပ်လုပ်လား။ 401 device_auth_required က မှန်တယ် (signature
  # မပါဘဲ ခေါ်တာမို့)။ 500 ဆိုရင် server ပျက်နေတယ်။
  LOC="$(curl -s -m 10 -o /tmp/n4loc.$$ -w '%{http_code}' \
        "https://$DOMAIN/api/public/locations.php" 2>/dev/null || echo "000")"
  case "$LOC" in
    200) ok "locations.php အလုပ်လုပ်တယ် (device auth ပိတ်ထားတယ်)" ;;
    401) if grep -q "device_auth_required\|device_not_registered" /tmp/n4loc.$$ 2>/dev/null; then
           ok "locations.php က device auth တောင်းတယ် (HTTP 401 — မှန်တယ်)"
         else
           warn "locations.php HTTP 401 (အခြားအကြောင်း)"
         fi ;;
    500|502|503)
         err "locations.php က HTTP $LOC — server ပျက်နေတယ်!"
         echo "     ${DIM}Device auth ဖွင့်ရင် server list မရတော့ဘူး ဆိုတာ ဒီအချက်ပဲ။${RST}"
         SEC_FAIL=1 ;;
    000) warn "locations.php probe မရ" ;;
    *)   warn "locations.php HTTP $LOC" ;;
  esac
  rm -f /tmp/n4loc.$$

  # source ဖိုင် ဖော်ပြမပြ
  LEAK=0
  for p in "config/config.php" "core/DeviceAuth.php" "sql/schema_v2.sql"; do
    C="$(curl -s -m 8 -o /dev/null -w '%{http_code}' "https://$DOMAIN/$p" 2>/dev/null || echo "000")"
    [ "$C" = "200" ] && { err "$p က ဖတ်လို့ ရနေတယ် (HTTP 200)!"; LEAK=1; }
  done
  [ "$LEAK" -eq 0 ] && ok "source ဖိုင်တွေ ပိတ်ထားတယ်"
fi

# ---------------------------------------------------------------- fpm reload
if [ "$CHECK_ONLY" -eq 0 ]; then
  for svc in php8.4-fpm php8.3-fpm php8.2-fpm php8.1-fpm php-fpm; do
    if systemctl is-active --quiet "$svc" 2>/dev/null; then
      systemctl reload "$svc" 2>/dev/null || systemctl restart "$svc" 2>/dev/null
      ok "$svc reload ပြီး"
    fi
  done
fi

echo
# API က crash ဖြစ်နေရင် "✅ ပြီးပါပြီ" လို့ မပြရဘူး — အဲ့ဒါက အခု ဖြစ်ခဲ့တဲ့
# ပြဿနာရဲ့ အဓိက အကြောင်းရင်း: script က success ပြပေမယ့် app က မရဘူး။
if [ "${SEC_FAIL:-0}" -ne 0 ]; then
  echo "${RED}══════════════════════════════════════════════════${RST}"
  echo "${RED}${BD}  ❌ API က crash ဖြစ်နေတယ် — App မှာ server မရဘူး${RST}"
  echo "${RED}══════════════════════════════════════════════════${RST}"
  echo
  echo "  ${BD}အမြန် ပြန်ရုပ်ရန် (device auth ပိတ်လိုက်ပါ):${RST}"
  echo "    ${DIM}sudo n4core${RST}  → ၂ (Device auth toggle)"
  echo
  echo "  ${BD}အမြဲတမ်း ဖြေရှင်းရန် — core ဖိုင်အားလုံး ပြန်တင်ပါ:${RST}"
  echo "    ${DIM}sudo bash \$(dirname \"\$0\")/n4core-apply-v23.sh${RST}"
  echo
  exit 1
fi
echo "${GRN}══════════════════════════════════════════════════${RST}"
if [ "$CHECK_ONLY" -eq 1 ]; then
  echo "${GRN}${BD}  ✅ စစ်ပြီးပါပြီ (ဘာမှ မပြင်ထားဘူး)${RST}"
else
  echo "${GRN}${BD}  ✅ Security hardening ပြီးပါပြီ${RST}"
fi
echo "${GRN}══════════════════════════════════════════════════${RST}"
echo
if [ "$CHECK_ONLY" -eq 0 ]; then
  echo "  ${CYN}ပြောင်းသွားတာ:${RST}"
  [ -n "$HASH1" ] && echo "    • Cert pinning ဖွင့်ပြီး — ခိုးပြင်တဲ့ APK register မရတော့ဘူး"
  echo "    • Rate limit — device_id နဲ့ server-wide breaker ၂ ခု ထပ်ထည့်"
  [ "$HSTS_DONE" -eq 1 ] && echo "    • HSTS header — HTTP downgrade attack ပိတ်ပြီး"
  echo "    • VIP access code plaintext မကျန်တော့ဘူး (hash + encrypted ပဲ)"
  echo
  echo "  ${YLW}အရေးကြီး —${RST} App အသစ် (build 8) ကို အရင် ဖြန့်ပါ။"
  echo "  Cert pin ဖွင့်ပြီးရင် pin မကိုက်တဲ့ APK အားလုံး register မရတော့ဘူး။"
  echo
  echo "  ပြန်စစ်ချင်ရင်:  ${DIM}sudo bash $0 --check${RST}"
  echo "  ပြန်ရုပ်ချင်ရင်:  ${DIM}cp $BK/config.php.bak $CFG${RST}"
fi
echo
