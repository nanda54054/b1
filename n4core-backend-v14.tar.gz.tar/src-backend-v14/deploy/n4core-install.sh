#!/usr/bin/env bash
#
# ============================================================================
#  N4 Core VPN — One-Click VPS Installer
# ============================================================================
#  VPS အသစ်တစ်လုံးမှာ backend တစ်ခုလုံးကို တစ်ခါတည်း တင်ပေးတယ်။
#
#  USAGE
#     sudo ./n4core-install.sh core.example.com
#     sudo ./n4core-install.sh core.example.com --no-ssl     (SSL မထုတ်ဘူး)
#     sudo ./n4core-install.sh core.example.com --restore=/root/db.sql
#                                                            (VPS အဟောင်းက data ပြန်သွင်း)
#     sudo ./n4core-install.sh --uninstall                   (ပြန်ဖြုတ်)
#
#  ဘာလုပ်သလဲ
#     1. nginx + php-fpm + mariadb install
#     2. Database + user ဖန်တီး (password အလိုအလျောက်)
#     3. Code ကို /var/www/n4core ကူး
#     4. config.php ထုတ် (secret တွေ အလိုအလျောက်)
#     5. Schema တင် + Super Admin ဖန်တီး
#     6. nginx vhost + Let's Encrypt SSL
#     7. Cron တင် + health check
#
#  လိုအပ်ချက် — Ubuntu 22.04/24.04 or Debian 12, root, domain က VPS ကို
#  ညွှန်ထားပြီးသား ဖြစ်ရမယ် (A record)။
# ============================================================================

set -uo pipefail

APP_DIR="/var/www/n4core"
DB_NAME="n4core"
DB_USER="n4core"
STAMP="$(date +%F-%H%M%S)"
CRED_FILE="/root/n4core-credentials.txt"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

DOMAIN=""
DO_SSL=1
UNINSTALL=0
RESTORE_SQL=""
OLD_KEY=""
OLD_PEPPER=""
OLD_SECRET=""

# ---------------------------------------------------------------- အရောင်
if [ -t 1 ]; then
  R=$'\e[31m'; G=$'\e[32m'; Y=$'\e[33m'; B=$'\e[36m'; BD=$'\e[1m'; N=$'\e[0m'
else
  R=""; G=""; Y=""; B=""; BD=""; N=""
fi

step() { echo; echo "${B}${BD}▸ $*${N}"; }
good() { echo "  ${G}✅ $*${N}"; }
warn() { echo "  ${Y}⚠️  $*${N}"; }
bad()  { echo "  ${R}❌ $*${N}"; }
die()  { bad "$*"; echo; exit 1; }

# ---------------------------------------------------------------- ဆေးဆို
while [ $# -gt 0 ]; do
  case "$1" in
    --no-ssl)    DO_SSL=0 ;;
    --uninstall) UNINSTALL=1 ;;
    --restore=*) RESTORE_SQL="${1#*=}" ;;
    # VPS အဟောင်းက encryption_key ကို မမေးဘဲ တန်းထည့်ချင်ရင်
    # (n4core-migrate.sh က ဒီနည်းနဲ့ ခေါ်ပါတယ်)
    --encryption-key=*) OLD_KEY="${1#*=}" ;;
    --pepper=*)         OLD_PEPPER="${1#*=}" ;;
    --app-secret=*)     OLD_SECRET="${1#*=}" ;;
    -h|--help)   sed -n '3,27p' "$0"; exit 0 ;;
    -*)          die "မသိတဲ့ option: $1" ;;
    *)           DOMAIN="$1" ;;
  esac
  shift
done

[ "$(id -u)" -eq 0 ] || die "root နဲ့ run ပါ:  sudo $0 $*"

# ============================================================ UNINSTALL
if [ "$UNINSTALL" -eq 1 ]; then
  echo "${R}${BD}N4 Core backend ကို ဖြုတ်တော့မယ်။${N}"
  echo "Database နဲ့ file အားလုံး ပျက်ပါမယ်။"
  read -rp "'DELETE' လို့ ရိုက်ပါ: " c
  [ "$c" = "DELETE" ] || die "ရပ်လိုက်ပြီ။"

  step "Backup ယူနေတယ်"
  mkdir -p "/root/n4core-final-backup-${STAMP}"
  mysqldump "$DB_NAME" > "/root/n4core-final-backup-${STAMP}/db.sql" 2>/dev/null \
    && good "DB backup: /root/n4core-final-backup-${STAMP}/db.sql" \
    || warn "DB backup မရ (DB မရှိတော့ဘူးထင်တယ်)"
  [ -d "$APP_DIR" ] && cp -a "$APP_DIR" "/root/n4core-final-backup-${STAMP}/files" 2>/dev/null

  step "ဖြုတ်နေတယ်"
  rm -f /etc/nginx/sites-enabled/n4core.conf /etc/nginx/sites-available/n4core.conf
  systemctl reload nginx 2>/dev/null
  rm -f /etc/cron.d/n4core
  mysql -e "DROP DATABASE IF EXISTS \`$DB_NAME\`; DROP USER IF EXISTS '$DB_USER'@'localhost';" 2>/dev/null
  rm -rf "$APP_DIR"
  good "ဖြုတ်ပြီးပြီ။ Backup: /root/n4core-final-backup-${STAMP}/"
  exit 0
fi

# ============================================================ စစ်ဆေးမှု
[ -n "$DOMAIN" ] || die "Domain ထည့်ပါ:  sudo $0 core.example.com"
echo "$DOMAIN" | grep -Eq '^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$' \
  || die "Domain ပုံစံ မမှန်ပါ: $DOMAIN"

[ -f "$SRC_DIR/bin/install.php" ] \
  || die "Source မတွေ့ပါ။ script ကို backend folder ရဲ့ deploy/ ထဲကနေ run ပါ။"

if [ -n "$RESTORE_SQL" ]; then
  [ -f "$RESTORE_SQL" ] || die "Restore ဖိုင် မတွေ့ပါ: $RESTORE_SQL"
  [ -s "$RESTORE_SQL" ] || die "Restore ဖိုင် ဗလာဖြစ်နေတယ်: $RESTORE_SQL"
  # dump မှန်မမှန် အကြမ်းစစ် — မှားတာကို DB ထဲ မထည့်မိအောင်
  grep -qi "CREATE TABLE\|INSERT INTO" "$RESTORE_SQL" \
    || die "Restore ဖိုင်က mysqldump ပုံစံ မဟုတ်ပါ: $RESTORE_SQL"
fi

echo
echo "${BD}════════════════════════════════════════════════${N}"
echo "${BD}  N4 Core VPN — VPS Installer${N}"
echo "${BD}════════════════════════════════════════════════${N}"
echo "  Domain   : ${BD}$DOMAIN${N}"
echo "  Install  : $APP_DIR"
echo "  SSL      : $([ "$DO_SSL" -eq 1 ] && echo 'ထုတ်မယ် (Let'\''s Encrypt)' || echo 'မထုတ်ဘူး')"
echo "  Source   : $SRC_DIR"
[ -n "$RESTORE_SQL" ] && echo "  Restore  : ${BD}$RESTORE_SQL${N}"
echo

if [ -d "$APP_DIR" ]; then
  warn "$APP_DIR ရှိနေပြီးသားပါ — ဖိပြီး တင်မယ် (config နဲ့ DB က မထိပါ)"
fi
read -rp "ဆက်လုပ်မလား? [y/N] " a
case "$a" in y|Y|yes) ;; *) die "ရပ်လိုက်ပြီ။" ;; esac

# ============================================================ 1. PACKAGES
step "1/7 — Package တွေ install လုပ်နေတယ်"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq || die "apt update မအောင်မြင်ပါ"

PKGS="nginx mariadb-server php-fpm php-mysql php-mbstring php-curl php-json php-xml unzip curl cron rsync"
[ "$DO_SSL" -eq 1 ] && PKGS="$PKGS certbot python3-certbot-nginx"

apt-get install -y -qq $PKGS || die "package install မအောင်မြင်ပါ"

PHP_VER="$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')"
PHP_SOCK="$(find /run/php -name 'php*-fpm.sock' 2>/dev/null | head -1)"
[ -n "$PHP_SOCK" ] || die "php-fpm socket မတွေ့ပါ"
good "PHP $PHP_VER  ·  socket: $PHP_SOCK"

systemctl enable --now mariadb nginx >/dev/null 2>&1
good "nginx + mariadb စတင်ပြီး"

# ============================================================ 2. DATABASE
step "2/7 — Database ပြင်ဆင်နေတယ်"
if mysql -e "USE \`$DB_NAME\`" 2>/dev/null; then
  good "Database '$DB_NAME' ရှိပြီးသား — မထိပါ"
  DB_PASS="$(php -r '
    $c = @include $argv[1];
    echo is_array($c) ? ($c["db"]["pass"] ?? "") : "";
  ' "$APP_DIR/config/config.php" 2>/dev/null)"
  [ -n "$DB_PASS" ] || die "DB ရှိပေမဲ့ config.php ထဲက password မဖတ်နိုင်ပါ"
else
  DB_PASS="$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 28)"
  mysql <<SQL || die "Database ဖန်တီးမရပါ"
CREATE DATABASE \`$DB_NAME\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASS';
GRANT ALL PRIVILEGES ON \`$DB_NAME\`.* TO '$DB_USER'@'localhost';
FLUSH PRIVILEGES;
SQL
  good "Database '$DB_NAME' + user '$DB_USER' ဖန်တီးပြီး"
fi

# ============================================================ 3. FILES
step "3/7 — Code ကူးနေတယ်"
if [ -d "$APP_DIR/config" ]; then
  cp -a "$APP_DIR/config" "/root/n4core-config-backup-${STAMP}" 2>/dev/null && \
    good "config backup: /root/n4core-config-backup-${STAMP}"
fi

mkdir -p "$APP_DIR"
# config/ နဲ့ storage/ ကို မဖိပါ — ရှိပြီးသား secret နဲ့ log မပျက်အောင်
rsync -a --exclude 'config/config.php' --exclude 'storage/' \
      "$SRC_DIR"/ "$APP_DIR"/ || die "file ကူးမရပါ"
mkdir -p "$APP_DIR"/storage/{logs,cache,tmp,backups}

chown -R www-data:www-data "$APP_DIR"
find "$APP_DIR" -type d -exec chmod 755 {} \;
find "$APP_DIR" -type f -exec chmod 644 {} \;
chmod -R 775 "$APP_DIR"/storage
chmod 750 "$APP_DIR"/bin
good "Code ကူးပြီး → $APP_DIR"

# ============================================================ 4. CONFIG
step "4/7 — config.php ထုတ်နေတယ်"
if [ -f "$APP_DIR/config/config.php" ]; then
  good "config.php ရှိပြီးသား — secret တွေ မထိပါ"
else
  sudo -u www-data php "$APP_DIR/bin/keygen.php" --write >/dev/null \
    || die "keygen မအောင်မြင်ပါ"
  good "Secret တွေ ထုတ်ပြီး"

  # Secret ၃ ခု (encryption_key / pepper / app_secret) ကို ဒီမှာ
  # မတောင်းတော့ပါ။ backup archive ထဲမှာ config/config.php ပါပြီးသားမို့
  # bin/restore.php က သူ့ဘာသာသူ ဆွဲထုတ်ပြီး ထည့်ပေးပါတယ်။
  #
  # flag နဲ့ ပေးလိုက်ရင်တော့ လက်ခံပါတယ် (script အဟောင်းတွေ ဆက်အလုပ်လုပ်ဖို့)။
  if [ -n "$OLD_KEY" ] || [ -n "$OLD_PEPPER" ] || [ -n "$OLD_SECRET" ]; then
    php -r '
      [, $f, $enc, $pep, $sec] = $argv;
      $s = file_get_contents($f);
      $done = [];
      foreach (["encryption_key" => $enc, "pepper" => $pep, "app_secret" => $sec] as $k => $v) {
        if ($v === "") { continue; }
        $n = 0;
        $s = preg_replace("/(\x27".$k."\x27\s*=>\s*\x27)[^\x27]*/", "\${1}".$v, $s, 1, $n);
        if ($n !== 1) { fwrite(STDERR, $k." line not found\n"); exit(1); }
        $done[] = $k;
      }
      file_put_contents($f, $s);
      fwrite(STDOUT, implode(", ", $done));
    ' "$APP_DIR/config/config.php" "$OLD_KEY" "$OLD_PEPPER" "$OLD_SECRET" \
      > /tmp/n4keys.out 2>/tmp/n4keys.err \
      && good "Secret အဟောင်း ထည့်ပြီး: $(cat /tmp/n4keys.out)" \
      || die "Secret ထည့်လို့ မရပါ: $(cat /tmp/n4keys.err)"
    rm -f /tmp/n4keys.out /tmp/n4keys.err
  fi
fi

# DB အချက်အလက်နဲ့ domain ကို ထည့်။ keygen.php က secret တွေ ထည့်ပြီးသားမို့
# db block နဲ့ cors ပဲ ထိတယ် — တခြားဘာမှ မပြောင်းပါ။
php -r '
[, $f, $db, $user, $pass, $domain] = $argv;
$s = file_get_contents($f);
$n = 0;
// db block ထဲက name/user/pass သုံးလုံးပဲ — တခြားနေရာက name/user မထိအောင်
// db => [ ... ] အပိုင်းကို သီးသန့် ဖြတ်ပြီး ပြင်တယ်။
$s = preg_replace_callback(
  "/(\x27db\x27\s*=>\s*\[)(.*?)(\n    \],)/s",
  function ($m) use ($db, $user, $pass) {
    $b = $m[2];
    $b = preg_replace("/(\x27name\x27\s*=>\s*\x27)[^\x27]*/", "\${1}".$db,   $b, 1);
    $b = preg_replace("/(\x27user\x27\s*=>\s*\x27)[^\x27]*/", "\${1}".$user, $b, 1);
    $b = preg_replace("/(\x27pass\x27\s*=>\s*\x27)[^\x27]*/", "\${1}".$pass, $b, 1);
    return $m[1].$b.$m[3];
  },
  $s, 1, $n
);
if ($n !== 1) { fwrite(STDERR, "db block not found\n"); exit(1); }
$s = preg_replace("/(\x27allowed_origins\x27\s*=>\s*\[)[^\]]*/",
                  "\${1}\x27https://".$domain."\x27",
                  $s, 1);
file_put_contents($f, $s);
' "$APP_DIR/config/config.php" "$DB_NAME" "$DB_USER" "$DB_PASS" "$DOMAIN" \
  || die "config.php ပြင်မရပါ"

# ပြင်လိုက်တာ တကယ်ဝင်လား စစ်တယ် — မဝင်ရင် install.php က ဘာမှန်းမသိတဲ့
# DB error နဲ့ ကျမှာမို့ အခုတင် ဖမ်းတာ ပိုကောင်းတယ်။
grep -q "'name'    => '$DB_NAME'" "$APP_DIR/config/config.php" 2>/dev/null \
  || grep -q "'name' => '$DB_NAME'" "$APP_DIR/config/config.php" \
  || die "config.php ထဲ DB name မဝင်ပါ — ကိုယ်တိုင် ပြင်ပါ: $APP_DIR/config/config.php"

chown www-data:www-data "$APP_DIR/config/config.php"
chmod 640 "$APP_DIR/config/config.php"
good "DB + domain ချိတ်ပြီး"

# ============================================================ 5. SCHEMA
step "5/7 — Schema တင်ပြီး Admin ဖန်တီးနေတယ်"

# VPS အဟောင်းက dump ကို schema မတင်ခင် သွင်းတယ်။ dump ထဲမှာ table
# အပြည့်ပါပြီးသားမို့ install.php က ကျန်တာဖြည့်ပြီး migration ဆက်လုပ်မယ်။
if [ -n "$RESTORE_SQL" ]; then
  echo "  ⏳ Data ပြန်သွင်းနေတယ် — ဖိုင်ကြီးရင် ခဏစောင့်ပါ"
  if mysql "$DB_NAME" < "$RESTORE_SQL" 2>/tmp/n4restore.err; then
    RC="$(mysql -N -B -e "SELECT COUNT(*) FROM \`$DB_NAME\`.vip_accounts" 2>/dev/null || echo '?')"
    SC="$(mysql -N -B -e "SELECT COUNT(*) FROM \`$DB_NAME\`.servers" 2>/dev/null || echo '?')"
    good "ပြန်သွင်းပြီး — VIP account $RC ခု · server $SC ခု"
  else
    bad "Restore မအောင်မြင်ပါ:"
    sed 's/^/     /' /tmp/n4restore.err | head -5
    die "DB ကို လက်နဲ့ ရှင်းပြီး ပြန်စမ်းပါ"
  fi
fi

sudo -u www-data php "$APP_DIR/bin/install.php" || die "install.php မအောင်မြင်ပါ"

ADMIN_PASS=""
ADMIN_USER="owner"
ADMIN_EXISTS="$(mysql -N -B -e "SELECT COUNT(*) FROM \`$DB_NAME\`.admin_users" 2>/dev/null || echo 0)"
if [ "$ADMIN_EXISTS" = "0" ]; then
  ADMIN_PASS="$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 20)"
  sudo -u www-data php "$APP_DIR/bin/create_admin.php" \
    --username="$ADMIN_USER" --role=super --password="$ADMIN_PASS" >/dev/null \
    || die "Admin ဖန်တီးမရပါ"
  good "Super Admin '$ADMIN_USER' ဖန်တီးပြီး"
elif [ -n "$RESTORE_SQL" ]; then
  # Dump ကနေ admin တွေ ပါလာတယ်။ password အဟောင်း သိရင် အဲ့ဒါနဲ့ပဲ ဝင်လို့ရတယ်။
  # မသိရင် panel ကို ဘယ်တော့မှ ဝင်လို့ရမှာ မဟုတ်တော့လို့ ဒီမှာ ရွေးခွင့်ပေးတယ်။
  good "Dump ထဲက admin $ADMIN_EXISTS ယောက် ပါလာတယ်"
  echo
  read -rp "  Password အသစ်နဲ့ recovery admin တစ်ယောက် ထပ်လုပ်မလား? [y/N] " mk
  case "$mk" in
    y|Y|yes)
      ADMIN_USER="recovery"
      ADMIN_PASS="$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 20)"
      sudo -u www-data php "$APP_DIR/bin/create_admin.php" \
        --username="$ADMIN_USER" --role=super --password="$ADMIN_PASS" >/dev/null \
        && good "Super Admin 'recovery' ဖန်တီးပြီး" \
        || { warn "မအောင်မြင်ပါ — 'recovery' ရှိနေပြီလား စစ်ပါ"; ADMIN_PASS=""; }
      ;;
    *) good "Admin အဟောင်းတွေနဲ့ပဲ ဝင်ပါ" ;;
  esac
else
  good "Admin ရှိပြီးသား ($ADMIN_EXISTS ယောက်) — အသစ်မလုပ်ပါ"
fi

# ============================================================ 6. NGINX
step "6/7 — nginx + SSL ပြင်ဆင်နေတယ်"
cat > /etc/nginx/sites-available/n4core.conf <<NGINX
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN;
    root $APP_DIR;
    index index.php index.html;

    client_max_body_size 8m;
    server_tokens off;

    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header Referrer-Policy "same-origin" always;

    # Secret တွေ web ကနေ လုံးဝ မဖတ်ရ
    location ~ ^/(config|core|storage|bin|sql|tests|deploy|docs)/ {
        deny all;
        return 404;
    }
    location ~ /\. { deny all; return 404; }

    location /api/ {
        try_files \$uri =404;
    }

    location / {
        try_files \$uri \$uri/ =404;
    }

    location ~ \.php\$ {
        try_files \$uri =404;
        fastcgi_pass unix:$PHP_SOCK;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_read_timeout 60;
    }
}
NGINX

ln -sf /etc/nginx/sites-available/n4core.conf /etc/nginx/sites-enabled/n4core.conf
rm -f /etc/nginx/sites-enabled/default
nginx -t >/dev/null 2>&1 || die "nginx config မမှန်ပါ — 'nginx -t' နဲ့ စစ်ပါ"
systemctl reload nginx
good "nginx vhost တင်ပြီး"

if [ "$DO_SSL" -eq 1 ]; then
  if certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos \
       --register-unsafely-without-email --redirect >/dev/null 2>&1; then
    good "SSL ထုတ်ပြီး (auto-renew ပါ)"
    SCHEME="https"
  else
    warn "SSL မထုတ်နိုင်ပါ — domain က ဒီ VPS ကို ညွှန်မထားလို့ ဖြစ်နိုင်တယ်"
    warn "DNS ပြင်ပြီးမှ:  certbot --nginx -d $DOMAIN"
    SCHEME="http"
  fi
else
  SCHEME="http"
fi

# ============================================================ 7. CRON
step "7/7 — Cron တင်ပြီး စစ်ဆေးနေတယ်"
cat > /etc/cron.d/n4core <<CRON
# N4 Core VPN — housekeeping + nightly backup
SHELL=/bin/bash
PATH=/usr/local/bin:/usr/bin:/bin

# Housekeeping only (sessions, rate limits, nonces) — every 10 minutes.
*/10 * * * * www-data php $APP_DIR/bin/cron.php --prune-only >/dev/null 2>&1

# Backup gate — runs hourly, and cron.php itself decides whether it is
# backup o'clock in Asia/Yangon (default 00:00, changeable in Settings).
# The hourly tick is what lets it catch up if the box was down at midnight.
0 * * * * www-data php $APP_DIR/bin/cron.php >> $APP_DIR/storage/logs/cron.log 2>&1
CRON
chmod 644 /etc/cron.d/n4core
mkdir -p "$APP_DIR/storage/logs"
chown -R www-data:www-data "$APP_DIR/storage" 2>/dev/null || true
systemctl restart cron 2>/dev/null || systemctl restart crond 2>/dev/null
good "Cron တင်ပြီး (housekeeping ၁၀ မိနစ်တစ်ခါ · Backup ည ၁၂ နာရီ)"

HEALTH="$(curl -s -o /dev/null -w '%{http_code}' \
  "$SCHEME://$DOMAIN/api/public/locations.php" 2>/dev/null)"
if [ "$HEALTH" = "200" ] || [ "$HEALTH" = "403" ] || [ "$HEALTH" = "401" ]; then
  good "API တုံ့ပြန်နေပြီ (HTTP $HEALTH)"
else
  warn "API စစ်လို့ HTTP $HEALTH ရတယ် — DNS မရောက်သေးရင် ခဏနေမှ ပြန်စစ်ပါ"
fi

# ============================================================ ရလဒ်
{
  echo "N4 Core VPN — Install $(date)"
  echo "=============================================="
  echo "Domain        : $SCHEME://$DOMAIN"
  echo "Admin panel   : $SCHEME://$DOMAIN/admin/"
  echo "API base      : $SCHEME://$DOMAIN/api"
  echo "App directory : $APP_DIR"
  echo
  echo "Database name : $DB_NAME"
  echo "Database user : $DB_USER"
  echo "Database pass : $DB_PASS"
  [ -n "$ADMIN_PASS" ] && { echo; echo "Admin user    : $ADMIN_USER"; echo "Admin pass    : $ADMIN_PASS"; }
} > "$CRED_FILE"
chmod 600 "$CRED_FILE"

echo
echo "${G}${BD}════════════════════════════════════════════════${N}"
echo "${G}${BD}  ✅ တင်ပြီးပါပြီ${N}"
echo "${G}${BD}════════════════════════════════════════════════${N}"
echo
echo "  Admin panel : ${BD}$SCHEME://$DOMAIN/admin/${N}"
if [ -n "$ADMIN_PASS" ]; then
  echo "  Username    : ${BD}$ADMIN_USER${N}"
  echo "  Password    : ${BD}$ADMIN_PASS${N}"
  echo "  ${Y}↑ ဒီ password ကို ချက်ချင်း သိမ်းပါ — ထပ်မပြပါ${N}"
else
  echo "  Username    : ${BD}admin အဟောင်းတွေနဲ့ ဝင်ပါ${N}"
fi
echo
echo "  အားလုံး သိမ်းထားတဲ့နေရာ: ${BD}$CRED_FILE${N}"
echo
echo "${BD}နောက်တစ်ဆင့် — GitHub config ပြင်ပါ${N}"
echo "  https://github.com/Nanda-N4/Core → n4core-config.json"
echo
echo "    \"api_base_url\": \"$SCHEME://$DOMAIN/api\","
echo
echo "  ဒီတစ်ကြောင်း ပြောင်းလိုက်ရင် app က VPS အသစ်ကို ချက်ချင်း လှည့်ပါမယ်။"
echo "  App ကို ပြန် build စရာ မလိုပါ။"
echo
