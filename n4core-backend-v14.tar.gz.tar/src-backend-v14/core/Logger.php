<?php
/**
 * Minimal file logger. Writes JSON lines to storage/logs/app-YYYY-MM-DD.log.
 * Never echoes anything to the client.
 */
declare(strict_types=1);

final class Logger
{
    private static ?string $dir = null;

    private static function dir(): string
    {
        if (self::$dir !== null) {
            return self::$dir;
        }
        $dir = Config::storagePath('logs');
        if (!is_dir($dir)) {
            @mkdir($dir, 0750, true);
        }
        return self::$dir = $dir;
    }

    public static function write(string $level, string $event, array $ctx = []): void
    {
        try {
            $line = json_encode([
                'ts'    => date('c'),
                'level' => $level,
                'event' => $event,
                'ip'    => PHP_SAPI === 'cli' ? 'cli' : Request::ip(),
                'ctx'   => self::scrub($ctx),
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

            $file = self::dir() . '/app-' . date('Y-m-d') . '.log';
            @file_put_contents($file, $line . "\n", FILE_APPEND | LOCK_EX);
            @chmod($file, 0640);
        } catch (Throwable) {
            // logging must never throw
        }
    }

    /** Redacts anything that looks like a secret before it reaches disk. */
    private static function scrub(array $ctx): array
    {
        $sensitive = [
            'password', 'new_password', 'current_password', 'access_code',
            'token', 'admin_token', 'vip_token', 'secret', 'bot_token',
            'raw_config', 'password_hash', 'access_code_hash',
        ];
        foreach ($ctx as $k => $v) {
            if (in_array(strtolower((string) $k), $sensitive, true)) {
                $ctx[$k] = '[redacted]';
            } elseif (is_array($v)) {
                $ctx[$k] = self::scrub($v);
            } elseif (is_string($v) && strlen($v) > 500) {
                $ctx[$k] = substr($v, 0, 500) . '...[truncated]';
            }
        }
        return $ctx;
    }

    public static function info(string $e, array $c = []): void  { self::write('info', $e, $c); }
    public static function warn(string $e, array $c = []): void  { self::write('warn', $e, $c); }
    public static function error(string $e, array $c = []): void { self::write('error', $e, $c); }

    /** Deletes logs older than $days. Called by bin/cron.php. */
    public static function prune(int $days = 30): int
    {
        $n = 0;
        $cutoff = time() - $days * 86400;
        foreach (glob(self::dir() . '/app-*.log') ?: [] as $f) {
            if (@filemtime($f) < $cutoff) {
                @unlink($f);
                $n++;
            }
        }
        return $n;
    }
}
