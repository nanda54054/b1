<?php
/**
 * Country/region presets + helpers. Used by the parser's auto-fill, by
 * bulk import (auto-creating a region when a new country shows up), and
 * by the dashboard's region picker.
 */
declare(strict_types=1);

final class Locations
{
    /** code => [name, flag] */
    public const PRESETS = [
        'SG' => ['Singapore', '🇸🇬'],           'MM' => ['Myanmar', '🇲🇲'],
        'TH' => ['Thailand', '🇹🇭'],            'JP' => ['Japan', '🇯🇵'],
        'US' => ['United States', '🇺🇸'],       'GB' => ['United Kingdom', '🇬🇧'],
        'DE' => ['Germany', '🇩🇪'],             'FR' => ['France', '🇫🇷'],
        'KR' => ['South Korea', '🇰🇷'],         'HK' => ['Hong Kong', '🇭🇰'],
        'TW' => ['Taiwan', '🇹🇼'],              'IN' => ['India', '🇮🇳'],
        'MY' => ['Malaysia', '🇲🇾'],            'VN' => ['Vietnam', '🇻🇳'],
        'ID' => ['Indonesia', '🇮🇩'],           'PH' => ['Philippines', '🇵🇭'],
        'CN' => ['China', '🇨🇳'],               'CA' => ['Canada', '🇨🇦'],
        'AU' => ['Australia', '🇦🇺'],           'NL' => ['Netherlands', '🇳🇱'],
        'CH' => ['Switzerland', '🇨🇭'],         'SE' => ['Sweden', '🇸🇪'],
        'FI' => ['Finland', '🇫🇮'],             'NO' => ['Norway', '🇳🇴'],
        'DK' => ['Denmark', '🇩🇰'],             'PL' => ['Poland', '🇵🇱'],
        'RU' => ['Russia', '🇷🇺'],              'TR' => ['Turkey', '🇹🇷'],
        'AE' => ['United Arab Emirates', '🇦🇪'], 'SA' => ['Saudi Arabia', '🇸🇦'],
        'BR' => ['Brazil', '🇧🇷'],              'AR' => ['Argentina', '🇦🇷'],
        'MX' => ['Mexico', '🇲🇽'],              'ZA' => ['South Africa', '🇿🇦'],
        'IT' => ['Italy', '🇮🇹'],               'ES' => ['Spain', '🇪🇸'],
        'IE' => ['Ireland', '🇮🇪'],             'AT' => ['Austria', '🇦🇹'],
        'BE' => ['Belgium', '🇧🇪'],             'CZ' => ['Czechia', '🇨🇿'],
        'RO' => ['Romania', '🇷🇴'],             'UA' => ['Ukraine', '🇺🇦'],
        'KH' => ['Cambodia', '🇰🇭'],            'LA' => ['Laos', '🇱🇦'],
        'BD' => ['Bangladesh', '🇧🇩'],          'PK' => ['Pakistan', '🇵🇰'],
        'NP' => ['Nepal', '🇳🇵'],               'LK' => ['Sri Lanka', '🇱🇰'],
        'IL' => ['Israel', '🇮🇱'],              'NZ' => ['New Zealand', '🇳🇿'],
        'KZ' => ['Kazakhstan', '🇰🇿'],          'AM' => ['Armenia', '🇦🇲'],
        'GE' => ['Georgia', '🇬🇪'],             'MD' => ['Moldova', '🇲🇩'],
        'LT' => ['Lithuania', '🇱🇹'],           'LV' => ['Latvia', '🇱🇻'],
        'EE' => ['Estonia', '🇪🇪'],             'HU' => ['Hungary', '🇭🇺'],
        'BG' => ['Bulgaria', '🇧🇬'],            'RS' => ['Serbia', '🇷🇸'],
        'GR' => ['Greece', '🇬🇷'],              'PT' => ['Portugal', '🇵🇹'],
        'CL' => ['Chile', '🇨🇱'],               'CO' => ['Colombia', '🇨🇴'],
        'PE' => ['Peru', '🇵🇪'],                'EG' => ['Egypt', '🇪🇬'],
        'NG' => ['Nigeria', '🇳🇬'],             'KE' => ['Kenya', '🇰🇪'],
    ];

    /** @return array{name:string,flag:string}|null */
    public static function preset(string $code): ?array
    {
        $code = strtoupper(trim($code));
        if (!isset(self::PRESETS[$code])) {
            return null;
        }
        return ['name' => self::PRESETS[$code][0], 'flag' => self::PRESETS[$code][1]];
    }

    /** Derives the regional-indicator flag emoji from any 2-letter code. */
    public static function flagFor(string $code): string
    {
        $code = strtoupper(preg_replace('/[^A-Za-z]/', '', $code) ?? '');
        if (strlen($code) !== 2) {
            return '🌐';
        }
        $flag = '';
        foreach ([$code[0], $code[1]] as $ch) {
            $flag .= mb_chr(0x1F1E6 + (ord($ch) - ord('A')), 'UTF-8');
        }
        return $flag;
    }

    /**
     * Returns the location id for a country code, creating the row when it
     * does not exist yet. Used by bulk import so pasting 50 links from 12
     * countries just works.
     */
    public static function ensure(string $code, ?string $name = null): ?string
    {
        $code = strtoupper(trim($code));
        if (strlen($code) < 2 || strlen($code) > 8) {
            return null;
        }

        $existing = Db::value('SELECT id FROM locations WHERE country_code = ?', [$code]);
        if ($existing) {
            return (string) $existing;
        }

        $preset = self::preset($code);
        $finalName = $name ?? ($preset['name'] ?? $code);
        $flag      = $preset['flag'] ?? self::flagFor($code);

        $id = Crypto::uuid4();
        $nextOrder = (int) (Db::value('SELECT COALESCE(MAX(sort_order), 0) + 1 FROM locations') ?? 1);

        try {
            Db::run(
                'INSERT INTO locations (id, name, country_code, flag_emoji, sort_order, is_enabled)
                 VALUES (?, ?, ?, ?, ?, 1)',
                [$id, mb_substr($finalName, 0, 100), $code, $flag, $nextOrder]
            );
            Audit::log('location.auto_create', 'location', $id, ['code' => $code, 'name' => $finalName]);
            return $id;
        } catch (Throwable $e) {
            // Race with a concurrent insert — re-read.
            $again = Db::value('SELECT id FROM locations WHERE country_code = ?', [$code]);
            return $again ? (string) $again : null;
        }
    }

    /** Presets not yet present in the DB (for the "Bulk Add" picker). */
    public static function availablePresets(): array
    {
        $have = [];
        foreach (Db::all('SELECT country_code FROM locations') as $r) {
            $have[strtoupper((string) $r['country_code'])] = true;
        }
        $out = [];
        foreach (self::PRESETS as $code => [$name, $flag]) {
            if (!isset($have[$code])) {
                $out[] = ['country_code' => $code, 'name' => $name, 'flag_emoji' => $flag];
            }
        }
        return $out;
    }
}
