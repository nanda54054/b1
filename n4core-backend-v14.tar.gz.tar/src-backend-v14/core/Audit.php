<?php
/**
 * Audit trail. Every mutating admin/telegram action writes one row here,
 * so "who deleted that server?" always has an answer.
 */
declare(strict_types=1);

final class Audit
{
    public static function log(
        string $action,
        ?string $entityType = null,
        ?string $entityId = null,
        array $detail = [],
        string $actorType = 'admin',
        ?string $actorId = null,
        ?string $actorName = null
    ): void {
        try {
            // Default actor = the currently authenticated admin.
            if ($actorType === 'admin' && $actorId === null) {
                $admin = Auth::currentAdmin();
                if ($admin) {
                    $actorId   = (string) $admin['admin_id'];
                    $actorName = $admin['username'] . ' (' . $admin['role'] . ')';
                }
            }

            Db::run(
                'INSERT INTO audit_log
                   (actor_type, actor_id, actor_name, action, entity_type, entity_id, detail, ip, user_agent)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [
                    $actorType,
                    $actorId,
                    $actorName !== null ? mb_substr($actorName, 0, 128) : null,
                    mb_substr($action, 0, 64),
                    $entityType !== null ? mb_substr($entityType, 0, 48) : null,
                    $entityId !== null ? mb_substr($entityId, 0, 64) : null,
                    $detail ? json_encode(self::scrub($detail), JSON_UNESCAPED_UNICODE) : null,
                    PHP_SAPI === 'cli' ? null : Request::ip(),
                    PHP_SAPI === 'cli' ? 'cli' : Request::userAgent(),
                ]
            );
        } catch (Throwable $e) {
            Logger::error('audit_write_failed', ['msg' => $e->getMessage(), 'action' => $action]);
        }
    }

    private static function scrub(array $d): array
    {
        $keys = ['password', 'access_code', 'raw_config', 'token', 'new_password', 'current_password'];
        foreach ($d as $k => $v) {
            if (in_array(strtolower((string) $k), $keys, true)) {
                $d[$k] = '[redacted]';
            } elseif (is_array($v)) {
                $d[$k] = self::scrub($v);
            } elseif (is_string($v) && strlen($v) > 300) {
                $d[$k] = substr($v, 0, 300) . '...';
            }
        }
        return $d;
    }

    public static function recent(int $limit = 100, ?string $action = null): array
    {
        $limit = max(1, min(500, $limit));
        if ($action) {
            return Db::all(
                'SELECT * FROM audit_log WHERE action LIKE ? ORDER BY id DESC LIMIT ' . $limit,
                [$action . '%']
            );
        }
        return Db::all('SELECT * FROM audit_log ORDER BY id DESC LIMIT ' . $limit);
    }

    public static function prune(int $days = 180): int
    {
        try {
            return Db::run('DELETE FROM audit_log WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)', [$days]);
        } catch (Throwable) {
            return 0;
        }
    }
}
