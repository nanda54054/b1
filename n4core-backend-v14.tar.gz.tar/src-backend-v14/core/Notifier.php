<?php
/**
 * Turns backend events into Telegram messages: login alarms, security
 * alerts, backup reports. Every send is best-effort — a Telegram outage
 * must never break the API.
 */
declare(strict_types=1);

final class Notifier
{
    /** @return array<int,array> active telegram admins by notify flag */
    private static function recipients(string $flag): array
    {
        try {
            $rows = Db::all(
                "SELECT telegram_user_id, role FROM telegram_admins
                 WHERE is_active = 1 AND {$flag} = 1",
                []
            );
        } catch (Throwable) {
            $rows = [];
        }

        $ids = [];
        foreach ($rows as $r) {
            $ids[(int) $r['telegram_user_id']] = $r;
        }
        // The owner always gets everything, even if the row is missing.
        $owner = Telegram::ownerId();
        if ($owner > 0 && !isset($ids[$owner])) {
            $ids[$owner] = ['telegram_user_id' => $owner, 'role' => 'owner'];
        }
        return $ids;
    }

    private static function broadcast(string $flag, string $html): void
    {
        if (!Telegram::enabled()) {
            return;
        }
        foreach (array_keys(self::recipients($flag)) as $chatId) {
            try {
                Telegram::send((int) $chatId, $html);
            } catch (Throwable $e) {
                Logger::warn('notify_failed', ['chat' => $chatId, 'msg' => $e->getMessage()]);
            }
        }
    }

    /** Owner-only message (used for sensitive credential delivery). */
    public static function toOwner(string $html): void
    {
        $owner = Telegram::ownerId();
        if ($owner > 0) {
            Telegram::send($owner, $html);
        }
    }

    // =================================================================
    // Events
    // =================================================================

    /** Dashboard login alarm. */
    public static function loginAlert(array $admin, string $ip, string $userAgent): void
    {
        if (!Config::settingBool('login_alert_enabled', true)) {
            return;
        }

        $role = $admin['role'] === Auth::ROLE_SUPER ? '👑 Super Admin' : '👤 Admin';
        $when = date('Y-m-d H:i:s');
        $tz   = (string) Config::get('app.timezone', 'Asia/Yangon');

        $html =
            "🔐 <b>Dashboard Login</b>\n"
            . "━━━━━━━━━━━━━━━━━━\n"
            . "User: <code>" . Telegram::esc((string) $admin['username']) . "</code>\n"
            . "Role: {$role}\n"
            . "IP: <code>" . Telegram::esc($ip) . "</code>\n"
            . "Time: <code>{$when}</code> ({$tz})\n"
            . "Device: <i>" . Telegram::esc(self::shortUa($userAgent)) . "</i>\n\n"
            . "<i>If this was not you, use /revoke immediately.</i>";

        self::broadcast('notify_login', $html);

        try {
            Db::run(
                'UPDATE login_events SET notified = 1
                 WHERE kind = ? AND username = ? ORDER BY id DESC LIMIT 1',
                ['admin_success', $admin['username']]
            );
        } catch (Throwable) {
        }
    }

    /** Lockouts, CSRF failures, suspicious activity. */
    public static function securityAlert(string $html): void
    {
        self::broadcast('notify_security', "⚠️ <b>Security Alert</b>\n━━━━━━━━━━━━━━━━━━\n" . $html);
    }

    /** Backup result. */
    public static function backupReport(string $html): void
    {
        self::broadcast('notify_backup', $html);
    }

    /** Admin account created / deleted / role changed. */
    public static function adminChange(string $html): void
    {
        self::broadcast('notify_security', $html);
    }

    private static function shortUa(string $ua): string
    {
        if ($ua === '') {
            return 'unknown';
        }
        $browser = 'Unknown browser';
        foreach ([
            'Edg/' => 'Edge', 'OPR/' => 'Opera', 'Chrome/' => 'Chrome',
            'Firefox/' => 'Firefox', 'Safari/' => 'Safari',
        ] as $needle => $label) {
            if (str_contains($ua, $needle)) {
                $browser = $label;
                break;
            }
        }
        $os = 'Unknown OS';
        foreach ([
            'Windows NT 10' => 'Windows', 'Windows' => 'Windows', 'Android' => 'Android',
            'iPhone' => 'iPhone', 'iPad' => 'iPad', 'Mac OS X' => 'macOS', 'Linux' => 'Linux',
        ] as $needle => $label) {
            if (str_contains($ua, $needle)) {
                $os = $label;
                break;
            }
        }
        return "$browser on $os";
    }
}
