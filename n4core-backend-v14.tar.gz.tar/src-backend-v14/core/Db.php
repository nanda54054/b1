<?php
/**
 * PDO wrapper. Prepared statements only, no emulation, exceptions on.
 */
declare(strict_types=1);

final class Db
{
    private static ?PDO $pdo = null;

    public static function pdo(): PDO
    {
        if (self::$pdo !== null) {
            return self::$pdo;
        }

        $host    = (string) Config::get('db.host', '127.0.0.1');
        $port    = (int)    Config::get('db.port', 3306);
        $name    = (string) Config::get('db.name', '');
        $user    = (string) Config::get('db.user', '');
        $pass    = (string) Config::get('db.pass', '');
        $charset = (string) Config::get('db.charset', 'utf8mb4');
        $sslCa   = Config::get('db.ssl_ca');

        // A leading slash means "unix socket path".
        if (str_starts_with($host, '/')) {
            $dsn = "mysql:unix_socket={$host};dbname={$name};charset={$charset}";
        } else {
            $dsn = "mysql:host={$host};port={$port};dbname={$name};charset={$charset}";
        }

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_STRINGIFY_FETCHES  => false,
        ];
        if ($sslCa) {
            $options[PDO::MYSQL_ATTR_SSL_CA] = $sslCa;
        }

        try {
            self::$pdo = new PDO($dsn, $user, $pass, $options);
            // Strict mode: silent truncation is how bad data gets in.
            self::$pdo->exec("SET SESSION sql_mode = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION'");

            // ---- CRITICAL: align MySQL's clock with PHP's -------------
            // Almost every VPS/cPanel box runs MySQL in UTC while we run
            // PHP in Asia/Yangon. Session expiry, lockouts and backup
            // scheduling all compare NOW() against PHP timestamps, so a
            // 6h30m skew would expire every session the moment it is
            // issued. Pinning the session offset makes both agree.
            self::syncTimezone();
        } catch (PDOException $e) {
            Logger::error('db_connect_failed', ['msg' => $e->getMessage()]);
            if (PHP_SAPI === 'cli') {
                fwrite(STDERR, '[db] connection failed: ' . $e->getMessage() . "\n");
                exit(1);
            }
            // Never leak credentials or DSN details to a client.
            Response::error('Service temporarily unavailable', 503);
        }

        return self::$pdo;
    }

    /**
     * Pins the MySQL session timezone to PHP's current UTC offset, e.g.
     * "+06:30" for Asia/Yangon. Uses a numeric offset rather than a named
     * zone because most servers never load the mysql.time_zone tables.
     */
    private static function syncTimezone(): void
    {
        try {
            $offsetSeconds = (new DateTimeZone(date_default_timezone_get()))
                ->getOffset(new DateTime('now'));

            $sign    = $offsetSeconds < 0 ? '-' : '+';
            $abs     = abs($offsetSeconds);
            $hours   = intdiv($abs, 3600);
            $minutes = intdiv($abs % 3600, 60);
            $offset  = sprintf('%s%02d:%02d', $sign, $hours, $minutes);

            $stmt = self::$pdo->prepare('SET SESSION time_zone = ?');
            $stmt->execute([$offset]);
        } catch (Throwable $e) {
            // Non-fatal: log it so a skew is diagnosable, keep serving.
            Logger::warn('db_timezone_sync_failed', ['msg' => $e->getMessage()]);
        }
    }

    public static function one(string $sql, array $params = []): ?array
    {
        $st = self::pdo()->prepare($sql);
        $st->execute($params);
        $row = $st->fetch();
        return $row === false ? null : $row;
    }

    public static function all(string $sql, array $params = []): array
    {
        $st = self::pdo()->prepare($sql);
        $st->execute($params);
        return $st->fetchAll();
    }

    public static function run(string $sql, array $params = []): int
    {
        $st = self::pdo()->prepare($sql);
        $st->execute($params);
        return $st->rowCount();
    }

    public static function value(string $sql, array $params = []): mixed
    {
        $st = self::pdo()->prepare($sql);
        $st->execute($params);
        $v = $st->fetchColumn();
        return $v === false ? null : $v;
    }

    public static function tx(callable $fn): mixed
    {
        $pdo = self::pdo();
        $own = !$pdo->inTransaction();
        if ($own) {
            $pdo->beginTransaction();
        }
        try {
            $result = $fn($pdo);
            if ($own) {
                $pdo->commit();
            }
            return $result;
        } catch (Throwable $e) {
            if ($own && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    /** Whether a column exists — used by the compatibility shims. */
    public static function hasColumn(string $table, string $column): bool
    {
        static $cache = [];
        $key = "$table.$column";
        if (isset($cache[$key])) {
            return $cache[$key];
        }
        $n = self::value(
            'SELECT COUNT(*) FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?',
            [$table, $column]
        );
        return $cache[$key] = ((int) $n) > 0;
    }

    public static function now(): string
    {
        return date('Y-m-d H:i:s');
    }
}
