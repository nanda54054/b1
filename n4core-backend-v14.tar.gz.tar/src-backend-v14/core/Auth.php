<?php
/**
 * Authentication + Role-Based Access Control.
 *
 * Roles
 *   super_admin : everything — servers, locations, VIP plans/prices,
 *                 VIP accounts, admin list, settings, backups, audit
 *   admin       : VIP accounts only (create / extend / unbind / disable)
 *
 * Session tokens are random 32-byte values. Only their keyed sha256 is
 * stored, so a database dump does not hand over live sessions. Sessions
 * carry a sliding idle timeout AND a hard absolute expiry, are bound to
 * the client fingerprint, and pair with a CSRF token for browser writes.
 */
declare(strict_types=1);

final class Auth
{
    public const ROLE_SUPER = 'super_admin';
    public const ROLE_ADMIN = 'admin';

    /** Capability matrix. Anything not listed is super-admin only. */
    private const CAPS = [
        // Acting on your OWN account. Every signed-in admin must be able to
        // do this — it is also the single capability allowed while the
        // must_change_password flag is set, so leaving it out of this table
        // locks a plain `admin` out of the dashboard entirely.
        'self.password'  => [self::ROLE_SUPER, self::ROLE_ADMIN],

        'server.read'    => [self::ROLE_SUPER, self::ROLE_ADMIN],
        'server.write'   => [self::ROLE_SUPER],
        'location.read'  => [self::ROLE_SUPER, self::ROLE_ADMIN],
        'location.write' => [self::ROLE_SUPER],
        'plan.read'      => [self::ROLE_SUPER, self::ROLE_ADMIN],
        'plan.write'     => [self::ROLE_SUPER],
        'vip.read'       => [self::ROLE_SUPER, self::ROLE_ADMIN],
        'vip.write'      => [self::ROLE_SUPER, self::ROLE_ADMIN],
        'vip.delete'     => [self::ROLE_SUPER],
        // Seeing EVERY VIP account, not just your own. A plain `admin`
        // manages only the accounts they created; the owner sees all.
        'vip.scope_all'  => [self::ROLE_SUPER],
        'admin.read'     => [self::ROLE_SUPER],
        'admin.write'    => [self::ROLE_SUPER],
        'settings.write' => [self::ROLE_SUPER],
        'backup.run'     => [self::ROLE_SUPER],
        'audit.read'     => [self::ROLE_SUPER],
        'stats.read'     => [self::ROLE_SUPER, self::ROLE_ADMIN],
    ];

    private static ?array $admin = null;
    private static bool $resolved = false;

    // =================================================================
    // Login
    // =================================================================

    /**
     * Verifies credentials and issues a session.
     * @return array{token:string,csrf:string,admin:array,expires_at:string}
     */
    public static function login(string $username, string $password): array
    {
        $ip = Request::ip();
        RateLimiter::hit('admin_login', $ip);

        $username = mb_substr(trim($username), 0, 64);

        $admin = Db::one('SELECT * FROM admin_users WHERE username = ?', [$username]);

        // Constant-ish work whether or not the user exists, so response
        // timing does not reveal valid usernames.
        $hash = $admin['password_hash'] ?? '$2y$10$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvalidinv';
        $passwordOk = Crypto::verifySecret($password, $hash);

        if (!$admin) {
            self::recordLogin('admin_failed', $username, null, 'no_such_user');
            Response::error('Invalid username or password', 401);
        }

        if (!(int) $admin['is_active']) {
            self::recordLogin('admin_failed', $username, (int) $admin['id'], 'disabled');
            Response::error('This account has been disabled', 403);
        }

        // Account-level lockout after repeated failures.
        if (!empty($admin['locked_until']) && strtotime((string) $admin['locked_until']) > time()) {
            $mins = (int) ceil((strtotime((string) $admin['locked_until']) - time()) / 60);
            self::recordLogin('admin_locked', $username, (int) $admin['id'], 'locked');
            Response::error("Account locked. Try again in {$mins} minute(s).", 429);
        }

        if (!$passwordOk) {
            $attempts = (int) $admin['failed_attempts'] + 1;
            $max      = (int) Config::get('security.admin_max_attempts', 5);
            $lockMin  = (int) Config::get('security.admin_lock_minutes', 15);

            if ($attempts >= $max) {
                Db::run(
                    'UPDATE admin_users SET failed_attempts = ?, locked_until = DATE_ADD(NOW(), INTERVAL ? MINUTE) WHERE id = ?',
                    [$attempts, $lockMin, $admin['id']]
                );
                self::recordLogin('admin_locked', $username, (int) $admin['id'], 'too_many_attempts');
                Notifier::securityAlert(
                    "🔒 <b>Admin account locked</b>\n"
                    . "User: <code>" . self::esc($username) . "</code>\n"
                    . "Reason: {$attempts} failed logins\n"
                    . "IP: <code>" . self::esc($ip) . "</code>\n"
                    . "Locked for {$lockMin} minutes."
                );
                Response::error("Too many failed attempts. Account locked for {$lockMin} minutes.", 429);
            }

            Db::run('UPDATE admin_users SET failed_attempts = ? WHERE id = ?', [$attempts, $admin['id']]);
            self::recordLogin('admin_failed', $username, (int) $admin['id'], 'bad_password');
            $left = $max - $attempts;
            Response::error("Invalid username or password ({$left} attempt(s) left)", 401);
        }

        // ---- Success ------------------------------------------------
        RateLimiter::clear('admin_login', $ip);

        // Opportunistic rehash if the algorithm/cost changed.
        if (Crypto::needsRehash((string) $admin['password_hash'])) {
            Db::run(
                'UPDATE admin_users SET password_hash = ? WHERE id = ?',
                [Crypto::hashSecret($password), $admin['id']]
            );
        }

        Db::run(
            'UPDATE admin_users
             SET failed_attempts = 0, locked_until = NULL, last_login_at = NOW(), last_login_ip = ?
             WHERE id = ?',
            [$ip, $admin['id']]
        );

        $session = self::issueSession((int) $admin['id']);

        self::recordLogin('admin_success', $username, (int) $admin['id'], null);
        Audit::log(
            'admin.login',
            'admin_user',
            (string) $admin['id'],
            ['role' => $admin['role']],
            'admin',
            (string) $admin['id'],
            $admin['username']
        );

        Notifier::loginAlert($admin, $ip, Request::userAgent());

        return [
            'token'      => $session['token'],
            'csrf'       => $session['csrf'],
            'expires_at' => $session['expires_at'],
            'admin'      => [
                'id'                   => (int) $admin['id'],
                'username'             => $admin['username'],
                'display_name'         => $admin['display_name'],
                'role'                 => $admin['role'],
                'must_change_password' => (bool) (int) $admin['must_change_password'],
                'permissions'          => self::permissionsFor((string) $admin['role']),
                'vip_scoped'           => !self::can('vip.scope_all', (string) $admin['role'])
                                            && Config::settingBool('vip_isolate_by_admin', true),
            ],
        ];
    }

    private static function issueSession(int $adminId): array
    {
        $token = Crypto::token(32);
        $csrf  = Crypto::token(24);

        $idleMin  = (int) Config::get('security.admin_idle_minutes', 45);
        $absHours = (int) Config::get('security.admin_absolute_hours', 12);

        $expires    = date('Y-m-d H:i:s', time() + $idleMin * 60);
        $absExpires = date('Y-m-d H:i:s', time() + $absHours * 3600);

        // Cap concurrent sessions per admin — keep the 4 newest.
        try {
            $old = Db::all(
                'SELECT id FROM admin_sessions
                 WHERE admin_id = ? AND revoked_at IS NULL
                 ORDER BY created_at DESC LIMIT 100 OFFSET 4',
                [$adminId]
            );
            foreach ($old as $o) {
                Db::run('UPDATE admin_sessions SET revoked_at = NOW() WHERE id = ?', [$o['id']]);
            }
        } catch (Throwable) {
        }

        Db::run(
            'INSERT INTO admin_sessions
               (admin_id, token_hash, csrf_hash, ip, user_agent, ua_hash, expires_at, absolute_expires_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            [
                $adminId,
                Crypto::hashToken($token),
                Crypto::hashToken($csrf),
                Request::ip(),
                Request::userAgent(),
                self::uaFingerprint(),
                $expires,
                $absExpires,
            ]
        );

        return ['token' => $token, 'csrf' => $csrf, 'expires_at' => $expires];
    }

    private static function uaFingerprint(): string
    {
        // Deliberately coarse: the raw UA plus the app secret. Stable for
        // a browser session, useless to an attacker on another machine.
        return Crypto::hashToken('ua|' . Request::userAgent());
    }

    // =================================================================
    // Session resolution
    // =================================================================

    private static function tokenFromRequest(): ?string
    {
        $t = Request::header('X-Admin-Token');
        if ($t) {
            return trim($t);
        }
        // Bearer fallback
        $auth = Request::header('Authorization');
        if ($auth && stripos($auth, 'bearer ') === 0) {
            return trim(substr($auth, 7));
        }
        // NOTE: v1 accepted ?admin_token= in the query string. That is
        // deliberately no longer supported — query strings end up in
        // access logs, browser history and Referer headers.
        return null;
    }

    /** Resolves the current admin, or null. Does not fail the request. */
    public static function currentAdmin(): ?array
    {
        if (self::$resolved) {
            return self::$admin;
        }
        self::$resolved = true;

        $token = self::tokenFromRequest();
        if (!$token || strlen($token) < 32) {
            return self::$admin = null;
        }

        $row = Db::one(
            'SELECT s.id AS session_id, s.expires_at, s.absolute_expires_at, s.revoked_at,
                    s.ua_hash, s.csrf_hash,
                    a.id AS admin_id, a.username, a.display_name, a.role, a.is_active,
                    a.must_change_password
             FROM admin_sessions s
             JOIN admin_users a ON a.id = s.admin_id
             WHERE s.token_hash = ?',
            [Crypto::hashToken($token)]
        );

        if (!$row || $row['revoked_at'] !== null || !(int) $row['is_active']) {
            return self::$admin = null;
        }
        if (strtotime((string) $row['expires_at']) < time()) {
            return self::$admin = null;
        }
        if (!empty($row['absolute_expires_at']) && strtotime((string) $row['absolute_expires_at']) < time()) {
            Db::run('UPDATE admin_sessions SET revoked_at = NOW() WHERE id = ?', [$row['session_id']]);
            return self::$admin = null;
        }
        if (Config::get('security.bind_session_to_ua', true) && !empty($row['ua_hash'])) {
            if (!Crypto::equals((string) $row['ua_hash'], self::uaFingerprint())) {
                Logger::warn('session_ua_mismatch', ['admin' => $row['username']]);
                return self::$admin = null;
            }
        }

        // Slide the idle window forward (at most once a minute).
        $idleMin = (int) Config::get('security.admin_idle_minutes', 45);
        Db::run(
            'UPDATE admin_sessions
             SET last_seen_at = NOW(), expires_at = DATE_ADD(NOW(), INTERVAL ? MINUTE)
             WHERE id = ? AND last_seen_at < DATE_SUB(NOW(), INTERVAL 60 SECOND)',
            [$idleMin, $row['session_id']]
        );

        return self::$admin = $row;
    }

    /** Requires a valid session, else 401. */
    public static function requireAdmin(): array
    {
        $admin = self::currentAdmin();
        if (!$admin) {
            Response::error('Invalid or expired admin session', 401);
        }
        return $admin;
    }

    /** Requires a session AND a capability, else 401/403. */
    public static function require(string $capability): array
    {
        $admin = self::requireAdmin();

        // A password change is the only thing allowed while flagged.
        if ((int) $admin['must_change_password'] === 1 && $capability !== 'self.password') {
            Response::error('Password change required before continuing', 428, ['must_change_password' => true]);
        }

        if (!self::can($capability, (string) $admin['role'])) {
            Audit::log('rbac.denied', 'capability', $capability, ['role' => $admin['role']]);
            Response::error('Your role does not have permission for this action', 403);
        }

        return $admin;
    }

    public static function can(string $capability, ?string $role = null): bool
    {
        if ($role === null) {
            $admin = self::currentAdmin();
            if (!$admin) {
                return false;
            }
            $role = (string) $admin['role'];
        }
        $allowed = self::CAPS[$capability] ?? [self::ROLE_SUPER];
        return in_array($role, $allowed, true);
    }

    public static function permissionsFor(string $role): array
    {
        $out = [];
        foreach (self::CAPS as $cap => $roles) {
            if (in_array($role, $roles, true)) {
                $out[] = $cap;
            }
        }
        return $out;
    }

    // =================================================================
    // Row-level scoping
    // =================================================================

    /**
     * True when the current admin may only touch the VIP accounts they
     * created themselves. Super Admins always see everything.
     *
     * The behaviour is a runtime setting so the owner can flip it from
     * the dashboard without a redeploy — default ON (isolated), which is
     * the safer posture.
     */
    public static function vipScopedToSelf(): bool
    {
        if (self::can('vip.scope_all')) {
            return false;
        }
        return Config::settingBool('vip_isolate_by_admin', true);
    }

    /**
     * SQL fragment + params that restrict a vip_accounts query to the
     * caller's own rows. Returns ['', []] when no restriction applies, so
     * callers can splice it in unconditionally.
     *
     * @param string $alias table alias used in the query (e.g. 'a')
     * @return array{0:string,1:array}
     */
    public static function vipScopeSql(string $alias = 'a'): array
    {
        if (!self::vipScopedToSelf()) {
            return ['', []];
        }
        $admin = self::currentAdmin();
        if (!$admin) {
            // No session: match nothing rather than everything.
            return ['1 = 0', []];
        }
        return [$alias . '.created_by = ?', [(int) $admin['admin_id']]];
    }

    /**
     * Guards a single VIP account by id. Sends 404 (not 403) when the row
     * exists but belongs to someone else — leaking "this account exists"
     * would let one admin probe another's customer list.
     */
    public static function requireVipAccess(array $account): void
    {
        if (!self::vipScopedToSelf()) {
            return;
        }
        $admin = self::currentAdmin();
        $owner = $account['created_by'] === null ? null : (int) $account['created_by'];

        if (!$admin || $owner === null || $owner !== (int) $admin['admin_id']) {
            Response::error('Account not found', 404);
        }
    }

    /** CSRF check for browser-driven writes. */
    public static function requireCsrf(): void
    {
        if (!Config::get('security.csrf_protection', true)) {
            return;
        }
        $method = Request::method();
        if (in_array($method, ['GET', 'HEAD', 'OPTIONS'], true)) {
            return;
        }
        $admin = self::currentAdmin();
        if (!$admin) {
            return; // requireAdmin() will handle it
        }
        $sent = Request::header('X-CSRF-Token');
        if (!$sent || !Crypto::equals((string) $admin['csrf_hash'], Crypto::hashToken(trim($sent)))) {
            Logger::warn('csrf_failed', ['admin' => $admin['username'] ?? '?']);
            Response::error('CSRF validation failed. Please reload the dashboard.', 419);
        }
    }

    public static function logout(): void
    {
        $token = self::tokenFromRequest();
        if (!$token) {
            return;
        }
        Db::run(
            'UPDATE admin_sessions SET revoked_at = NOW() WHERE token_hash = ? AND revoked_at IS NULL',
            [Crypto::hashToken($token)]
        );
    }

    public static function revokeAllFor(int $adminId): void
    {
        Db::run(
            'UPDATE admin_sessions SET revoked_at = NOW() WHERE admin_id = ? AND revoked_at IS NULL',
            [$adminId]
        );
    }

    // =================================================================
    // Helpers
    // =================================================================

    public static function recordLogin(string $kind, ?string $username, ?int $adminId, ?string $reason): void
    {
        try {
            Db::run(
                'INSERT INTO login_events (kind, username, admin_id, ip, user_agent, reason)
                 VALUES (?, ?, ?, ?, ?, ?)',
                [$kind, $username, $adminId, Request::ip(), Request::userAgent(), $reason]
            );
        } catch (Throwable $e) {
            Logger::error('login_event_failed', ['msg' => $e->getMessage()]);
        }

        if ($kind !== 'admin_success') {
            Logger::warn('login_' . $kind, ['username' => $username, 'reason' => $reason]);
        }
    }

    /** Password policy for admin accounts. */
    public static function validatePassword(string $pw): ?string
    {
        if (strlen($pw) < 10) {
            return 'Password must be at least 10 characters';
        }
        if (strlen($pw) > 200) {
            return 'Password is too long';
        }
        if (!preg_match('/[A-Z]/', $pw)) {
            return 'Password must contain an uppercase letter';
        }
        if (!preg_match('/[a-z]/', $pw)) {
            return 'Password must contain a lowercase letter';
        }
        if (!preg_match('/\d/', $pw)) {
            return 'Password must contain a number';
        }
        $weak = ['password', '12345678', 'qwerty', 'admin123', 'n4core', 'letmein'];
        $lower = strtolower($pw);
        foreach ($weak as $w) {
            if (str_contains($lower, $w)) {
                return 'Password contains a commonly guessed word';
            }
        }
        return null;
    }

    private static function esc(string $s): string
    {
        return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
    }

    /** Housekeeping — called by bin/cron.php. */
    public static function pruneSessions(): int
    {
        try {
            return Db::run(
                'DELETE FROM admin_sessions
                 WHERE (revoked_at IS NOT NULL AND revoked_at < DATE_SUB(NOW(), INTERVAL 7 DAY))
                    OR absolute_expires_at < DATE_SUB(NOW(), INTERVAL 7 DAY)'
            );
        } catch (Throwable) {
            return 0;
        }
    }
}
