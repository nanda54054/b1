<?php
/**
 * Request facade: safe accessors for method, headers, JSON body, client
 * IP and query params. Everything that touches raw superglobals lives
 * here so validation is consistent.
 */
declare(strict_types=1);

final class Request
{
    private static ?array $bodyCache = null;

    public static function method(): string
    {
        $m = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        // Allow method override only for clients that can't send PUT/DELETE.
        $override = strtoupper((string) self::header('X-HTTP-Method-Override'));
        if ($m === 'POST' && in_array($override, ['PUT', 'PATCH', 'DELETE'], true)) {
            return $override;
        }
        return $m;
    }

    public static function header(string $name): ?string
    {
        $key = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
        if (isset($_SERVER[$key])) {
            return (string) $_SERVER[$key];
        }
        // Content-Type / Content-Length are not HTTP_ prefixed
        $alt = strtoupper(str_replace('-', '_', $name));
        return isset($_SERVER[$alt]) ? (string) $_SERVER[$alt] : null;
    }

    /** Decoded JSON body (empty array when absent/invalid). */
    public static function body(): array
    {
        if (self::$bodyCache !== null) {
            return self::$bodyCache;
        }
        $raw = file_get_contents('php://input');
        if ($raw === false || $raw === '') {
            return self::$bodyCache = [];
        }
        // Hard cap: nothing legitimate needs a megabyte of JSON except
        // raw configs, which are still comfortably under this.
        if (strlen($raw) > 512 * 1024) {
            Response::error('Request body too large', 413);
        }
        $data = json_decode($raw, true);
        return self::$bodyCache = is_array($data) ? $data : [];
    }

    public static function rawBody(): string
    {
        $raw = file_get_contents('php://input');
        return $raw === false ? '' : $raw;
    }

    public static function query(string $key, ?string $default = null): ?string
    {
        $v = $_GET[$key] ?? null;
        if ($v === null) {
            return $default;
        }
        if (!is_string($v)) {
            return $default;
        }
        return $v;
    }

    /**
     * Real client IP. Proxy headers are only honoured when the immediate
     * peer is a configured trusted proxy — otherwise a client could spoof
     * X-Forwarded-For to dodge rate limits and poison the audit log.
     */
    public static function ip(): string
    {
        $remote = (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
        $trusted = ['127.0.0.1', '::1'];

        if (in_array($remote, $trusted, true)) {
            $fwd = self::header('X-Forwarded-For');
            if ($fwd) {
                $first = trim(explode(',', $fwd)[0]);
                if (filter_var($first, FILTER_VALIDATE_IP)) {
                    return $first;
                }
            }
            $real = self::header('X-Real-IP');
            if ($real && filter_var($real, FILTER_VALIDATE_IP)) {
                return $real;
            }
        }
        return filter_var($remote, FILTER_VALIDATE_IP) ? $remote : '0.0.0.0';
    }

    public static function userAgent(): string
    {
        return substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255);
    }

    public static function isHttps(): bool
    {
        if (($_SERVER['HTTPS'] ?? '') === 'on' || ($_SERVER['HTTPS'] ?? '') === '1') {
            return true;
        }
        if ((int) ($_SERVER['SERVER_PORT'] ?? 0) === 443) {
            return true;
        }
        return strtolower((string) self::header('X-Forwarded-Proto')) === 'https';
    }

    // ---- Validation helpers ------------------------------------------

    public static function requireFields(array $data, array $fields): void
    {
        $missing = [];
        foreach ($fields as $f) {
            if (!array_key_exists($f, $data) || $data[$f] === '' || $data[$f] === null) {
                $missing[] = $f;
            }
        }
        if ($missing) {
            Response::error('Missing required field: ' . implode(', ', $missing), 422);
        }
    }

    public static function str(array $data, string $key, int $max = 255, string $default = ''): string
    {
        $v = $data[$key] ?? $default;
        if (!is_scalar($v)) {
            return $default;
        }
        $v = trim((string) $v);
        // Strip control characters (except tab/newline for config blobs).
        $v = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $v) ?? '';
        return mb_substr($v, 0, $max);
    }

    public static function text(array $data, string $key, int $max = 65535, string $default = ''): string
    {
        $v = $data[$key] ?? $default;
        if (!is_scalar($v)) {
            return $default;
        }
        $v = (string) $v;
        $v = str_replace("\0", '', $v);
        return mb_substr($v, 0, $max);
    }

    public static function int(array $data, string $key, int $default = 0, ?int $min = null, ?int $max = null): int
    {
        $v = $data[$key] ?? $default;
        if (is_bool($v)) {
            $v = $v ? 1 : 0;
        }
        if (!is_numeric($v)) {
            $v = $default;
        }
        $n = (int) $v;
        if ($min !== null && $n < $min) {
            $n = $min;
        }
        if ($max !== null && $n > $max) {
            $n = $max;
        }
        return $n;
    }

    public static function bool(array $data, string $key, bool $default = false): bool
    {
        if (!array_key_exists($key, $data)) {
            return $default;
        }
        $v = $data[$key];
        if (is_bool($v)) {
            return $v;
        }
        if (is_numeric($v)) {
            return ((int) $v) === 1;
        }
        $s = strtolower(trim((string) $v));
        return in_array($s, ['1', 'true', 'yes', 'on'], true);
    }

    public static function enum(array $data, string $key, array $allowed, string $default): string
    {
        $v = (string) ($data[$key] ?? $default);
        return in_array($v, $allowed, true) ? $v : $default;
    }

    /** Validates a UUID-ish id used as a primary key. */
    public static function id(?string $v): ?string
    {
        if ($v === null) {
            return null;
        }
        $v = trim($v);
        if ($v === '' || strlen($v) > 36) {
            return null;
        }
        return preg_match('/^[A-Za-z0-9\-]{8,36}$/', $v) === 1 ? $v : null;
    }
}
