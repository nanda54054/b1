<?php
/**
 * All cryptography lives here so nothing else has to make choices.
 *
 *  - password/access-code hashing: Argon2id (fallback bcrypt) + pepper
 *  - session tokens: 32 random bytes, stored only as sha256
 *  - reversible secrets (VIP access codes, backup archives):
 *    AES-256-GCM with a random 12-byte nonce
 */
declare(strict_types=1);

final class Crypto
{
    // ---- Random ------------------------------------------------------

    public static function token(int $bytes = 32): string
    {
        return bin2hex(random_bytes($bytes));
    }

    public static function uuid4(): string
    {
        $d = random_bytes(16);
        $d[6] = chr(ord($d[6]) & 0x0f | 0x40);
        $d[8] = chr(ord($d[8]) & 0x3f | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($d), 4));
    }

    /** Human-friendly code (no look-alike characters). */
    public static function readableCode(int $len = 10): string
    {
        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        $out = '';
        $max = strlen($alphabet) - 1;
        for ($i = 0; $i < $len; $i++) {
            $out .= $alphabet[random_int(0, $max)];
        }
        return $out;
    }

    /**
     * Digits-only access code, for codes a customer has to remember or type
     * on a phone keypad.
     *
     * Six digits is a million possibilities, which is thin on its own — but
     * this code is never guessed in isolation: VipAuth requires the matching
     * username, and the account locks after a handful of failed attempts, so
     * an attacker gets a few tries against one specific name rather than a
     * free run at the keyspace. The lockout is what carries the security
     * here, not the length.
     *
     * Never starts with 0, so the value survives being pasted into a
     * spreadsheet or anything else that will happily eat a leading zero.
     */
    public static function numericCode(int $len = 6): string
    {
        if ($len < 4)  { $len = 4; }
        if ($len > 12) { $len = 12; }

        $out = (string) random_int(1, 9);
        for ($i = 1; $i < $len; $i++) {
            $out .= (string) random_int(0, 9);
        }
        return $out;
    }

    /** Strong password for bot-created admins. */
    public static function strongPassword(int $len = 16): string
    {
        $sets = [
            'ABCDEFGHJKLMNPQRSTUVWXYZ',
            'abcdefghijkmnopqrstuvwxyz',
            '23456789',
            '!@#$%^&*-_=+?',
        ];
        $out = '';
        foreach ($sets as $s) {
            $out .= $s[random_int(0, strlen($s) - 1)];
        }
        $all = implode('', $sets);
        for ($i = strlen($out); $i < $len; $i++) {
            $out .= $all[random_int(0, strlen($all) - 1)];
        }
        // Fisher-Yates with CSPRNG
        $chars = str_split($out);
        for ($i = count($chars) - 1; $i > 0; $i--) {
            $j = random_int(0, $i);
            [$chars[$i], $chars[$j]] = [$chars[$j], $chars[$i]];
        }
        return implode('', $chars);
    }

    // ---- Hashing -----------------------------------------------------

    public static function hashToken(string $token): string
    {
        // Keyed so a stolen DB dump can't be brute-forced offline against
        // a rainbow table of hex tokens.
        return hash_hmac('sha256', $token, (string) Config::get('security.app_secret'));
    }

    private static function algo(): string
    {
        $want = (string) Config::get('security.password_algo', 'auto');
        if ($want === 'bcrypt') {
            return PASSWORD_BCRYPT;
        }
        if (defined('PASSWORD_ARGON2ID')) {
            return PASSWORD_ARGON2ID;
        }
        return PASSWORD_BCRYPT;
    }

    private static function pepper(string $secret): string
    {
        // Pre-hash with the pepper so long inputs aren't truncated by
        // bcrypt's 72-byte limit and the pepper is always mixed in.
        return base64_encode(
            hash_hmac('sha256', $secret, (string) Config::get('security.pepper'), true)
        );
    }

    public static function hashSecret(string $secret): string
    {
        return password_hash(self::pepper($secret), self::algo());
    }

    public static function verifySecret(string $secret, string $hash): bool
    {
        if ($hash === '') {
            return false;
        }
        return password_verify(self::pepper($secret), $hash);
    }

    public static function needsRehash(string $hash): bool
    {
        return password_needs_rehash($hash, self::algo());
    }

    // ---- Reversible encryption (AES-256-GCM) -------------------------

    private static function key(): string
    {
        static $key = null;
        if ($key !== null) {
            return $key;
        }
        $raw = (string) Config::get('security.encryption_key');
        $decoded = base64_decode($raw, true);
        if ($decoded !== false && strlen($decoded) === 32) {
            return $key = $decoded;
        }
        // Any other shape: derive a 32-byte key deterministically.
        return $key = hash('sha256', $raw, true);
    }

    /** Returns "v1.<base64 nonce>.<base64 ciphertext+tag>" */
    public static function encrypt(string $plain): string
    {
        $nonce = random_bytes(12);
        $tag = '';
        $cipher = openssl_encrypt(
            $plain,
            'aes-256-gcm',
            self::key(),
            OPENSSL_RAW_DATA,
            $nonce,
            $tag
        );
        if ($cipher === false) {
            throw new RuntimeException('encryption failed');
        }
        return 'v1.' . base64_encode($nonce) . '.' . base64_encode($cipher . $tag);
    }

    public static function decrypt(?string $payload): ?string
    {
        if ($payload === null || $payload === '') {
            return null;
        }
        $parts = explode('.', $payload, 3);
        if (count($parts) !== 3 || $parts[0] !== 'v1') {
            return null;
        }
        $nonce = base64_decode($parts[1], true);
        $blob  = base64_decode($parts[2], true);
        if ($nonce === false || $blob === false || strlen($blob) < 17) {
            return null;
        }
        $tag    = substr($blob, -16);
        $cipher = substr($blob, 0, -16);
        $plain  = openssl_decrypt(
            $cipher,
            'aes-256-gcm',
            self::key(),
            OPENSSL_RAW_DATA,
            $nonce,
            $tag
        );
        return $plain === false ? null : $plain;
    }

    /** Encrypt a file in place (used for backup archives). */
    public static function encryptFile(string $src, string $dst): bool
    {
        $data = file_get_contents($src);
        if ($data === false) {
            return false;
        }
        $nonce = random_bytes(12);
        $tag = '';
        $cipher = openssl_encrypt($data, 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, $nonce, $tag);
        if ($cipher === false) {
            return false;
        }
        // Format: magic(8) | nonce(12) | tag(16) | ciphertext
        return file_put_contents($dst, "N4CBK001" . $nonce . $tag . $cipher) !== false;
    }

    public static function decryptFile(string $src, string $dst): bool
    {
        $data = file_get_contents($src);
        if ($data === false || strlen($data) < 36 || substr($data, 0, 8) !== 'N4CBK001') {
            return false;
        }
        $nonce  = substr($data, 8, 12);
        $tag    = substr($data, 20, 16);
        $cipher = substr($data, 36);
        $plain  = openssl_decrypt($cipher, 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, $nonce, $tag);
        if ($plain === false) {
            return false;
        }
        return file_put_contents($dst, $plain) !== false;
    }

    public static function equals(string $a, string $b): bool
    {
        return hash_equals($a, $b);
    }
}
