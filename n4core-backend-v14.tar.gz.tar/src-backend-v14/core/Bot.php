<?php
/**
 * Telegram bot brain.
 *
 * The bot is the control room for things that must NOT live behind a web
 * form: creating dashboard admins, receiving login alarms, and pulling
 * backups. Only the configured OWNER can create or delete admins.
 *
 * Access levels
 *   owner        : configured telegram.owner_id — everything, cannot be removed
 *   super_admin  : bot admin with full commands except owner-only ones
 *   admin        : read-only status + own notification toggles
 *
 * Both transports (webhook + long polling) feed handleUpdate().
 */
declare(strict_types=1);

final class Bot
{
    private const HELP_OWNER = <<<'TXT'
<b>N4 Core VPN — Control Bot</b>
━━━━━━━━━━━━━━━━━━━━━━

<b>👑 Owner commands</b>
/addadmin — create a dashboard admin (wizard)
/deladmin — delete a dashboard admin
/role — change an admin's role
/resetpw — reset an admin's password
/tgadd &lt;user_id&gt; — allow a Telegram user to use this bot
/tgdel &lt;user_id&gt; — remove a Telegram user
/tglist — list bot users
/keys — show the encryption key for moving to a new VPS

<b>🛡 Admin commands</b>
/admins — list dashboard admins
/status — server + database health
/vip — VIP account summary
/servers — server summary
/backup — manual backup now (files + database)
/backups — recent backup list
/logins — last dashboard logins
/revoke — kill all dashboard sessions (panic button)
/unlock — clear login lockouts and blocks
/alerts — my notification switches
/whoami — my access level
/cancel — abort the current wizard
TXT;

    private const HELP_ADMIN = <<<'TXT'
<b>N4 Core VPN — Control Bot</b>
━━━━━━━━━━━━━━━━━━━━━━
/status — server health
/vip — VIP account summary
/servers — server summary
/logins — last dashboard logins
/alerts — my notification switches
/whoami — my access level
/cancel — abort the current wizard
TXT;

    /**
     * Publishes the /command menu so Telegram shows autocomplete.
     * Called by bin/setup_webhook.php and bin/bot.php on startup.
     */
    public static function registerCommands(): bool
    {
        $commands = [
            ['command' => 'help',     'description' => 'Show all commands'],
            ['command' => 'status',   'description' => 'Server + database health'],
            ['command' => 'vip',      'description' => 'VIP account summary'],
            ['command' => 'servers',  'description' => 'Servers by region'],
            ['command' => 'backup',   'description' => 'Backup now (files + database)'],
            ['command' => 'backups',  'description' => 'Recent backup list'],
            ['command' => 'logins',   'description' => 'Recent dashboard logins'],
            ['command' => 'admins',   'description' => 'List dashboard admins'],
            ['command' => 'addadmin', 'description' => 'Create a dashboard admin (owner)'],
            ['command' => 'deladmin', 'description' => 'Delete a dashboard admin (owner)'],
            ['command' => 'role',     'description' => "Change an admin's role (owner)"],
            ['command' => 'resetpw',  'description' => "Reset an admin's password (owner)"],
            ['command' => 'revoke',   'description' => 'Log out all dashboard sessions'],
            ['command' => 'unlock',   'description' => 'Clear login lockouts'],
            ['command' => 'alerts',   'description' => 'My notification switches'],
            ['command' => 'whoami',   'description' => 'My access level'],
            ['command' => 'cancel',   'description' => 'Abort the current wizard'],
        ];

        return Telegram::call('setMyCommands', [
            'commands' => json_encode($commands, JSON_UNESCAPED_UNICODE),
        ]) !== null;
    }

    // =================================================================
    // Entry point
    // =================================================================

    /** @param array $update raw Telegram update */
    public static function handleUpdate(array $update): void
    {
        $updateId = (int) ($update['update_id'] ?? 0);
        if ($updateId > 0 && !self::claimUpdate($updateId)) {
            return; // already processed (webhook retry / poll overlap)
        }

        try {
            if (isset($update['callback_query'])) {
                self::onCallback($update['callback_query']);
                return;
            }
            $msg = $update['message'] ?? $update['edited_message'] ?? null;
            if (is_array($msg)) {
                self::onMessage($msg);
            }
        } catch (Throwable $e) {
            Logger::error('bot_handler_failed', ['msg' => $e->getMessage(), 'update' => $updateId]);
        }
    }

    /** Insert-once guard so retries do not double-execute a command. */
    private static function claimUpdate(int $id): bool
    {
        try {
            Db::run('INSERT INTO telegram_updates (update_id) VALUES (?)', [$id]);
            // Housekeeping: keep the table tiny.
            if (random_int(1, 50) === 1) {
                Db::run('DELETE FROM telegram_updates WHERE processed_at < DATE_SUB(NOW(), INTERVAL 2 DAY)');
            }
            return true;
        } catch (Throwable) {
            return false; // duplicate primary key
        }
    }

    // =================================================================
    // Message routing
    // =================================================================

    private static function onMessage(array $msg): void
    {
        $chatId = (int) ($msg['chat']['id'] ?? 0);
        $from   = $msg['from'] ?? [];
        $userId = (int) ($from['id'] ?? 0);
        $text   = trim((string) ($msg['text'] ?? ''));

        if ($chatId === 0 || $userId === 0) {
            return;
        }
        // Groups are ignored — this bot only talks in private chats.
        if (($msg['chat']['type'] ?? 'private') !== 'private') {
            return;
        }

        $actor = self::actor($userId, $from);
        if ($actor === null) {
            // Unknown user. Tell the owner once, stay silent otherwise.
            self::rejectStranger($chatId, $userId, $from);
            return;
        }

        self::touch($userId, $from);

        if ($text === '') {
            return;
        }

        // A wizard in progress swallows plain text (but not commands).
        if ($text[0] !== '/') {
            $state = self::state($chatId);
            if ($state !== null) {
                self::wizardInput($chatId, $actor, $state, $text);
                return;
            }
            Telegram::send($chatId, "Send /help to see what I can do.");
            return;
        }

        // /command@BotName arg1 arg2
        $parts   = preg_split('/\s+/', $text) ?: [];
        $command = strtolower((string) array_shift($parts));
        if (str_contains($command, '@')) {
            $command = (string) strstr($command, '@', true);
        }
        $args = $parts;

        self::dispatch($chatId, $actor, $command, $args);
    }

    private static function dispatch(int $chatId, array $actor, string $command, array $args): void
    {
        $isOwner = $actor['role'] === 'owner';
        $isSuper = $isOwner || $actor['role'] === 'super_admin';

        // Owner-gated commands.
        // /keys prints encryption_key in clear text, so it is the most
        // dangerous command in the bot — owner only, never super_admin.
        $ownerOnly = ['/addadmin', '/deladmin', '/role', '/resetpw', '/tgadd', '/tgdel', '/tglist', '/keys'];
        if (in_array($command, $ownerOnly, true) && !$isOwner) {
            Telegram::send($chatId, "⛔️ This command is reserved for the owner.");
            return;
        }

        // Super-gated commands
        $superOnly = ['/admins', '/backup', '/backups', '/revoke', '/unlock'];
        if (in_array($command, $superOnly, true) && !$isSuper) {
            Telegram::send($chatId, "⛔️ Your bot role does not allow this.");
            return;
        }

        match ($command) {
            '/start', '/help' => Telegram::send($chatId, $isSuper ? self::HELP_OWNER : self::HELP_ADMIN),
            '/cancel'   => self::cmdCancel($chatId),
            '/whoami'   => self::cmdWhoami($chatId, $actor),
            '/status'   => self::cmdStatus($chatId, $isSuper),
            '/vip'      => self::cmdVip($chatId),
            '/servers'  => self::cmdServers($chatId),
            '/logins'   => self::cmdLogins($chatId),
            '/alerts'   => self::cmdAlerts($chatId, $actor),
            '/admins'   => self::cmdAdmins($chatId),
            '/backup'   => self::cmdBackup($chatId, $actor, $args),
            '/backups'  => self::cmdBackupList($chatId),
            '/revoke'   => self::cmdRevoke($chatId, $actor),
            '/unlock'   => self::cmdUnlock($chatId, $actor),
            '/addadmin' => self::cmdAddAdmin($chatId),
            '/deladmin' => self::cmdDelAdmin($chatId),
            '/role'     => self::cmdRole($chatId),
            '/resetpw'  => self::cmdResetPw($chatId),
            '/keys'     => self::cmdKeys($chatId, $actor),
            '/tgadd'    => self::cmdTgAdd($chatId, $actor, $args),
            '/tgdel'    => self::cmdTgDel($chatId, $actor, $args),
            '/tglist'   => self::cmdTgList($chatId),
            default     => Telegram::send($chatId, "Unknown command. Try /help."),
        };
    }

    // =================================================================
    // Access control
    // =================================================================

    /** Resolves the caller into a bot actor, or null if not allowed. */
    private static function actor(int $userId, array $from): ?array
    {
        $owner = Telegram::ownerId();

        if ($owner > 0 && $userId === $owner) {
            self::ensureOwnerRow($userId, $from);
            return ['telegram_user_id' => $userId, 'role' => 'owner', 'display_name' => 'Owner'];
        }

        $row = Db::one(
            'SELECT * FROM telegram_admins WHERE telegram_user_id = ? AND is_active = 1',
            [$userId]
        );
        return $row ?: null;
    }

    private static function ensureOwnerRow(int $userId, array $from): void
    {
        try {
            $exists = Db::value('SELECT 1 FROM telegram_admins WHERE telegram_user_id = ?', [$userId]);
            if ($exists) {
                Db::run("UPDATE telegram_admins SET role = 'owner', is_active = 1 WHERE telegram_user_id = ?", [$userId]);
                return;
            }
            Db::run(
                "INSERT INTO telegram_admins
                   (telegram_user_id, telegram_username, display_name, role, is_active)
                 VALUES (?, ?, ?, 'owner', 1)",
                [
                    $userId,
                    mb_substr((string) ($from['username'] ?? ''), 0, 64) ?: null,
                    mb_substr(trim(($from['first_name'] ?? '') . ' ' . ($from['last_name'] ?? '')), 0, 128) ?: 'Owner',
                ]
            );
        } catch (Throwable $e) {
            Logger::warn('bot_owner_row_failed', ['msg' => $e->getMessage()]);
        }
    }

    private static function rejectStranger(int $chatId, int $userId, array $from): void
    {
        Telegram::send(
            $chatId,
            "⛔️ <b>Access denied</b>\n\nThis bot is private.\nYour Telegram ID: <code>{$userId}</code>\n\n"
            . "Ask the owner to run <code>/tgadd {$userId}</code>."
        );

        // Rate-limit the owner notification to once per hour per stranger.
        $bucket = 'bot_stranger:' . $userId;
        try {
            $seen = Db::value(
                'SELECT 1 FROM rate_limits WHERE bucket = ? AND window_start > DATE_SUB(NOW(), INTERVAL 1 HOUR)',
                [$bucket]
            );
            if ($seen) {
                return;
            }
            Db::run(
                'INSERT INTO rate_limits (bucket, hits, window_start) VALUES (?, 1, NOW())
                 ON DUPLICATE KEY UPDATE hits = hits + 1, window_start = NOW()',
                [$bucket]
            );
        } catch (Throwable) {
        }

        $name = trim(($from['first_name'] ?? '') . ' ' . ($from['last_name'] ?? ''));
        Notifier::toOwner(
            "👤 <b>Unknown user tried the bot</b>\n"
            . "ID: <code>{$userId}</code>\n"
            . "Name: " . Telegram::esc($name !== '' ? $name : '—') . "\n"
            . "Username: @" . Telegram::esc((string) ($from['username'] ?? '—')) . "\n\n"
            . "Allow with <code>/tgadd {$userId}</code>"
        );
    }

    private static function touch(int $userId, array $from): void
    {
        try {
            Db::run(
                'UPDATE telegram_admins
                 SET last_seen_at = NOW(), telegram_username = COALESCE(?, telegram_username)
                 WHERE telegram_user_id = ?',
                [mb_substr((string) ($from['username'] ?? ''), 0, 64) ?: null, $userId]
            );
        } catch (Throwable) {
        }
    }

    // =================================================================
    // Wizard state
    // =================================================================

    private static function state(int $chatId): ?array
    {
        $row = Db::one(
            'SELECT step, payload FROM telegram_state
             WHERE chat_id = ? AND updated_at > DATE_SUB(NOW(), INTERVAL 20 MINUTE)',
            [$chatId]
        );
        if (!$row || empty($row['step'])) {
            return null;
        }
        $payload = json_decode((string) ($row['payload'] ?? '{}'), true);
        return ['step' => (string) $row['step'], 'payload' => is_array($payload) ? $payload : []];
    }

    private static function setState(int $chatId, ?string $step, array $payload = []): void
    {
        if ($step === null) {
            Db::run('DELETE FROM telegram_state WHERE chat_id = ?', [$chatId]);
            return;
        }
        Db::run(
            'INSERT INTO telegram_state (chat_id, step, payload) VALUES (?, ?, ?)
             ON DUPLICATE KEY UPDATE step = VALUES(step), payload = VALUES(payload), updated_at = NOW()',
            [$chatId, $step, json_encode($payload, JSON_UNESCAPED_UNICODE)]
        );
    }

    private static function cmdCancel(int $chatId): void
    {
        self::setState($chatId, null);
        Telegram::send($chatId, "✅ Cancelled.");
    }

    /** Text typed while a wizard is active. */
    private static function wizardInput(int $chatId, array $actor, array $state, string $text): void
    {
        switch ($state['step']) {
            case 'addadmin:username':
                self::addAdminUsername($chatId, $state['payload'], $text);
                return;

            case 'addadmin:display':
                $p = $state['payload'];
                $p['display_name'] = mb_substr($text, 0, 128);
                self::setState($chatId, 'addadmin:role', $p);
                self::askRole($chatId, $p['username']);
                return;

            case 'addadmin:telegram':
                $p = $state['payload'];
                $lower = strtolower(trim($text));
                if (in_array($lower, ['skip', 'no', '-'], true)) {
                    $p['telegram_user_id'] = null;
                } elseif (ctype_digit(ltrim(trim($text), '-')) && (int) $text > 0) {
                    $p['telegram_user_id'] = (int) $text;
                } else {
                    Telegram::send($chatId, "Send a numeric Telegram user ID, or type <code>skip</code>.");
                    return;
                }
                self::setState($chatId, null);
                self::createAdmin($chatId, $actor, $p);
                return;

            default:
                self::setState($chatId, null);
                Telegram::send($chatId, "That wizard expired. Start again.");
        }
    }

    // =================================================================
    // Owner: dashboard admin management
    // =================================================================

    private static function cmdAddAdmin(int $chatId): void
    {
        self::setState($chatId, 'addadmin:username', []);
        Telegram::send(
            $chatId,
            "➕ <b>New dashboard admin</b>\n━━━━━━━━━━━━━━━━━━\n"
            . "Step 1/4 — send the <b>username</b>.\n\n"
            . "<i>3–32 characters, letters/numbers/._- only.</i>\n"
            . "Type /cancel to stop."
        );
    }

    private static function addAdminUsername(int $chatId, array $payload, string $text): void
    {
        $username = strtolower(trim($text));

        if (!preg_match('/^[a-z0-9._-]{3,32}$/', $username)) {
            Telegram::send($chatId, "❌ Invalid username. Use 3–32 chars: a-z 0-9 . _ -\nTry again or /cancel.");
            return;
        }
        if (Db::value('SELECT 1 FROM admin_users WHERE username = ?', [$username])) {
            Telegram::send($chatId, "❌ <code>" . Telegram::esc($username) . "</code> already exists.\nSend a different username.");
            return;
        }

        $payload['username'] = $username;
        self::setState($chatId, 'addadmin:display', $payload);
        Telegram::send(
            $chatId,
            "Step 2/4 — send a <b>display name</b> for <code>" . Telegram::esc($username) . "</code>.\n"
            . "<i>e.g. Ko Aung — Sales</i>"
        );
    }

    private static function askRole(int $chatId, string $username): void
    {
        Telegram::send(
            $chatId,
            "Step 3/4 — pick the <b>role</b> for <code>" . Telegram::esc($username) . "</code>:\n\n"
            . "👑 <b>Super Admin</b>\n<i>Servers add/delete, VIP accounts, VIP prices, settings, backups</i>\n\n"
            . "👤 <b>Admin</b>\n<i>VIP accounts only</i>",
            Telegram::inlineKeyboard([
                [Telegram::btn('👑 Super Admin', 'role:super_admin')],
                [Telegram::btn('👤 Admin', 'role:admin')],
                [Telegram::btn('✖️ Cancel', 'role:cancel')],
            ])
        );
    }

    private static function createAdmin(int $chatId, array $actor, array $p): void
    {
        $username = (string) ($p['username'] ?? '');
        $role     = ($p['role'] ?? 'admin') === Auth::ROLE_SUPER ? Auth::ROLE_SUPER : Auth::ROLE_ADMIN;
        $display  = (string) ($p['display_name'] ?? $username);
        $tgId     = $p['telegram_user_id'] ?? null;

        if ($username === '') {
            Telegram::send($chatId, "❌ Wizard data lost. Start again with /addadmin.");
            return;
        }
        if (Db::value('SELECT 1 FROM admin_users WHERE username = ?', [$username])) {
            Telegram::send($chatId, "❌ <code>" . Telegram::esc($username) . "</code> was created in the meantime.");
            return;
        }

        // The bot generates the password; the admin MUST rotate it on first
        // login (must_change_password = 1).
        $password = Crypto::strongPassword(16);

        Db::run(
            'INSERT INTO admin_users
               (username, password_hash, display_name, role, is_active,
                telegram_user_id, created_by_tg_id, must_change_password)
             VALUES (?, ?, ?, ?, 1, ?, ?, 1)',
            [
                $username,
                Crypto::hashSecret($password),
                $display,
                $role,
                $tgId,
                (int) $actor['telegram_user_id'],
            ]
        );
        $newId = (int) Db::value('SELECT id FROM admin_users WHERE username = ?', [$username]);

        // If a Telegram ID was supplied, let that person use the bot too.
        if ($tgId !== null) {
            try {
                Db::run(
                    'INSERT INTO telegram_admins
                       (telegram_user_id, display_name, role, is_active, linked_admin_id)
                     VALUES (?, ?, ?, 1, ?)
                     ON DUPLICATE KEY UPDATE role = VALUES(role), is_active = 1,
                       linked_admin_id = VALUES(linked_admin_id)',
                    [$tgId, $display, $role, $newId]
                );
            } catch (Throwable) {
            }
        }

        Audit::log(
            'admin.create',
            'admin_user',
            (string) $newId,
            ['username' => $username, 'role' => $role, 'via' => 'telegram'],
            'telegram',
            (string) $actor['telegram_user_id'],
            'bot:' . ($actor['display_name'] ?? 'owner')
        );

        $roleLabel = $role === Auth::ROLE_SUPER ? '👑 Super Admin' : '👤 Admin';

        // Credentials go ONLY to the owner chat, in one deletable message.
        Telegram::send(
            $chatId,
            "✅ <b>Admin created</b>\n━━━━━━━━━━━━━━━━━━\n"
            . "Username: <code>" . Telegram::esc($username) . "</code>\n"
            . "Password: <code>" . Telegram::esc($password) . "</code>\n"
            . "Role: {$roleLabel}\n"
            . ($tgId !== null ? "Telegram: <code>{$tgId}</code>\n" : '')
            . "\n⚠️ <b>Send this to the person over a secure channel and delete this message.</b>\n"
            . "They must change the password at first login."
        );

        Notifier::adminChange(
            "👤 <b>New dashboard admin</b>\n"
            . "Username: <code>" . Telegram::esc($username) . "</code>\n"
            . "Role: {$roleLabel}\n"
            . "Created by: owner via bot"
        );
    }

    private static function cmdDelAdmin(int $chatId): void
    {
        $rows = Db::all('SELECT id, username, role FROM admin_users ORDER BY username ASC LIMIT 40');
        if (!$rows) {
            Telegram::send($chatId, "No dashboard admins exist.");
            return;
        }

        $superCount = (int) Db::value("SELECT COUNT(*) FROM admin_users WHERE role = 'super_admin' AND is_active = 1");

        $buttons = [];
        foreach ($rows as $r) {
            $icon = $r['role'] === Auth::ROLE_SUPER ? '👑' : '👤';
            $buttons[] = [Telegram::btn($icon . ' ' . $r['username'], 'del:' . $r['id'])];
        }
        $buttons[] = [Telegram::btn('✖️ Cancel', 'del:cancel')];

        Telegram::send(
            $chatId,
            "🗑 <b>Delete a dashboard admin</b>\n━━━━━━━━━━━━━━━━━━\n"
            . "Pick the account to remove.\n"
            . "<i>The last active Super Admin cannot be deleted "
            . "(currently {$superCount}).</i>",
            Telegram::inlineKeyboard($buttons)
        );
    }

    private static function cmdRole(int $chatId): void
    {
        $rows = Db::all('SELECT id, username, role FROM admin_users ORDER BY username ASC LIMIT 40');
        if (!$rows) {
            Telegram::send($chatId, "No dashboard admins exist.");
            return;
        }
        $buttons = [];
        foreach ($rows as $r) {
            $icon = $r['role'] === Auth::ROLE_SUPER ? '👑' : '👤';
            $buttons[] = [Telegram::btn($icon . ' ' . $r['username'], 'chrole:' . $r['id'])];
        }
        $buttons[] = [Telegram::btn('✖️ Cancel', 'chrole:cancel')];

        Telegram::send(
            $chatId,
            "🔀 <b>Change role</b>\n━━━━━━━━━━━━━━━━━━\nPick an admin to flip between Super Admin and Admin.",
            Telegram::inlineKeyboard($buttons)
        );
    }

    private static function cmdResetPw(int $chatId): void
    {
        $rows = Db::all('SELECT id, username, role FROM admin_users ORDER BY username ASC LIMIT 40');
        if (!$rows) {
            Telegram::send($chatId, "No dashboard admins exist.");
            return;
        }
        $buttons = [];
        foreach ($rows as $r) {
            $icon = $r['role'] === Auth::ROLE_SUPER ? '👑' : '👤';
            $buttons[] = [Telegram::btn($icon . ' ' . $r['username'], 'pw:' . $r['id'])];
        }
        $buttons[] = [Telegram::btn('✖️ Cancel', 'pw:cancel')];

        Telegram::send(
            $chatId,
            "🔑 <b>Reset password</b>\n━━━━━━━━━━━━━━━━━━\n"
            . "A new random password is generated and all their sessions are killed.",
            Telegram::inlineKeyboard($buttons)
        );
    }

    // =================================================================
    // Owner: bot user management
    // =================================================================

    private static function cmdTgAdd(int $chatId, array $actor, array $args): void
    {
        $id = (int) ($args[0] ?? 0);
        if ($id <= 0) {
            Telegram::send($chatId, "Usage: <code>/tgadd 123456789</code>\n\nThe person can find their ID by messaging this bot once.");
            return;
        }
        $role = strtolower((string) ($args[1] ?? 'admin'));
        $role = in_array($role, ['admin', 'super_admin'], true) ? $role : 'admin';

        Db::run(
            'INSERT INTO telegram_admins (telegram_user_id, role, is_active)
             VALUES (?, ?, 1)
             ON DUPLICATE KEY UPDATE role = VALUES(role), is_active = 1',
            [$id, $role]
        );

        Audit::log(
            'bot.user_add', 'telegram_admin', (string) $id, ['role' => $role],
            'telegram', (string) $actor['telegram_user_id'], 'bot:owner'
        );

        Telegram::send($chatId, "✅ <code>{$id}</code> can now use the bot as <b>{$role}</b>.");
        Telegram::send($id, "✅ You have been granted access to the <b>N4 Core VPN</b> control bot.\nSend /help to begin.");
    }

    private static function cmdTgDel(int $chatId, array $actor, array $args): void
    {
        $id = (int) ($args[0] ?? 0);
        if ($id <= 0) {
            Telegram::send($chatId, "Usage: <code>/tgdel 123456789</code>");
            return;
        }
        if ($id === Telegram::ownerId()) {
            Telegram::send($chatId, "⛔️ The owner cannot be removed.");
            return;
        }
        $n = Db::run('DELETE FROM telegram_admins WHERE telegram_user_id = ?', [$id]);
        Db::run('DELETE FROM telegram_state WHERE chat_id = ?', [$id]);

        Audit::log(
            'bot.user_del', 'telegram_admin', (string) $id, [],
            'telegram', (string) $actor['telegram_user_id'], 'bot:owner'
        );

        Telegram::send($chatId, $n > 0 ? "🗑 Removed <code>{$id}</code>." : "Not found: <code>{$id}</code>.");
    }

    private static function cmdTgList(int $chatId): void
    {
        $rows = Db::all('SELECT * FROM telegram_admins ORDER BY FIELD(role, \'owner\', \'super_admin\', \'admin\'), telegram_user_id');
        if (!$rows) {
            Telegram::send($chatId, "No bot users yet.");
            return;
        }
        $out = "🤖 <b>Bot users</b>\n━━━━━━━━━━━━━━━━━━\n";
        foreach ($rows as $r) {
            $icon = match ($r['role']) {
                'owner' => '👑👑',
                'super_admin' => '👑',
                default => '👤',
            };
            $out .= $icon . ' <code>' . (int) $r['telegram_user_id'] . '</code>'
                . ' — ' . Telegram::esc((string) ($r['display_name'] ?? '—'))
                . ((int) $r['is_active'] === 1 ? '' : ' <i>(disabled)</i>')
                . "\n";
        }
        Telegram::send($chatId, $out);
    }

    // =================================================================
    // Read-only reports
    // =================================================================

    private static function cmdWhoami(int $chatId, array $actor): void
    {
        $role = match ($actor['role']) {
            'owner'       => '👑👑 Owner (permanent, full access)',
            'super_admin' => '👑 Super Admin',
            default       => '👤 Admin',
        };
        Telegram::send(
            $chatId,
            "🪪 <b>You</b>\n━━━━━━━━━━━━━━━━━━\n"
            . "Telegram ID: <code>" . (int) $actor['telegram_user_id'] . "</code>\n"
            . "Bot role: {$role}"
        );
    }

    /**
     * Sends the ONE key needed to open a backup archive on a new VPS.
     *
     * There are three secrets in config.php, but only encryption_key has to
     * travel by hand: it is what unseals the .enc file. pepper and app_secret
     * are inside that file already (backups include config/config.php), and
     * bin/restore.php lifts them out on its own. Sending all three would be
     * two extra chances to leak a secret for no benefit.
     */
    private static function cmdKeys(int $chatId, array $actor): void
    {
        $enc = (string) Config::get('security.encryption_key', '');

        if ($enc === '') {
            Telegram::send($chatId, "❌ Secrets are not configured on this server.");
            return;
        }

        Audit::log(
            'security.keys_exported', 'config', null,
            ['via' => 'telegram', 'chat' => $chatId],
            'telegram', (string) $actor['telegram_user_id'], 'bot'
        );

        Telegram::send(
            $chatId,
            "🔑 <b>Encryption Key</b>\n━━━━━━━━━━━━━━━━━━\n"
            . "VPS အသစ်မှာ backup ဖွင့်ဖို့ ဒီတစ်ခုတည်း လိုပါတယ်။"
        );

        // Sent alone so a single tap copies exactly the value and nothing else.
        Telegram::send($chatId, "<code>" . Telegram::esc($enc) . "</code>");

        Telegram::send(
            $chatId,
            "▸ <b>သုံးပုံ</b>\n"
            . "<code>bash deploy/n4core-newvps.sh yourdomain.com backup.enc</code>\n"
            . "key ကို တောင်းလာရင် အပေါ်က တန်ဖိုးကို paste ပါ။\n\n"
            . "ကျန် key တွေ (pepper, app_secret) က backup ဖိုင်ထဲမှာ "
            . "ပါပြီးသားမို့ အလိုအလျောက် ဝင်သွားပါမယ်။\n\n"
            . "⚠️ သုံးပြီးရင် ဒီ message ကို <b>ဖျက်ပစ်ပါ</b>။"
        );
    }

    private static function cmdStatus(int $chatId, bool $isSuper): void
    {
        $tz    = (string) Config::get('app.timezone', 'Asia/Yangon');
        $maint = Config::settingBool('maintenance_mode', false);

        $out = "📊 <b>System Status</b>\n━━━━━━━━━━━━━━━━━━\n"
            . "Time: <code>" . date('Y-m-d H:i:s') . "</code> ({$tz})\n"
            . "API: " . ($maint ? "🛠 <b>MAINTENANCE</b>" : "✅ Live") . "\n"
            . "PHP: <code>" . PHP_VERSION . "</code>\n";

        try {
            $out .= "Database: ✅ connected\n";
            $out .= "\n<b>Catalogue</b>\n"
                . "Servers: <b>" . (int) Db::value('SELECT COUNT(*) FROM servers WHERE is_enabled = 1') . "</b> active"
                . " (" . (int) Db::value("SELECT COUNT(*) FROM servers WHERE tier='vip' AND is_enabled=1") . " VIP)\n"
                . "Regions: <b>" . (int) Db::value('SELECT COUNT(*) FROM locations WHERE is_enabled = 1') . "</b>\n"
                . "Plans: <b>" . (int) Db::value('SELECT COUNT(*) FROM vip_plans WHERE is_enabled = 1') . "</b>\n"
                . "\n<b>VIP</b>\n"
                . "Active: <b>" . (int) Db::value('SELECT COUNT(*) FROM vip_accounts WHERE is_active=1 AND expires_at>NOW()') . "</b>\n"
                . "Expired: <b>" . (int) Db::value('SELECT COUNT(*) FROM vip_accounts WHERE expires_at<=NOW()') . "</b>\n"
                . "Live sessions: <b>" . (int) Db::value('SELECT COUNT(*) FROM vip_sessions WHERE revoked_at IS NULL AND expires_at>NOW()') . "</b>\n";
        } catch (Throwable $e) {
            $out .= "Database: ❌ <b>ERROR</b>\n";
        }

        if ($isSuper) {
            try {
                $out .= "\n<b>Security (24h)</b>\n"
                    . "Failed admin logins: <b>"
                    . (int) Db::value("SELECT COUNT(*) FROM login_events WHERE kind LIKE 'admin_fail%' AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)")
                    . "</b>\n"
                    . "Blocked IPs: <b>"
                    . (int) Db::value('SELECT COUNT(*) FROM rate_limits WHERE blocked_until > NOW()')
                    . "</b>\n"
                    . "Dashboard sessions: <b>"
                    . (int) Db::value('SELECT COUNT(*) FROM admin_sessions WHERE revoked_at IS NULL AND expires_at>NOW()')
                    . "</b>\n";

                $bk = Db::one('SELECT filename, size_bytes, created_at, status FROM backups ORDER BY id DESC LIMIT 1');
                $out .= "\n<b>Last backup</b>\n";
                $out .= $bk
                    ? "<code>" . Telegram::esc((string) $bk['filename']) . "</code>\n"
                      . Backup::human((int) $bk['size_bytes']) . " — " . (string) $bk['created_at'] . "\n"
                    : "<i>none yet</i>\n";

                $free = @disk_free_space(Config::storagePath('backups'));
                if ($free !== false) {
                    $out .= "Disk free: <b>" . Backup::human((int) $free) . "</b>\n";
                }
            } catch (Throwable) {
            }
        }

        Telegram::send($chatId, $out);
    }

    private static function cmdVip(int $chatId): void
    {
        $rows = Db::all(
            'SELECT username, plan_name, device_limit, is_active, expires_at,
                    (SELECT COUNT(*) FROM vip_devices d WHERE d.account_id = a.id) AS devices
             FROM vip_accounts a
             ORDER BY expires_at ASC
             LIMIT 20'
        );
        if (!$rows) {
            Telegram::send($chatId, "No VIP accounts yet.");
            return;
        }

        $out = "💎 <b>VIP Accounts</b> (soonest expiry first)\n━━━━━━━━━━━━━━━━━━\n";
        foreach ($rows as $r) {
            $exp     = strtotime((string) $r['expires_at']);
            $expired = $exp !== false && $exp <= time();
            $icon    = (int) $r['is_active'] !== 1 ? '⛔️' : ($expired ? '⌛️' : '✅');
            $days    = $exp !== false ? (int) ceil(($exp - time()) / 86400) : 0;

            $out .= "{$icon} <code>" . Telegram::esc((string) $r['username']) . "</code>"
                . " — " . Telegram::esc((string) ($r['plan_name'] ?? '—'))
                . "\n    " . (int) $r['devices'] . "/" . (int) $r['device_limit'] . " devices · "
                . ($expired ? "expired" : "{$days}d left") . "\n";
        }
        $total = (int) Db::value('SELECT COUNT(*) FROM vip_accounts');
        if ($total > 20) {
            $out .= "\n<i>…and " . ($total - 20) . " more. Use the dashboard for the full list.</i>";
        }
        Telegram::send($chatId, $out);
    }

    private static function cmdServers(int $chatId): void
    {
        $rows = Db::all(
            'SELECT l.flag_emoji, l.name AS region,
                    COUNT(s.id) AS total,
                    SUM(CASE WHEN s.tier = \'vip\' THEN 1 ELSE 0 END) AS vip,
                    SUM(CASE WHEN s.is_enabled = 0 THEN 1 ELSE 0 END) AS off
             FROM locations l
             LEFT JOIN servers s ON s.location_id = l.id
             GROUP BY l.id
             HAVING total > 0
             ORDER BY total DESC
             LIMIT 30'
        );
        if (!$rows) {
            Telegram::send($chatId, "No servers configured yet.");
            return;
        }

        $out = "🌍 <b>Servers by region</b>\n━━━━━━━━━━━━━━━━━━\n";
        foreach ($rows as $r) {
            $out .= (string) $r['flag_emoji'] . ' ' . Telegram::esc((string) $r['region'])
                . ' — <b>' . (int) $r['total'] . '</b>'
                . ' (VIP ' . (int) $r['vip'] . ($r['off'] > 0 ? ', off ' . (int) $r['off'] : '') . ")\n";
        }
        Telegram::send($chatId, $out);
    }

    private static function cmdLogins(int $chatId): void
    {
        $rows = Db::all(
            "SELECT kind, username, ip, reason, created_at
             FROM login_events
             WHERE kind LIKE 'admin%'
             ORDER BY id DESC LIMIT 15"
        );
        if (!$rows) {
            Telegram::send($chatId, "No dashboard logins recorded yet.");
            return;
        }
        $out = "🔐 <b>Recent dashboard logins</b>\n━━━━━━━━━━━━━━━━━━\n";
        foreach ($rows as $r) {
            $icon = match ($r['kind']) {
                'admin_success' => '✅',
                'admin_locked'  => '🔒',
                default         => '❌',
            };
            $out .= "{$icon} <code>" . Telegram::esc((string) ($r['username'] ?? '?')) . "</code>"
                . " · " . Telegram::esc((string) ($r['ip'] ?? '—'))
                . "\n    <i>" . (string) $r['created_at']
                . (!empty($r['reason']) ? ' — ' . Telegram::esc((string) $r['reason']) : '')
                . "</i>\n";
        }
        Telegram::send($chatId, $out);
    }

    private static function cmdAdmins(int $chatId): void
    {
        $rows = Db::all(
            'SELECT id, username, display_name, role, is_active, must_change_password,
                    last_login_at, locked_until
             FROM admin_users
             ORDER BY (role = \'super_admin\') DESC, username ASC'
        );
        if (!$rows) {
            Telegram::send($chatId, "No dashboard admins exist. Use /addadmin.");
            return;
        }

        $out = "🛡 <b>Dashboard admins</b>\n━━━━━━━━━━━━━━━━━━\n";
        foreach ($rows as $r) {
            $icon   = $r['role'] === Auth::ROLE_SUPER ? '👑' : '👤';
            $locked = !empty($r['locked_until']) && strtotime((string) $r['locked_until']) > time();

            $flags = [];
            if ((int) $r['is_active'] !== 1) {
                $flags[] = 'disabled';
            }
            if ($locked) {
                $flags[] = 'locked';
            }
            if ((int) $r['must_change_password'] === 1) {
                $flags[] = 'pw change pending';
            }

            $out .= "{$icon} <code>" . Telegram::esc((string) $r['username']) . "</code>"
                . ' — ' . Telegram::esc((string) ($r['display_name'] ?? '—'))
                . ($flags ? ' <i>(' . implode(', ', $flags) . ')</i>' : '')
                . "\n    <i>last login: " . (string) ($r['last_login_at'] ?? 'never') . "</i>\n";
        }
        Telegram::send($chatId, $out);
    }

    private static function cmdAlerts(int $chatId, array $actor): void
    {
        $row = Db::one(
            'SELECT notify_login, notify_backup, notify_security
             FROM telegram_admins WHERE telegram_user_id = ?',
            [(int) $actor['telegram_user_id']]
        ) ?? ['notify_login' => 1, 'notify_backup' => 1, 'notify_security' => 1];

        $mark = fn($v) => ((int) $v === 1 ? '🔔 ON' : '🔕 OFF');

        Telegram::send(
            $chatId,
            "🔔 <b>My notifications</b>\n━━━━━━━━━━━━━━━━━━\n"
            . "Login alarm: " . $mark($row['notify_login']) . "\n"
            . "Backup delivery: " . $mark($row['notify_backup']) . "\n"
            . "Security alerts: " . $mark($row['notify_security']) . "\n\nTap to toggle:",
            Telegram::inlineKeyboard([
                [Telegram::btn('Login alarm', 'alert:notify_login')],
                [Telegram::btn('Backup delivery', 'alert:notify_backup')],
                [Telegram::btn('Security alerts', 'alert:notify_security')],
            ])
        );
    }

    // =================================================================
    // Backups
    // =================================================================

    private static function cmdBackup(int $chatId, array $actor, array $args): void
    {
        $scope = strtolower((string) ($args[0] ?? 'full'));
        $scope = in_array($scope, ['full', 'db', 'files'], true) ? $scope : 'full';

        $label = match ($scope) {
            'db'    => 'Database only',
            'files' => 'Files only',
            default => 'All files + database',
        };

        Telegram::send($chatId, "💾 <b>Backup started</b>\nScope: {$label}\n\n<i>This can take a minute…</i>");

        @set_time_limit(900);

        $by     = 'telegram:' . (int) $actor['telegram_user_id'];
        $result = Backup::create($scope, 'manual', $by);

        if (!$result['ok']) {
            Telegram::send($chatId, "❌ <b>Backup failed</b>\n<code>" . Telegram::esc((string) $result['error']) . "</code>");
            return;
        }

        Audit::log(
            'backup.create', 'backup', $result['filename'],
            ['scope' => $scope, 'size' => Backup::human($result['size']), 'via' => 'telegram'],
            'telegram', (string) $actor['telegram_user_id'], 'bot'
        );

        $caption = "💾 <b>Manual Backup</b>\nRequested via bot";
        if (!Backup::deliver($result, $caption)) {
            Telegram::send(
                $chatId,
                "✅ Backup created but not sent as a file.\n"
                . "<code>" . Telegram::esc($result['filename']) . "</code>\n"
                . Backup::human($result['size']) . "\n\n"
                . "<i>Download it from the dashboard → Backups.</i>"
            );
        }

        Backup::prune();
    }

    private static function cmdBackupList(int $chatId): void
    {
        $rows = Backup::listRecent(10);
        if (!$rows) {
            Telegram::send($chatId, "No backups recorded yet. Run /backup.");
            return;
        }
        $out = "📦 <b>Recent backups</b>\n━━━━━━━━━━━━━━━━━━\n";
        foreach ($rows as $r) {
            // status is ENUM('ok','failed','sending','sent'); only 'failed' is bad.
            $st   = (string) $r['status'];
            $icon = $st === 'failed'
                ? '❌'
                : ($st === 'sending' ? '⏳' : ((int) $r['delivered_tg'] === 1 ? '📨' : '💾'));
            $out .= "{$icon} <code>" . Telegram::esc((string) $r['filename']) . "</code>\n"
                . '    ' . Backup::human((int) $r['size_bytes'])
                . ' · ' . strtoupper((string) $r['scope'])
                . ' · ' . (string) $r['kind']
                . ((int) $r['encrypted'] === 1 ? ' · 🔐' : '')
                . "\n    <i>" . (string) $r['created_at'] . "</i>\n";
        }
        Telegram::send($chatId, $out);
    }

    // =================================================================
    // Panic buttons
    // =================================================================

    private static function cmdRevoke(int $chatId, array $actor): void
    {
        Telegram::send(
            $chatId,
            "🚨 <b>Kill all dashboard sessions?</b>\n━━━━━━━━━━━━━━━━━━\n"
            . "Every admin (including you, in the browser) will be logged out immediately.\n"
            . "Passwords are NOT changed. App users are NOT affected.",
            Telegram::inlineKeyboard([
                [Telegram::btn('🚨 Yes, log everyone out', 'revoke:yes')],
                [Telegram::btn('✖️ Cancel', 'revoke:no')],
            ])
        );
    }

    private static function cmdUnlock(int $chatId, array $actor): void
    {
        $blocks = Db::run('DELETE FROM rate_limits WHERE blocked_until IS NOT NULL');
        $locked = Db::run('UPDATE admin_users SET failed_attempts = 0, locked_until = NULL WHERE locked_until IS NOT NULL');
        Db::run('UPDATE vip_accounts SET failed_attempts = 0, locked_until = NULL WHERE locked_until IS NOT NULL');

        Audit::log(
            'security.unlock_all', 'system', null,
            ['blocks' => $blocks, 'admins' => $locked],
            'telegram', (string) $actor['telegram_user_id'], 'bot'
        );

        Telegram::send(
            $chatId,
            "🔓 <b>Cleared</b>\nRate-limit blocks: <b>{$blocks}</b>\nLocked accounts: <b>{$locked}</b>"
        );
    }

    // =================================================================
    // Callback buttons
    // =================================================================

    private static function onCallback(array $cb): void
    {
        $id     = (string) ($cb['id'] ?? '');
        $from   = $cb['from'] ?? [];
        $userId = (int) ($from['id'] ?? 0);
        $chatId = (int) ($cb['message']['chat']['id'] ?? 0);
        $data   = (string) ($cb['data'] ?? '');

        if ($chatId === 0 || $userId === 0) {
            return;
        }

        $actor = self::actor($userId, $from);
        if ($actor === null) {
            Telegram::answerCallback($id, 'Access denied', true);
            return;
        }
        $isOwner = $actor['role'] === 'owner';
        $isSuper = $isOwner || $actor['role'] === 'super_admin';

        [$kind, $arg] = array_pad(explode(':', $data, 2), 2, '');

        // Owner-only button groups
        if (in_array($kind, ['role', 'del', 'delok', 'chrole', 'chroleok', 'pw'], true) && !$isOwner) {
            Telegram::answerCallback($id, 'Owner only', true);
            return;
        }
        if ($kind === 'revoke' && !$isSuper) {
            Telegram::answerCallback($id, 'Not allowed', true);
            return;
        }

        switch ($kind) {
            case 'role':
                Telegram::answerCallback($id);
                self::cbRole($chatId, $arg);
                return;

            case 'del':
                Telegram::answerCallback($id);
                self::cbDelConfirm($chatId, $arg);
                return;

            case 'delok':
                Telegram::answerCallback($id, 'Deleting…');
                self::cbDelExecute($chatId, $actor, $arg);
                return;

            case 'chrole':
                Telegram::answerCallback($id);
                self::cbChangeRoleConfirm($chatId, $arg);
                return;

            case 'chroleok':
                Telegram::answerCallback($id, 'Updating…');
                self::cbChangeRoleExecute($chatId, $actor, $arg);
                return;

            case 'pw':
                Telegram::answerCallback($id, 'Resetting…');
                self::cbResetPassword($chatId, $actor, $arg);
                return;

            case 'revoke':
                Telegram::answerCallback($id);
                self::cbRevoke($chatId, $actor, $arg);
                return;

            case 'alert':
                Telegram::answerCallback($id, 'Saved');
                self::cbToggleAlert($chatId, $actor, $arg);
                return;

            default:
                Telegram::answerCallback($id);
        }
    }

    /** Role chosen in the /addadmin wizard. */
    private static function cbRole(int $chatId, string $arg): void
    {
        if ($arg === 'cancel') {
            self::setState($chatId, null);
            Telegram::send($chatId, "✅ Cancelled.");
            return;
        }
        $state = self::state($chatId);
        if ($state === null || !str_starts_with($state['step'], 'addadmin:')) {
            Telegram::send($chatId, "That wizard expired. Start again with /addadmin.");
            return;
        }
        $p = $state['payload'];
        $p['role'] = $arg === Auth::ROLE_SUPER ? Auth::ROLE_SUPER : Auth::ROLE_ADMIN;

        self::setState($chatId, 'addadmin:telegram', $p);
        Telegram::send(
            $chatId,
            "Step 4/4 — send this admin's <b>Telegram user ID</b> so they receive their own alerts,\n"
            . "or type <code>skip</code>.\n\n"
            . "<i>They can get their ID by sending any message to this bot.</i>"
        );
    }

    private static function cbDelConfirm(int $chatId, string $arg): void
    {
        if ($arg === 'cancel') {
            Telegram::send($chatId, "✅ Cancelled.");
            return;
        }
        $adminId = (int) $arg;
        $row = Db::one('SELECT id, username, role FROM admin_users WHERE id = ?', [$adminId]);
        if (!$row) {
            Telegram::send($chatId, "Not found — maybe already deleted.");
            return;
        }
        Telegram::send(
            $chatId,
            "⚠️ <b>Delete <code>" . Telegram::esc((string) $row['username']) . "</code>?</b>\n"
            . "Role: " . ($row['role'] === Auth::ROLE_SUPER ? '👑 Super Admin' : '👤 Admin') . "\n\n"
            . "This cannot be undone.",
            Telegram::inlineKeyboard([
                [Telegram::btn('🗑 Yes, delete', 'delok:' . $adminId)],
                [Telegram::btn('✖️ Cancel', 'delok:cancel')],
            ])
        );
    }

    private static function cbDelExecute(int $chatId, array $actor, string $arg): void
    {
        if ($arg === 'cancel') {
            Telegram::send($chatId, "✅ Cancelled.");
            return;
        }
        $adminId = (int) $arg;
        $row = Db::one('SELECT id, username, role, is_active FROM admin_users WHERE id = ?', [$adminId]);
        if (!$row) {
            Telegram::send($chatId, "Not found.");
            return;
        }

        // Never leave the system without a Super Admin.
        if ($row['role'] === Auth::ROLE_SUPER) {
            $others = (int) Db::value(
                "SELECT COUNT(*) FROM admin_users WHERE role = 'super_admin' AND is_active = 1 AND id <> ?",
                [$adminId]
            );
            if ($others === 0) {
                Telegram::send($chatId, "⛔️ Refused: this is the last active Super Admin.\nCreate another one first.");
                return;
            }
        }

        Db::run('DELETE FROM admin_sessions WHERE admin_id = ?', [$adminId]);
        Db::run('UPDATE telegram_admins SET linked_admin_id = NULL WHERE linked_admin_id = ?', [$adminId]);
        Db::run('DELETE FROM admin_users WHERE id = ?', [$adminId]);

        Audit::log(
            'admin.delete', 'admin_user', (string) $adminId,
            ['username' => $row['username'], 'role' => $row['role'], 'via' => 'telegram'],
            'telegram', (string) $actor['telegram_user_id'], 'bot:owner'
        );

        Telegram::send($chatId, "🗑 Deleted <code>" . Telegram::esc((string) $row['username']) . "</code>.");
        Notifier::adminChange(
            "🗑 <b>Dashboard admin deleted</b>\n"
            . "Username: <code>" . Telegram::esc((string) $row['username']) . "</code>\n"
            . "By: owner via bot"
        );
    }

    private static function cbChangeRoleConfirm(int $chatId, string $arg): void
    {
        if ($arg === 'cancel') {
            Telegram::send($chatId, "✅ Cancelled.");
            return;
        }
        $adminId = (int) $arg;
        $row = Db::one('SELECT id, username, role FROM admin_users WHERE id = ?', [$adminId]);
        if (!$row) {
            Telegram::send($chatId, "Not found.");
            return;
        }
        $next      = $row['role'] === Auth::ROLE_SUPER ? Auth::ROLE_ADMIN : Auth::ROLE_SUPER;
        $nextLabel = $next === Auth::ROLE_SUPER ? '👑 Super Admin' : '👤 Admin';

        Telegram::send(
            $chatId,
            "🔀 Change <code>" . Telegram::esc((string) $row['username']) . "</code> to <b>{$nextLabel}</b>?\n\n"
            . ($next === Auth::ROLE_ADMIN
                ? "<i>They will lose server, price, settings and backup access.</i>"
                : "<i>They will gain full access including server add/delete and prices.</i>"),
            Telegram::inlineKeyboard([
                [Telegram::btn('✅ Confirm', 'chroleok:' . $adminId)],
                [Telegram::btn('✖️ Cancel', 'chroleok:cancel')],
            ])
        );
    }

    private static function cbChangeRoleExecute(int $chatId, array $actor, string $arg): void
    {
        if ($arg === 'cancel') {
            Telegram::send($chatId, "✅ Cancelled.");
            return;
        }
        $adminId = (int) $arg;
        $row = Db::one('SELECT id, username, role FROM admin_users WHERE id = ?', [$adminId]);
        if (!$row) {
            Telegram::send($chatId, "Not found.");
            return;
        }
        $next = $row['role'] === Auth::ROLE_SUPER ? Auth::ROLE_ADMIN : Auth::ROLE_SUPER;

        if ($next === Auth::ROLE_ADMIN) {
            $others = (int) Db::value(
                "SELECT COUNT(*) FROM admin_users WHERE role = 'super_admin' AND is_active = 1 AND id <> ?",
                [$adminId]
            );
            if ($others === 0) {
                Telegram::send($chatId, "⛔️ Refused: that would leave zero Super Admins.");
                return;
            }
        }

        Db::run('UPDATE admin_users SET role = ? WHERE id = ?', [$next, $adminId]);
        // Role changes must not ride on an existing session.
        Db::run('UPDATE admin_sessions SET revoked_at = NOW() WHERE admin_id = ? AND revoked_at IS NULL', [$adminId]);
        Db::run('UPDATE telegram_admins SET role = ? WHERE linked_admin_id = ? AND role <> \'owner\'', [$next, $adminId]);

        Audit::log(
            'admin.role_change', 'admin_user', (string) $adminId,
            ['username' => $row['username'], 'from' => $row['role'], 'to' => $next, 'via' => 'telegram'],
            'telegram', (string) $actor['telegram_user_id'], 'bot:owner'
        );

        $label = $next === Auth::ROLE_SUPER ? '👑 Super Admin' : '👤 Admin';
        Telegram::send($chatId, "✅ <code>" . Telegram::esc((string) $row['username']) . "</code> is now <b>{$label}</b>.\n<i>Their sessions were logged out.</i>");
        Notifier::adminChange(
            "🔀 <b>Role changed</b>\n<code>" . Telegram::esc((string) $row['username']) . "</code> → {$label}"
        );
    }

    private static function cbResetPassword(int $chatId, array $actor, string $arg): void
    {
        if ($arg === 'cancel') {
            Telegram::send($chatId, "✅ Cancelled.");
            return;
        }
        $adminId = (int) $arg;
        $row = Db::one('SELECT id, username, role FROM admin_users WHERE id = ?', [$adminId]);
        if (!$row) {
            Telegram::send($chatId, "Not found.");
            return;
        }

        $password = Crypto::strongPassword(16);
        Db::run(
            'UPDATE admin_users
             SET password_hash = ?, must_change_password = 1, failed_attempts = 0,
                 locked_until = NULL, password_changed_at = NOW()
             WHERE id = ?',
            [Crypto::hashSecret($password), $adminId]
        );
        Db::run('UPDATE admin_sessions SET revoked_at = NOW() WHERE admin_id = ? AND revoked_at IS NULL', [$adminId]);

        Audit::log(
            'admin.password_reset', 'admin_user', (string) $adminId,
            ['username' => $row['username'], 'via' => 'telegram'],
            'telegram', (string) $actor['telegram_user_id'], 'bot:owner'
        );

        Telegram::send(
            $chatId,
            "🔑 <b>Password reset</b>\n━━━━━━━━━━━━━━━━━━\n"
            . "Username: <code>" . Telegram::esc((string) $row['username']) . "</code>\n"
            . "New password: <code>" . Telegram::esc($password) . "</code>\n\n"
            . "⚠️ <b>Delete this message after sharing it.</b>\n"
            . "They must change it at first login. All their sessions were killed."
        );
    }

    private static function cbRevoke(int $chatId, array $actor, string $arg): void
    {
        if ($arg !== 'yes') {
            Telegram::send($chatId, "✅ Cancelled.");
            return;
        }
        $n = Db::run('UPDATE admin_sessions SET revoked_at = NOW() WHERE revoked_at IS NULL');

        Audit::log(
            'admin.revoke_all', 'admin_session', null, ['sessions' => $n, 'via' => 'telegram'],
            'telegram', (string) $actor['telegram_user_id'], 'bot'
        );

        Telegram::send($chatId, "🚨 <b>Done.</b> {$n} dashboard session(s) terminated.\n<i>App users were not affected.</i>");
        Notifier::securityAlert("🚨 All dashboard sessions were revoked from the bot.");
    }

    private static function cbToggleAlert(int $chatId, array $actor, string $arg): void
    {
        $allowed = ['notify_login', 'notify_backup', 'notify_security'];
        if (!in_array($arg, $allowed, true)) {
            return;
        }
        $userId = (int) $actor['telegram_user_id'];

        // The owner may not have flags yet — ensureOwnerRow() already ran.
        Db::run("UPDATE telegram_admins SET {$arg} = 1 - {$arg} WHERE telegram_user_id = ?", [$userId]);

        self::cmdAlerts($chatId, $actor);
    }
}
