<?php
/**
 * Thin Telegram Bot API client (cURL, no dependencies).
 */
declare(strict_types=1);

final class Telegram
{
    private static function token(): string
    {
        return (string) Config::get('telegram.bot_token', '');
    }

    public static function enabled(): bool
    {
        $t = self::token();
        return (bool) Config::get('telegram.enabled', true)
            && $t !== ''
            && !str_starts_with($t, 'CHANGE_ME');
    }

    public static function ownerId(): int
    {
        return (int) Config::get('telegram.owner_id', 0);
    }

    /** Raw API call. Returns the decoded `result`, or null on failure. */
    public static function call(string $method, array $params = [], int $timeout = 20): mixed
    {
        if (!self::enabled()) {
            return null;
        }
        $url = 'https://api.telegram.org/bot' . self::token() . '/' . $method;

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $params,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        $body = curl_exec($ch);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($body === false) {
            Logger::error('telegram_curl_failed', ['method' => $method, 'err' => $err]);
            return null;
        }
        $json = json_decode((string) $body, true);
        if (!is_array($json) || ($json['ok'] ?? false) !== true) {
            Logger::warn('telegram_api_error', [
                'method' => $method,
                'desc'   => $json['description'] ?? 'unknown',
            ]);
            return null;
        }
        return $json['result'] ?? true;
    }

    /** HTML-formatted message. Long text is split across messages. */
    public static function send(int $chatId, string $html, ?array $keyboard = null, bool $silent = false): mixed
    {
        $chunks = self::chunk($html, 3800);
        $last = null;
        foreach ($chunks as $i => $chunk) {
            $params = [
                'chat_id'    => $chatId,
                'text'       => $chunk,
                'parse_mode' => 'HTML',
                'link_preview_options' => json_encode(['is_disabled' => true]),
                'disable_notification' => $silent,
            ];
            // Attach the keyboard only to the final chunk.
            if ($keyboard !== null && $i === count($chunks) - 1) {
                $params['reply_markup'] = json_encode($keyboard);
            }
            $last = self::call('sendMessage', $params);
        }
        return $last;
    }

    public static function editText(int $chatId, int $messageId, string $html, ?array $keyboard = null): mixed
    {
        $params = [
            'chat_id'    => $chatId,
            'message_id' => $messageId,
            'text'       => mb_substr($html, 0, 3800),
            'parse_mode' => 'HTML',
        ];
        if ($keyboard !== null) {
            $params['reply_markup'] = json_encode($keyboard);
        }
        return self::call('editMessageText', $params);
    }

    public static function answerCallback(string $callbackId, string $text = '', bool $alert = false): void
    {
        self::call('answerCallbackQuery', [
            'callback_query_id' => $callbackId,
            'text'              => mb_substr($text, 0, 190),
            'show_alert'        => $alert,
        ], 10);
    }

    /** Uploads a file (used for backups). Bots are capped at 50 MB. */
    public static function sendDocument(int $chatId, string $path, string $caption = ''): bool
    {
        if (!self::enabled() || !is_file($path)) {
            return false;
        }
        $url = 'https://api.telegram.org/bot' . self::token() . '/sendDocument';
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => [
                'chat_id'    => $chatId,
                'caption'    => mb_substr($caption, 0, 1000),
                'parse_mode' => 'HTML',
                'document'   => new CURLFile($path, 'application/octet-stream', basename($path)),
            ],
            CURLOPT_TIMEOUT        => 300,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        $body = curl_exec($ch);
        curl_close($ch);

        $json = json_decode((string) $body, true);
        $ok = is_array($json) && ($json['ok'] ?? false) === true;
        if (!$ok) {
            Logger::error('telegram_send_document_failed', [
                'file' => basename($path),
                'desc' => $json['description'] ?? 'unknown',
            ]);
        }
        return $ok;
    }

    // ---- Webhook management ------------------------------------------

    public static function setWebhook(string $url, string $secret): mixed
    {
        return self::call('setWebhook', [
            'url'                  => $url,
            'secret_token'         => $secret,
            'max_connections'      => 20,
            'allowed_updates'      => json_encode(['message', 'callback_query']),
            'drop_pending_updates' => true,
        ]);
    }

    public static function deleteWebhook(): mixed
    {
        return self::call('deleteWebhook', ['drop_pending_updates' => false]);
    }

    public static function getUpdates(int $offset, int $timeout = 25): array
    {
        $r = self::call('getUpdates', [
            'offset'          => $offset,
            'timeout'         => $timeout,
            'allowed_updates' => json_encode(['message', 'callback_query']),
        ], $timeout + 10);
        return is_array($r) ? $r : [];
    }

    // ---- Helpers -----------------------------------------------------

    public static function esc(?string $s): string
    {
        return htmlspecialchars((string) $s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    /** @return string[] */
    private static function chunk(string $text, int $size): array
    {
        if (mb_strlen($text) <= $size) {
            return [$text];
        }
        $out   = [];
        $lines = explode("\n", $text);
        $buf   = '';
        foreach ($lines as $line) {
            if (mb_strlen($buf) + mb_strlen($line) + 1 > $size) {
                if ($buf !== '') {
                    $out[] = $buf;
                }
                $buf = mb_substr($line, 0, $size);
            } else {
                $buf .= ($buf === '' ? '' : "\n") . $line;
            }
        }
        if ($buf !== '') {
            $out[] = $buf;
        }
        return $out;
    }

    public static function inlineKeyboard(array $rows): array
    {
        return ['inline_keyboard' => $rows];
    }

    public static function btn(string $text, string $data): array
    {
        return ['text' => $text, 'callback_data' => mb_substr($data, 0, 64)];
    }
}
