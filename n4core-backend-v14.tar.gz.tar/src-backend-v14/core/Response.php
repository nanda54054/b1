<?php
/**
 * JSON responses + security headers.
 *
 * The response envelope is IDENTICAL to v1 ({ok, data} / {ok, error}),
 * because the shipped Flutter app parses exactly that shape. Do not
 * change it.
 */
declare(strict_types=1);

final class Response
{
    private static bool $headersSent = false;

    public static function boot(): void
    {
        if (self::$headersSent) {
            return;
        }
        self::$headersSent = true;

        header('Content-Type: application/json; charset=utf-8');

        // ---- Hardening headers --------------------------------------
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('Referrer-Policy: no-referrer');
        header('Cross-Origin-Resource-Policy: same-site');
        header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
        header('Cache-Control: no-store, no-cache, must-revalidate, private');
        header('Pragma: no-cache');
        header_remove('X-Powered-By');

        if (Request::isHttps()) {
            header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
        }

        self::cors();

        if (Request::method() === 'OPTIONS') {
            http_response_code(204);
            exit;
        }
    }

    /**
     * CORS. The native Flutter client sends no Origin header and is never
     * affected. Browsers only get an allow header when the Origin is
     * explicitly whitelisted (or same-origin), so a random website cannot
     * drive the admin API with a victim's session.
     */
    private static function cors(): void
    {
        $origin = Request::header('Origin');
        if (!$origin) {
            return; // native app / server-to-server
        }

        $allowed = (array) Config::get('cors.allowed_origins', []);
        $host    = (string) ($_SERVER['HTTP_HOST'] ?? '');
        $scheme  = Request::isHttps() ? 'https' : 'http';
        $self    = $scheme . '://' . $host;

        $ok = in_array($origin, $allowed, true) || $origin === $self;
        if (!$ok) {
            return;
        }

        header('Access-Control-Allow-Origin: ' . $origin);
        header('Vary: Origin');
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, X-Admin-Token, X-Vip-Token, X-CSRF-Token, X-HTTP-Method-Override');
        header('Access-Control-Max-Age: 600');
    }

    public static function ok(mixed $data = [], int $code = 200): never
    {
        self::boot();
        http_response_code($code);
        echo json_encode(
            ['ok' => true, 'data' => $data],
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        );
        exit;
    }

    public static function error(string $message, int $code = 400, array $extra = []): never
    {
        self::boot();
        http_response_code($code);
        echo json_encode(
            ['ok' => false, 'error' => $message] + $extra,
            JSON_UNESCAPED_UNICODE
        );
        exit;
    }

    public static function methodNotAllowed(array $allowed = []): never
    {
        if ($allowed) {
            header('Allow: ' . implode(', ', $allowed));
        }
        self::error('Method not allowed', 405);
    }
}
