<?php
/**
 * VIP (end-user app) authentication.
 *
 * ⚠️  CONTRACT LOCK — the shipped Flutter app talks to these flows and
 * must NOT need a rebuild. Everything visible on the wire stays exactly
 * as v1:
 *   - header name              : X-Vip-Token
 *   - login error codes        : invalid_credentials | inactive | expired
 *                                | device_limit_reached
 *   - login response payload   : { token, expires_at, account{ username,
 *                                  plan_name, device_limit, expires_at } }
 *   - status response payload  : { valid, account{...} }
 * Only the storage and defence-in-depth behind it changed.
 */
declare(strict_types=1);

final class VipAuth
{
    /** Reads the token exactly like v1 did (header, then query fallback). */
    public static function tokenFromRequest(): ?string
    {
        $t = Request::header('X-Vip-Token');
        if ($t && trim($t) !== '') {
            return trim($t);
        }
        // v1 compatibility: the app only uses the header, but older builds
        // are documented to accept ?vip_token=, so keep it working.
        $q = Request::query('vip_token');
        return ($q !== null && trim($q) !== '') ? trim($q) : null;
    }

    /**
     * Resolves the current VIP session, or null.
     * Accepts both v2 hashed tokens and any leftover v1 plain-text rows,
     * so users who were logged in before the upgrade stay logged in.
     */
    public static function currentSession(): ?array
    {
        static $cached = false;
        static $value = null;
        if ($cached) {
            return $value;
        }
        $cached = true;

        $token = self::tokenFromRequest();
        if (!$token || strlen($token) < 16) {
            return $value = null;
        }

        $hash = Crypto::hashToken($token);

        $row = Db::one(
            'SELECT s.id AS session_id, s.device_id, s.expires_at, s.revoked_at, s.token,
                    v.id, v.username, v.plan_name, v.device_limit, v.is_active,
                    v.expires_at AS account_expires_at
             FROM vip_sessions s
             JOIN vip_accounts v ON v.id = s.account_id
             WHERE s.token_hash = ?
             LIMIT 1',
            [$hash]
        );

        // Legacy plain-token row (pre-migration): accept once, then upgrade
        // it in place to a hash so the plain value stops being stored.
        if (!$row) {
            $row = Db::one(
                'SELECT s.id AS session_id, s.device_id, s.expires_at, s.revoked_at, s.token,
                        v.id, v.username, v.plan_name, v.device_limit, v.is_active,
                        v.expires_at AS account_expires_at
                 FROM vip_sessions s
                 JOIN vip_accounts v ON v.id = s.account_id
                 WHERE s.token = ?
                 LIMIT 1',
                [$token]
            );
            if ($row) {
                try {
                    Db::run(
                        'UPDATE vip_sessions SET token_hash = ?, token = NULL WHERE id = ?',
                        [$hash, $row['session_id']]
                    );
                } catch (Throwable) {
                    // duplicate hash: harmless
                }
            }
        }

        if (!$row) {
            return $value = null;
        }
        if ($row['revoked_at'] !== null) {
            return $value = null;
        }
        if (strtotime((string) $row['expires_at']) < time()) {
            return $value = null;
        }
        if (!(int) $row['is_active']) {
            return $value = null;
        }
        if (strtotime((string) $row['account_expires_at']) < time()) {
            return $value = null;
        }

        // Touch last_seen (cheap, throttled by the WHERE clause).
        try {
            Db::run(
                'UPDATE vip_sessions SET last_seen_at = NOW(), ip = ?
                 WHERE id = ? AND last_seen_at < DATE_SUB(NOW(), INTERVAL 5 MINUTE)',
                [Request::ip(), $row['session_id']]
            );
        } catch (Throwable) {
        }

        return $value = $row;
    }

    /**
     * Login. Mirrors v1 semantics/error codes exactly.
     * @return array the `data` payload to hand back to the app
     */
    public static function login(string $username, string $accessCode, string $deviceId, ?string $deviceLabel): array
    {
        $ip = Request::ip();
        RateLimiter::hit('vip_login', $ip);

        $username   = mb_substr(trim($username), 0, 64);
        $accessCode = mb_substr(trim($accessCode), 0, 64);
        $deviceId   = mb_substr(trim($deviceId), 0, 128);

        if ($username === '' || $accessCode === '' || $deviceId === '') {
            Response::error('invalid_credentials', 401);
        }

        $account = Db::one('SELECT * FROM vip_accounts WHERE username = ?', [$username]);

        if (!$account) {
            // Burn a comparable amount of time so a missing user is not
            // distinguishable from a wrong code by response latency.
            Crypto::verifySecret($accessCode, '$2y$10$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvalidinv');
            self::recordFailure(null, $username, 'no_such_user');
            Response::error('invalid_credentials', 401);
        }

        // Per-account lockout (stops code-guessing against one username).
        if (!empty($account['locked_until']) && strtotime((string) $account['locked_until']) > time()) {
            self::recordFailure($account['id'], $username, 'locked');
            Response::error('invalid_credentials', 401);
        }

        if (!self::verifyAccessCode($account, $accessCode)) {
            $attempts = (int) ($account['failed_attempts'] ?? 0) + 1;
            $max      = (int) Config::get('security.vip_max_attempts', 10);
            $lockMin  = (int) Config::get('security.vip_lock_minutes', 30);
            if ($attempts >= $max) {
                Db::run(
                    'UPDATE vip_accounts SET failed_attempts = ?, locked_until = DATE_ADD(NOW(), INTERVAL ? MINUTE) WHERE id = ?',
                    [$attempts, $lockMin, $account['id']]
                );
            } else {
                Db::run('UPDATE vip_accounts SET failed_attempts = ? WHERE id = ?', [$attempts, $account['id']]);
            }
            self::recordFailure($account['id'], $username, 'bad_code');
            Response::error('invalid_credentials', 401);
        }

        if (!(int) $account['is_active']) {
            Response::error('inactive', 403);
        }
        if (strtotime((string) $account['expires_at']) < time()) {
            Response::error('expired', 403);
        }

        // ---- Device binding (unchanged rules) -----------------------
        $existing = Db::one(
            'SELECT id FROM vip_devices WHERE account_id = ? AND device_id = ?',
            [$account['id'], $deviceId]
        );

        if (!$existing) {
            $count = (int) Db::value('SELECT COUNT(*) FROM vip_devices WHERE account_id = ?', [$account['id']]);
            if ($count >= (int) $account['device_limit']) {
                Response::error('device_limit_reached', 403);
            }
            Db::run(
                'INSERT INTO vip_devices (account_id, device_id, device_label, last_ip) VALUES (?, ?, ?, ?)',
                [$account['id'], $deviceId, $deviceLabel !== null ? mb_substr($deviceLabel, 0, 100) : null, $ip]
            );
        } else {
            Db::run(
                'UPDATE vip_devices SET last_seen_at = NOW(), last_ip = ? WHERE id = ?',
                [$ip, $existing['id']]
            );
        }

        // ---- Issue token --------------------------------------------
        $token     = Crypto::token(32);
        $hours     = (int) Config::get('security.vip_session_hours', 720);
        $expiresAt = date('Y-m-d H:i:s', time() + $hours * 3600);
        if (strtotime((string) $account['expires_at']) < strtotime($expiresAt)) {
            $expiresAt = (string) $account['expires_at'];
        }

        // One live session per device: revoke older ones for this device.
        Db::run(
            'UPDATE vip_sessions SET revoked_at = NOW()
             WHERE account_id = ? AND device_id = ? AND revoked_at IS NULL',
            [$account['id'], $deviceId]
        );

        Db::run(
            'INSERT INTO vip_sessions (account_id, device_id, token_hash, ip, expires_at)
             VALUES (?, ?, ?, ?, ?)',
            [$account['id'], $deviceId, Crypto::hashToken($token), $ip, $expiresAt]
        );

        Db::run(
            'UPDATE vip_accounts SET failed_attempts = 0, locked_until = NULL, last_login_at = NOW() WHERE id = ?',
            [$account['id']]
        );

        RateLimiter::clear('vip_login', $ip);
        Auth::recordLogin('vip_success', $username, null, null);

        // EXACT v1 response shape.
        return [
            'token'      => $token,
            'expires_at' => $expiresAt,
            'account'    => [
                'username'     => $account['username'],
                'plan_name'    => $account['plan_name'],
                'device_limit' => (int) $account['device_limit'],
                'expires_at'   => $account['expires_at'],
            ],
        ];
    }

    /**
     * Verifies the code against the hashed column, falling back to the
     * legacy plain column (and upgrading it on the fly) so a v1 database
     * keeps working before/while bin/migrate.php runs.
     */
    private static function verifyAccessCode(array $account, string $code): bool
    {
        $hash = (string) ($account['access_code_hash'] ?? '');
        if ($hash !== '') {
            return Crypto::verifySecret($code, $hash);
        }

        $plain = (string) ($account['access_code'] ?? '');
        if ($plain !== '' && Crypto::equals($plain, $code)) {
            // Upgrade this row to hashed + encrypted storage now.
            try {
                Db::run(
                    'UPDATE vip_accounts
                     SET access_code_hash = ?, access_code_enc = ?, access_code = ?
                     WHERE id = ?',
                    [Crypto::hashSecret($code), Crypto::encrypt($code), '', $account['id']]
                );
            } catch (Throwable $e) {
                Logger::error('vip_code_upgrade_failed', ['msg' => $e->getMessage()]);
            }
            return true;
        }

        return false;
    }

    public static function logout(): void
    {
        $token = self::tokenFromRequest();
        if (!$token) {
            return;
        }
        // Revoke by hash, and clean any legacy plain row.
        Db::run(
            'UPDATE vip_sessions SET revoked_at = NOW() WHERE token_hash = ? AND revoked_at IS NULL',
            [Crypto::hashToken($token)]
        );
        Db::run('DELETE FROM vip_sessions WHERE token = ?', [$token]);
    }

    private static function recordFailure(?string $accountId, string $username, string $reason): void
    {
        Auth::recordLogin('vip_failed', $username, null, $reason);
    }

    public static function pruneSessions(): int
    {
        try {
            return Db::run(
                'DELETE FROM vip_sessions
                 WHERE expires_at < DATE_SUB(NOW(), INTERVAL 7 DAY)
                    OR (revoked_at IS NOT NULL AND revoked_at < DATE_SUB(NOW(), INTERVAL 7 DAY))'
            );
        } catch (Throwable) {
            return 0;
        }
    }
}
