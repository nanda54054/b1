<?php
/**
 * Config loader — reads config/config.php once and exposes dot-path
 * lookups. Also merges the DB-backed `settings` table for values the
 * dashboard is allowed to change at runtime.
 */
declare(strict_types=1);

final class Config
{
    private static ?array $data = null;
    private static array $dbSettings = [];
    private static bool $dbLoaded = false;

    public static function boot(): void
    {
        if (self::$data !== null) {
            return;
        }

        $file = __DIR__ . '/../config/config.php';
        if (!is_file($file)) {
            self::fail(
                'Backend is not configured yet. Copy config/config.sample.php '
                . 'to config/config.php and fill in your values.'
            );
        }

        /** @noinspection PhpIncludeInspection */
        $data = require $file;
        if (!is_array($data)) {
            self::fail('config/config.php must return an array.');
        }
        self::$data = $data;

        // Refuse to run with sample secrets in place — a misconfigured
        // deploy is a security incident, not a warning.
        foreach (['security.app_secret', 'security.encryption_key', 'security.pepper'] as $k) {
            $v = (string) self::get($k, '');
            if ($v === '' || str_starts_with($v, 'CHANGE_ME')) {
                self::fail('Backend secrets are not set. Run: php bin/keygen.php');
            }
        }

        date_default_timezone_set((string) self::get('app.timezone', 'Asia/Yangon'));
    }

    /** Dot-path getter: Config::get('db.host') */
    public static function get(string $path, mixed $default = null): mixed
    {
        self::boot();
        $node = self::$data;
        foreach (explode('.', $path) as $part) {
            if (!is_array($node) || !array_key_exists($part, $node)) {
                return $default;
            }
            $node = $node[$part];
        }
        return $node;
    }

    /**
     * Runtime setting from the `settings` table (dashboard-editable),
     * falling back to $default. Cached per request.
     */
    public static function setting(string $key, mixed $default = null): mixed
    {
        if (!self::$dbLoaded) {
            self::$dbLoaded = true;
            try {
                $rows = Db::pdo()->query('SELECT skey, svalue FROM settings')->fetchAll();
                foreach ($rows as $r) {
                    self::$dbSettings[$r['skey']] = $r['svalue'];
                }
            } catch (Throwable) {
                // settings table missing (pre-migration) — ignore
            }
        }
        return self::$dbSettings[$key] ?? $default;
    }

    public static function settingBool(string $key, bool $default = false): bool
    {
        $v = self::setting($key, $default ? '1' : '0');
        return $v === '1' || $v === 1 || $v === true || $v === 'true';
    }

    public static function putSetting(string $key, string $value): void
    {
        $st = Db::pdo()->prepare(
            'INSERT INTO settings (skey, svalue) VALUES (?, ?)
             ON DUPLICATE KEY UPDATE svalue = VALUES(svalue)'
        );
        $st->execute([$key, $value]);
        self::$dbSettings[$key] = $value;
    }

    public static function storagePath(string $sub = ''): string
    {
        $base = (string) self::get('paths.storage', __DIR__ . '/../storage');
        $base = rtrim($base, '/');
        return $sub === '' ? $base : $base . '/' . ltrim($sub, '/');
    }

    private static function fail(string $msg): never
    {
        if (PHP_SAPI === 'cli') {
            fwrite(STDERR, "[config] $msg\n");
            exit(1);
        }
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode(['ok' => false, 'error' => $msg]);
        exit;
    }
}
