<?php
/**
 * Universal VPN config / share-link parser.
 *
 * Paste ANY of these into the dashboard's "Add Server" box and the form
 * auto-fills Region, Protocol, Address/IP, Port (plus transport, TLS, SNI
 * and a suggested name):
 *
 *   vmess://<base64 json>                 (v2rayN format)
 *   vmess://<base64 of vmess://...>       (double-encoded, seen in the wild)
 *   vless://uuid@host:port?...#name
 *   trojan://pass@host:port?...#name
 *   trojan-go://...
 *   ss://<base64 method:pass>@host:port#name
 *   ss://<base64 of whole userinfo@host:port>#name   (legacy SIP002)
 *   ssr://<base64 ...>
 *   socks://[user:pass@]host:port#name  /  socks5://...
 *   http(s)://user:pass@host:port         (proxy form)
 *   hysteria://, hysteria2://, hy2://, tuic://   (address/port extracted)
 *   [Interface]/[Peer] WireGuard .conf text
 *   raw "host:port" or bare IP
 *   Xray/V2Ray JSON outbound config
 *
 * The parser is deliberately tolerant: if it can find a host and a port it
 * returns them, and it never throws. The ORIGINAL text is always kept
 * verbatim as raw_config, because that is what the Flutter app feeds to
 * Xray-core / WireGuard — the parsed fields are metadata for the panel.
 */
declare(strict_types=1);

final class ConfigParser
{
    /** Protocols the DB enum accepts. */
    public const DB_PROTOCOLS = ['vmess', 'vless', 'trojan', 'shadowsocks', 'socks', 'wireguard'];

    /**
     * @return array{
     *   ok:bool, protocol:string, address:string, port:int, name:string,
     *   network:?string, security:?string, sni:?string, country_code:?string,
     *   region_hint:?string, meta:array, warnings:string[]
     * }
     */
    public static function parse(string $raw): array
    {
        $raw = trim($raw);
        $out = self::blank();

        if ($raw === '') {
            $out['warnings'][] = 'Empty input';
            return $out;
        }

        // Users often paste several links at once — parse the first line
        // that looks like a link, but tell them about the rest.
        $lines = preg_split('/\r\n|\r|\n/', $raw) ?: [];
        $isWireguard = self::looksLikeWireGuard($raw);
        if (!$isWireguard && count($lines) > 1) {
            $links = array_values(array_filter(array_map('trim', $lines), fn($l) => $l !== '' && self::looksLikeLink($l)));
            if (count($links) > 1) {
                $out['warnings'][] = count($links) . ' links detected — use "Bulk Import" to add them all.';
            }
            if ($links) {
                $raw = $links[0];
            }
        }

        try {
            if ($isWireguard) {
                // NOTE: fall through to the shared region/ok pass below —
                // returning here would skip country detection.
                $result = self::parseWireGuard($raw);
            } elseif (self::looksLikeJson($raw)) {
                $result = self::parseJsonConfig($raw);
            } else {
            $scheme = strtolower((string) parse_url($raw, PHP_URL_SCHEME));
            // parse_url fails on some malformed links; fall back to a prefix scan.
            if ($scheme === '') {
                if (preg_match('#^([a-z0-9\-]+)://#i', $raw, $m)) {
                    $scheme = strtolower($m[1]);
                }
            }

            $result = match ($scheme) {
                'vmess'                        => self::parseVmess($raw),
                'vless'                        => self::parseVless($raw),
                'trojan', 'trojan-go'          => self::parseTrojan($raw),
                'ss'                           => self::parseShadowsocks($raw),
                'ssr'                          => self::parseSsr($raw),
                'socks', 'socks5', 'socks4'    => self::parseSocks($raw),
                'http', 'https'                => self::parseHttpProxy($raw),
                'hysteria', 'hysteria2', 'hy2',
                'tuic', 'wg', 'wireguard'      => self::parseGenericUrl($raw, $scheme),
                default                        => self::parseHostPort($raw),
            };
            }
        } catch (Throwable $e) {
            Logger::warn('config_parse_error', ['msg' => $e->getMessage()]);
            $result = self::blank();
            $result['warnings'][] = 'Could not fully parse this config — please check the fields.';
        }

        // Region detection from the display name / SNI / host.
        $result = self::detectRegion($result);
        $result['ok'] = $result['address'] !== '' && $result['port'] > 0;
        if (!$result['ok'] && !$result['warnings']) {
            $result['warnings'][] = 'Address or port could not be detected.';
        }

        return $result;
    }

    // =================================================================
    // Per-protocol parsers
    // =================================================================

    private static function parseVmess(string $raw): array
    {
        $out = self::blank();
        $out['protocol'] = 'vmess';

        $payload = substr($raw, strlen('vmess://'));
        $payload = trim($payload);

        // Some providers double-encode: base64 whose content is another link.
        $decoded = self::b64($payload);
        if ($decoded !== null && stripos(ltrim($decoded), 'vmess://') === 0) {
            return self::parseVmess(trim($decoded));
        }

        // Standard v2rayN: base64(JSON)
        if ($decoded !== null && str_starts_with(ltrim($decoded), '{')) {
            $json = json_decode($decoded, true);
            if (is_array($json)) {
                $out['address']  = self::cleanHost((string) ($json['add'] ?? ''));
                $out['port']     = self::intPort($json['port'] ?? 0);
                $out['name']     = self::cleanName((string) ($json['ps'] ?? ''));
                $out['network']  = self::pickNetwork((string) ($json['net'] ?? 'tcp'));
                $tls             = strtolower((string) ($json['tls'] ?? ''));
                $out['security'] = $tls === '' ? 'none' : self::pickSecurity($tls);
                $out['sni']      = self::cleanHost((string) ($json['sni'] ?? $json['host'] ?? ''));
                $out['meta']     = [
                    'uuid_present' => !empty($json['id']),
                    'aid'          => $json['aid'] ?? null,
                    'scy'          => $json['scy'] ?? null,
                    'path'         => $json['path'] ?? null,
                    'host'         => $json['host'] ?? null,
                    'type'         => $json['type'] ?? null,
                    'alpn'         => $json['alpn'] ?? null,
                    'fp'           => $json['fp'] ?? null,
                ];
                return $out;
            }
        }

        // Non-standard: vmess://uuid@host:port?...  (VLESS-like layout)
        $u = self::parseUrlLoose($raw);
        if ($u) {
            $out['address']  = self::cleanHost($u['host'] ?? '');
            $out['port']     = self::intPort($u['port'] ?? 0);
            $out['name']     = self::cleanName($u['fragment'] ?? '');
            $q               = $u['query'] ?? [];
            $out['network']  = self::pickNetwork($q['type'] ?? $q['net'] ?? 'tcp');
            $out['security'] = self::pickSecurity($q['security'] ?? 'none');
            $out['sni']      = self::cleanHost($q['sni'] ?? $q['host'] ?? '');
            $out['meta']     = $q;
            return $out;
        }

        $out['warnings'][] = 'VMess link could not be decoded (not valid base64/JSON).';
        return $out;
    }

    private static function parseVless(string $raw): array
    {
        $out = self::blank();
        $out['protocol'] = 'vless';
        $u = self::parseUrlLoose($raw);
        if (!$u) {
            $out['warnings'][] = 'VLESS link is malformed.';
            return $out;
        }
        $q = $u['query'] ?? [];
        $out['address']  = self::cleanHost($u['host'] ?? '');
        $out['port']     = self::intPort($u['port'] ?? 0);
        $out['name']     = self::cleanName($u['fragment'] ?? '');
        $out['network']  = self::pickNetwork($q['type'] ?? 'tcp');
        $out['security'] = self::pickSecurity($q['security'] ?? 'none');
        $out['sni']      = self::cleanHost($q['sni'] ?? $q['host'] ?? '');
        $out['meta']     = self::transportMeta($q);
        return $out;
    }

    private static function parseTrojan(string $raw): array
    {
        $out = self::blank();
        $out['protocol'] = 'trojan';
        $u = self::parseUrlLoose($raw);
        if (!$u) {
            $out['warnings'][] = 'Trojan link is malformed.';
            return $out;
        }
        $q = $u['query'] ?? [];
        $out['address']  = self::cleanHost($u['host'] ?? '');
        $out['port']     = self::intPort($u['port'] ?? 443);
        $out['name']     = self::cleanName($u['fragment'] ?? '');
        $out['network']  = self::pickNetwork($q['type'] ?? 'tcp');
        // Trojan is TLS by definition unless explicitly overridden.
        $out['security'] = self::pickSecurity($q['security'] ?? 'tls');
        $out['sni']      = self::cleanHost($q['sni'] ?? $q['peer'] ?? $q['host'] ?? '');
        $out['meta']     = self::transportMeta($q);
        return $out;
    }

    private static function parseShadowsocks(string $raw): array
    {
        $out = self::blank();
        $out['protocol'] = 'shadowsocks';

        // Split off the #name fragment first (it may contain non-base64 chars).
        $name = '';
        $hashPos = strpos($raw, '#');
        if ($hashPos !== false) {
            $name = self::cleanName(substr($raw, $hashPos + 1));
            $raw  = substr($raw, 0, $hashPos);
        }
        $out['name'] = $name;

        $body = substr($raw, strlen('ss://'));
        $body = trim($body);

        // Strip plugin query if present
        $query = [];
        $qPos = strpos($body, '?');
        if ($qPos !== false) {
            parse_str(substr($body, $qPos + 1), $query);
            $body = substr($body, 0, $qPos);
        }

        if (str_contains($body, '@')) {
            // SIP002: base64(method:password)@host:port  (userinfo may be plain too)
            $atPos = strrpos($body, '@');
            $hostPart = substr($body, $atPos + 1);
            [$host, $port] = self::splitHostPort($hostPart);
            $out['address'] = $host;
            $out['port']    = $port;
            $userinfo = substr($body, 0, $atPos);
            $dec = self::b64($userinfo);
            if ($dec !== null && str_contains($dec, ':')) {
                $out['meta']['method'] = explode(':', $dec, 2)[0];
            } elseif (str_contains($userinfo, ':')) {
                $out['meta']['method'] = explode(':', $userinfo, 2)[0];
            }
        } else {
            // Legacy: base64(method:password@host:port)
            $dec = self::b64($body);
            if ($dec !== null && str_contains($dec, '@')) {
                $atPos = strrpos($dec, '@');
                [$host, $port] = self::splitHostPort(substr($dec, $atPos + 1));
                $out['address'] = $host;
                $out['port']    = $port;
                $creds = substr($dec, 0, $atPos);
                if (str_contains($creds, ':')) {
                    $out['meta']['method'] = explode(':', $creds, 2)[0];
                }
            } else {
                $out['warnings'][] = 'Shadowsocks link could not be decoded.';
            }
        }

        if (!empty($query['plugin'])) {
            $out['meta']['plugin'] = (string) $query['plugin'];
            if (str_contains((string) $query['plugin'], 'v2ray-plugin')) {
                $out['network'] = 'ws';
            }
        }
        $out['security'] = $out['security'] ?? 'none';
        return $out;
    }

    private static function parseSsr(string $raw): array
    {
        $out = self::blank();
        $out['protocol'] = 'shadowsocks';
        $body = substr($raw, strlen('ssr://'));
        $dec  = self::b64($body);
        if ($dec === null) {
            $out['warnings'][] = 'SSR link could not be decoded.';
            return $out;
        }
        // host:port:proto:method:obfs:base64pass/?params
        $main = explode('/?', $dec, 2)[0];
        $parts = explode(':', $main);
        if (count($parts) >= 2) {
            $out['address'] = self::cleanHost($parts[0]);
            $out['port']    = self::intPort($parts[1]);
        }
        if (isset($parts[3])) {
            $out['meta']['method'] = $parts[3];
        }
        if (isset($parts[4])) {
            $out['meta']['obfs'] = $parts[4];
        }
        if (isset(explode('/?', $dec, 2)[1])) {
            parse_str(explode('/?', $dec, 2)[1], $q);
            if (!empty($q['remarks'])) {
                $out['name'] = self::cleanName((string) (self::b64((string) $q['remarks']) ?? $q['remarks']));
            }
        }
        $out['warnings'][] = 'SSR is parsed for display only — confirm your app core supports it.';
        return $out;
    }

    private static function parseSocks(string $raw): array
    {
        $out = self::blank();
        $out['protocol'] = 'socks';
        $u = self::parseUrlLoose($raw);
        if ($u && !empty($u['host'])) {
            $out['address'] = self::cleanHost($u['host']);
            $out['port']    = self::intPort($u['port'] ?? 1080);
            $out['name']    = self::cleanName($u['fragment'] ?? '');
            $out['meta']['auth'] = !empty($u['user']);
            return $out;
        }
        // socks://base64(host:port) is also seen.
        $body = preg_replace('#^socks[45]?://#i', '', $raw) ?? '';
        $dec  = self::b64($body);
        if ($dec !== null) {
            [$h, $p] = self::splitHostPort($dec);
            $out['address'] = $h;
            $out['port']    = $p ?: 1080;
            return $out;
        }
        $out['warnings'][] = 'SOCKS link is malformed.';
        return $out;
    }

    private static function parseHttpProxy(string $raw): array
    {
        $out = self::blank();
        // A bare https:// URL is far more likely to be a subscription link
        // than a server, so say so instead of silently creating junk.
        $u = self::parseUrlLoose($raw);
        $out['protocol'] = 'socks';
        if ($u && !empty($u['host'])) {
            $out['address'] = self::cleanHost($u['host']);
            $out['port']    = self::intPort($u['port'] ?? (str_starts_with(strtolower($raw), 'https') ? 443 : 80));
            $out['name']    = self::cleanName($u['fragment'] ?? '');
        }
        $out['warnings'][] = 'This looks like an HTTP proxy or a subscription URL, not a VPN share-link. Use "Import from Subscription" if it is a subscription.';
        return $out;
    }

    private static function parseGenericUrl(string $raw, string $scheme): array
    {
        $out = self::blank();
        // Not in the app's protocol enum — map to the closest and warn.
        $out['protocol'] = in_array($scheme, ['wg', 'wireguard'], true) ? 'wireguard' : 'socks';
        $u = self::parseUrlLoose($raw);
        if ($u) {
            $out['address'] = self::cleanHost($u['host'] ?? '');
            $out['port']    = self::intPort($u['port'] ?? 443);
            $out['name']    = self::cleanName($u['fragment'] ?? '');
            $q = $u['query'] ?? [];
            $out['sni'] = self::cleanHost($q['sni'] ?? $q['peer'] ?? '');
            $out['meta'] = $q;
        }
        if (!in_array($scheme, ['wg', 'wireguard'], true)) {
            $out['warnings'][] = strtoupper($scheme) . ' is not supported by the app core (Xray/WireGuard only) — the address was extracted, but the app cannot connect to it.';
        }
        return $out;
    }

    private static function parseWireGuard(string $raw): array
    {
        $out = self::blank();
        $out['protocol'] = 'wireguard';
        $out['network']  = 'udp';
        $out['security'] = 'none';

        // Endpoint = host:port  (host may be IPv6 in brackets)
        if (preg_match('/^\s*Endpoint\s*=\s*(.+)$/im', $raw, $m)) {
            [$h, $p] = self::splitHostPort(trim($m[1]));
            $out['address'] = $h;
            $out['port']    = $p ?: 51820;
        }
        if (preg_match('/^\s*ListenPort\s*=\s*(\d+)/im', $raw, $m) && $out['port'] === 0) {
            $out['port'] = self::intPort($m[1]);
        }
        if (preg_match('/^\s*Address\s*=\s*([^\s,]+)/im', $raw, $m)) {
            $out['meta']['interface_address'] = trim($m[1]);
        }
        if (preg_match('/^\s*DNS\s*=\s*(.+)$/im', $raw, $m)) {
            $out['meta']['dns'] = trim($m[1]);
        }
        if (preg_match('/^\s*AllowedIPs\s*=\s*(.+)$/im', $raw, $m)) {
            $out['meta']['allowed_ips'] = trim($m[1]);
        }
        if (preg_match('/^\s*#\s*(.+)$/m', $raw, $m)) {
            $out['name'] = self::cleanName($m[1]);
        }
        $out['meta']['has_private_key'] = (bool) preg_match('/^\s*PrivateKey\s*=/im', $raw);
        $out['meta']['has_peer']        = (bool) preg_match('/\[Peer\]/i', $raw);

        if (!$out['meta']['has_private_key']) {
            $out['warnings'][] = 'No PrivateKey found in this WireGuard config — the app will not be able to connect.';
        }
        if ($out['address'] === '') {
            $out['warnings'][] = 'No Endpoint found in this WireGuard config.';
        }
        return $out;
    }

    private static function parseJsonConfig(string $raw): array
    {
        $out = self::blank();
        $json = json_decode($raw, true);
        if (!is_array($json)) {
            $out['warnings'][] = 'Invalid JSON.';
            return $out;
        }

        // Find the first outbound that has a server address.
        $candidates = [];
        if (isset($json['outbounds']) && is_array($json['outbounds'])) {
            $candidates = $json['outbounds'];
        } elseif (isset($json['outbound'])) {
            $candidates = [$json['outbound']];
        } else {
            $candidates = [$json];
        }

        foreach ($candidates as $ob) {
            if (!is_array($ob)) {
                continue;
            }
            $proto = strtolower((string) ($ob['protocol'] ?? ''));
            if (!in_array($proto, self::DB_PROTOCOLS, true)) {
                continue;
            }
            $vnext = $ob['settings']['vnext'][0]
                ?? $ob['settings']['servers'][0]
                ?? null;
            if (!is_array($vnext)) {
                continue;
            }
            $out['protocol'] = $proto;
            $out['address']  = self::cleanHost((string) ($vnext['address'] ?? ''));
            $out['port']     = self::intPort($vnext['port'] ?? 0);
            $stream          = $ob['streamSettings'] ?? [];
            $out['network']  = self::pickNetwork((string) ($stream['network'] ?? 'tcp'));
            $out['security'] = self::pickSecurity((string) ($stream['security'] ?? 'none'));
            $out['sni']      = self::cleanHost(
                (string) ($stream['tlsSettings']['serverName']
                    ?? $stream['realitySettings']['serverName'] ?? '')
            );
            $out['name']     = self::cleanName((string) ($ob['tag'] ?? ''));
            $out['meta']['source'] = 'json_outbound';
            return $out;
        }

        $out['warnings'][] = 'No usable outbound found in this JSON config.';
        return $out;
    }

    private static function parseHostPort(string $raw): array
    {
        $out = self::blank();
        $line = trim(explode("\n", $raw)[0]);
        [$h, $p] = self::splitHostPort($line);
        if ($h !== '') {
            $out['address'] = $h;
            $out['port']    = $p;
            $out['warnings'][] = 'Only an address/port was recognised — pick the protocol manually.';
        } else {
            $out['warnings'][] = 'Unrecognised config format.';
        }
        return $out;
    }

    // =================================================================
    // Region detection
    // =================================================================

    /** name/SNI/host -> country code, matched against the locations table. */
    private static function detectRegion(array $out): array
    {
        $haystack = strtolower(
            ($out['name'] ?? '') . ' ' . ($out['sni'] ?? '') . ' ' . ($out['address'] ?? '')
        );

        // 1. Flag emoji in the name is the strongest signal.
        if (preg_match('/[\x{1F1E6}-\x{1F1FF}]{2}/u', (string) ($out['name'] ?? ''), $m)) {
            $cc = self::flagToCode($m[0]);
            if ($cc !== null) {
                $out['country_code'] = $cc;
                $out['region_hint']  = 'flag emoji';
                return $out;
            }
        }

        // 2. Country name / common aliases / airport-ish codes.
        foreach (self::COUNTRY_HINTS as $code => $words) {
            foreach ($words as $w) {
                // Word-boundary match so "in" doesn't match "india" etc.
                if (preg_match('/(?<![a-z])' . preg_quote($w, '/') . '(?![a-z])/i', $haystack)) {
                    $out['country_code'] = $code;
                    $out['region_hint']  = $w;
                    return $out;
                }
            }
        }

        // 3. ccTLD of the hostname (…​.jp, .sg, .de)
        $host = (string) ($out['address'] ?? '');
        if ($host !== '' && !filter_var($host, FILTER_VALIDATE_IP)) {
            $tld = strtoupper((string) (array_slice(explode('.', $host), -1)[0] ?? ''));
            if (strlen($tld) === 2 && isset(self::COUNTRY_HINTS[$tld])) {
                $out['country_code'] = $tld;
                $out['region_hint']  = 'domain suffix .' . strtolower($tld);
            }
        }

        return $out;
    }

    private static function flagToCode(string $flag): ?string
    {
        $chars = preg_split('//u', $flag, -1, PREG_SPLIT_NO_EMPTY) ?: [];
        if (count($chars) !== 2) {
            return null;
        }
        $code = '';
        foreach ($chars as $ch) {
            $cp = self::codepoint($ch);
            if ($cp < 0x1F1E6 || $cp > 0x1F1FF) {
                return null;
            }
            $code .= chr($cp - 0x1F1E6 + ord('A'));
        }
        return $code;
    }

    private static function codepoint(string $char): int
    {
        $b = unpack('N', mb_convert_encoding($char, 'UCS-4BE', 'UTF-8'));
        return $b[1] ?? 0;
    }

    /** code => search words (lowercase). Order matters: longest first. */
    private const COUNTRY_HINTS = [
        'SG' => ['singapore', 'sgp', 'sing', 'sg'],
        'MM' => ['myanmar', 'burma', 'yangon', 'mandalay', 'mmr', 'mm'],
        'TH' => ['thailand', 'bangkok', 'thai', 'tha', 'bkk', 'th'],
        'JP' => ['japan', 'tokyo', 'osaka', 'jpn', 'nrt', 'jp'],
        'US' => ['united states', 'america', 'usa', 'losangeles', 'los angeles', 'newyork', 'new york', 'dallas', 'seattle', 'miami', 'chicago', 'us'],
        'GB' => ['united kingdom', 'england', 'london', 'britain', 'gbr', 'uk', 'gb'],
        'DE' => ['germany', 'frankfurt', 'berlin', 'deutschland', 'deu', 'fra', 'de'],
        'KR' => ['south korea', 'korea', 'seoul', 'kor', 'icn', 'kr'],
        'HK' => ['hong kong', 'hongkong', 'hkg', 'hk'],
        'TW' => ['taiwan', 'taipei', 'twn', 'tw'],
        'IN' => ['india', 'mumbai', 'delhi', 'chennai', 'ind', 'in'],
        'MY' => ['malaysia', 'kuala lumpur', 'kualalumpur', 'mys', 'my'],
        'VN' => ['vietnam', 'viet nam', 'hanoi', 'saigon', 'vnm', 'vn'],
        'ID' => ['indonesia', 'jakarta', 'idn', 'id'],
        'PH' => ['philippines', 'manila', 'phl', 'ph'],
        'CN' => ['china', 'shanghai', 'beijing', 'chn', 'cn'],
        'CA' => ['canada', 'toronto', 'montreal', 'vancouver', 'can', 'ca'],
        'AU' => ['australia', 'sydney', 'melbourne', 'aus', 'au'],
        'NL' => ['netherlands', 'amsterdam', 'holland', 'nld', 'ams', 'nl'],
        'FR' => ['france', 'paris', 'fra', 'fr'],
        'CH' => ['switzerland', 'zurich', 'geneva', 'che', 'ch'],
        'SE' => ['sweden', 'stockholm', 'swe', 'se'],
        'FI' => ['finland', 'helsinki', 'fin', 'fi'],
        'NO' => ['norway', 'oslo', 'nor', 'no'],
        'PL' => ['poland', 'warsaw', 'pol', 'pl'],
        'RU' => ['russia', 'moscow', 'rus', 'ru'],
        'TR' => ['turkey', 'turkiye', 'istanbul', 'tur', 'tr'],
        'AE' => ['united arab emirates', 'dubai', 'emirates', 'are', 'uae', 'ae'],
        'SA' => ['saudi', 'riyadh', 'sau', 'sa'],
        'BR' => ['brazil', 'sao paulo', 'saopaulo', 'bra', 'br'],
        'ZA' => ['south africa', 'johannesburg', 'zaf', 'za'],
        'IT' => ['italy', 'milan', 'rome', 'ita', 'it'],
        'ES' => ['spain', 'madrid', 'barcelona', 'esp', 'es'],
        'IE' => ['ireland', 'dublin', 'irl', 'ie'],
        'KH' => ['cambodia', 'phnom penh', 'khm', 'kh'],
        'LA' => ['laos', 'vientiane', 'lao'],
        'BD' => ['bangladesh', 'dhaka', 'bgd', 'bd'],
        'PK' => ['pakistan', 'karachi', 'lahore', 'pak', 'pk'],
        'NP' => ['nepal', 'kathmandu', 'npl', 'np'],
        'LK' => ['sri lanka', 'colombo', 'lka', 'lk'],
        'UA' => ['ukraine', 'kyiv', 'kiev', 'ukr', 'ua'],
        'AR' => ['argentina', 'buenos aires', 'arg', 'ar'],
        'MX' => ['mexico', 'mex', 'mx'],
        'IL' => ['israel', 'tel aviv', 'isr', 'il'],
        'NZ' => ['new zealand', 'auckland', 'nzl', 'nz'],
    ];

    // =================================================================
    // Utilities
    // =================================================================

    private static function blank(): array
    {
        return [
            'ok'           => false,
            'protocol'     => 'vmess',
            'address'      => '',
            'port'         => 0,
            'name'         => '',
            'network'      => null,
            'security'     => null,
            'sni'          => null,
            'country_code' => null,
            'region_hint'  => null,
            'meta'         => [],
            'warnings'     => [],
        ];
    }

    public static function looksLikeWireGuard(string $raw): bool
    {
        return (bool) preg_match('/\[Interface\]/i', $raw)
            || ((bool) preg_match('/^\s*PrivateKey\s*=/im', $raw)
                && (bool) preg_match('/^\s*(Endpoint|PublicKey)\s*=/im', $raw));
    }

    private static function looksLikeJson(string $raw): bool
    {
        $t = ltrim($raw);
        return str_starts_with($t, '{') || str_starts_with($t, '[');
    }

    public static function looksLikeLink(string $line): bool
    {
        return (bool) preg_match(
            '#^(vmess|vless|trojan|trojan-go|ss|ssr|socks[45]?|hysteria2?|hy2|tuic|wg|wireguard)://#i',
            trim($line)
        );
    }

    /** Tolerant base64 (URL-safe, missing padding, whitespace). */
    private static function b64(string $s): ?string
    {
        $s = trim($s);
        if ($s === '') {
            return null;
        }
        $s = strtr($s, '-_', '+/');
        $s = preg_replace('/\s+/', '', $s) ?? $s;
        $pad = strlen($s) % 4;
        if ($pad) {
            $s .= str_repeat('=', 4 - $pad);
        }
        $d = base64_decode($s, false);
        if ($d === false || $d === '') {
            return null;
        }
        // Reject binary noise — real payloads are text.
        if (!mb_check_encoding($d, 'UTF-8')) {
            return null;
        }
        return $d;
    }

    /**
     * parse_url() chokes on links whose userinfo contains unescaped
     * characters (very common in trojan/ss links), so do it by hand.
     * @return array{scheme:string,user:string,pass:string,host:string,port:int,path:string,query:array,fragment:string}|null
     */
    private static function parseUrlLoose(string $url): ?array
    {
        if (!preg_match('#^([a-z0-9\-]+)://(.*)$#is', trim($url), $m)) {
            return null;
        }
        $scheme = strtolower($m[1]);
        $rest   = $m[2];

        $fragment = '';
        if (($h = strpos($rest, '#')) !== false) {
            $fragment = rawurldecode(substr($rest, $h + 1));
            $rest     = substr($rest, 0, $h);
        }

        $query = [];
        if (($q = strpos($rest, '?')) !== false) {
            parse_str(substr($rest, $q + 1), $query);
            $rest = substr($rest, 0, $q);
        }

        $path = '';
        // Only treat "/" as a path separator after the authority.
        if (($s = strpos($rest, '/')) !== false) {
            $path = substr($rest, $s);
            $rest = substr($rest, 0, $s);
        }

        $user = '';
        $pass = '';
        if (($at = strrpos($rest, '@')) !== false) {
            $userinfo = substr($rest, 0, $at);
            $rest     = substr($rest, $at + 1);
            if (str_contains($userinfo, ':')) {
                [$user, $pass] = explode(':', $userinfo, 2);
            } else {
                $user = $userinfo;
            }
        }

        [$host, $port] = self::splitHostPort($rest);
        if ($host === '') {
            return null;
        }

        // Normalise query keys to lowercase strings.
        $q2 = [];
        foreach ($query as $k => $v) {
            $q2[strtolower((string) $k)] = is_scalar($v) ? (string) $v : '';
        }

        return [
            'scheme'   => $scheme,
            'user'     => rawurldecode($user),
            'pass'     => rawurldecode($pass),
            'host'     => $host,
            'port'     => $port,
            'path'     => $path,
            'query'    => $q2,
            'fragment' => $fragment,
        ];
    }

    /** Handles host:port, [v6]:port, bare host, bare [v6]. */
    private static function splitHostPort(string $s): array
    {
        $s = trim($s);
        if ($s === '') {
            return ['', 0];
        }
        // IPv6 in brackets
        if (str_starts_with($s, '[')) {
            $end = strpos($s, ']');
            if ($end !== false) {
                $host = substr($s, 1, $end - 1);
                $tail = substr($s, $end + 1);
                $port = 0;
                if (str_starts_with($tail, ':')) {
                    $port = self::intPort(substr($tail, 1));
                }
                return [self::cleanHost($host), $port];
            }
        }
        // Bare IPv6 without brackets (more than one colon and no port)
        if (substr_count($s, ':') > 1 && filter_var($s, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            return [self::cleanHost($s), 0];
        }
        if (($c = strrpos($s, ':')) !== false) {
            $host = substr($s, 0, $c);
            $port = self::intPort(substr($s, $c + 1));
            return [self::cleanHost($host), $port];
        }
        return [self::cleanHost($s), 0];
    }

    private static function cleanHost(string $h): string
    {
        $h = trim($h);
        $h = trim($h, "[]/\"' \t");
        $h = preg_replace('/[^A-Za-z0-9\.\-:_]/', '', $h) ?? '';
        return mb_substr($h, 0, 255);
    }

    private static function intPort(mixed $p): int
    {
        $n = (int) preg_replace('/\D/', '', (string) $p);
        return ($n >= 1 && $n <= 65535) ? $n : 0;
    }

    private static function cleanName(string $n): string
    {
        $n = rawurldecode(trim($n));
        $n = preg_replace('/[\x00-\x1F\x7F]/u', '', $n) ?? '';
        return mb_substr(trim($n), 0, 100);
    }

    private static function pickNetwork(string $n): string
    {
        $n = strtolower(trim($n));
        return match ($n) {
            'ws', 'websocket'        => 'ws',
            'grpc', 'gun'            => 'grpc',
            'h2', 'http', 'httpupgrade' => 'h2',
            'kcp', 'mkcp'            => 'kcp',
            'quic'                   => 'quic',
            'xhttp', 'splithttp'     => 'xhttp',
            ''                       => 'tcp',
            default                  => 'tcp',
        };
    }

    private static function pickSecurity(string $s): string
    {
        $s = strtolower(trim($s));
        return match ($s) {
            'tls', '1', 'true' => 'tls',
            'reality'          => 'reality',
            'xtls'             => 'xtls',
            ''                 => 'none',
            default            => in_array($s, ['none', '0', 'false'], true) ? 'none' : $s,
        };
    }

    private static function transportMeta(array $q): array
    {
        $keep = ['type', 'security', 'sni', 'host', 'path', 'serviceName', 'servicename',
                 'alpn', 'fp', 'flow', 'pbk', 'sid', 'spx', 'headerType', 'headertype',
                 'seed', 'mode', 'encryption', 'allowInsecure', 'allowinsecure'];
        $out = [];
        foreach ($q as $k => $v) {
            if (in_array((string) $k, $keep, true) || in_array(strtolower((string) $k), array_map('strtolower', $keep), true)) {
                $out[(string) $k] = mb_substr((string) $v, 0, 200);
            }
        }
        return $out;
    }

    /**
     * Splits a pasted blob (or a decoded subscription body) into
     * individual links for bulk import.
     * @return string[]
     */
    public static function splitLinks(string $blob): array
    {
        $blob = trim($blob);
        if ($blob === '') {
            return [];
        }

        // A whole-body base64 subscription decodes to a newline list.
        if (!self::looksLikeLink($blob) && !self::looksLikeWireGuard($blob) && !self::looksLikeJson($blob)) {
            $dec = self::b64($blob);
            if ($dec !== null && (str_contains($dec, '://'))) {
                $blob = $dec;
            }
        }

        // NOTE: the ":\/\/" must stay escaped — an unescaped "//" would close
        // the pattern delimiter and produce "Unknown modifier '/'".
        $pattern = '~\r\n|\r|\n|\s+(?=(?:vmess|vless|trojan|ss|ssr|socks5?|https?|hysteria2?|hy2|tuic)://)~i';
        $lines   = preg_split($pattern, $blob) ?: [];
        $out = [];
        foreach ($lines as $l) {
            $l = trim($l);
            if ($l !== '' && self::looksLikeLink($l)) {
                $out[] = $l;
            }
        }
        return $out;
    }
}
