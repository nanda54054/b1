<?php
/**
 * Per-device request authentication for the end-user app.
 *
 * =====================================================================
 * WHY THIS FILE EXISTS
 * =====================================================================
 *
 * Before it, every /api/public/ endpoint answered anyone:
 *
 *     curl https://core.nandaxr.tech/api/public/servers.php
 *     → 200, 12 KB of JSON, every free-tier vless:// config in full
 *
 * Those paste straight into V2rayNG. Nobody had to modify the app to take
 * the servers — the URL is a plain string inside any APK. And because there
 * was no per-caller identity, there was nothing to ban except an IP.
 *
 * =====================================================================
 * WHAT IT DOES
 * =====================================================================
 *
 * Registration, once per install:
 *
 *     POST /api/public/register_device.php
 *       { device_id, timestamp, signature, integrity{...}, ... }
 *       signature = HMAC(device_id\ntimestamp\ncert, registration_key)
 *     → { device_secret }
 *
 * Every later request:
 *
 *     X-Device-Id, X-Timestamp, X-Nonce, X-Sig
 *     X-Sig = HMAC-SHA256(canonical, device_secret)
 *     canonical = METHOD\npath\nsortedQuery\nsha256(body)\ntimestamp\nnonce
 *
 * =====================================================================
 * THE ANTI-TAMPER PART — HOW A RE-SIGNED APK IS REFUSED
 * =====================================================================
 *
 * The registration key is NOT the bare bootstrap secret. It is:
 *
 *     HMAC-SHA256(key: app_bootstrap_secret, message: <signing cert sha256>)
 *
 * The app reads its own certificate at runtime and derives the same value.
 *
 *  - Genuine APK  → our certificate → correct key → registers.
 *  - Modified APK → Android forces a re-sign → different certificate →
 *                   different key → signature does not verify → 401.
 *
 * The property that matters: **there is no boolean on the phone to flip.**
 * A client-side `if (tampered) exit()` is one smali branch and MT Manager
 * deletes it in seconds. Here the certificate is an *input to the HMAC*, and
 * the verification happens on this server. Patching the app cannot forge a
 * credential only the server can issue; a patched build simply fails to
 * register and receives no configs.
 *
 * `expected_cert_sha256` in config is additionally compared directly, so a
 * mismatch is recorded with a precise reason even when the derivation is
 * disabled during rollout.
 *
 * =====================================================================
 * HONEST LIMITS — read before trusting this too far
 * =====================================================================
 *
 * The certificate hash is a public value: it can be read out of the genuine
 * APK. A skilled attacker can therefore hardcode it back into a modified
 * build and derive the right key again. This is a real limitation, not a
 * theoretical one.
 *
 * What it still buys, which is substantial:
 *
 *   Before : one curl command, 2 minutes, zero skill
 *   After  : unpack APK, recover the cert hash and bootstrap secret from
 *            obfuscated AOT ARM, reimplement the HMAC canonicalisation
 *            exactly, and keep a device id that can be banned the moment
 *            it misbehaves
 *
 * And the config still has to reach the VPN core as plaintext, so a rooted
 * phone can always read it out of the running process. No client-side
 * measure closes that, which is precisely why the durable defence is
 * attribution and banning (see `banned`, `req_count`, `integrity_flags`)
 * rather than pretending the payload can be hidden.
 */
declare(strict_types=1);

final class DeviceAuth
{
    /** Accepted clock difference, in seconds, between phone and server. */
    private const SKEW = 300;

    /** How long a nonce is remembered for replay detection. */
    private const NONCE_TTL = 3600;

    private static bool $resolved = false;
    private static ?array $device = null;

    // =================================================================
    // Toggle
    // =================================================================

    /**
     * Master switch, so enforcement can be rolled out safely.
     *
     * Turning this on before enough users have upgraded would lock out
     * everyone still running an older build, so the intended sequence is:
     * deploy this code with the flag OFF, ship the app update, watch
     * `app_devices` fill up, then switch it ON.
     */
    public static function enabled(): bool
    {
        return (bool) Config::get('security.require_device_auth', false);
    }

    // =================================================================
    // Registration
    // =================================================================

    /**
     * The key the app must have signed its registration with.
     *
     * @param string $certHash lowercase hex sha256 of the APK signing cert,
     *                         or '' when the client could not report one
     */
    private static function registrationKey(string $certHash): string
    {
        $bootstrap = (string) Config::get('security.app_bootstrap_secret', '');
        if ($certHash === '') {
            // Client had no certificate to report (browser preview, an OEM
            // ROM that refuses). Accept the bare secret so those builds still
            // work; the row records that it happened.
            return $bootstrap;
        }
        return hash_hmac('sha256', $certHash, $bootstrap);
    }

    /**
     * Every signing certificate this deployment accepts, lowercase hex.
     *
     * Accepts either shape in config so an existing single-channel install
     * needs no edit:
     *
     *   'expected_cert_sha256' => 'a9f7…'                 // one channel
     *   'expected_cert_sha256' => ['a9f7…', '3b21…']      // Play + direct
     *
     * Malformed entries are dropped rather than trusted: a typo'd pin that
     * silently matched nothing would disable the check without saying so.
     *
     * @return list<string>
     */
    private static function expectedCerts(): array
    {
        $raw = Config::get('security.expected_cert_sha256', '');
        $list = is_array($raw) ? $raw : [$raw];

        $out = [];
        foreach ($list as $c) {
            $c = strtolower(trim((string) $c));
            if (preg_match('/^[0-9a-f]{64}$/', $c) === 1) {
                $out[] = $c;
            }
        }
        return array_values(array_unique($out));
    }

    /**
     * Constant-time membership test against the accepted certificate set.
     *
     * Every entry is compared even after a match so the running time does not
     * reveal which position matched, or how many pins are configured.
     *
     * @param list<string> $expected
     */
    private static function certAccepted(string $certHash, array $expected): bool
    {
        $ok = false;
        foreach ($expected as $c) {
            $ok = hash_equals($c, $certHash) || $ok;
        }
        return $ok;
    }

    /**
     * Issues (or rotates) a device secret.
     *
     * @return string the plaintext secret — returned to the client exactly
     *                once and never stored in that form
     */
    public static function register(array $body): string
    {
        $ip = Request::ip();
        RateLimiter::hit('device_reg', $ip);

        $bootstrap = (string) Config::get('security.app_bootstrap_secret', '');
        if ($bootstrap === '' || str_starts_with($bootstrap, 'CHANGE_ME')) {
            // Misconfiguration, not a client error. Fail loudly in the log so
            // it is caught during deployment rather than silently accepting
            // everyone.
            Logger::error('device_register_misconfigured', [
                'msg' => 'security.app_bootstrap_secret is not set',
            ]);
            Response::error('server_misconfigured', 500);
        }

        $deviceId  = Request::str($body, 'device_id', 128);
        $timestamp = Request::int($body, 'timestamp', 0);
        $signature = Request::str($body, 'signature', 128);
        $appVer    = Request::str($body, 'app_version', 32);
        $platform  = Request::str($body, 'platform', 16);
        $model     = Request::str($body, 'model', 64);
        $osVersion = Request::str($body, 'os_version', 32);

        $integrity = is_array($body['integrity'] ?? null) ? $body['integrity'] : [];
        $certHash  = strtolower(Request::str($integrity, 'cert_sha256', 64));

        // The IP bucket above is trivially defeated by rotating through a
        // proxy pool, so registration is limited on two further axes that an
        // attacker cannot rotate as cheaply:
        //
        //   device_reg_id     — per device_id, catching one identity being
        //                       re-minted over and over from many addresses
        //   device_reg_global — a server-wide circuit breaker, so a botnet
        //                       with fresh IPs *and* fresh device_ids still
        //                       cannot mint identities faster than real
        //                       installs plausibly arrive
        //
        // Both are checked only once the body has been parsed, because the
        // discriminators live in the body.
        if ($deviceId !== '') {
            RateLimiter::hit('device_reg_id', hash('sha256', $deviceId));
        }
        RateLimiter::hit('device_reg_global', 'all');

        if ($deviceId === '' || $signature === '') {
            Response::error('invalid_registration', 400);
        }

        // A device id is always a sha256 hex digest or a UUID from the
        // fallback path. Anything else is a hand-rolled client.
        if (!preg_match('/^[a-f0-9]{64}$/i', $deviceId) &&
            !preg_match('/^[a-f0-9\-]{32,36}$/i', $deviceId)) {
            Response::error('invalid_registration', 400);
        }

        if ($certHash !== '' && !preg_match('/^[a-f0-9]{64}$/', $certHash)) {
            Response::error('invalid_registration', 400);
        }

        if (abs(time() - $timestamp) > self::SKEW) {
            Response::error('clock_skew', 401);
        }

        // ---- Verify the registration signature ----------------------
        $expectedSig = hash_hmac(
            'sha256',
            $deviceId . "\n" . $timestamp . "\n" . $certHash,
            self::registrationKey($certHash)
        );

        if (!hash_equals($expectedSig, strtolower($signature))) {
            self::flagRejection($deviceId, $ip, 'bad_bootstrap_signature', $certHash);
            Response::error('invalid_signature', 401);
        }

        // ---- Pin the signing certificate ----------------------------
        //
        // Belt and braces alongside the key derivation above: an explicit
        // comparison so the audit trail says *why* a build was refused, and
        // so enforcement still works if the derivation is ever relaxed.
        //
        // A LIST, not a single value, because the app is distributed through
        // two channels that legitimately carry different certificates:
        //
        //   * Play Store  -> Google re-signs the AAB with their App Signing
        //                    key, so the phone reports Google's certificate.
        //   * Direct APK  -> signed locally, reports release-key.jks.
        //
        // Pinning only one of those would 401 every user of the other
        // channel. The set stays closed and small, so an attacker's own key
        // still matches nothing — the property that actually mattered.
        $expectedCerts = self::expectedCerts();
        if ($expectedCerts !== [] && $certHash !== '' && !self::certAccepted($certHash, $expectedCerts)) {
            self::flagRejection($deviceId, $ip, 'cert_mismatch', $certHash);
            // Guarded on purpose. `securityAlert()` only exists in the newer
            // Notifier.php, so deploying this file WITHOUT that one used to
            // raise "Call to undefined method" — a PHP fatal, which this
            // endpoint turns into HTTP 500. The app reads any non-200 here as
            // "could not verify itself with the server", so a partial deploy
            // took every device offline while the deploy script still
            // reported success.
            //
            // The alert is a notification, not a control: failing to send it
            // must never change whether a build is refused. Registration is
            // rejected below either way.
            if (method_exists('Notifier', 'securityAlert')) {
                try {
                    Notifier::securityAlert(
                        "🚨 <b>Modified app blocked</b>\n"
                        . "A re-signed build tried to register.\n"
                        . "Device: <code>" . htmlspecialchars(substr($deviceId, 0, 16), ENT_QUOTES) . "…</code>\n"
                        . "Cert: <code>" . htmlspecialchars(substr($certHash, 0, 16), ENT_QUOTES) . "…</code>\n"
                        . "IP: <code>" . htmlspecialchars($ip, ENT_QUOTES) . "</code>"
                    );
                } catch (Throwable) {
                    // Telegram down, token unset, network blocked — all
                    // irrelevant to the decision being made here.
                }
            }
            Response::error('invalid_signature', 401);
        }

        // A release build is never debuggable, and a debuggable one can be
        // read with `run-as` on an unrooted phone. Refuse it outright.
        if (!empty($integrity['debuggable'])) {
            self::flagRejection($deviceId, $ip, 'debuggable_build', $certHash);
            Response::error('invalid_signature', 401);
        }

        // ---- Issue the secret ---------------------------------------
        $secret = Crypto::token(32);

        // Root / Frida / cloning are recorded, NOT refused. They have
        // legitimate users who pay, and Magisk DenyList defeats detection
        // anyway — so blocking on them punishes honest customers while
        // barely inconveniencing an attacker. Stored so a human can act on
        // real evidence via the admin panel.
        $flags = json_encode([
            'rooted'       => !empty($integrity['rooted']),
            'instrumented' => !empty($integrity['instrumented']),
            'cloned'       => !empty($integrity['cloned']),
            'installer'    => (string) ($integrity['installer'] ?? ''),
            'signer_count' => (int) ($integrity['signer_count'] ?? 0),
        ], JSON_UNESCAPED_SLASHES);

        // ---- How the secret is stored, and why not as a hash --------
        //
        // Session tokens elsewhere in this codebase are stored as a one-way
        // keyed hash, which is correct for a bearer token: the server only
        // ever needs to compare.
        //
        // An HMAC key is different. To verify `HMAC(canonical, secret)` the
        // server must recompute it, which needs the secret ITSELF — a hash
        // of it is mathematically unusable here. So it is stored reversibly,
        // encrypted with AES-256-GCM under `security.encryption_key`
        // (Crypto::encrypt), exactly as VIP access codes already are.
        //
        // A stolen database dump therefore still yields nothing: the key
        // lives in config/config.php, which is outside the web root and
        // denied by .htaccess.
        Db::run(
            'INSERT INTO app_devices
                (device_id, secret_enc, cert_sha256, app_version, platform,
                 model, os_version, integrity_flags, last_ip, created_at, last_seen_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
             ON DUPLICATE KEY UPDATE
                secret_enc      = VALUES(secret_enc),
                cert_sha256     = VALUES(cert_sha256),
                app_version     = VALUES(app_version),
                model           = VALUES(model),
                os_version      = VALUES(os_version),
                integrity_flags = VALUES(integrity_flags),
                last_ip         = VALUES(last_ip),
                last_seen_at    = NOW()',
            [
                $deviceId,
                Crypto::encrypt($secret),
                $certHash !== '' ? $certHash : null,
                $appVer !== '' ? $appVer : null,
                $platform !== '' ? $platform : 'android',
                $model !== '' ? $model : null,
                $osVersion !== '' ? $osVersion : null,
                $flags,
                $ip,
            ]
        );

        // ---- Clear the registration buckets on success ------------------
        //
        // The three limiters above are counted BEFORE the outcome is known,
        // which is correct — an attacker's failures have to be counted too.
        // But nothing ever cleared them, so a run of failures that the
        // OPERATOR caused (a schema fault, a partial deploy, a bad secret)
        // stayed on the clock for a full hour after the fault was fixed:
        //
        //     device_reg     limit 5/hour   block 3600s
        //     device_reg_id  limit 8/hour   block 3600s
        //
        // A phone that retried a handful of times during an outage is then
        // locked out long after the server is healthy, and the app reports
        // the same "could not verify itself" as the original fault — so the
        // fix looks like it did not work. Exactly what happened here.
        //
        // Clearing only on SUCCESS keeps the protection intact: an attacker
        // never reaches this line, because it sits after signature
        // verification, the certificate pin and the INSERT. A device that
        // genuinely registered has proved it holds the bootstrap secret, so
        // its failed attempts carry no further information.
        //
        // `device_reg_global` is deliberately NOT cleared: it is a
        // server-wide breaker measuring total mint rate, and one legitimate
        // registration says nothing about the other 199.
        try {
            RateLimiter::clear('device_reg', $ip);
            RateLimiter::clear('device_reg_id', hash('sha256', $deviceId));
        } catch (Throwable) {
            // Housekeeping only — a limiter fault must never fail a
            // registration that has already been written.
        }

        return $secret;
    }

    /** Records a refused registration so patterns are visible later. */
    private static function flagRejection(
        string $deviceId,
        string $ip,
        string $reason,
        string $certHash
    ): void {
        try {
            Logger::warn('device_register_rejected', [
                'device' => substr($deviceId, 0, 24),
                'ip'     => $ip,
                'reason' => $reason,
                'cert'   => substr($certHash, 0, 24),
            ]);
            Audit::log(
                'device.rejected',
                'app_device',
                null,
                ['reason' => $reason, 'cert' => substr($certHash, 0, 24)],
                'system',
                null,
                $ip
            );
        } catch (Throwable) {
            // Never let logging break the rejection path.
        }
    }

    // =================================================================
    // Per-request verification
    // =================================================================

    /**
     * Enforces device authentication, or terminates the request.
     *
     * Call immediately after `guard_maintenance()` in every public endpoint.
     */
    public static function require(): void
    {
        if (!self::enabled()) {
            // Still resolve opportunistically so `req_count` and `last_seen`
            // populate during the rollout window and the operator can watch
            // adoption before switching enforcement on.
            self::resolve();
            return;
        }

        $device = self::resolve();

        if ($device === null) {
            Response::error(self::$failure ?? 'device_auth_required', 401);
        }

        if ((int) $device['banned'] === 1) {
            Response::error('device_banned', 403);
        }
    }

    /** Set by resolve() so require() can report a precise reason. */
    private static ?string $failure = null;

    /**
     * Verifies the signature headers and returns the device row, or null.
     *
     * Never terminates — callers decide what a failure means.
     */
    public static function resolve(): ?array
    {
        if (self::$resolved) {
            return self::$device;
        }
        self::$resolved = true;

        $deviceId  = trim((string) (Request::header('X-Device-Id') ?? ''));
        $timestamp = (int) (Request::header('X-Timestamp') ?? 0);
        $nonce     = trim((string) (Request::header('X-Nonce') ?? ''));
        $sig       = strtolower(trim((string) (Request::header('X-Sig') ?? '')));

        if ($deviceId === '' || $sig === '' || $nonce === '') {
            self::$failure = 'device_auth_required';
            return null;
        }

        if (!preg_match('/^[a-f0-9]{64}$/', $sig) ||
            !preg_match('/^[a-f0-9]{16,64}$/i', $nonce)) {
            self::$failure = 'invalid_signature';
            return null;
        }

        // Clock check first: it is the cheapest, and a wrong device clock is
        // a common, innocent cause that deserves its own error code so the
        // app can tell the user to fix their date & time.
        if (abs(time() - $timestamp) > self::SKEW) {
            self::$failure = 'clock_skew';
            return null;
        }

        $row = Db::one(
            'SELECT device_id, secret_enc, banned FROM app_devices WHERE device_id = ? LIMIT 1',
            [$deviceId]
        );

        if ($row === null) {
            // Distinct from a bad signature on purpose: the app treats this
            // as "re-register silently and retry", which is what should
            // happen after an operator resets the table or a ROM update
            // wipes the Keystore entry.
            self::$failure = 'device_not_registered';
            return null;
        }

        $secret = Crypto::decrypt((string) $row['secret_enc']);
        if ($secret === null || $secret === '') {
            // Undecryptable row: the encryption key was rotated without
            // re-keying. Treat as unregistered so the app quietly registers
            // again instead of showing the user a hard failure.
            self::$failure = 'device_not_registered';
            return null;
        }

        // ---- Rebuild the canonical string ---------------------------
        $canonical = self::canonicalString($timestamp, $nonce);
        $expected  = hash_hmac('sha256', $canonical, $secret);

        if (!hash_equals($expected, $sig)) {
            self::$failure = 'invalid_signature';
            return null;
        }

        // ---- Replay protection --------------------------------------
        //
        // Checked only AFTER the signature verifies, so an unauthenticated
        // caller cannot fill the nonce table with junk.
        try {
            Db::run(
                'INSERT INTO app_nonces (nonce, device_id) VALUES (?, ?)',
                [$nonce, $deviceId]
            );
        } catch (Throwable $e) {
            // A duplicate primary key means this exact request was already
            // seen — a genuine replay.
            //
            // But this used to catch EVERYTHING and call it a replay, which
            // sent the diagnosis badly wrong in the field: an old app_nonces
            // table carrying an extra NOT NULL column made every insert fail
            // with "Field 'x' doesn't have a default value", and the app was
            // told `replay_detected`. A server-side schema fault therefore
            // looked like a client attacking the API — so the logs blamed the
            // phone while the phone was behaving perfectly.
            //
            // Distinguish by SQLSTATE: 23000 is an integrity violation (the
            // real replay), anything else is our problem, not the caller's.
            $sqlState = $e instanceof PDOException ? (string) $e->getCode() : '';

            if ($sqlState === '23000') {
                self::$failure = 'replay_detected';
                return null;
            }

            Logger::error('nonce_insert_failed', [
                'msg'   => $e->getMessage(),
                'state' => $sqlState,
                'hint'  => 'app_nonces schema — run php bin/migrate.php --device-auth',
            ]);
            self::$failure = 'server_error';
            return null;
        }

        // ---- Touch counters (throttled) -----------------------------
        try {
            Db::run(
                'UPDATE app_devices
                    SET last_seen_at = NOW(), last_ip = ?, req_count = req_count + 1
                  WHERE device_id = ?',
                [Request::ip(), $deviceId]
            );
        } catch (Throwable) {
        }

        return self::$device = $row;
    }

    /**
     * The exact string the app signed.
     *
     * Must match `DeviceAuthService.buildCanonicalString` in the Flutter app
     * byte for byte. A disagreement shows up as a blanket 401 with no useful
     * diagnostic, which is a miserable bug to chase in the field, so the two
     * subtle decisions are spelled out:
     *
     *  - Query parameters are sorted by key and joined using their DECODED
     *    values, because percent-encoding differs between Dart's `Uri` and
     *    PHP's `$_GET` (spaces, `+`, unreserved characters).
     *  - The body is hashed rather than embedded, keeping the string short
     *    and binary-safe. An absent body hashes as sha256('') on both sides.
     */
    private static function canonicalString(int $timestamp, string $nonce): string
    {
        $method = Request::method();

        // Path only — no scheme, no host, no query — so a reverse proxy
        // rewriting the host cannot invalidate every signature.
        $uri  = (string) ($_SERVER['REQUEST_URI'] ?? '');
        $path = (string) (parse_url($uri, PHP_URL_PATH) ?: '');

        $query = $_GET;
        ksort($query);
        $parts = [];
        foreach ($query as $k => $v) {
            if (is_scalar($v)) {
                $parts[] = $k . '=' . $v;
            }
        }
        $canonicalQuery = implode('&', $parts);

        $bodyHash = hash('sha256', Request::rawBody());

        return implode("\n", [
            strtoupper($method),
            $path,
            $canonicalQuery,
            $bodyHash,
            (string) $timestamp,
            $nonce,
        ]);
    }

    // =================================================================
    // Housekeeping
    // =================================================================

    /** Called from bin/cron.php. */
    public static function pruneNonces(): int
    {
        return Db::run(
            'DELETE FROM app_nonces WHERE used_at < DATE_SUB(NOW(), INTERVAL ? SECOND)',
            [self::NONCE_TTL]
        );
    }
}
