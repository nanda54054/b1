<?php
/**
 * DB-backed sliding-window rate limiter. No Redis dependency so it works
 * on plain cPanel/VPS PHP.
 *
 * Buckets look like "admin_login:203.0.113.7". Once the limit is hit the
 * bucket is blocked for `block` seconds and every further request gets a
 * 429 with Retry-After.
 */
declare(strict_types=1);

final class RateLimiter
{
    /**
     * @param string $name  profile name from config('rate_limits')
     * @param string $key    discriminator (usually the client IP)
     */
    public static function hit(string $name, string $key): void
    {
        $profile = (array) Config::get("rate_limits.$name", []);
        $limit  = (int) ($profile['limit']  ?? 0);
        $window = (int) ($profile['window'] ?? 60);
        $block  = (int) ($profile['block']  ?? 60);

        if ($limit <= 0) {
            return; // profile disabled
        }

        $bucket = substr($name . ':' . $key, 0, 160);
        $now    = time();

        try {
            $row = Db::one(
                'SELECT hits, UNIX_TIMESTAMP(window_start) AS ws,
                        UNIX_TIMESTAMP(blocked_until) AS bu
                 FROM rate_limits WHERE bucket = ?',
                [$bucket]
            );

            if ($row === null) {
                Db::run(
                    'INSERT INTO rate_limits (bucket, hits, window_start)
                     VALUES (?, 1, FROM_UNIXTIME(?))
                     ON DUPLICATE KEY UPDATE hits = hits + 1',
                    [$bucket, $now]
                );
                return;
            }

            // Currently blocked?
            if (!empty($row['bu']) && (int) $row['bu'] > $now) {
                self::reject((int) $row['bu'] - $now);
            }

            // Window expired -> start a fresh one.
            if ($now - (int) $row['ws'] >= $window) {
                Db::run(
                    'UPDATE rate_limits
                     SET hits = 1, window_start = FROM_UNIXTIME(?), blocked_until = NULL
                     WHERE bucket = ?',
                    [$now, $bucket]
                );
                return;
            }

            $hits = (int) $row['hits'] + 1;

            if ($hits > $limit) {
                Db::run(
                    'UPDATE rate_limits
                     SET hits = ?, blocked_until = FROM_UNIXTIME(?)
                     WHERE bucket = ?',
                    [$hits, $now + $block, $bucket]
                );
                Logger::warn('rate_limited', ['bucket' => $bucket, 'hits' => $hits]);
                self::reject($block);
            }

            Db::run('UPDATE rate_limits SET hits = ? WHERE bucket = ?', [$hits, $bucket]);
        } catch (Throwable $e) {
            // A limiter failure must never take the API down.
            Logger::error('rate_limiter_error', ['msg' => $e->getMessage()]);
        }
    }

    /** Clears a bucket (e.g. after a successful login). */
    public static function clear(string $name, string $key): void
    {
        try {
            Db::run('DELETE FROM rate_limits WHERE bucket = ?', [substr($name . ':' . $key, 0, 160)]);
        } catch (Throwable) {
        }
    }

    private static function reject(int $retryAfter): never
    {
        header('Retry-After: ' . max(1, $retryAfter));
        Response::error('Too many requests. Please slow down.', 429);
    }

    /** Housekeeping — called by bin/cron.php. */
    public static function prune(): int
    {
        try {
            return Db::run(
                'DELETE FROM rate_limits
                 WHERE (blocked_until IS NULL OR blocked_until < NOW())
                   AND window_start < DATE_SUB(NOW(), INTERVAL 1 DAY)'
            );
        } catch (Throwable) {
            return 0;
        }
    }
}
