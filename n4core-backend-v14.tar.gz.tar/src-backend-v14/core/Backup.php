<?php
/**
 * Backup engine: dumps the database + all backend files into one archive,
 * optionally encrypts it, records it, ships it to Telegram, and prunes
 * old copies.
 *
 * Uses mysqldump when available and falls back to a pure-PHP dumper, so
 * it works on locked-down shared hosting too.
 */
declare(strict_types=1);

final class Backup
{
    public const SCOPE_FULL  = 'full';
    public const SCOPE_DB    = 'db';
    public const SCOPE_FILES = 'files';

    /**
     * @return array{ok:bool,filename:string,path:string,size:int,sha256:string,encrypted:bool,error:?string,scope:string}
     */
    public static function create(string $scope = self::SCOPE_FULL, string $kind = 'auto', string $triggeredBy = 'cron'): array
    {
        $stamp   = date('Ymd-His');
        $dir     = Config::storagePath('backups');
        $tmpDir  = Config::storagePath('tmp') . '/bk-' . $stamp . '-' . bin2hex(random_bytes(3));

        self::ensureDir($dir);
        self::ensureDir($tmpDir);

        $result = [
            'ok' => false, 'filename' => '', 'path' => '', 'size' => 0,
            'sha256' => '', 'encrypted' => false, 'error' => null, 'scope' => $scope,
        ];

        try {
            $manifest = [
                'created_at' => date('c'),
                'timezone'   => (string) Config::get('app.timezone'),
                'scope'      => $scope,
                'kind'       => $kind,
                'triggered'  => $triggeredBy,
                'db_name'    => (string) Config::get('db.name'),
                'php'        => PHP_VERSION,
                'version'    => 'n4core-backend-v2',
            ];

            // ---- 1. Database dump -----------------------------------
            if ($scope !== self::SCOPE_FILES) {
                $sqlFile = $tmpDir . '/database.sql';
                $dumped  = self::dumpDatabase($sqlFile);
                if (!$dumped) {
                    throw new RuntimeException('Database dump failed');
                }
                $manifest['db_size'] = filesize($sqlFile) ?: 0;
                $manifest['db_tool'] = self::$lastTool;
            }

            // ---- 2. Files -------------------------------------------
            if ($scope !== self::SCOPE_DB) {
                $manifest['files'] = self::collectFiles($tmpDir . '/files');
            }

            file_put_contents(
                $tmpDir . '/manifest.json',
                json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)
            );

            // ---- 3. Archive -----------------------------------------
            $base    = "n4core-{$scope}-{$stamp}";
            $archive = $dir . '/' . $base . '.tar.gz';
            if (!self::makeArchive($tmpDir, $archive)) {
                // Fall back to zip
                $archive = $dir . '/' . $base . '.zip';
                if (!self::makeZip($tmpDir, $archive)) {
                    throw new RuntimeException('Could not create an archive (tar and zip both unavailable)');
                }
            }

            // ---- 4. Encrypt -----------------------------------------
            $encrypted = false;
            if (Config::get('backup.encrypt', true)) {
                $enc = $archive . '.enc';
                if (Crypto::encryptFile($archive, $enc)) {
                    @unlink($archive);
                    $archive   = $enc;
                    $encrypted = true;
                } else {
                    Logger::warn('backup_encrypt_failed', ['file' => basename($archive)]);
                }
            }

            @chmod($archive, 0600);

            $result['ok']        = true;
            $result['filename']  = basename($archive);
            $result['path']      = $archive;
            $result['size']      = (int) (filesize($archive) ?: 0);
            $result['sha256']    = (string) (hash_file('sha256', $archive) ?: '');
            $result['encrypted'] = $encrypted;

            self::record($result, $kind, $scope, $triggeredBy, 'ok', null);
        } catch (Throwable $e) {
            $result['error'] = $e->getMessage();
            Logger::error('backup_failed', ['msg' => $e->getMessage(), 'scope' => $scope]);
            self::record($result, $kind, $scope, $triggeredBy, 'failed', $e->getMessage());
        } finally {
            self::rmrf($tmpDir);
        }

        return $result;
    }

    // =================================================================
    // Database dump
    // =================================================================

    private static string $lastTool = 'php';

    private static function dumpDatabase(string $outFile): bool
    {
        $host = (string) Config::get('db.host');
        $port = (int) Config::get('db.port', 3306);
        $name = (string) Config::get('db.name');
        $user = (string) Config::get('db.user');
        $pass = (string) Config::get('db.pass');

        // Prefer mysqldump: faster and handles every type correctly.
        $bin = self::findBinary(['mysqldump', 'mariadb-dump']);
        if ($bin !== null && self::canExec()) {
            // Credentials go in a 0600 defaults file, never on argv
            // (argv is visible in `ps` to every user on the box).
            $cnf = tempnam(sys_get_temp_dir(), 'n4my');
            if ($cnf !== false) {
                @chmod($cnf, 0600);
                $body = "[client]\nuser=" . $user . "\npassword=\"" . str_replace('"', '\"', $pass) . "\"\n";
                if (!str_starts_with($host, '/')) {
                    $body .= "host=" . $host . "\nport=" . $port . "\n";
                } else {
                    $body .= "socket=" . $host . "\n";
                }
                file_put_contents($cnf, $body);

                $cmd = escapeshellcmd($bin)
                    . ' --defaults-extra-file=' . escapeshellarg($cnf)
                    . ' --single-transaction --quick --routines --events --triggers'
                    . ' --default-character-set=utf8mb4 --add-drop-table'
                    . ' ' . escapeshellarg($name)
                    . ' 2>/dev/null > ' . escapeshellarg($outFile);

                $code = 1;
                @exec($cmd, $ignore, $code);
                @unlink($cnf);

                if ($code === 0 && is_file($outFile) && filesize($outFile) > 100) {
                    self::$lastTool = basename($bin);
                    return true;
                }
                @unlink($outFile);
            }
        }

        // ---- Pure-PHP fallback --------------------------------------
        self::$lastTool = 'php';
        return self::dumpDatabasePhp($outFile);
    }

    private static function dumpDatabasePhp(string $outFile): bool
    {
        $fh = fopen($outFile, 'w');
        if ($fh === false) {
            return false;
        }

        $pdo = Db::pdo();
        fwrite($fh, "-- N4 Core VPN backup (PHP dumper)\n-- " . date('c') . "\n");
        fwrite($fh, "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\nSET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\n\n");

        $tables = $pdo->query('SHOW FULL TABLES WHERE Table_type = "BASE TABLE"')->fetchAll(PDO::FETCH_NUM);

        foreach ($tables as $t) {
            $table = (string) $t[0];
            $quoted = '`' . str_replace('`', '``', $table) . '`';

            $create = $pdo->query("SHOW CREATE TABLE {$quoted}")->fetch(PDO::FETCH_NUM);
            fwrite($fh, "\n-- Table: {$table}\nDROP TABLE IF EXISTS {$quoted};\n" . ($create[1] ?? '') . ";\n\n");

            // Stream rows so memory stays flat on big tables.
            $st = $pdo->query("SELECT * FROM {$quoted}");
            $batch = [];
            $cols  = null;
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                if ($cols === null) {
                    $cols = array_map(fn($c) => '`' . str_replace('`', '``', (string) $c) . '`', array_keys($row));
                }
                $vals = [];
                foreach ($row as $v) {
                    if ($v === null) {
                        $vals[] = 'NULL';
                    } elseif (is_int($v) || is_float($v)) {
                        $vals[] = (string) $v;
                    } else {
                        $vals[] = $pdo->quote((string) $v);
                    }
                }
                $batch[] = '(' . implode(',', $vals) . ')';
                if (count($batch) >= 200) {
                    fwrite($fh, "INSERT INTO {$quoted} (" . implode(',', $cols) . ") VALUES\n" . implode(",\n", $batch) . ";\n");
                    $batch = [];
                }
            }
            if ($batch && $cols !== null) {
                fwrite($fh, "INSERT INTO {$quoted} (" . implode(',', $cols) . ") VALUES\n" . implode(",\n", $batch) . ";\n");
            }
        }

        // Views
        $views = $pdo->query('SHOW FULL TABLES WHERE Table_type = "VIEW"')->fetchAll(PDO::FETCH_NUM);
        foreach ($views as $v) {
            $view = '`' . str_replace('`', '``', (string) $v[0]) . '`';
            $c = $pdo->query("SHOW CREATE VIEW {$view}")->fetch(PDO::FETCH_NUM);
            if (!empty($c[1])) {
                fwrite($fh, "\nDROP VIEW IF EXISTS {$view};\n" . $c[1] . ";\n");
            }
        }

        fwrite($fh, "\nSET FOREIGN_KEY_CHECKS=1;\n");
        fclose($fh);
        return filesize($outFile) > 100;
    }

    // =================================================================
    // Files
    // =================================================================

    /** Copies the backend tree (minus storage/) into $dest. */
    private static function collectFiles(string $dest): array
    {
        self::ensureDir($dest);
        $root = dirname(__DIR__);
        $copied = [];

        $skipDirs = ['storage', '.git', 'node_modules', 'vendor', 'tmp'];

        $it = new RecursiveIteratorIterator(
            new RecursiveCallbackFilterIterator(
                new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS),
                function (SplFileInfo $file) use ($skipDirs) {
                    if ($file->isDir()) {
                        return !in_array($file->getFilename(), $skipDirs, true);
                    }
                    // Skip archives/log noise
                    return !preg_match('/\.(tar\.gz|zip|enc|log)$/i', $file->getFilename());
                }
            ),
            RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($it as $file) {
            /** @var SplFileInfo $file */
            $rel = ltrim(str_replace($root, '', $file->getPathname()), '/\\');
            $target = $dest . '/' . $rel;
            if ($file->isDir()) {
                self::ensureDir($target);
                continue;
            }
            if ($file->getSize() > 20 * 1024 * 1024) {
                continue; // no giant binaries in a config backup
            }
            self::ensureDir(dirname($target));
            if (@copy($file->getPathname(), $target)) {
                $copied[] = $rel;
            }
        }

        // Extra paths the operator asked for.
        foreach ((array) Config::get('backup.extra_paths', []) as $extra) {
            if (is_file($extra)) {
                $t = $dest . '/extra/' . basename($extra);
                self::ensureDir(dirname($t));
                if (@copy($extra, $t)) {
                    $copied[] = 'extra/' . basename($extra);
                }
            }
        }

        return ['count' => count($copied), 'sample' => array_slice($copied, 0, 25)];
    }

    // =================================================================
    // Archiving
    // =================================================================

    private static function makeArchive(string $srcDir, string $outFile): bool
    {
        $tar = self::findBinary(['tar']);
        if ($tar !== null && self::canExec()) {
            $cmd = escapeshellcmd($tar) . ' -czf ' . escapeshellarg($outFile)
                . ' -C ' . escapeshellarg($srcDir) . ' . 2>/dev/null';
            $code = 1;
            @exec($cmd, $o, $code);
            if ($code === 0 && is_file($outFile) && filesize($outFile) > 0) {
                return true;
            }
            @unlink($outFile);
        }

        // PharData fallback (works without shell_exec)
        if (class_exists('PharData') && !ini_get('phar.readonly')) {
            try {
                $tarPath = preg_replace('/\.tar\.gz$/', '.tar', $outFile) ?? ($outFile . '.tar');
                @unlink($tarPath);
                $phar = new PharData($tarPath);
                $phar->buildFromDirectory($srcDir);
                $phar->compress(Phar::GZ);
                unset($phar);
                @unlink($tarPath);
                $gz = $tarPath . '.gz';
                if (is_file($gz)) {
                    @rename($gz, $outFile);
                    return is_file($outFile);
                }
            } catch (Throwable $e) {
                Logger::warn('phar_archive_failed', ['msg' => $e->getMessage()]);
            }
        }

        return false;
    }

    private static function makeZip(string $srcDir, string $outFile): bool
    {
        if (!class_exists('ZipArchive')) {
            return false;
        }
        $zip = new ZipArchive();
        if ($zip->open($outFile, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            return false;
        }
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($srcDir, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($it as $file) {
            /** @var SplFileInfo $file */
            $rel = ltrim(str_replace($srcDir, '', $file->getPathname()), '/\\');
            if ($file->isDir()) {
                $zip->addEmptyDir($rel);
            } else {
                $zip->addFile($file->getPathname(), $rel);
            }
        }
        $zip->close();
        return is_file($outFile);
    }

    // =================================================================
    // Delivery + retention
    // =================================================================

    /** Ships the archive to every Telegram admin with notify_backup on. */
    public static function deliver(array $result, string $captionPrefix = ''): bool
    {
        if (!$result['ok'] || !is_file($result['path'])) {
            return false;
        }
        if (!Telegram::enabled()) {
            return false;
        }

        $maxMb = (float) Config::get('backup.telegram_max_mb', 45);
        $sizeMb = $result['size'] / 1048576;

        $caption =
            ($captionPrefix !== '' ? $captionPrefix . "\n" : '')
            . "📦 <b>" . Telegram::esc($result['filename']) . "</b>\n"
            . "Size: " . self::human($result['size']) . "\n"
            . "Scope: " . strtoupper($result['scope']) . "\n"
            . ($result['encrypted'] ? "🔐 Encrypted (AES-256-GCM)\n" : "")
            . "SHA256: <code>" . substr($result['sha256'], 0, 16) . "…</code>";

        $owner = Telegram::ownerId();
        $recipients = [];
        try {
            $rows = Db::all('SELECT telegram_user_id FROM telegram_admins WHERE is_active = 1 AND notify_backup = 1');
            foreach ($rows as $r) {
                $recipients[(int) $r['telegram_user_id']] = true;
            }
        } catch (Throwable) {
        }
        if ($owner > 0) {
            $recipients[$owner] = true;
        }

        if ($sizeMb > $maxMb) {
            $msg = $caption . "\n\n⚠️ Too large for Telegram ("
                . self::human($result['size']) . " > {$maxMb} MB).\n"
                . "Kept on the server at:\n<code>storage/backups/"
                . Telegram::esc($result['filename']) . "</code>";
            foreach (array_keys($recipients) as $chat) {
                Telegram::send((int) $chat, $msg);
            }
            return false;
        }

        $sent = false;
        foreach (array_keys($recipients) as $chat) {
            if (Telegram::sendDocument((int) $chat, $result['path'], $caption)) {
                $sent = true;
            }
        }

        if ($sent) {
            try {
                Db::run(
                    'UPDATE backups SET delivered_tg = 1, status = ? WHERE filename = ?',
                    ['sent', $result['filename']]
                );
            } catch (Throwable) {
            }
        }
        return $sent;
    }

    /** Deletes archives older than the retention window. */
    public static function prune(): int
    {
        $days = (int) Config::setting('backup_retention_days', (string) Config::get('backup.retention_days', 14));
        $days = max(1, $days);
        $cutoff = time() - $days * 86400;
        $dir = Config::storagePath('backups');
        $removed = 0;

        foreach (glob($dir . '/n4core-*') ?: [] as $f) {
            if (is_file($f) && @filemtime($f) < $cutoff) {
                if (@unlink($f)) {
                    $removed++;
                    try {
                        Db::run('DELETE FROM backups WHERE filename = ?', [basename($f)]);
                    } catch (Throwable) {
                    }
                }
            }
        }

        try {
            Db::run('DELETE FROM backups WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)', [$days * 3]);
        } catch (Throwable) {
        }

        return $removed;
    }

    public static function listRecent(int $limit = 20): array
    {
        $limit = max(1, min(100, $limit));
        try {
            return Db::all('SELECT * FROM backups ORDER BY id DESC LIMIT ' . $limit);
        } catch (Throwable) {
            return [];
        }
    }

    // =================================================================
    // Helpers
    // =================================================================

    private static function record(array $r, string $kind, string $scope, string $by, string $status, ?string $error): void
    {
        // The ENUM columns are strict, and a stray value would silently drop the
        // whole row (leaving an archive on disk that the dashboard cannot see).
        // Clamp to known values so a record ALWAYS lands.
        $kind   = in_array($kind, ['auto', 'manual'], true) ? $kind : 'manual';
        $scope  = in_array($scope, [self::SCOPE_FULL, self::SCOPE_DB, self::SCOPE_FILES], true)
                    ? $scope : self::SCOPE_FULL;
        $status = in_array($status, ['ok', 'failed', 'sending', 'sent'], true) ? $status : 'ok';

        try {
            Db::run(
                'INSERT INTO backups (filename, kind, scope, size_bytes, sha256, encrypted, status, error, triggered_by)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [
                    $r['filename'] !== '' ? $r['filename'] : 'failed-' . date('Ymd-His'),
                    $kind, $scope, $r['size'], $r['sha256'] ?: null,
                    $r['encrypted'] ? 1 : 0, $status,
                    $error !== null ? mb_substr($error, 0, 255) : null,
                    mb_substr($by, 0, 128),
                ]
            );
        } catch (Throwable $e) {
            Logger::error('backup_record_failed', ['msg' => $e->getMessage()]);
        }
    }

    private static function canExec(): bool
    {
        if (!function_exists('exec')) {
            return false;
        }
        $disabled = array_map('trim', explode(',', (string) ini_get('disable_functions')));
        return !in_array('exec', $disabled, true);
    }

    private static function findBinary(array $names): ?string
    {
        $paths = ['/usr/bin/', '/usr/local/bin/', '/bin/', '/usr/local/mysql/bin/', '/opt/homebrew/bin/'];
        foreach ($names as $n) {
            foreach ($paths as $p) {
                if (is_executable($p . $n)) {
                    return $p . $n;
                }
            }
        }
        return null;
    }

    private static function ensureDir(string $dir): void
    {
        if (!is_dir($dir)) {
            @mkdir($dir, 0750, true);
        }
    }

    private static function rmrf(string $dir): void
    {
        if (!is_dir($dir)) {
            return;
        }
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($it as $f) {
            /** @var SplFileInfo $f */
            $f->isDir() ? @rmdir($f->getPathname()) : @unlink($f->getPathname());
        }
        @rmdir($dir);
    }

    public static function human(int $bytes): string
    {
        $units = ['B', 'KB', 'MB', 'GB'];
        $i = 0;
        $n = (float) $bytes;
        while ($n >= 1024 && $i < count($units) - 1) {
            $n /= 1024;
            $i++;
        }
        return round($n, $i === 0 ? 0 : 2) . ' ' . $units[$i];
    }
}
