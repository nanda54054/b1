<?php
/**
 * Single entry point for every API script and CLI tool.
 *   require_once __DIR__ . '/../../core/bootstrap.php';
 */
declare(strict_types=1);

// ---- Never leak internals to a client -------------------------------
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
ini_set('log_errors', '1');

// Session cookies are unused (token auth), but harden anyway.
ini_set('session.use_strict_mode', '1');
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_samesite', 'Strict');

// ---- Autoload core classes ------------------------------------------
spl_autoload_register(static function (string $class): void {
    if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $class)) {
        return;
    }
    $file = __DIR__ . '/' . $class . '.php';
    if (is_file($file)) {
        require_once $file;
    }
});

// ---- Fatal handlers -------------------------------------------------
set_exception_handler(static function (Throwable $e): void {
    try {
        Logger::error('uncaught_exception', [
            'class' => $e::class,
            'msg'   => $e->getMessage(),
            'file'  => basename($e->getFile()) . ':' . $e->getLine(),
        ]);
    } catch (Throwable) {
    }
    if (PHP_SAPI === 'cli') {
        fwrite(STDERR, '[fatal] ' . $e->getMessage() . "\n");
        exit(1);
    }
    Response::error('Internal server error', 500);
});

set_error_handler(static function (int $no, string $str, string $file = '', int $line = 0): bool {
    if (!(error_reporting() & $no)) {
        return false;
    }
    throw new ErrorException($str, 0, $no, $file, $line);
});

register_shutdown_function(static function (): void {
    $err = error_get_last();
    if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        try {
            Logger::error('fatal_error', [
                'msg'  => $err['message'],
                'file' => basename($err['file']) . ':' . $err['line'],
            ]);
        } catch (Throwable) {
        }
        if (PHP_SAPI !== 'cli' && !headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json');
            echo json_encode(['ok' => false, 'error' => 'Internal server error']);
        }
    }
});

// ---- Boot -----------------------------------------------------------
Config::boot();

if (PHP_SAPI !== 'cli') {
    Response::boot();     // headers + CORS + OPTIONS short-circuit

    // Reject absurd payloads early.
    $len = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
    if ($len > 1024 * 1024) {
        Response::error('Request body too large', 413);
    }
}

/**
 * Public-API maintenance gate. Applied by public endpoints only — the
 * admin dashboard must keep working during maintenance so you can fix
 * whatever caused it.
 */
function guard_maintenance(): void
{
    $on = Config::get('app.maintenance', false) || Config::settingBool('maintenance_mode', false);
    if (!$on) {
        return;
    }
    $msg = (string) Config::setting('maintenance_message', '');
    if ($msg === '') {
        $msg = 'Service is under maintenance. Please try again shortly.';
    }
    Response::error($msg, 503);
}
