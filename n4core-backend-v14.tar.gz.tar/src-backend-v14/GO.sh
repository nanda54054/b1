#!/usr/bin/env bash
# =====================================================================
#  N4 Core VPN — VPS အသစ်မှာ တင်ခြင်း
#
#  Code ရော backup ရော ဒီ folder ထဲ ပါပြီးသားပါ။
#  လိုတာ ၂ ခုပဲ — domain နဲ့ encryption_key
#
#    bash GO.sh
#
# =====================================================================
set -uo pipefail

R=$'\e[31m'; G=$'\e[32m'; Y=$'\e[33m'; B=$'\e[36m'; BD=$'\e[1m'; N=$'\e[0m'
die() { echo; echo "${R}${BD}✗ $*${N}" >&2; exit 1; }

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

cat <<BANNER

${B}${BD}═══════════════════════════════════════════════════${N}
${B}${BD}  N4 Core VPN — VPS အသစ် တင်ခြင်း${N}
${B}${BD}═══════════════════════════════════════════════════${N}

BANNER

[ "$(id -u)" = "0" ] || die "root အနေနဲ့ run ပါ  →  sudo -i  ပြီးမှ  bash GO.sh"

# Backup ဖိုင်။ bot ကနေ ရလာတဲ့ အသစ်ကို သုံးလိုရင် —
#   bash GO.sh /root/n4core-db-XXXX.tar.gz.enc
# ဘာမှ မထည့်ရင် folder ထဲက အဟောင်းကို ကိုယ်တိုင် ရှာတယ်။
BK="${1:-}"
if [ -n "$BK" ]; then
  [ -f "$BK" ] || die "ထည့်ထားတဲ့ backup ဖိုင် မတွေ့ပါ: $BK"
else
  BK="$(find "$HERE" -maxdepth 2 -type f \( -name 'backup.enc' -o -name 'n4core-*.tar.gz.enc' \) 2>/dev/null | head -1)"
fi
[ -n "$BK" ] || die "backup ဖိုင် မတွေ့ပါ — zip မပြည့်စုံဘူးထင်တယ်"
[ -s "$BK" ] || die "backup ဖိုင် ဗလာဖြစ်နေတယ်"

# N4CBK001 = encrypt လုပ်ထားတဲ့ backup ရဲ့ အမှတ်အသား
[ "$(head -c 8 "$BK")" = "N4CBK001" ] \
  || die "backup ဖိုင် ပုံစံ မှားနေတယ် — download မပြည့်စုံဘူးထင်တယ်"

echo "  ${G}✓${N} Backup ဖိုင် တွေ့ပြီ ($(du -h "$BK" | cut -f1))"
echo

read -rp "  ၁) Domain         : " DOMAIN
[ -n "${DOMAIN:-}" ] || die "Domain မထည့်ထားပါ"
# copy လုပ်တဲ့အခါ https:// နဲ့ အဆုံး / ပါလာတာ များတာမို့ ဖြုတ်ပေးတယ်
DOMAIN="$(printf '%s' "$DOMAIN" | sed -E 's#^https?://##; s#/.*$##; s/[[:space:]]//g')"

echo
echo "  ၂) encryption_key   (bot မှာ ${BD}/keys${N})"
read -rp "     : " KEY
KEY="$(printf '%s' "$KEY" | tr -d '[:space:]')"
[ -n "$KEY" ] || die "encryption_key မထည့်ထားပါ"

echo
echo "  ${G}✓${N} Domain: $DOMAIN"
echo "  ${G}✓${N} Key: ${#KEY} လုံး"
echo
echo "  ${Y}အခု စတင်ပါမယ်။ ၅-၁၅ မိနစ် ကြာနိုင်ပါတယ် — စောင့်ပေးပါ။${N}"
echo "  ${Y}ဘာမှ နှိပ်စရာ မလိုပါ။${N}"

export DEBIAN_FRONTEND=noninteractive
chmod +x "$HERE"/deploy/*.sh 2>/dev/null || true

cd "$HERE" || die "$HERE ထဲ ဝင်လို့ မရပါ"
exec bash deploy/n4core-newvps.sh "$DOMAIN" "$BK" "$KEY"
