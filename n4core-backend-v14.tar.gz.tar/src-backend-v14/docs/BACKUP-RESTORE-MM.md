# N4 Core VPN — Backup နဲ့ VPS ပြောင်းခြင်း

---

## အကျဉ်းချုပ်

ည ၁၂ နာရီတိုင်း backup ဖိုင် **၂ မျိုး** အလိုအလျောက် ထွက်ပါတယ် —

| ဖိုင် | ဘာပါလဲ | ဘာအတွက် |
|---|---|---|
| `n4core-full-*.enc` | Dashboard **တစ်ခုလုံး** (files + database + key တွေ) | VPS အသစ်မှာ အကုန်ပြန်တည်ဆောက်ဖို့ |
| `n4core-db-*.enc` | Database သီးသန့် | Panel ရှိပြီးသားမှာ ဒေတာပဲ ပြန်ထည့်ဖို့ |

နှစ်ခုလုံး Telegram bot ကနေ အလိုအလျောက် ပို့ပေးပါတယ်။
သိမ်းရာနေရာ — `/var/www/n4core/storage/backups/`

---

## VPS အသစ်ပြောင်းခြင်း

လိုတာ **၂ ခုပဲ** — `n4core-full-*.enc` ဖိုင် နဲ့ `encryption_key`

### အဆင့် ၁ — Key ကို ယူပါ

Telegram bot မှာ ရိုက်ပါ —

```
/keys
```

Key တစ်ခုကို ပို့ပေးပါလိမ့်မယ်။ နှိပ်ပြီး copy ထားပါ။

> bot မရှိရင် VPS အဟောင်းမှာ —
> `grep encryption_key /var/www/n4core/config/config.php`

### အဆင့် ၂ — Backup ဖိုင်ကို VPS အသစ်ပေါ် တင်ပါ

Telegram ကနေ download လုပ်ထားတဲ့ `n4core-full-*.enc` ဖိုင်ကို
VPS အသစ်ရဲ့ `/root/` ထဲ တင်ပါ။

### အဆင့် ၃ — Command တစ်ကြောင်း run ပါ

```bash
bash deploy/n4core-newvps.sh yourdomain.com /root/n4core-full-XXXX.tar.gz.enc
```

Key ကို တောင်းလာရင် အဆင့် ၁ က တန်ဖိုးကို paste ပါ။ ပြီးပါပြီ။

Script က အလိုအလျောက် လုပ်သွားမှာ —

1. Panel အသစ် တင်တယ်
2. Panel တက်မတက် စစ်တယ်
3. Backup ကို ဖွင့်ပြီး **ရှိသမျှ အကုန်** ပြန်ထည့်တယ်
4. ဒေတာ ဝင်မဝင် ရေတွက်ပြတယ်

### အဆင့် ၄ — စစ်ပါ

- `https://yourdomain.com/admin/` ဝင်ပါ
- Password **အဟောင်း** အတိုင်းပဲ ဝင်ပါ (ပြောင်းစရာ မလိုပါ)
- Servers နဲ့ VIP Accounts ပြည့်စုံလား ကြည့်ပါ
- VIP access code တစ်ခု ဖွင့်ကြည့်ပါ — ဖတ်လို့ရရင် အားလုံး မှန်ပါပြီ

**အားလုံး အဆင်ပြေမှ** VPS အဟောင်းကို ဖျက်ပါ။

---

## Telegram bot

Restore လုပ်တဲ့အခါ `bot_token`, `owner_id`, `webhook_secret` တွေကိုပါ
backup ထဲကနေ ဆွဲထုတ်ပြီး ထည့်ပေးပါတယ်။ ပြီးရင် webhook အသစ်ကို
အလိုအလျောက် တင်ပေးတယ်။

Telegram က token တစ်ခုကို **webhook တစ်ခုပဲ** မှတ်ထားတာမို့
အသစ်တင်လိုက်တာနဲ့ VPS အဟောင်းရဲ့ webhook က သူ့ဘာသာသူ ပြုတ်သွားပါတယ်။
(webhook မရရင် polling service `n4core-bot` နဲ့ အလိုအလျောက် ပြောင်းလုပ်တယ်)

မရရင် —

```bash
cd /var/www/n4core
php bin/setup_webhook.php --info                    # အခုအခြေအနေ
php bin/setup_webhook.php https://yourdomain.com    # ပြန်တင်
systemctl status n4core-bot                         # polling mode စစ်
```

Bot မှာ `/backup` ရိုက်ရင် backup အသစ် ရပါတယ်။ ဒါကို VPS အသစ်မှာ —

```bash
bash GO.sh /root/n4core-full-XXXX.tar.gz.enc
```

---

## ဘာကြောင့် key ၁ ခုပဲ လိုတာလဲ

config.php ထဲမှာ secret ၃ ခု ရှိပါတယ် —

| Secret | အလုပ် | မှားရင် |
|---|---|---|
| `encryption_key` | Backup ဖိုင် + VIP code တွေကို ဖျက်/ဖတ် | Backup ဖွင့်လို့ မရ |
| `pepper` | Password hash အားလုံးမှာ ရောထားတာ | ဘယ်သူမှ login ဝင်လို့ မရ |
| `app_secret` | Session လက်မှတ် | ပြန် login ဝင်ရုံပဲ |

**ဒါပေမဲ့ ၃ ခုလုံးကို လက်နဲ့ ကူးစရာ မလိုပါ။**

Backup ဖိုင်ထဲမှာ `config/config.php` ပါပြီးသားမို့ `pepper`,
`app_secret` နဲ့ bot token တွေက ဖိုင်ထဲမှာ ရှိနေပါပြီ။ `restore.php` က
သူ့ဘာသာသူ ဆွဲထုတ်ပြီး ထည့်ပေးပါတယ်။

လက်နဲ့ ထည့်ရတာက `encryption_key` တစ်ခုတည်း — **ဖိုင်ကို ဖွင့်ဖို့**။
ဖိုင်ကို မဖွင့်ရသေးရင် ထဲက key တွေ ဖတ်လို့ မရသေးလို့ပါ။

---

## လုံခြုံရေး

Key ၃ ခု တောင်းတာကနေ ၁ ခု လျှော့လိုက်တာက **လုံခြုံရေး မလျော့ပါ** —

- Backup ဖိုင်က **AES-256-GCM** နဲ့ သော့ခတ်ထားတုန်းပဲ
- Key တွေက ဖိုင်ထဲကနေ **အပြင်မထွက်ပါ** — server ပေါ်တင် ဖွင့်တာ
- `encryption_key` မရှိရင် ဖိုင်က **အသုံးမဝင်တဲ့ အမှိုက်** ပဲ
- Telegram ကနေ ပို့တာ **နည်းသွားလို့** ပေါက်ကြားနိုင်ခြေ **ပိုနည်း**သွားတယ်

နောက်ထပ် ပိုကောင်းသွားတာတွေ —

- Restore လုပ်တဲ့အခါ `config.php.bak-*` ဖိုင်အဟောင်းတွေ (key တွေ
  plaintext နဲ့ ပါနေတာ) ကို **မကူးတော့ပါ**
- Config သိမ်းထားတဲ့ safety copy ကို `storage/` ထဲ ထားလို့
  နောက်ထွက်မယ့် backup ထဲ **ပြန်မပါတော့ပါ**

VPS အသစ်ရဲ့ **database password ကို မထိပါ** — အဲ့ဒါက စက်နဲ့ဆိုင်တာမို့
အဟောင်းနဲ့ လဲလိုက်ရင် panel က database ကို ဆက်လို့ မရတော့ပါ။

---

## လက်နဲ့ လုပ်ချင်ရင်

```bash
# ၁။ Panel တင်
bash deploy/n4core-install.sh yourdomain.com

# ၂။ အရင် စစ်ကြည့် (ဘာမှ မပြောင်းဘူး)
php bin/restore.php /root/n4core-full-XXXX.tar.gz.enc --dry-run --key=YOUR_KEY

# ၃။ တကယ် ထည့်
php bin/restore.php /root/n4core-full-XXXX.tar.gz.enc --key=YOUR_KEY
```

Flag မထည့်ရင် **ဖိုင်ထဲက ရှိသမျှ အကုန်** ပြန်ထည့်ပါတယ်။

| Flag | အလုပ် |
|---|---|
| `--key=KEY` | Backup ဖွင့်ဖို့ key |
| `--db` | Database ပဲ |
| `--files` | Files ပဲ |
| `--dry-run` | စစ်ရုံ၊ ဘာမှ မပြောင်း |
| `--yes` | မမေးဘဲ ဆက်လုပ် |

---

## Database name အကြောင်း

Backup ထဲက dump မှာ `USE database` မပါလို့ **database name ဘာဖြစ်ဖြစ်
ထည့်လို့ရပါတယ်**။ VPS အသစ်မှာ name ကွဲနေရင်လည်း ကိစ္စမရှိပါ။

---

## အလိုအလျောက် Backup

| အချိန် | ဘာလုပ် |
|---|---|
| ည ၁၂ နာရီ (Asia/Yangon) | `full` + `db` ဖိုင် ၂ ခု ထုတ်ပြီး Telegram ပို့ |
| ၁၀ မိနစ်တိုင်း | ဖိုင်အဟောင်းတွေ ရှင်းလင်း |

VPS ပိတ်ထားလို့ ည ၁၂ နာရီ လွတ်သွားရင် **၃ နာရီအတွင်း** ပြန်ဖွင့်တာနဲ့
အလိုအလျောက် ထုတ်ပေးပါတယ်။

Dashboard ကနေ ကိုယ်တိုင် လုပ်ချင်ရင် — **Backup → ▣ Full + Database**
