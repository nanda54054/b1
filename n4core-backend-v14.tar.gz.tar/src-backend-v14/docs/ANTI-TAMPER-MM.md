# N4 Core VPN — Anti-Tamper (Mod ကာကွယ်ရေး) လမ်းညွှန်

Version 2.2 · မြန်မာဘာသာ

---

## ၀။ အရေးအကြီးဆုံး တွေ့ရှိချက် (ဒါကို အရင်ဖတ်ပါ)

သင့် **App ဘက်မှာ** request signing code တွေ ရှိပြီးသားပါ။
`X-Device-Id`, `X-Sig`, `X-Nonce` header တွေ ပို့နေပါတယ်။

ဒါပေမဲ့ **Backend v2.1 မှာ အဲဒါတွေကို စစ်တဲ့ code လုံးဝ မပါပါဘူး။**

```bash
# v2.1 backend ထဲမှာ ရှာကြည့်တဲ့အခါ
grep -rn "X-Sig|DeviceAuth|register_device" .
# ရလဒ် — ဘာမှ မတွေ့ပါ
```

ဆိုလိုတာက —

| အရာ | v2.1 အခြေအနေ |
|---|---|
| `register_device.php` | မရှိပါ → **404** |
| App က register လုပ်ဖို့ ကြိုးစားတာ | **အမြဲ ကျရှုံး** |
| `curl .../api/public/servers.php` | **200 OK — Free config အားလုံး ထွက်သွား** |

App က signature ပို့နေပေမဲ့ Server က ဘာမှ မစစ်တဲ့အတွက် **ဘာအကာအကွယ်မှ မရှိခဲ့ပါ**။
v2.2 က အဲဒီ ပျောက်နေတဲ့ တစ်ဝက်ကို ဖြည့်ပေးတာ ဖြစ်ပါတယ်။

---

## ၁။ Mod App ကို ဘယ်လို တားလဲ

### အခြေခံ သဘောတရား

APK ကို **တစ်ဗိုက်လောက် ပြင်လိုက်တာနဲ့** Android က signature မကိုက်တော့လို့
install လုပ်လို့ မရတော့ပါဘူး။ ဒါကြောင့် Mod လုပ်သူဟာ **သူ့ကိုယ်ပိုင် key နဲ့
ပြန် sign လုပ်ကို လုပ်ရမယ်**။ သင့် `release-key.jks` ရဲ့ private key မရှိလို့
သင့် signature ကို အတုလုပ်လို့ မရပါဘူး။

ဒါကြောင့် **Signing Certificate ဟာ Mod လုပ်မလုပ် အတိအကျ ပြောပြနိုင်တဲ့
တစ်ခုတည်းသော အထောက်အထား** ဖြစ်ပါတယ်။

### အလွှာ ၃ ခု

```
အလွှာ ၁ — App ထဲက စစ်ဆေးမှု        (ခံနိုင်ရည် — အနည်းဆုံး)
အလွှာ ၂ — Request တိုင်း signature   (ခံနိုင်ရည် — အလယ်)
အလွှာ ၃ — Server မှာ cert စစ်တာ      (ခံနိုင်ရည် — အမြင့်ဆုံး) ★
```

**★ အလွှာ ၃ က အဓိကပါ။**

### ဘာကြောင့် Kotlin မှာ မစစ်တာလဲ

MT Manager က `classes.dex` ကို ပြင်ဖို့ လုပ်ထားတဲ့ tool ပါ။
Kotlin မှာ ဒီလိုရေးရင် —

```kotlin
if (signature != EXPECTED) { System.exit(0) }   // ❌ မလုပ်ပါနဲ့
```

smali မှာ `if-nez` တစ်ကြောင်းပဲ ဖြစ်သွားပြီး **၃၀ စက္ကန့်အတွင်း ဖျက်လို့ရ**ပါတယ်။

ဒါကြောင့် ကျွန်တော် အဲလို **မရေးပါဘူး**။

`IntegrityGuard.kt` က **အချက်အလက်ပဲ ပြန်ပေးတယ် — ဆုံးဖြတ်ချက် လုံးဝ မလုပ်ပါ**။

### အဓိက အကြံဉာဏ် — စစ်စရာ `if` ကို ဖျောက်ပစ်တာ

Device secret ရဖို့ signature လုပ်တဲ့ key က —

```
key = HMAC-SHA256(bootstrap_secret, signing_cert_sha256)
                                    ↑
                        App က runtime မှာ ဖတ်တာ
```

| APK အမျိုးအစား | Certificate | ရလာတဲ့ Key | ရလဒ် |
|---|---|---|---|
| စစ်မှန်တဲ့ App | သင့် cert | မှန်ကန်တဲ့ key | ✅ Register အောင်မြင် |
| Mod လုပ်ထားတဲ့ App | တခြား cert | မှားနေတဲ့ key | ❌ Server က ငြင်းပယ် |

**အရေးကြီးဆုံးအချက် —** ဖုန်းထဲမှာ **ဖျက်စရာ `if` မရှိပါဘူး**။
Certificate က HMAC ရဲ့ **input** ဖြစ်နေတာ၊ `if` စစ်တာ မဟုတ်ပါ။
Code ဖျက်လိုက်လည်း အလကားပါ — key မှားနေရင် signature မှားပြီး
**သင့် Server က ငြင်းပယ်လိုက်မှာပါ**။

---

## ၂။ ရိုးသားစွာ ပြောရရင် — ဘာတွေ မလုပ်နိုင်လဲ

ဒါတွေကို ဖုံးကွယ်မထားဘဲ ပြောပြပါရစေ။

### ❌ ၁၀၀% မတားနိုင်ပါ

Certificate hash ဟာ **လူတိုင်း ဖတ်လို့ရတဲ့ တန်ဖိုး** ဖြစ်ပါတယ်။
တကယ် ကျွမ်းကျင်တဲ့သူဟာ စစ်မှန်တဲ့ APK ထဲက အဲဒါကို ထုတ်ပြီး
Mod app ထဲ ပြန်ထည့်နိုင်ပါတယ်။

### ❌ Config ကို လုံးဝ မဖျောက်နိုင်ပါ

VPN config ဟာ tunnel စဖို့အတွက် **plaintext အနေနဲ့ VPN core ဆီ ရောက်ကို ရောက်ရမယ်**။
ဒါကြောင့် root ဖောက်ထားတဲ့ ဖုန်းမှာ memory ထဲကနေ အမြဲ ဖတ်လို့ရပါတယ်။
ဒါက **ဘယ် app မှ မဖြေရှင်းနိုင်တဲ့ ပြဿနာ** ပါ (V2rayNG, Napsternetv အားလုံး အတူတူပါပဲ)။

### ✅ ဒါပေမဲ့ ဘာတွေ ရလဲ

| | ယခင် | ယခု |
|---|---|---|
| Config ခိုးဖို့ | `curl` တစ်ကြောင်း၊ **၂ မိနစ်**၊ ကျွမ်းကျင်မှု မလို | APK ဖြည်၊ secret ရှာ၊ HMAC ပြန်ရေး — **၁-၂ ရက်** |
| ဖမ်းမိမှု | မဖြစ်နိုင် (IP ပဲ မြင်ရ) | Device တစ်လုံးချင်း မြင်ရ |
| အရေးယူမှု | မရှိ | **Ban လုပ်လို့ရ (အမြဲတမ်း)** |

**အဓိက အမြတ်က "ban လုပ်လို့ရတာ" ပါ။**
Device ID က ANDROID_ID ကနေ ဆွဲထုတ်ထားတာမို့ —
**Clear Data လုပ်လည်း၊ App ဖျက်ပြီး ပြန်သွင်းလည်း မပြောင်းပါဘူး။**
Factory Reset မှသာ ပြောင်းပါတယ်။ Ban တစ်ခါ လုပ်လိုက်ရင် ခံရတာပါပဲ။

---

## ၃။ တပ်ဆင်နည်း — User မရှိသေးတဲ့ အခြေအနေ (အခု သင့်အခြေအနေ)

> ✅ **App က အပြင်မထွက်ရသေးဘူး၊ User တစ်ယောက်မှ မရှိသေးဘူး** ဆိုရင်
> အဆင့်ဆင့် ဖြည်းဖြည်းဖွင့်စရာ **လုံးဝ မလိုပါဘူး**။
> `require_device_auth = true` ကို **ပထမနေ့ကတည်းက** ဖွင့်လိုက်ပါ။
>
> ဘာလို့လဲဆိုတော့ အဆင့်ဆင့်ဖွင့်ရတဲ့ တစ်ခုတည်းသော အကြောင်းရင်းက
> "APK အဟောင်း သုံးနေတဲ့ User တွေ ရုတ်တရက် 401 မဖြစ်စေဖို့" ပါ။
> APK အဟောင်း ကိုယ်တိုင် မရှိသေးရင် အဲ့ဒီ အန္တရာယ် မရှိပါဘူး။
>
> ပိုအရေးကြီးတာက — **VPS အသစ်ကို enforcement ပိတ်ထားပြီး တင်လိုက်ရင်**
> Domain က အများမြင်နိုင်တဲ့ အချိန်အတွင်း `curl` နဲ့ server config တွေ
> အားလုံး အလကား ဆွဲယူလို့ ရနေပါလိမ့်မယ်။ ဒါကြောင့် ပထမနေ့ကတည်းက
> ပိတ်ထားတာက ပိုလုံခြုံပါတယ်။

### အဆင့် ၁ — Backend ဖိုင်တွေ တင်ပါ

```bash
core/DeviceAuth.php
api/public/register_device.php
api/admin/devices.php
sql/migrate_v21_to_v22.sql
tests/device_auth_test.php
```

### အဆင့် ၂ — Database migrate လုပ်ပါ

```bash
php bin/migrate.php --device-auth
```

`app_devices` နဲ့ `app_nonces` table ၂ ခု ဆောက်ပေးပြီး config မှန်မမှန်
စစ်ပေးပါလိမ့်မယ်။

### အဆင့် ၃ — Secret နဲ့ Certificate hash တွေ ထုတ်ပါ

```bash
php bin/keygen.php     # bootstrap secret ထုတ်ရန်

# ကိုယ့် keystore ရဲ့ hash (Direct Download APK အတွက်)
keytool -list -v -keystore android/release-key.jks -alias <alias> \
  | grep 'SHA256:' | awk '{print $2}' | tr -d ':' | tr 'A-Z' 'a-z'
```

**Play Store တင်မယ်ဆိုရင် hash ၂ ခု လိုပါတယ်။**
Google Play App Signing က ကိုယ်တင်လိုက်တဲ့ AAB ကို Google ရဲ့ key နဲ့
**ပြန် sign လုပ်ပါတယ်**။ ဒါကြောင့် —

| ဘယ်ကနေ သွင်းလဲ | ဖုန်းက report လုပ်တဲ့ certificate |
|---|---|
| Play Store | **Google ရဲ့ App Signing key** |
| Direct Download | ကိုယ့် `release-key.jks` |

ဒုတိယ hash ကို ဒီနေရာက ယူပါ —
**Play Console → Test and release → Setup → App signing →
App signing key certificate → SHA-256**

`config/config.php` ထဲမှာ —

```php
'require_device_auth'  => true,            // ★ ပထမနေ့ကတည်းက true
'app_bootstrap_secret' => 'keygen ကရတဲ့ တန်ဖိုး',

// Play + Direct ၂ ခုလုံး တင်မယ်ဆိုရင် hash ၂ ခုလုံး ထည့်ပါ
'expected_cert_sha256' => [
    'a9f7…',   // release-key.jks   → Direct Download
    '3b21…',   // Play App Signing  → Play Store
],
```

> ⚠️ **hash တစ်ခုတည်း ထည့်ထားရင်** ကျန်တဲ့ channel က User အားလုံး
> register မရဘဲ 401 ဖြစ်ပါလိမ့်မယ်။ Server ပျက်နေသလို ထင်ရပေမဲ့
> အမှန်က config မှားနေတာပါ။

Direct Download ချည်းပဲဆိုရင် string တစ်ခုတည်းလည်း ရပါသေးတယ် —
`'expected_cert_sha256' => 'a9f7…'`

Rate limit အသစ် ၂ ခုကိုလည်း `config.sample.php` ကနေ ကူးထည့်ပါ —
`config_read`, `device_reg`

### အဆင့် ၄ — စစ်ဆေးပါ

```bash
php tests/device_auth_test.php
# 🎉 ALL 20 CHECKS PASSED   ← ဒါ မြင်ရမှ ဆက်လုပ်ပါ

php bin/migrate.php --device-auth
# ✅ expected_cert_sha256 pinned (2 certificates)
```

### အဆင့် ၅ — App ထုတ်ပါ

**Play Store အတွက် (AAB):**

```bash
flutter build appbundle --release \
  --obfuscate --split-debug-info=build/symbols \
  --dart-define=N4_BOOTSTRAP_SECRET=<config ထဲက အတိုင်း> \
  --dart-define=N4_CERT_SHA256=<release-key.jks hash> \
  --dart-define=N4_CERT_SHA256_ALT=<Play App Signing hash> \
  --dart-define=N4_APP_VERSION=1.0.0
```

**Direct Download အတွက် (APK):**

```bash
flutter build apk --release \
  --obfuscate --split-debug-info=build/symbols \
  --dart-define=N4_BOOTSTRAP_SECRET=<config ထဲက အတိုင်း> \
  --dart-define=N4_CERT_SHA256=<release-key.jks hash> \
  --dart-define=N4_CERT_SHA256_ALT=<Play App Signing hash> \
  --dart-define=N4_APP_VERSION=1.0.0
```

> `--dart-define` တွေ **၂ ခုလုံးမှာ တူညီအောင်** ထားပါ။
> အဲ့ဒါဆိုရင် build တစ်ခုတည်းက binary က channel ၂ ခုလုံးမှာ
> အလုပ်လုပ်ပါလိမ့်မယ်။
>
> **`--obfuscate` မဖြစ်မနေ ထည့်ပါ။** မထည့်ရင် secret တွေကို
> `strings libapp.so` နဲ့ ချက်ချင်း ဖတ်လို့ရပါတယ်။
>
> ⚠️ **Play Console မှာ App Signing key hash က AAB တင်ပြီးမှ ရပါတယ်။**
> ဒါကြောင့် ပထမဆုံး AAB ကို `N4_CERT_SHA256_ALT` မပါဘဲ **internal
> testing track** ကို တင်၊ hash ကို ကူးယူ၊ ပြီးမှ `_ALT` ထည့်ပြီး
> production အတွက် ပြန် build လုပ်ပါ။ (Version code တစ်ဆင့် တိုးဖို့
> မမေ့ပါနဲ့။)

### အဆင့် ၆ — အလုပ်လုပ်မလုပ် အတည်ပြုပါ

```bash
curl -i https://core.nandaxr.tech/api/public/servers.php
# HTTP/1.1 401
# {"ok":false,"error":"device_auth_required"}      ← ဒါ မြင်ရမှ မှန်တယ်
```

ပြီးရင် ဖုန်းအစစ်မှာ App ဖွင့်ကြည့်ပါ — server list တွေ ပေါ်ရပါမယ်။
ပေါ်မလာရင် အောက်က ပြဿနာ ဇယားကို ကြည့်ပါ။

## ၄။ Admin — Mod App သုံးသူတွေ ရှာနည်း

```
GET /api/admin/devices.php?filter=modified      ← Cert မတူတဲ့ device
GET /api/admin/devices.php?filter=heavy         ← Request များလွန်းတဲ့ device
GET /api/admin/devices.php?filter=instrumented  ← Frida/Xposed သုံးထားတဲ့
GET /api/admin/devices.php?view=summary         ← ခြုံငုံ အခြေအနေ

POST /api/admin/devices.php?action=ban    { device_id, reason }
POST /api/admin/devices.php?action=unban  { device_id }
```

Ban လုပ်လိုက်ရင် VIP session ကိုပါ ချက်ချင်း ဖျက်ပေးပါတယ်။

---

## ၅။ ဘာကို ပိတ်ပြီး ဘာကို မပိတ်လဲ (အရေးကြီးသော ဆုံးဖြတ်ချက်)

### 🔴 ပိတ်တာ (Mod လုပ်ထားတယ်လို့ သေချာတဲ့အခါသာ)

| အခြေအနေ | ဘာကြောင့် |
|---|---|
| Certificate မတူ | ပြန် sign လုပ်ထားတယ် = ပြင်ထားတယ် (မှားစရာ မရှိ) |
| Debuggable build | Release APK က ဘယ်တော့မှ debuggable မဖြစ်ပါ |

### 🟡 မှတ်တမ်းပဲ တင်တာ (မပိတ်ပါ)

| အခြေအနေ | ဘာကြောင့် မပိတ်လဲ |
|---|---|
| Root | Root သုံးတဲ့ ပိုက်ဆံပေးတဲ့ customer တွေ အများကြီး ရှိပါတယ်။ Magisk DenyList နဲ့ ဖုံးလို့လည်း ရတာမို့ ပိတ်ရင် **ရိုးသားတဲ့သူတွေပဲ ဒုက္ခရောက်ပြီး ခိုးသူကို မထိပါဘူး** |
| Frida / Xposed | အန္တရာယ် အရှိဆုံး signal ဖြစ်ပေမဲ့ Server ကို ပို့ပြီး လူကိုယ်တိုင် ဆုံးဖြတ်တာ ပိုမှန်ပါတယ် |
| App Clone | Work profile လို တရားဝင် အသုံးပြုမှုတွေ ရှိပါတယ် |

**အခြေခံ မူ —** ပိတ်တာ မှားရင် **ပိုက်ဆံပေးထားတဲ့ customer** ဆုံးရှုံးပါတယ်။
ဒါကြောင့် **သေချာမှသာ ပိတ်ပြီး၊ မသေချာရင် မှတ်တမ်းတင်ရုံ** သာ လုပ်ပါတယ်။

---

## ၆။ ပြဿနာ ဖြေရှင်းနည်း

| လက္ခဏာ | အကြောင်းရင်း | ဖြေရှင်းနည်း |
|---|---|---|
| **Play Store က ဒေါင်းတဲ့သူ အားလုံး 401** | `expected_cert_sha256` မှာ Play App Signing hash မပါသေးဘူး | Play Console → Setup → App signing က SHA-256 ကို ကူးပြီး array ထဲ **ဒုတိယ တန်ဖိုး** အဖြစ် ထည့်ပါ |
| **Direct Download သူ အားလုံး 401** | array ထဲ Play hash ပဲ ရှိပြီး ကိုယ့် `release-key.jks` hash မပါဘူး | `keytool -list -v -keystore release-key.jks` က SHA-256 ကို ထပ်ထည့်ပါ |
| Register မရ | `app_bootstrap_secret` က APK နဲ့ မတူ | `--dart-define` တန်ဖိုး ပြန်စစ် |
| `clock_skew` | ဖုန်းချိန် မှားနေတယ် | Auto date & time ဖွင့်ခိုင်း |
| စစ်မှန်တဲ့ App ကို ပိတ်ခံရ (App ထဲမှာ ပိတ်) | APK ထဲက `N4_CERT_SHA256` / `N4_CERT_SHA256_ALT` မှားနေ | build command ပြန်စစ်၊ colon `:` ဖြုတ်၊ အသေးစာလုံး ၆၄ လုံး |
| `app_nonces` ကြီးလာ | cron မလည်ဘူး | `php bin/cron.php --prune-only` |

> **မှတ်ချက် —** User မရှိသေးတဲ့အတွက် `require_device_auth = false` ပြန်ပြောင်းစရာ **မလိုပါ**။
> 401 အားလုံး ထွက်နေရင် အကြောင်းရင်းက အမြဲလိုလို **cert pin တစ်ခု ကျန်နေတာ** ပါ။

---

## ၇။ နောက်တစ်ဆင့် — Play Integrity API

**Play Integrity API** က Google က hardware အဆင့် အာမခံပေးတဲ့ စနစ်ဖြစ်ပြီး
smali patch လုပ်လို့ မရပါဘူး။ ဒါပေမဲ့ **အလိုအလျောက် မပါလာပါ** —
Play Console မှာ Google Cloud project ချိတ်ပြီး code ကိုယ်တိုင် ရေးရပါတယ်။

### ⚠️ Direct Download နဲ့ ပတ်သက်တဲ့ သတိပေးချက်

Play Console မှာ **"Automatic protection"** ဆိုတဲ့ သီးခြား option တစ်ခု ရှိပါတယ်
(App integrity စာမျက်နှာအောက်မှာ)။ ဒါက code မရေးဘဲ Google က installer စစ်တဲ့
code ကို AAB ထဲ ထည့်ပေးတာပါ။ **ဒါကို မဖွင့်ပါနဲ့။**

> Google ရဲ့ စာသားအတိုင်း — protected app ကို တခြား channel ကနေ ဖြန့်ရင်
> user ကို "Play Store ကနေ ပြန်ယူပါ" ဆိုတဲ့ dialog ပြပါလိမ့်မယ်။

သင့် App က **Play Store ရော Direct Download ရော** ထားမှာဖြစ်လို့
Automatic protection ဖွင့်လိုက်ရင် ကိုယ့် website ကနေ ဒေါင်းတဲ့သူတွေ
App သုံးလို့ မရတော့ပါဘူး။

### ဘယ်လို ထည့်သင့်လဲ (နောင်တစ်ချိန်)

| အဆင့် | လုပ်ရမယ့်အရာ |
|---|---|
| ၁ | Play Console → App integrity → Play Integrity API → Cloud project ချိတ် |
| ၂ | `com.google.android.play:integrity:1.5.0` dependency ထည့် |
| ၃ | Server မှာ token ကို Google API နဲ့ decode (App ထဲမှာ မစစ်ရ) |
| ၄ | **Install source ကို မစစ်ပါနဲ့** — `appIntegrity` ကို `PLAY_RECOGNIZED` မဟုတ်လို့ ပိတ်ရင် Direct Download သေပါတယ် |
| ၅ | ပထမပိုင်း **log ပဲ တင်ပါ**၊ data စုပြီးမှ ပိတ်ဖို့ ဆုံးဖြတ်ပါ |

**အခုချက်ချင်း မထည့်ပါနဲ့။** အကြောင်းရင်း ၂ ချက် —
Play Console မှာ App တင်ပြီးမှသာ Cloud project ချိတ်လို့ ရတာနဲ့၊
ချိတ်မထားခင် integrity call တွေက error ပြန်ပြီး App ဖွင့်လို့ မရနိုင်လို့ပါ။
