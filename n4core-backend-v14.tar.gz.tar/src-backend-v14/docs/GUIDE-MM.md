# N4 Core VPN — Backend & Dashboard လက်စွဲ (မြန်မာ)

> ဗားရှင်း : v2.1 · ရက်စွဲ : 2026-08-29
> Domain : `core.nandaxr.tech` · Path : `/var/www/n4core`
> Telegram Bot : `@CoreVN4NBOT` · Owner ID : `5567910560`

---

## မာတိကာ

| အပိုင်း | အကြောင်းအရာ |
|---|---|
| [၀](#part0) | ZIP ထဲမှာ ဘာတွေပါလဲ |
| [၁](#part1) | ပထမဆုံး လုပ်ရမယ့် အလုပ် (Patch တင်ခြင်း) |
| [၂](#part2) | **Domain အသစ် ပြောင်းခြင်း** — `n4core-domain.sh` |
| [၃](#part3) | **VPS အသစ် ပြောင်းခြင်း** — `n4core-migrate-vps.sh` |
| [၄](#part4) | GitHub `n4core-config.json` ပြင်ခြင်း |
| [၅](#part5) | လုံခြုံရေး Checklist (တစ်ခါတည်း လုပ်ထားရမယ့်) |
| [၆](#part6) | Backup စနစ် (Auto + Manual) |
| [၇](#part7) | Telegram Bot Command အားလုံး |
| [၈](#part8) | ပြဿနာတွေ ဖြေရှင်းနည်း (Troubleshooting) |
| [၉](#part9) | အမြဲသုံးရမယ့် Command အတိုချုပ် |

---

<a name="part0"></a>
## အပိုင်း ၀ — ZIP ထဲမှာ ဘာတွေပါလဲ

```
n4core-backend-v2-complete.zip
│
├── README-မြန်မာ.txt          ← အမြန်ဖတ်ရန် (ဒီ file ကို အရင်ဖတ်ပါ)
│
├── docs/
│   ├── GUIDE-MM.md            ← ဒီ file (အပြည့်အစုံ လက်စွဲ)
│   └── INSTALL.md             ← စတင် တပ်ဆင်ခြင်း (ပထမဆုံး install အတွက်)
│
├── deploy/
│   ├── n4core-domain.sh       ★ Domain ပြောင်းရန် Script
│   ├── n4core-migrate-vps.sh  ★ VPS ပြောင်းရန် Script
│   ├── nginx/n4core.conf      ← nginx နမူနာ
│   ├── apache/n4core.conf     ← apache နမူနာ
│   ├── systemd/               ← Auto Backup timer + Bot service
│   └── n4core.cron            ← crontab နမူနာ
│
├── config/config.sample.php   ← Config နမူနာ (config.php မပါ — လုံခြုံရေးအတွက်)
├── core/                      ← Library ၁၅ ဖိုင် (Auth, Db, Crypto, Bot, Backup ...)
├── api/                       ← API endpoint အားလုံး (public + admin + telegram)
├── admin/                     ← Dashboard (HTML + CSS + JS)
├── bin/                       ← CLI tools (install, cron, bot, migrate, keygen ...)
├── sql/                       ← schema_v2.sql + migrate_v1_to_v2.sql
└── storage/                   ← backups / logs / cache (အလွတ် folder)
```

**အရေးကြီး —** `config/config.php` (တကယ့် password, key ပါတဲ့ file) ကို ZIP ထဲ **မထည့်ထားပါ**။
VPS ပေါ်မှာ ရှိပြီးသား file ကို ဆက်သုံးပါ။ အသစ် install မှသာ `config.sample.php` ကို copy ယူပါ။

---

<a name="part1"></a>
## အပိုင်း ၁ — ပထမဆုံး လုပ်ရမယ့် အလုပ် (Patch တင်ခြင်း)

> **ဘာအတွက်လဲ?** Backup က Telegram ကို အောင်မြင်စွာ ပို့ပေမယ့် Dashboard ထဲမှာ အနီရောင်
> `failed` ပြနေတဲ့ ပြဿနာ + Admin role တွေ VIP account ခွဲထားခြင်း (role isolation) +
> Admin ကိုယ်တိုင် password ပြောင်းလို့ ရအောင် ဖြေရှင်းထားတဲ့ patch ဖြစ်ပါတယ်။

### ၁.၁ VPS ကို ဝင်ပါ

```bash
ssh root@core.nandaxr.tech
cd /var/www/n4core
```

### ၁.၂ မူရင်း file တွေကို အရင် backup ယူပါ

```bash
STAMP=$(date +%F-%H%M%S)
mkdir -p /root/n4core-before-patch-$STAMP
cp -a core/Auth.php core/Bot.php \
      api/admin/accounts.php api/admin/account_devices.php \
      api/admin/stats.php api/admin/session.php \
      api/admin/settings.php api/admin/backups.php \
      admin/assets/js/app.js \
      /root/n4core-before-patch-$STAMP/
echo "Backup ယူပြီး → /root/n4core-before-patch-$STAMP"
```

### ၁.၃ ZIP ထဲက file တွေကို အစားထိုးပါ

ZIP ကို local မှာ ဖြေပြီး အောက်ပါ ၁၀ ဖိုင်ကို VPS ပေါ် တင်ပါ (WinSCP / FileZilla / scp) :

```
core/Auth.php
core/Bot.php
api/admin/accounts.php
api/admin/account_devices.php
api/admin/stats.php
api/admin/session.php
api/admin/settings.php
api/admin/backups.php
admin/assets/js/app.js
bin/claim_vips.php
```

scp နဲ့ တင်ရင် :

```bash
# ကိုယ့် computer ပေါ်မှာ run ပါ (ZIP ဖြေထားတဲ့ folder ထဲကနေ)
scp core/Auth.php core/Bot.php root@core.nandaxr.tech:/var/www/n4core/core/
scp api/admin/{accounts,account_devices,stats,session,settings,backups}.php \
    root@core.nandaxr.tech:/var/www/n4core/api/admin/
scp admin/assets/js/app.js root@core.nandaxr.tech:/var/www/n4core/admin/assets/js/
scp bin/claim_vips.php root@core.nandaxr.tech:/var/www/n4core/bin/
```

### ၁.၄ ပိုင်ဆိုင်မှု (permission) ပြန်ပေးပါ

```bash
cd /var/www/n4core
chown -R www-data:www-data core api admin bin
find core api admin bin -type f -exec chmod 640 {} \;
chmod 750 bin/*.php
```

### ၁.၅ PHP syntax စစ်ပါ (မှားရင် site ပျက်မှာမို့ မဖြစ်မနေ စစ်ပါ)

```bash
for f in core/Auth.php core/Bot.php \
         api/admin/accounts.php api/admin/account_devices.php \
         api/admin/stats.php api/admin/session.php \
         api/admin/settings.php api/admin/backups.php \
         bin/claim_vips.php ; do
  php -l "$f"
done
```

ဖိုင် ၉ ခုအားလုံး `No syntax errors detected` ပြရမယ်။

### ၁.၆ Patch ရောက်ပြီလား စစ်ပါ

```bash
grep -c "OK_STATUS" admin/assets/js/app.js      # → 1 သို့မဟုတ် ပိုရမယ်
grep -c "'success'" api/admin/backups.php       # → 2 ရမယ်
grep -c "vipScopeSql" core/Auth.php             # → 1 ပိုရမယ်
```

### ၁.၇ PHP-FPM ကို reload ပါ

```bash
systemctl reload php8.1-fpm
systemctl status php8.1-fpm --no-pager | head -5
```

### ၁.၈ Browser cache ရှင်းပါ

Dashboard ကိုဖွင့်ပြီး **Ctrl + Shift + R** (Android Chrome ဆိုရင် Settings → Clear cache) နှိပ်ပါ။
`Backups` page ထဲမှာ အစိမ်းရောင် **`delivered`** / **`stored`** ပြရင် ပြီးပါပြီ။

### ၁.၉ VIP account အိုင်ရှင်နာ သတ်မှတ်ပါ (v1 က ရွှေ့လာတဲ့ account ၃ ခု)

```bash
# အရင် ဘယ်ဟာတွေလဲ ကြည့်ရုံ (ဘာမှ မပြောင်းဘူး)
sudo -u www-data php bin/claim_vips.php

# owner ကို ပိုင်ဆိုင်မှု ပေးမယ်ဆိုရင်
sudo -u www-data php bin/claim_vips.php --to owner --apply
```

---

<a name="part2"></a>
## အပိုင်း ၂ — Domain အသစ် ပြောင်းခြင်း ★

> Script : `deploy/n4core-domain.sh`
> Domain အသစ်တစ်ခု ဝယ်လိုက်တာမျိုး၊ ဒါမှမဟုတ် domain ပြောင်းလိုက်တာမျိုးဆိုရင် ဒီ script တစ်ခုနဲ့ ပြီးပါတယ်။

### ဒီ Script က ဘာတွေ အလိုအလျောက် လုပ်ပေးလဲ

| အဆင့် | လုပ်ဆောင်ချက် |
|---|---|
| ၁ | `config.php` နဲ့ ရှိပြီးသား nginx vhost ကို `/root/` ထဲ backup ယူ |
| ၂ | nginx vhost အသစ် ရေး (SSL ရှိရင် HTTPS + redirect၊ မရှိရင် HTTP) |
| ၂b | ထပ်နေတဲ့ vhost တွေ (default အပါအဝင်) ကို ရှာပြီး disable |
| ၃ | `config.php` ထဲ `cors.allowed_origins` ကို domain အသစ်နဲ့ ပြောင်း + syntax စစ် |
| ၄ | Let's Encrypt SSL certificate ထုတ် (`--ssl` ပါရင်) |
| ၅ | `nginx -t` စစ်ပြီး reload + `php-fpm` reload |
| ၆ | Telegram webhook ကို domain အသစ်နဲ့ ပြန်မှတ်ပုံတင် |
| ၇ | Health check ၈ ခု စစ် (admin 200၊ api 200၊ config 403 ...) |

### ၂.၁ Script ကို VPS ပေါ် တင်ပါ

```bash
# ကိုယ့် computer ပေါ်မှာ
scp deploy/n4core-domain.sh root@core.nandaxr.tech:/var/www/n4core/deploy/

# VPS ပေါ်မှာ
ssh root@core.nandaxr.tech
cd /var/www/n4core
chmod +x deploy/n4core-domain.sh
```

### ၂.၂ လက်ရှိ အခြေအနေ ကြည့်ပါ (ဘာမှ မပြောင်းဘူး)

```bash
sudo ./deploy/n4core-domain.sh --show
```

ဒီလို ပြပါလိမ့်မယ် :

```
   App directory   : /var/www/n4core
   PHP version     : 8.1.2
   PHP-FPM socket  : /run/php/php8.1-fpm.sock
   လက်ရှိ domain    : core.nandaxr.tech
   Brand           : N4 Core VPN
   Timezone        : Asia/Yangon
   DB              : n4core_user@127.0.0.1:3306/n4core_db
   Telegram owner  : 5567910560
   CORS origins    : https://core.nandaxr.tech
   nginx service   : active
   php-fpm service : active
```

### ၂.၃ ⚠️ DNS ကို အရင် ချိန်ပါ (ဒါမလုပ်ရင် SSL မရဘူး)

Domain ဝယ်ထားတဲ့ site (Namecheap / Cloudflare / GoDaddy) ထဲဝင်ပြီး :

| Type | Name | Value |
|---|---|---|
| A | `core` (ဒါမှမဟုတ် `@`) | **VPS ရဲ့ IP** |

VPS IP ကို သိရန် :

```bash
curl -s https://api.ipify.org ; echo
```

DNS ရောက်ပြီလား စစ်ရန် (၅–၃၀ မိနစ် စောင့်ရနိုင်) :

```bash
dig +short core.newdomain.com
# → VPS IP ပြရမယ်
```

### ၂.၄ အရင် စမ်းကြည့်ပါ (Dry Run — ဘာမှ တကယ် မပြောင်းဘူး)

```bash
sudo ./deploy/n4core-domain.sh core.newdomain.com --dry-run
```

အဆင့် ၇ ခု အားလုံး အစိမ်းရောင် ပြရင် တကယ် run လို့ရပါပြီ။

### ၂.၅ တကယ် ပြောင်းပါ (SSL ပါ)

```bash
sudo ./deploy/n4core-domain.sh core.newdomain.com --ssl
```

`--ssl` က Let's Encrypt certificate အလိုအလျောက် ထုတ်ပေးပါတယ် (certbot မရှိရင် install ပေးပါတယ်)။

**SSL မလိုဘူး / ခဏ HTTP နဲ့ စမ်းချင်ရင် :**

```bash
sudo ./deploy/n4core-domain.sh core.newdomain.com
```

### ၂.၆ Script ဆုံးရင် ဒီလို ပြပါလိမ့်မယ်

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   ✅ Domain ပြောင်းခြင်း ပြီးပါပြီ
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

   Dashboard : https://core.newdomain.com/admin/
   API base  : https://core.newdomain.com/api

   ⚠️ နောက်ဆုံး အဆင့် — GitHub ထဲ n4core-config.json ကို ဒီအတိုင်း ပြောင်းပါ :

   {
     "api_base_url": "https://core.newdomain.com/api",
     "maintenance": false,
     "message": ""
   }
```

**GitHub မပြင်ရင် App က domain အသစ်ကို မသိပါဘူး** — အပိုင်း ၄ ကို ဆက်ဖတ်ပါ။

### ၂.၇ Option အားလုံး

```bash
sudo ./deploy/n4core-domain.sh --show                        # လက်ရှိ အခြေအနေ
sudo ./deploy/n4core-domain.sh <domain>                       # HTTP နဲ့ ပြောင်း
sudo ./deploy/n4core-domain.sh <domain> --ssl                 # SSL ပါ ပြောင်း
sudo ./deploy/n4core-domain.sh <domain> --dry-run             # စမ်းရုံ
sudo ./deploy/n4core-domain.sh --app-dir /path <domain>       # path မတူရင်
```

### ၂.၈ မှားသွားရင် ပြန်ပြင်နည်း (Rollback)

Script က backup ကို `/root/n4core-domain-backup-<ရက်စွဲ>/` ထဲ ထားပေးထားပါတယ်။

```bash
ls -la /root/ | grep n4core-domain-backup
BK=/root/n4core-domain-backup-2026-08-29-140000     # ကိုယ့်ဟာနဲ့ အစားထိုးပါ

cp $BK/config.php /var/www/n4core/config/config.php
cp $BK/n4core.conf /etc/nginx/sites-available/n4core.conf
nginx -t && systemctl reload nginx
systemctl reload php8.1-fpm
```

---

<a name="part3"></a>
## အပိုင်း ၃ — VPS အသစ် ပြောင်းခြင်း ★

> Script : `deploy/n4core-migrate-vps.sh`
> Command ၃ ခု ရှိပါတယ် : **`check`** (စစ်) → **`export`** (ထုတ်) → **`import`** (ထည့်)

### ပုံစံ အလွယ်

```
  VPS အိုကြီး (ရှိပြီးသား)              VPS အသစ်
  ─────────────────────                ────────────
  ၁. check    (စစ်ပါ)
  ၂. export   (package ထုတ်)
        │
        └── scp ─────────────────────►  ၃. import  (ထည့်ပါ)
                                        ၄. n4core-domain.sh (domain ချိန်)
                                        ၅. GitHub ပြင်
```

### ၃.၁ [VPS အိုကြီး] စစ်ပါ

```bash
cd /var/www/n4core
chmod +x deploy/n4core-migrate-vps.sh
sudo ./deploy/n4core-migrate-vps.sh check
```

ဒီလို ပြပါလိမ့်မယ် :

```
   ✅ App directory       /var/www/n4core
   ✅ config.php          ရှိ
   ✅ PHP CLI             8.1.2
   ✅ MySQL client        ရှိ
   ✅ nginx               ရှိ
   ✅ tar                 ရှိ
   ✅ openssl             ရှိ
   ✅ curl                ရှိ
   ✅ DB ချိတ်ရ — table 16 ခု
   ✅ အောင်: 9   မအောင်: 0
```

`❌` ပါရင် အရင် ဖြေရှင်းပါ (ဥပမာ — `apt install mariadb-client`)။

### ၃.၂ [VPS အိုကြီး] Package ထုတ်ပါ

```bash
sudo ./deploy/n4core-migrate-vps.sh export
```

လုပ်ဆောင်ချက် ၅ ဆင့် :

1. `mysqldump` နဲ့ database အားလုံး ထုတ် (routines + triggers + events ပါ)
2. Code + storage ကူး (`dl/`, `.git`, cache တွေ မပါ)
3. `MANIFEST.txt` ရေး (server info, table count, domain, timezone ...)
4. `tar.gz` ဖိတ်
5. **AES-256-CBC နဲ့ encrypt** (key = `config.php` ထဲက `encryption_key`)

ဆုံးရင် :

```
   ✅ Encrypt ပြီး
   File   : /root/n4core-migrate-2026-08-29-140000.tar.gz.enc
   SHA256 : a1b2c3d4e5f6...
   Size   : 452K
```

### ၃.၃ Decrypt Key ကို ကူးထားပါ (မရှိရင် ဖြေလို့ မရဘူး!)

```bash
grep encryption_key /var/www/n4core/config/config.php
```

ထွက်လာတဲ့ စာကြောင်းထဲက `'...'` ကြားက value ကို **လုံခြုံတဲ့ နေရာမှာ ကူးထားပါ**
(Telegram Saved Messages / Password manager)။ ဒါက package ကို ဖြေတဲ့ password ဖြစ်ပါတယ်။

### ၃.၄ [VPS အသစ်] File ၂ ခု ပို့ပါ

```bash
# ကိုယ့် computer ပေါ်မှာ (ဒါမှမဟုတ် VPS အိုကြီးကနေ တိုက်ရိုက်)
scp root@OLD_VPS_IP:/root/n4core-migrate-*.tar.gz.enc  ./
scp root@OLD_VPS_IP:/var/www/n4core/deploy/n4core-migrate-vps.sh  ./

scp n4core-migrate-*.tar.gz.enc  root@NEW_VPS_IP:/root/
scp n4core-migrate-vps.sh        root@NEW_VPS_IP:/root/
```

> **သတိ —** `.enc` file က encrypt ထားတာမို့ `tar -xzf` နဲ့ တိုက်ရိုက် ဖြေလို့ **မရပါ**။
> `import` command ကိုသာ သုံးပါ။

### ၃.၅ [VPS အသစ်] ထည့်ပါ

```bash
ssh root@NEW_VPS_IP
cd /root
chmod +x n4core-migrate-vps.sh
sudo ./n4core-migrate-vps.sh import /root/n4core-migrate-2026-08-29-140000.tar.gz.enc
```

Decrypt key တောင်းလာရင် အပိုင်း ၃.၃ က key ကို ရိုက်ထည့်ပါ (မမြင်ရပါဘူး — ပုံမှန်ပါ)။

လုပ်ဆောင်ချက် ၈ ဆင့် အလိုအလျောက် :

| အဆင့် | လုပ်ဆောင်ချက် |
|---|---|
| ၁ | Decrypt + ဖြေ |
| ၂ | `database.sql` နဲ့ `app/` ပါလား စစ် |
| ၃ | `MANIFEST.txt` ပြ (ဘယ် server ကလာလဲ) |
| ၄ | လိုအပ်တဲ့ package တွေ install (nginx, php-fpm, mariadb, openssl ...) |
| ၅ | Code ကို `/var/www/n4core` ထဲ ထည့် (အိုတာကို `.old-<ရက်စွဲ>` လုပ်) |
| ၆ | Database + user ဖန်တီး → dump import |
| ၇ | Permission ချိန် (config.php = **400**) + systemd timer တင် |
| ၈ | ခဏတာ nginx vhost ရေး + health check ၅ ခု + DB row count ပြ |

ဆုံးရင် :

```
   ✅ Import ပြီးပါပြီ

   Servers      : 6
   VIP accounts : 3
   Admins       : 1
   Regions      : 11
   Price plans  : 3

   နောက်ဆက်တွဲ ၄ ဆင့် :
   ၁. DNS ကို ဒီ IP ဆီ ချိန်ပါ → 203.0.113.45
   ၂. sudo /var/www/n4core/deploy/n4core-domain.sh <domain> --ssl
   ၃. GitHub n4core-config.json ပြင်ပါ
   ၄. http://203.0.113.45/admin/ နဲ့ စမ်းကြည့်ပါ
```

### ၃.၆ [VPS အသစ်] Domain ချိန်ပါ

```bash
cd /var/www/n4core
sudo ./deploy/n4core-domain.sh core.nandaxr.tech --ssl
```

DNS က IP အသစ်ဆီ ရောက်ပြီးမှ run ပါ (မဟုတ်ရင် SSL မထွက်ဘူး)။

### ၃.၇ ပြီးရင် စစ်ရမယ့် အချက်များ

```bash
# Dashboard တက်လား
curl -sI https://core.nandaxr.tech/admin/ | head -1        # HTTP/2 200

# API ကောင်းလား
curl -s https://core.nandaxr.tech/api/public/plans.php | head -c 60
# → {"ok":true,...

# Config file ကာကွယ်ထားလား
curl -sI https://core.nandaxr.tech/config/config.php | head -1   # 403 ဒါမှမဟုတ် 404

# Telegram webhook ပြန်မှတ်ပုံတင်
sudo -u www-data php bin/setup_webhook.php https://core.nandaxr.tech

# Backup timer အလုပ်လုပ်လား
systemctl list-timers | grep n4core
```

### ၃.၈ VPS အိုကြီးကို ဘယ်တော့ ပိတ်မလဲ

**ရက် ၃–၇ လောက် စောင့်ပါ** — အောက်ပါ အားလုံး အဆင်ပြေမှ ပိတ်ပါ :

- [ ] Dashboard ဝင်လို့ရ (owner + admin ၂ မျိုး)
- [ ] Flutter App မှာ VIP login ရ
- [ ] Server list / Region / Price အားလုံး ပြ
- [ ] Telegram Bot က login alarm ပို့
- [ ] နေ့ခင်း ၁၂ နာရီ auto backup ရောက်
- [ ] Manual backup `/backup` ရ

---

<a name="part4"></a>
## အပိုင်း ၄ — GitHub `n4core-config.json` ပြင်ခြင်း

> **အရေးကြီးဆုံး အဆင့်** — App က domain ကို GitHub ကနေ ဖတ်တာမို့ ဒါမပြင်ရင်
> Domain/VPS ပြောင်းလိုက်တာ App ကို မသိပါဘူး။

### ၄.၁ Browser နဲ့ ပြင်နည်း (အလွယ်ဆုံး)

1. GitHub repo ကို ဖွင့်ပါ
2. `n4core-config.json` ကို နှိပ်ပါ
3. **✏️ (Edit) pencil** icon ကို နှိပ်ပါ
4. အောက်ပါအတိုင်း ပြင်ပါ :

```json
{
  "api_base_url": "https://core.newdomain.com/api",
  "maintenance": false,
  "message": ""
}
```

5. **Commit changes** နှိပ်ပါ

### ၄.၂ ဂရုစိုက်ရမယ့် အချက်

| ✅ မှန် | ❌ မှား |
|---|---|
| `https://core.newdomain.com/api` | `http://...` (https လိုတယ်) |
| `https://core.newdomain.com/api` | `https://core.newdomain.com/api/` (နောက်မှာ `/` မထည့်ရ) |
| `https://core.newdomain.com/api` | `https://core.newdomain.com` (`/api` ကျန်နေတယ်) |

### ၄.၃ ရောက်ပြီလား စစ်ပါ

```bash
curl -s https://raw.githubusercontent.com/USER/REPO/main/n4core-config.json
```

### ၄.၄ Maintenance mode (ပြင်နေတဲ့အချိန် App ကို ရပ်ချင်ရင်)

```json
{
  "api_base_url": "https://core.newdomain.com/api",
  "maintenance": true,
  "message": "စနစ် ပြုပြင်နေပါသည်။ ၃၀ မိနစ်အတွင်း ပြန်ရပါမည်။"
}
```

---

<a name="part5"></a>
## အပိုင်း ၅ — လုံခြုံရေး Checklist (တစ်ခါတည်း လုပ်ထားရမယ့်)

အောက်ပါ command တွေကို **အစဉ်အလိုက်** run ပါ။

### ၅.၁ VIP code / token တွေကို hash လုပ်ပါ

```bash
cd /var/www/n4core
sudo -u www-data php bin/migrate.php --hash-codes --hash-tokens
sudo -u www-data php bin/migrate.php --status
```

`still plain : 0` ၂ ခေါင်း ပြရမယ်။

### ၅.၂ Download folder ဖျက်ပါ (public ကနေ code မကူးလို့ရအောင်)

```bash
rm -rf /var/www/n4core/dl
```

### ၅.၃ Config ကို backup ယူပြီး lock ပါ

```bash
cp /var/www/n4core/config/config.php /root/n4core-config-$(date +%F).php
chmod 600 /root/n4core-config-*.php
chmod 400 /var/www/n4core/config/config.php
ls -la /var/www/n4core/config/config.php     # → -r-------- ပြရမယ်
```

> Config ပြင်ရင် — `chmod 600 config/config.php` → ပြင် → `chmod 400 config/config.php`

### ၅.၄ Permission အားလုံး ချိန်ပါ

```bash
cd /var/www/n4core
chown -R www-data:www-data .
find . -type d -exec chmod 750 {} \;
find . -type f -exec chmod 640 {} \;
chmod -R 770 storage
chmod 750 bin/*.php deploy/*.sh
chmod 400 config/config.php
```

### ၅.၅ Security curl စစ်ဆေးမှု ၅ ခု

```bash
D=https://core.nandaxr.tech

echo -n "config   : " ; curl -so /dev/null -w "%{http_code}\n" $D/config/config.php
echo -n "core     : " ; curl -so /dev/null -w "%{http_code}\n" $D/core/Auth.php
echo -n "storage  : " ; curl -so /dev/null -w "%{http_code}\n" $D/storage/
echo -n "admin    : " ; curl -so /dev/null -w "%{http_code}\n" $D/admin/
echo -n "api      : " ; curl -s $D/api/public/plans.php | head -c 12 ; echo
```

**မျှော်လင့်တဲ့ အဖြေ :**

| စစ်ဆေးမှု | ရရမယ့် code |
|---|---|
| config | **403** ဒါမှမဟုတ် **404** |
| core | **403** ဒါမှမဟုတ် **404** |
| storage | **403** ဒါမှမဟုတ် **404** |
| admin | **200** |
| api | `{"ok":true` |

`config` က **200** ပြရင် **အလွန်အန္တရာယ်ကြီး** — nginx vhost ပြန်ရေးပါ :

```bash
sudo ./deploy/n4core-domain.sh core.nandaxr.tech --ssl
```

### ၅.၆ Firewall ချိန်ပါ

```bash
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable
ufw status
```

### ၅.၇ အိုနေတဲ့ folder တွေ ရှင်းပါ (ရက် ၃-၇ လွန်မှ)

```bash
ls -la /var/www/ | grep old
rm -rf /var/www/n4core.old-*
rm -f /tmp/n4core.zip
```

---

<a name="part6"></a>
## အပိုင်း ၆ — Backup စနစ်

### ၆.၁ Auto Backup (နေ့စဉ် ရန်ကုန်စံတော်ချိန် ၁၂:၀၀ AM)

**တစ်ခါတည်း တင်ပါ :**

```bash
cd /var/www/n4core
cp deploy/systemd/n4core-backup.service /etc/systemd/system/
cp deploy/systemd/n4core-backup.timer   /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now n4core-backup.timer
systemctl list-timers | grep n4core
```

**စမ်းကြည့်ရန် :**

```bash
sudo -u www-data php bin/cron.php
```

### ၆.၂ Manual Backup ၃ နည်း

**နည်း ၁ — Dashboard ကနေ**
`Backups` page → **Run Backup** → scope (Full / Database / Files) ရွေး → နှိပ်

**နည်း ၂ — Telegram Bot ကနေ**
```
/backup          →  Full backup
/backup db       →  Database သာ
/backup files    →  File သာ
/backups         →  နောက်ဆုံး ၂၀ ခု စာရင်း
```

**နည်း ၃ — Command line ကနေ**
```bash
cd /var/www/n4core
sudo -u www-data php -r '
require "core/bootstrap.php";
$r = Backup::create("full", "manual", "cli");
echo $r["ok"] ? "OK ".$r["filename"]." (".Backup::human($r["size_bytes"]).")\n"
              : "FAILED ".$r["error"]."\n";
Backup::deliver($r);
'
```

### ၆.၃ Backup Status အနေအထား နားလည်ခြင်း

| Dashboard မှာ ပြတာ | အဓိပ္ပါယ် |
|---|---|
| 🟢 **stored** | ဖိတ်ပြီး၊ server ပေါ်မှာ သိမ်းထားပြီး (Telegram မပို့သေး) |
| 🟢 **delivered** | ဖိတ်ပြီး၊ **Telegram ကိုပါ ပို့ပြီး** ← အောင်မြင်တယ် |
| 🟡 **missing** | Database မှာ record ရှိပေမယ့် file ပျောက်နေတယ် |
| 🔵 **sending…** | Telegram ကို ပို့နေတယ် |
| 🔴 **failed** | မအောင်မြင်ဘူး (mouse ထောက်ရင် အကြောင်းအရင်း ပြ) |

> **သတိ —** အရင် version မှာ `delivered` ကို အနီရောင် `failed` လို့ မှားပြခဲ့တာ
> အပိုင်း ၁ patch နဲ့ ဖြေရှင်းပြီးပါပြီ။

### ၆.၄ Backup ကို ပြန်ဖြေနည်း (Restore)

```bash
cd /var/www/n4core/storage/backups
ls -la

# Encrypt ဖြေမယ် (key = config.php ထဲက encryption_key)
KEY=$(sudo php -r '$c=require "/var/www/n4core/config/config.php"; echo $c["security"]["encryption_key"];')
openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 \
  -in n4core-full-20260829-143600.tar.gz.enc \
  -out /tmp/restore.tar.gz -pass "pass:$KEY"

mkdir -p /tmp/restore && tar -xzf /tmp/restore.tar.gz -C /tmp/restore
ls -la /tmp/restore

# Database ပြန်ထည့်မယ် (သတိ! ရှိပြီးသားကို အစားထိုးမယ်)
mysql -u root n4core_db < /tmp/restore/database.sql

rm -rf /tmp/restore /tmp/restore.tar.gz
```

### ၆.၅ Backup သိမ်းသက်တမ်း

`config.php` ထဲ :

```php
'backup' => [
    'enabled'          => true,
    'retention_days'   => 14,     // ရက် ၁၄ ကျော်ရင် အလိုအလျောက် ဖျက်
    'encrypt'          => true,
    'telegram_max_mb'  => 45,     // ဒီထက်ကြီးရင် Telegram ကို မပို့
],
```

---

<a name="part7"></a>
## အပိုင်း ၇ — Telegram Bot Command အားလုံး

Bot : **@CoreVN4NBOT** · Owner ID : **5567910560**

### အားလုံး သုံးလို့ရ

| Command | အလုပ် |
|---|---|
| `/start` | Bot စတင် + မီနူး |
| `/help` | Command စာရင်း |
| `/cancel` | လုပ်နေတဲ့ အလုပ် ရပ် |
| `/whoami` | ကိုယ့် Telegram ID + အဆင့် ပြ |

### Owner သာ (5567910560)

| Command | အလုပ် |
|---|---|
| `/status` | Server အခြေအနေ အားလုံး (VIP, Server, Backup, Uptime) |
| `/vip` | VIP account စာရင်း |
| `/servers` | Server စာရင်း |
| `/logins` | နောက်ဆုံး login မှတ်တမ်း |
| `/alerts` | Login alarm on/off |
| `/admins` | Admin စာရင်း |
| `/backup` | Manual backup (`db` / `files` / အလွတ်=full) |
| `/backups` | Backup ၂၀ ခု စာရင်း |
| `/addadmin` | Admin အသစ် ဖန်တီး (wizard) |
| `/deladmin` | Admin ဖျက် |
| `/role` | Admin ရဲ့ role ပြောင်း |
| `/resetpw` | Admin password reset |
| `/revoke` | Session အားလုံး ရုပ်သိမ်း |
| `/unlock` | Lock ဖြစ်နေတဲ့ account ဖြေ |
| `/tgadd` | Telegram admin ထည့် |
| `/tgdel` | Telegram admin ဖျက် |
| `/tglist` | Telegram admin စာရင်း |

### Bot အလုပ်မလုပ်ရင်

```bash
cd /var/www/n4core

# Webhook အခြေအနေ ကြည့်
sudo -u www-data php bin/setup_webhook.php --info

# ပြန်မှတ်ပုံတင်
sudo -u www-data php bin/setup_webhook.php https://core.nandaxr.tech

# HTTPS မရသေးရင် long-polling နဲ့ ခဏ လည်ပတ်
sudo -u www-data php bin/bot.php
```

---

<a name="part8"></a>
## အပိုင်း ၈ — ပြဿနာတွေ ဖြေရှင်းနည်း

### ၈.၁ Dashboard အဖြူထူထူ / တက်မလာ

```bash
# nginx အလုပ်လုပ်လား
systemctl status nginx --no-pager | head -5
nginx -t

# php-fpm အလုပ်လုပ်လား
systemctl status php8.1-fpm --no-pager | head -5

# Error log ကြည့်
tail -50 /var/log/nginx/error.log
tail -50 /var/www/n4core/storage/logs/*.log

# ၂ ခုလုံး restart
systemctl restart php8.1-fpm nginx
```

### ၈.၂ `502 Bad Gateway`

php-fpm socket မတူတာ ဖြစ်နိုင်တယ် :

```bash
ls /run/php/                                  # ဘယ် socket ရှိလဲ ကြည့်
grep fastcgi_pass /etc/nginx/sites-available/n4core.conf
```

မတူရင် script က အလိုအလျောက် ရှာပေးမယ် :

```bash
sudo ./deploy/n4core-domain.sh core.nandaxr.tech
```

### ၈.၃ API က `{"ok":false,"error":"..."}` ပြ

```bash
# Database ချိတ်လား
sudo php -r '
$c = require "/var/www/n4core/config/config.php";
$d = $c["db"];
try {
  new PDO("mysql:host={$d["host"]};port={$d["port"]};dbname={$d["name"]}", $d["user"], $d["pass"]);
  echo "DB OK\n";
} catch (Exception $e) { echo "DB FAIL: ".$e->getMessage()."\n"; }
'

# Log ကြည့်
tail -50 /var/www/n4core/storage/logs/error.log
```

### ၈.၄ App မှာ Server list မပြ

| စစ်ရမယ့်အချက် | Command |
|---|---|
| GitHub config မှန်လား | `curl -s https://raw.githubusercontent.com/USER/REPO/main/n4core-config.json` |
| API တက်လား | `curl -s https://core.nandaxr.tech/api/public/servers.php \| head -c 100` |
| Server active ဖြစ်လား | Dashboard → Servers → `is_active` စစ် |
| SSL မှန်လား | `curl -sI https://core.nandaxr.tech/api/public/plans.php \| head -1` |

### ၈.၅ SSL certificate ပြဿနာ

```bash
# Certificate စာရင်း
certbot certificates

# သက်တမ်း တိုးမယ်
certbot renew --dry-run
certbot renew

# အသစ် ထုတ်မယ်
sudo ./deploy/n4core-domain.sh core.nandaxr.tech --ssl
```

DNS မှန်လား အရင် စစ်ပါ — `dig +short core.nandaxr.tech`

### ၈.၆ Admin password မေ့သွားရင်

```bash
cd /var/www/n4core
sudo -u www-data php bin/create_admin.php --username owner --reset --password 'အသစ်Password123!'
```

ဒါမှမဟုတ် Telegram က `/resetpw` သုံးပါ။

### ၈.၇ Account lock ဖြစ်နေရင်

```bash
sudo -u www-data php -r '
require "/var/www/n4core/core/bootstrap.php";
Db::run("UPDATE admin_users SET failed_attempts = 0, locked_until = NULL WHERE username = ?", ["owner"]);
echo "unlocked\n";
'
```

ဒါမှမဟုတ် Telegram က `/unlock` သုံးပါ။

### ၈.၈ Disk ပြည့်နေရင်

```bash
df -h
du -sh /var/www/n4core/storage/backups
du -sh /var/log

# Backup အိုတွေ ဖျက်
find /var/www/n4core/storage/backups -name "*.enc" -mtime +14 -delete

# Log ရှင်း
journalctl --vacuum-time=7d
```

---

<a name="part9"></a>
## အပိုင်း ၉ — အမြဲသုံးရမယ့် Command အတိုချုပ်

```bash
# ══ အခြေအနေ စစ် ══════════════════════════════════
cd /var/www/n4core
sudo ./deploy/n4core-domain.sh --show
sudo ./deploy/n4core-migrate-vps.sh check
systemctl status nginx php8.1-fpm --no-pager | head -20
systemctl list-timers | grep n4core

# ══ Domain ပြောင်း ═══════════════════════════════
sudo ./deploy/n4core-domain.sh core.newdomain.com --dry-run    # စမ်း
sudo ./deploy/n4core-domain.sh core.newdomain.com --ssl        # တကယ်

# ══ VPS ပြောင်း ══════════════════════════════════
sudo ./deploy/n4core-migrate-vps.sh export                     # အိုကြီးမှာ
sudo ./n4core-migrate-vps.sh import /root/n4core-migrate-*.enc # အသစ်မှာ

# ══ Backup ═══════════════════════════════════════
sudo -u www-data php bin/cron.php                              # manual
ls -lah storage/backups | tail -10                             # စာရင်း

# ══ Telegram ═════════════════════════════════════
sudo -u www-data php bin/setup_webhook.php --info
sudo -u www-data php bin/setup_webhook.php https://core.nandaxr.tech

# ══ Admin ════════════════════════════════════════
sudo -u www-data php bin/create_admin.php --username staff01 --role admin
sudo -u www-data php bin/create_admin.php --username owner --reset

# ══ Restart ══════════════════════════════════════
systemctl reload php8.1-fpm
nginx -t && systemctl reload nginx

# ══ Log ══════════════════════════════════════════
tail -f /var/log/nginx/error.log
tail -f storage/logs/error.log

# ══ လုံခြုံရေး စစ် ═══════════════════════════════
D=https://core.nandaxr.tech
curl -so /dev/null -w "config  %{http_code}\n" $D/config/config.php
curl -so /dev/null -w "admin   %{http_code}\n" $D/admin/
curl -s $D/api/public/plans.php | head -c 12 ; echo
```

---

## ဆက်သွယ်ရန် မှတ်စု

| အရာ | တန်ဖိုး |
|---|---|
| App path | `/var/www/n4core` |
| Dashboard | `https core.nandaxr.tech /admin/` |
| API base | `https core.nandaxr.tech /api` |
| Database | `n4core_db` / user `n4core_user` |
| PHP-FPM | `php8.1-fpm` |
| nginx vhost | `/etc/nginx/sites-available/n4core.conf` |
| Telegram Bot | `@CoreVN4NBOT` |
| Owner ID | `5567910560` |
| Timezone | `Asia/Yangon` |
| Auto backup | နေ့စဉ် `00:00` YGN |
| Config backup | `/root/n4core-config-*.php` |

---

*N4 Core VPN Backend v2.1 — 2026-08-29*
