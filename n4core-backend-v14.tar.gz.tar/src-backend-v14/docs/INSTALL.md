# N4 Core VPN — Backend v2 · တပ်ဆင်လမ်းညွှန် / Install Guide

> မြန်မာ + English. အဆင့်အတိုင်း အပေါ်မှအောက် လိုက်လုပ်ပါ။
> Follow top to bottom.

---

## 0. လိုအပ်ချက် / Requirements

| အရာ | အနည်းဆုံး |
|---|---|
| PHP | 8.1+ (8.2 / 8.3 / 8.4 ရ) |
| PHP extensions | `pdo_mysql` `openssl` `curl` `mbstring` `json` `zlib` |
| MySQL / MariaDB | MySQL 5.7+ / MariaDB 10.4+ |
| Web server | nginx + php-fpm **သို့မဟုတ်** Apache + mod_php |
| SSL | **မရှိမဖြစ်** — HTTPS မရှိရင် app က ချိတ်လို့မရ |
| Composer | ❌ မလိုပါ (dependency လုံးဝမရှိ) |

စစ်ရန် / Check:
```bash
php -v
php -m | grep -E "pdo_mysql|openssl|curl|mbstring|zlib"
```

---

## 1. Upload

```bash
# ကိုယ့်ကွန်ပျူတာက / from your machine
scp n4core-backend-v2.zip root@YOUR_VPS_IP:/tmp/

# VPS ထဲ / on the VPS
ssh root@YOUR_VPS_IP
cd /var/www
unzip /tmp/n4core-backend-v2.zip
mv n4core_backend_v2 n4core
cd n4core
rm -rf dl          # sandbox download folder — မလိုပါ
```

---

## 2. Timezone — 🔴 မလုပ်ရင် backup မဆင်း

```bash
sudo timedatectl set-timezone Asia/Yangon
date               # YGN အချိန် ပေါ်ရမယ်
```

Backup က YGN 12:00 AM မှာ ဆင်းရမှာဖြစ်လို့ server timezone မှန်ရမယ်။
The daily backup fires at 00:00 **server** time, so the OS timezone must be Asia/Yangon.

---

## 3. Database

```bash
sudo mysql -u root -p
```

```sql
CREATE DATABASE n4core_db
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE USER 'n4core'@'localhost'
  IDENTIFIED BY 'ခိုင်တဲ့_password_အသစ်';

GRANT ALL PRIVILEGES ON n4core_db.* TO 'n4core'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

👉 ဒီ password ကို မှတ်ထားပါ — အဆင့် ၄ မှာ လိုမယ်။

### 3a. Table တင် / Load tables

**အခြေအနေ (က) — အသစ်လုံးလုံး / fresh install**
```bash
mysql -u n4core -p n4core_db < sql/schema_v2.sql
```

**အခြေအနေ (ခ) — v1 data ရှိပြီးသား / upgrading from v1**
```bash
# ⚠️ အရင်ဆုံး backup!
mysqldump -u root -p old_database_name > /root/v1-backup-$(date +%F).sql

mysql -u n4core -p n4core_db < sql/schema_v2.sql
mysql -u n4core -p n4core_db < sql/migrate_v1_to_v2.sql
```

Migration က idempotent ဖြစ်တယ် (၂ ခါ run လည်း ဘာမှမပျက်)။
**VIP session တွေ မပျက်ဘူး** — အသုံးပြုသူတွေ ပြန် login လုပ်စရာ မလိုဘူး။

---

## 4. Config + Secret key တွေ

### 4a. Key ၄ ခု အလိုအလျောက် ဖန်တီး

```bash
php bin/keygen.php --write
```

ဒီ command က:
- `config/config.sample.php` ကနေ `config/config.php` ဖန်တီးမယ်
- key ၄ ခုကို **အလိုအလျောက် ထည့်ပေးမယ်** (လက်နဲ့ copy-paste မလို)
- file mode 0640 ချမယ်

Key ၄ ခု ဆိုတာ:

| Key | ဘာအလုပ်လုပ်လဲ | ပျောက်ရင် |
|---|---|---|
| `app_secret` | Admin session token ကို HMAC လက်မှတ်ထိုး | Admin logout (data မပျက်) |
| `encryption_key` | 🔴 VIP access code + backup archive ကို AES-256-GCM encrypt | **VIP code + backup အားလုံး ပြန်ဖတ်လို့မရ** |
| `pepper` | Password hash ထဲ ရောထည့် (DB ခိုးလည်း ဖြေမရ) | Password အားလုံး reset ရမယ် |
| `webhook_secret` | Telegram webhook ကို ၂ လုံး စစ် (URL path + header) | Webhook ပြန်တင်ရမယ် |

### 4b. 🔴 `encryption_key` ကို သီးသန့် backup ထားပါ

```bash
grep encryption_key config/config.php
```

output ကို **password manager / စာရွက် / offline USB** မှာ သိမ်းပါ။

> ဒီ key ပျောက်ရင် VIP access code တွေ လုံးဝ ပြန်ဖတ်လို့မရတော့ဘူး၊
> အရင် backup archive တွေလည်း decrypt လုပ်လို့မရတော့ဘူး။
> Go-live ပြီးရင် **မပြောင်းရဘူး** — ပြောင်းချင်ရင် `php bin/migrate.php --rekey`

### 4c. လက်နဲ့ ဖြည့်ရမှာ ၂ ခုပဲ

```bash
nano config/config.php
```

```php
'db' => [
    'host' => '127.0.0.1',
    'port' => 3306,
    'name' => 'n4core_db',
    'user' => 'n4core',
    'pass' => 'အဆင့် ၃ က password',        // ← ① ဒီတစ်ခု
],

'telegram' => [
    'bot_token' => '7123456789:AAH...',     // ← ② ဒီတစ်ခု (@BotFather က)
    'owner_id'  => 5567910560,              // ✅ ထည့်ပြီးသား
    'webhook_secret' => '...',              // ✅ keygen က ထည့်ပြီးသား
],

'app' => [
    'brand'    => 'N4 Core VPN',
    'timezone' => 'Asia/Yangon',            // ✅ ပြီးသား
],
```

### 4d. `bot_token` ဘယ်ကယူမလဲ

1. Telegram → **@BotFather** ရှာ
2. `/newbot`
3. နာမည် ထည့် — ဥပမာ `N4 Core Admin`
4. Username ထည့် — **`bot` နဲ့ ဆုံးရမယ်** — ဥပမာ `n4core_admin_bot`
5. Token ပြန်ရမယ်: `7123456789:AAHxYz-Example_1234567890`
6. ဒါကို `bot_token` မှာ ထည့်

🔴 Token ကို ဘယ်သူ့မှ မပြရဘူး။

---

## 5. Install စစ်ခြင်း + Admin ဖန်တီး

```bash
php bin/install.php
```

DB ချိတ်မိမမိ၊ table ပြည့်စုံမပြည့်စုံ၊ storage ရေးလို့ရမရ၊ key တွေ မှန်မမှန် စစ်ပေးမယ်။

```bash
php bin/create_admin.php owner "Owner" super_admin
```

Password ထွက်လာမယ် → **မှတ်ထားပါ**။ ပထမဆုံး login မှာ ပြောင်းခိုင်းမယ်။

Role ၂ မျိုး:
- `super_admin` — Server Add/Del + VIP Account + VIP Price + Admins + Backups + Settings
- `admin` — VIP Account Manage ချည်းသာ

---

## 6. Permission — လုံခြုံရေး

```bash
chown -R www-data:www-data /var/www/n4core
find /var/www/n4core -type d -exec chmod 750 {} \;
find /var/www/n4core -type f -exec chmod 640 {} \;
chmod -R 770 storage
chmod 400 config/config.php     # 🔒 read-only
```

Dashboard → Settings → Server status မှာ **Config file: locked (read-only)** ပြရမယ်။

---

## 7. Web Server

### nginx
```bash
cp deploy/nginx/n4core.conf /etc/nginx/sites-available/
nano /etc/nginx/sites-available/n4core.conf
#   api.example.com  →  ကိုယ့် domain
#   php8.2-fpm.sock  →  ကိုယ့် PHP version
ln -s /etc/nginx/sites-available/n4core.conf /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx
```

### Apache
```bash
cp deploy/apache/n4core.conf /etc/apache2/sites-available/
a2ensite n4core && a2enmod rewrite headers ssl
apache2ctl configtest && systemctl reload apache2
```

### SSL — မရှိမဖြစ်
```bash
certbot --nginx -d api.yourdomain.com
#   Apache ဆိုရင်:  certbot --apache -d api.yourdomain.com
```

### စစ်ရန် — source file တွေ ကာကွယ်မထားလား
```bash
curl -I https://api.yourdomain.com/config/config.php   # 403/404 ဖြစ်ရမယ်
curl -I https://api.yourdomain.com/core/Auth.php       # 403/404 ဖြစ်ရမယ်
curl -I https://api.yourdomain.com/storage/            # 403/404 ဖြစ်ရမယ်
```
200 ပြရင် **ရပ်** — web server config ပြန်စစ်ပါ။

---

## 8. Telegram Bot

### နည်းလမ်း ၁ — Webhook (အကြံပြု)
```bash
php bin/setup_webhook.php https://api.yourdomain.com
```

### နည်းလမ်း ၂ — Long polling (webhook မရရင်)
```bash
cp deploy/systemd/n4core-bot.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now n4core-bot
systemctl status n4core-bot
```

### စမ်း
Telegram မှာ ကိုယ့် bot ကို `/start` ပို့ — owner (5567910560) ဆိုရင် menu ပေါ်လာမယ်။

### Bot commands
| Command | အလုပ် |
|---|---|
| `/start` | Menu |
| `/addadmin` | Admin အသစ် ဖန်တီး (wizard) |
| `/admins` | Admin list + ဖျက် |
| `/backup` | ချက်ချင်း backup |
| `/report` | အခြေအနေ report |
| `/revoke` | VIP session ဖျက် |
| `/unlock` | Login block ဖြေ |

Owner ID `5567910560` က hardcode ဖြစ်လို့ ဘယ်သူမှ မဖျက်နိုင်ဘူး၊ alert အားလုံး ရမယ်။

---

## 9. Auto Backup — YGN 12:00 AM

### systemd (အကြံပြု)
```bash
cp deploy/systemd/n4core-backup.service /etc/systemd/system/
cp deploy/systemd/n4core-backup.timer   /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now n4core-backup.timer
systemctl list-timers | grep n4core      # နောက်ဆုံးအချိန် စစ်
```

### cron (systemd မရရင်)
```bash
crontab -e
```
```
0 0 * * * /usr/bin/php /var/www/n4core/bin/cron.php >> /var/www/n4core/storage/logs/cron.log 2>&1
```

### လက်နဲ့ စမ်း
```bash
sudo -u www-data php bin/cron.php
ls -la storage/backups/
```

Archive အထဲမှာ ပါတာ: `database.sql` (table အားလုံး) + `files/` (backend file အားလုံး) + `manifest.json`
AES-256-GCM encrypt ထားတယ်၊ 45 MB အောက်ဆိုရင် Telegram ကို ပို့မယ်။

---

## 10. GitHub Config — App ဆက်စပ်ရေး ⭐

Repo `Nanda-N4/Core` ထဲက **`n4core-config.json`** ကို ပြင်:

```json
{
  "api_base_url": "https://api.yourdomain.com/api"
}
```

> 🔒 **App src ကို လုံးဝ ပြင်စရာမလိုပါ။**
> API response shape (`{ok:true,data:{...}}`), field နာမည်, error code,
> `X-Vip-Token` header အားလုံး v1 နဲ့ အတိအကျ တူထားတယ်။
> ဒီ URL တစ်ခုပဲ ပြောင်းရင် ရှိပြီးသား app က ဆက်အလုပ်လုပ်ပါတယ်။
>
> The published Flutter app needs **no update** — only this URL changes.

---

## 11. အသုံးပြုပုံ / Using the dashboard

**URL:** `https://api.yourdomain.com/admin/`

| လုပ်ချင်တာ | Menu | Role |
|---|---|---|
| Server ထည့် (URL paste → auto-fill) | Servers → Add server | Super Admin |
| Region စီမံ | Regions | Super Admin |
| VIP account | VIP Accounts | Admin + Super |
| VIP ဈေးနှုန်း | VIP Prices | Super Admin |
| Admin စီမံ | Admins | Super Admin |
| Backup | Backups | Super Admin |
| Login history / audit | Security | Super Admin |
| Settings | Settings | Super Admin |
| 🌗 Dark ↔ Light | ညာအပေါ် `☀ ◐ ☾` | အားလုံး |

### Server ထည့်တဲ့အခါ — Paste ရုံပဲ
`Servers → Add server → Config / share link` box ထဲ URL paste လုပ်ရင်
**Region / Protocol / Address(IP) / Port** အလိုအလျောက် ဖြည့်ပေးမယ်။

ပံ့ပိုးတဲ့ format:
`vmess://` `vless://` `trojan://` `ss://` `ssr://` `socks://` `http(s)://`
`hysteria://` `hysteria2://` `hy2://` `tuic://` WireGuard `.conf` · Xray JSON · `host:port`

အများကြီး တစ်ခါတည်း ထည့်ချင်ရင် **Bulk import** သုံးပါ — တစ်လိုင်း တစ်ခု။

---

## 12. ပြဿနာ ဖြေရှင်းခြင်း / Troubleshooting

| လက္ခဏာ | အကြောင်းရင်း | ဖြေရှင်းချက် |
|---|---|---|
| Dashboard blank | JS 403 | `curl -I .../admin/assets/js/app.js` → 200 ဖြစ်ရမယ် |
| `db_connect_failed` | DB creds မှား | `config/config.php` → `db.*` စစ် |
| Login ဝင်ပြီး ချက်ချင်း ထွက် | `app_secret` မှား/မရှိ | `php bin/keygen.php --write` |
| VIP code ဖတ်လို့မရ | `encryption_key` ပြောင်းသွား | backup ကနေ key ပြန်ယူ |
| Backup 12 AM မဆင်း | server TZ မှား | အဆင့် ၂ ပြန်လုပ် · `systemctl list-timers` |
| Bot တုံ့မပြန် | token/webhook | `php bin/setup_webhook.php <url>` ပြန် run |
| App မှာ server မပေါ် | `n4core-config.json` URL မှား | အဆင့် ၁၀ စစ် |
| `500` error | log ကြည့် | `tail -50 storage/logs/app-$(date +%F).log` |

### Log ဖိုင်တွေ
```bash
tail -f storage/logs/app-$(date +%F).log     # application
journalctl -u n4core-bot -f                  # bot
journalctl -u n4core-backup -n 50            # backup
```

---

## 13. Go-live Checklist

- [ ] `date` က Asia/Yangon ပြတယ်
- [ ] `php bin/install.php` အားလုံး ✅
- [ ] `chmod 400 config/config.php` ချပြီး → Settings မှာ "locked" ပြတယ်
- [ ] `encryption_key` ကို သီးသန့် backup ထားပြီး 🔴
- [ ] HTTPS အလုပ်လုပ်တယ် (`certbot`)
- [ ] `/config/` `/core/` `/storage/` → 403/404
- [ ] Super admin login ဝင်ပြီး password ပြောင်းပြီး
- [ ] Bot `/start` တုံ့ပြန်တယ် · login alarm ရတယ်
- [ ] `php bin/cron.php` လက်နဲ့ စမ်း → archive ထွက်တယ်
- [ ] `systemctl list-timers` မှာ backup timer ပေါ်တယ်
- [ ] `n4core-config.json` URL အသစ် တင်ပြီး
- [ ] **App ကနေ** VIP login + server list ရတယ်
- [ ] Server 1 ခု paste နဲ့ ထည့်စမ်းပြီး auto-fill အလုပ်လုပ်တယ်

---

## 14. သတိပေးချက် / Security notes

- `config/config.php` ကို **git ထဲ တင်လိုက်** ဖြစ်ခဲ့ရင် key အားလုံး ပြောင်းပါ
- Chat / screenshot / ticket ထဲ password မထည့်ပါ — ရောက်သွားပြီးရင် အမြန်ပြောင်းပါ
- Release build မှာ demo/test/guest account **မထားပါ**
- `bin/*.php` တွေ CLI သာ — web ကနေ ခေါ်လို့မရအောင် ပိတ်ထားပြီး
- Rate limit: admin login 8/5min · VIP login 20/5min · public read 600/5min
- Session: idle 45 min · absolute 12 hr · UA fingerprint binding · per-session CSRF
