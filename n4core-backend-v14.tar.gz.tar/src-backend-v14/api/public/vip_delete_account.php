<?php
/**
 * POST /api/public/vip_delete_account.php
 * Header: X-Vip-Token
 *
 * Permanently deletes the signed-in VIP account. Required by the Google Play
 * "Data deletion" policy, which obliges an app with accounts to offer deletion
 * from inside the app as well as on the web.
 *
 * ⚠️ CONTRACT LOCK: v1 shape — { ok:true, data:{ deleted:true } }
 *
 * Unlike vip_logout.php this endpoint must NOT pretend to succeed. The client
 * (VipAuthService.deleteAccount) clears the local session only after a 200, so
 * that a network failure can never sign a user out of an account that still
 * exists. Any error here has to surface as a real HTTP error.
 *
 * vip_devices and vip_sessions are removed by the schema's
 * ON DELETE CASCADE, so deleting the account row is sufficient.
 */
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

if (Request::method() !== 'POST') {
    Response::methodNotAllowed(['POST']);
}

// The login profile, not the read profile: deletion is a rare, destructive
// action, and reusing an existing tight profile avoids adding a config key
// that an older config.php would not have.
RateLimiter::hit('vip_login', Request::ip());
DeviceAuth::require();

$vip = VipAuth::currentSession();

if ($vip === null) {
    // 401 is correct and useful here: the app shows "please sign in again"
    // and, crucially, keeps the local session untouched.
    Response::error('Session expired — please sign in again', 401);
}

$accountId = (string) $vip['id'];
$username  = (string) $vip['username'];

try {
    Db::run('DELETE FROM vip_accounts WHERE id = ?', [$accountId]);
} catch (Throwable $e) {
    Logger::error('vip_delete_failed', [
        'account' => $username,
        'msg'     => $e->getMessage(),
    ]);
    Response::error('Could not delete the account — please try again', 500);
}

// Recorded with actorType 'vip' so it is clear this was the user's own
// decision and not an admin action. The username is kept because the
// account row is gone and an audit trail with no subject is useless.
Audit::log(
    'vip_account_self_deleted',
    'vip_account',
    $accountId,
    ['username' => $username, 'ip' => Request::ip()],
    'vip',
    $accountId,
    $username
);

Response::ok(['deleted' => true]);
