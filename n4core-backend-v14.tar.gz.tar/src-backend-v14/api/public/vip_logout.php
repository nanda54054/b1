<?php
/**
 * POST /api/public/vip_logout.php
 * Header: X-Vip-Token
 *
 * ⚠️ CONTRACT LOCK: v1 shape — { ok:true, data:{ logged_out:true } }
 * Always succeeds (the app ignores failures here anyway).
 *
 * Revokes the session token but deliberately KEEPS the device binding, so
 * signing back in on the same device does not consume another slot.
 */
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

if (!in_array(Request::method(), ['POST', 'GET'], true)) {
    Response::methodNotAllowed(['POST']);
}

try {
    VipAuth::logout();
} catch (Throwable $e) {
    Logger::warn('vip_logout_error', ['msg' => $e->getMessage()]);
}

Response::ok(['logged_out' => true]);
