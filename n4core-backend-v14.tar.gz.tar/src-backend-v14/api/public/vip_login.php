<?php
/**
 * POST /api/public/vip_login.php
 * Body: { "username": "...", "access_code": "...", "device_id": "...",
 *         "device_label": "..." (optional) }
 *
 * ⚠️ CONTRACT LOCK — the shipped app branches on these exact error codes:
 *      invalid_credentials | inactive | expired | device_limit_reached
 * and reads: data.token, data.expires_at,
 *            data.account.{username,plan_name,device_limit,expires_at}
 *
 * Hardening added behind that contract: per-IP rate limiting, per-account
 * lockout, hashed access codes, hashed session tokens, and one live
 * session per device.
 */
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

if (Request::method() !== 'POST') {
    Response::methodNotAllowed(['POST']);
}

guard_maintenance();

// Login is the highest-value endpoint on the public surface — it is what a
// credential-stuffing run targets — so it gets the same device requirement
// as everything else. VipAuth::login() applies its own per-IP and
// per-account limits on top.
DeviceAuth::require();

$data = Request::body();
Request::requireFields($data, ['username', 'access_code', 'device_id']);

$payload = VipAuth::login(
    Request::str($data, 'username', 64),
    Request::str($data, 'access_code', 64),
    Request::str($data, 'device_id', 128),
    isset($data['device_label']) ? Request::str($data, 'device_label', 100) : null
);

Response::ok($payload);
