<?php
/**
 * GET /api/public/servers.php
 * Optional header: X-Vip-Token
 *
 * ⚠️ CONTRACT LOCK: response shape is identical to v1 —
 *   { ok:true, data:{ servers:[ {id,name,location_id,protocol,tier,address,
 *     port,raw_config,load_percent,sort_order,updated_at,location_name,
 *     country_code,flag_emoji,locked} ], vip_active: bool } }
 *
 * Security rules (unchanged, and now enforced harder):
 *   - free servers      -> raw_config always included
 *   - vip servers       -> raw_config ONLY with a valid VIP session,
 *                          otherwise blanked and locked = true
 * The lock decision happens server-side; a client cannot ask for more.
 */
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

if (Request::method() !== 'GET') {
    Response::methodNotAllowed(['GET']);
}

guard_maintenance();
RateLimiter::hit('config_read', Request::ip());

// Every /public/ endpoint now requires a signed request from a registered
// device. This is what turns `curl .../servers.php` from a 200 with every
// free config into a 401. See core/DeviceAuth.php.
DeviceAuth::require();

$vip = VipAuth::currentSession();   // null when not signed in / expired

$rows = Db::all(
    'SELECT s.id, s.name, s.location_id, s.protocol, s.tier, s.address, s.port,
            s.raw_config, s.load_percent, s.sort_order, s.updated_at,
            l.name AS location_name, l.country_code, l.flag_emoji
     FROM servers s
     JOIN locations l ON l.id = s.location_id
     WHERE s.is_enabled = 1 AND l.is_enabled = 1
     ORDER BY s.tier ASC, s.sort_order ASC, s.name ASC'
);

$out = [];
foreach ($rows as $row) {
    $isVipServer = ($row['tier'] === 'vip');

    if ($isVipServer && $vip === null) {
        // Advertise that the server exists so the UI can render a locked
        // tile, but never hand over the connection payload.
        $row['raw_config'] = '';
        $row['locked'] = true;
    } else {
        $row['locked'] = false;
    }

    $row['port']         = (int) $row['port'];
    $row['load_percent'] = (int) $row['load_percent'];
    $row['sort_order']   = (int) $row['sort_order'];

    $out[] = $row;
}

Response::ok([
    'servers'    => $out,
    'vip_active' => $vip !== null,
]);
