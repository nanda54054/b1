<?php
/**
 * POST /api/public/register_device.php
 *
 * Body:
 *   {
 *     "device_id"  : "<sha256 hex>",
 *     "timestamp"  : 1735689600,
 *     "signature"  : "<hmac hex>",
 *     "platform"   : "android",
 *     "model"      : "SM-A536E",
 *     "os_version" : "14",
 *     "app_version": "1.1.0",
 *     "integrity"  : { cert_sha256, signer_count, debuggable, debugger,
 *                      rooted, instrumented, cloned, installer }
 *   }
 *
 * Response:
 *   { ok: true, data: { device_secret: "<64 hex>" } }
 *
 * The secret is returned exactly once and stored encrypted server-side. The
 * app keeps it in the Android Keystore and signs every later request with it.
 *
 * ---------------------------------------------------------------------
 * THE BOOTSTRAP PROBLEM — stated plainly rather than glossed over
 * ---------------------------------------------------------------------
 *
 * This endpoint cannot itself require a device secret, because issuing that
 * secret is its whole job. It is therefore the weakest point in the chain,
 * and it is defended in depth rather than pretended away:
 *
 *   1. Certificate-derived key — a re-signed APK derives the wrong
 *      registration key and is refused. See core/DeviceAuth.php.
 *   2. Explicit certificate pin — security.expected_cert_sha256.
 *   3. Debuggable builds refused outright.
 *   4. Hard rate limit — device_reg, 5/hour/IP.
 *   5. Every rejection logged and alerted to Telegram, so a campaign is
 *      visible while it is happening.
 *   6. Anomaly banning — the durable win. Once a device has an identity,
 *      abuse is attributable and `banned = 1` makes it actionable.
 *
 * What this does NOT do: stop a determined reverse engineer. The bootstrap
 * secret and the certificate hash both exist inside the APK and can be
 * recovered with enough effort. The realistic effect is moving the attack
 * from "one curl command, two minutes" to "a day of native reverse
 * engineering, and the result gets banned".
 */
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

if (Request::method() !== 'POST') {
    Response::methodNotAllowed(['POST']);
}

// Deliberately NOT behind guard_maintenance(): a device must be able to
// register during a maintenance window, otherwise every new install that
// happens to arrive mid-window is permanently stuck unregistered.

$secret = DeviceAuth::register(Request::body());

Response::ok(['device_secret' => $secret]);
