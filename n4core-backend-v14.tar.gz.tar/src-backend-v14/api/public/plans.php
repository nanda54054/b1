<?php
/**
 * GET /api/public/plans.php
 *
 * ⚠️ CONTRACT LOCK: response shape is identical to v1 —
 *   { ok:true, data:{ plans:[ {id,name,device_limit,duration_days,
 *     price_label,is_popular,sort_order} ] } }
 * The shipped Flutter app (VipPlan.fromApiJson) depends on it. The new
 * price_amount/currency columns are appended (extra keys are ignored by
 * the app's parser) so future app versions can use them.
 */
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

if (Request::method() !== 'GET') {
    Response::methodNotAllowed(['GET']);
}

guard_maintenance();
RateLimiter::hit('public_read', Request::ip());
DeviceAuth::require();

$rows = Db::all(
    'SELECT id, name, device_limit, duration_days, price_label,
            price_amount, currency, is_popular, sort_order
     FROM vip_plans
     WHERE is_enabled = 1
     ORDER BY sort_order ASC'
);

foreach ($rows as &$r) {
    $r['device_limit']  = (int) $r['device_limit'];
    $r['duration_days'] = (int) $r['duration_days'];
    $r['sort_order']    = (int) $r['sort_order'];
    // v1 sent 1/0 for is_popular; the app accepts both true and 1.
    $r['is_popular']    = (int) $r['is_popular'];
    $r['price_amount']  = $r['price_amount'] !== null ? (float) $r['price_amount'] : null;
}
unset($r);

Response::ok(['plans' => $rows]);
