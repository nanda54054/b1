<?php
/**
 * GET /api/public/vip_status.php
 * Header: X-Vip-Token
 *
 * ⚠️ CONTRACT LOCK: v1 shape —
 *   invalid: { ok:true, data:{ valid:false } }
 *   valid:   { ok:true, data:{ valid:true, account:{username,plan_name,
 *                                device_limit,expires_at} } }
 *
 * The app treats a *missing* `valid` flag as valid and only signs out on
 * an explicit false, so this endpoint must always answer HTTP 200 with a
 * definite flag — never a 401 (that would be a transient-looking failure).
 */
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

if (!in_array(Request::method(), ['GET', 'POST'], true)) {
    Response::methodNotAllowed(['GET']);
}

// Deliberately NOT behind guard_maintenance(): a maintenance window must
// not look like "session invalid" to a paying user.
RateLimiter::hit('public_read', Request::ip());
DeviceAuth::require();

$vip = VipAuth::currentSession();

if ($vip === null) {
    Response::ok(['valid' => false]);
}

Response::ok([
    'valid'   => true,
    'account' => [
        'username'     => $vip['username'],
        'plan_name'    => $vip['plan_name'],
        'device_limit' => (int) $vip['device_limit'],
        'expires_at'   => $vip['account_expires_at'],
    ],
]);
