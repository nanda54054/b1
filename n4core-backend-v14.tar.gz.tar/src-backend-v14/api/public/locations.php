<?php
/**
 * GET /api/public/locations.php
 *
 * ⚠️ CONTRACT LOCK: response shape is identical to v1 —
 *    { ok: true, data: { locations: [ {id,name,country_code,flag_emoji,sort_order} ] } }
 * The shipped Flutter app (VpnLocation.fromApiJson) depends on it.
 */
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

if (Request::method() !== 'GET') {
    Response::methodNotAllowed(['GET']);
}

guard_maintenance();
RateLimiter::hit('public_read', Request::ip());
DeviceAuth::require();

$rows = Db::all(
    'SELECT id, name, country_code, flag_emoji, sort_order
     FROM locations
     WHERE is_enabled = 1
     ORDER BY sort_order ASC, name ASC'
);

// Normalise numeric types (PDO with emulation off returns ints already,
// but be explicit so the payload never changes shape between hosts).
foreach ($rows as &$r) {
    $r['sort_order'] = (int) $r['sort_order'];
}
unset($r);

Response::ok(['locations' => $rows]);
