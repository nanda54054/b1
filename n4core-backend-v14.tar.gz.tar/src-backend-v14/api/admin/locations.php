<?php
/**
 * Admin Locations CRUD — SUPER ADMIN ONLY for writes.
 *
 * GET    /api/admin/locations.php                 list all (+ server counts)
 * GET    /api/admin/locations.php?action=presets  presets not yet added
 * POST   /api/admin/locations.php                 create one
 * POST   /api/admin/locations.php?action=bulk     { items:[{country_code,...}] }
 * PUT    /api/admin/locations.php?id=UUID         update
 * DELETE /api/admin/locations.php?id=UUID         delete (cascades servers)
 */
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

$method = Request::method();
$action = (string) Request::query('action', '');
$id     = Request::id(Request::query('id'));

// ---------------------------------------------------------------- READ
if ($method === 'GET') {
    Auth::require('location.read');

    if ($action === 'presets') {
        Response::ok(['presets' => Locations::availablePresets()]);
    }

    $rows = Db::all(
        'SELECT l.*,
                (SELECT COUNT(*) FROM servers s WHERE s.location_id = l.id) AS server_count,
                (SELECT COUNT(*) FROM servers s WHERE s.location_id = l.id AND s.tier = \'vip\') AS vip_count
         FROM locations l
         ORDER BY l.sort_order ASC, l.name ASC'
    );
    foreach ($rows as &$r) {
        $r['sort_order']   = (int) $r['sort_order'];
        $r['is_enabled']   = (int) $r['is_enabled'];
        $r['server_count'] = (int) $r['server_count'];
        $r['vip_count']    = (int) $r['vip_count'];
    }
    unset($r);

    Response::ok(['locations' => $rows]);
}

if (!in_array($method, ['POST', 'PUT', 'DELETE'], true)) {
    Response::methodNotAllowed(['GET', 'POST', 'PUT', 'DELETE']);
}

Auth::require('location.write');
Auth::requireCsrf();
RateLimiter::hit('admin_write', Request::ip());

// ----------------------------------------------------------- BULK ADD
if ($method === 'POST' && $action === 'bulk') {
    $data  = Request::body();
    $items = is_array($data['items'] ?? null) ? $data['items'] : [];
    if (!$items) {
        Response::error('items must be a non-empty array', 422);
    }
    if (count($items) > 100) {
        $items = array_slice($items, 0, 100);
    }

    $added = [];
    foreach ($items as $item) {
        if (!is_array($item)) {
            continue;
        }
        $code = strtoupper(Request::str($item, 'country_code', 8));
        if ($code === '') {
            continue;
        }
        $name = Request::str($item, 'name', 100);
        $locId = Locations::ensure($code, $name !== '' ? $name : null);
        if ($locId !== null) {
            $added[] = ['id' => $locId, 'country_code' => $code];
        }
    }

    Audit::log('location.bulk_add', 'location', null, ['count' => count($added)]);
    Response::ok(['added' => $added, 'inserted_or_updated' => count($added)]);
}

// -------------------------------------------------------------- CREATE
if ($method === 'POST') {
    $data = Request::body();
    Request::requireFields($data, ['name', 'country_code']);

    $code = strtoupper(Request::str($data, 'country_code', 8));
    if (!preg_match('/^[A-Z]{2,8}$/', $code)) {
        Response::error('country_code must be 2-8 letters (e.g. SG)', 422);
    }

    if (Db::value('SELECT 1 FROM locations WHERE country_code = ?', [$code])) {
        Response::error('A location with that country code already exists', 409);
    }

    $flag = Request::str($data, 'flag_emoji', 16);
    if ($flag === '') {
        $preset = Locations::preset($code);
        $flag = $preset['flag'] ?? Locations::flagFor($code);
    }

    $newId = Crypto::uuid4();
    Db::run(
        'INSERT INTO locations (id, name, country_code, flag_emoji, sort_order, is_enabled)
         VALUES (?, ?, ?, ?, ?, ?)',
        [
            $newId,
            Request::str($data, 'name', 100),
            $code,
            $flag,
            Request::int($data, 'sort_order', 0, 0, 100000),
            Request::bool($data, 'is_enabled', true) ? 1 : 0,
        ]
    );

    Audit::log('location.create', 'location', $newId, ['code' => $code]);
    Response::ok(['id' => $newId], 201);
}

// -------------------------------------------------------------- UPDATE
if ($method === 'PUT') {
    if ($id === null) {
        Response::error('Missing or invalid id', 422);
    }
    $existing = Db::one('SELECT * FROM locations WHERE id = ?', [$id]);
    if (!$existing) {
        Response::error('Location not found', 404);
    }

    $data   = Request::body();
    $fields = [];
    $params = [];

    if (array_key_exists('name', $data)) {
        $fields[] = 'name = ?';
        $params[] = Request::str($data, 'name', 100);
    }
    if (array_key_exists('country_code', $data)) {
        $code = strtoupper(Request::str($data, 'country_code', 8));
        if (!preg_match('/^[A-Z]{2,8}$/', $code)) {
            Response::error('country_code must be 2-8 letters', 422);
        }
        $clash = Db::value('SELECT id FROM locations WHERE country_code = ? AND id <> ?', [$code, $id]);
        if ($clash) {
            Response::error('Another location already uses that country code', 409);
        }
        $fields[] = 'country_code = ?';
        $params[] = $code;
    }
    if (array_key_exists('flag_emoji', $data)) {
        $fields[] = 'flag_emoji = ?';
        $params[] = Request::str($data, 'flag_emoji', 16);
    }
    if (array_key_exists('sort_order', $data)) {
        $fields[] = 'sort_order = ?';
        $params[] = Request::int($data, 'sort_order', 0, 0, 100000);
    }
    if (array_key_exists('is_enabled', $data)) {
        $fields[] = 'is_enabled = ?';
        $params[] = Request::bool($data, 'is_enabled', true) ? 1 : 0;
    }

    if (!$fields) {
        Response::error('No fields to update', 422);
    }

    $params[] = $id;
    Db::run('UPDATE locations SET ' . implode(', ', $fields) . ' WHERE id = ?', $params);

    Audit::log('location.update', 'location', $id, ['name' => $existing['name']]);
    Response::ok(['updated' => true]);
}

// -------------------------------------------------------------- DELETE
if ($method === 'DELETE') {
    if ($id === null) {
        Response::error('Missing or invalid id', 422);
    }
    $existing = Db::one('SELECT name, country_code FROM locations WHERE id = ?', [$id]);
    if (!$existing) {
        Response::error('Location not found', 404);
    }

    $serverCount = (int) Db::value('SELECT COUNT(*) FROM servers WHERE location_id = ?', [$id]);
    // Deleting a region cascades to its servers, which is destructive —
    // require an explicit confirmation flag rather than doing it silently.
    if ($serverCount > 0 && Request::query('force') !== '1') {
        Response::error(
            "This region still has {$serverCount} server(s). Delete or move them first, "
            . 'or repeat the request with force=1 to remove them too.',
            409,
            ['server_count' => $serverCount]
        );
    }

    Db::run('DELETE FROM locations WHERE id = ?', [$id]);
    Audit::log('location.delete', 'location', $id, $existing + ['servers_removed' => $serverCount]);

    Response::ok(['deleted' => true, 'servers_removed' => $serverCount]);
}

Response::error('Unknown action', 400);
