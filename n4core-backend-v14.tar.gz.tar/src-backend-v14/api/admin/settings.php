<?php
/**
 * Runtime settings — SUPER ADMIN ONLY.
 *
 * These are the switches that used to require editing PHP files on the
 * VPS. They live in the `settings` table so the dashboard and the
 * Telegram bot both read the same truth.
 *
 * GET  /api/admin/settings.php
 * POST /api/admin/settings.php   { key: value, ... }
 */
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

/**
 * Whitelist of editable keys. Anything not listed here is rejected, so a
 * compromised dashboard session cannot invent new settings rows.
 *
 * type: bool | int | text | time
 */
const N4_SETTINGS = [
    'maintenance_mode'        => ['type' => 'bool', 'default' => '0',
        'label' => 'Maintenance mode (public API returns 503)'],
    'maintenance_message'     => ['type' => 'text', 'default' => '', 'max' => 300,
        'label' => 'Message shown to app users during maintenance'],
    'login_alert_enabled'     => ['type' => 'bool', 'default' => '1',
        'label' => 'Telegram alarm on every dashboard login'],
    'backup_auto_enabled'     => ['type' => 'bool', 'default' => '1',
        'label' => 'Automatic daily backup'],
    'backup_auto_time'        => ['type' => 'time', 'default' => '00:00',
        'label' => 'Daily backup time (Asia/Yangon)'],
    'backup_retention_days'   => ['type' => 'int', 'default' => '14', 'min' => 1, 'max' => 365,
        'label' => 'Keep backups for N days'],
    'backup_send_telegram'    => ['type' => 'bool', 'default' => '1',
        'label' => 'Send backup archive to Telegram'],
    'vip_isolate_by_admin'    => ['type' => 'bool', 'default' => '1',
        'label' => 'Admins see only the VIP accounts they created (Super Admin always sees all)'],
    'vip_signup_note'         => ['type' => 'text', 'default' => '', 'max' => 300,
        'label' => 'Internal note shown on the VIP page'],
    'free_servers_visible'    => ['type' => 'bool', 'default' => '1',
        'label' => 'Show FREE tier servers in the app'],
];

$method = Request::method();

// ---------------------------------------------------------------- READ
if ($method === 'GET') {
    Auth::require('settings.write'); // reading settings is equally sensitive

    $rows = [];
    try {
        foreach (Db::all('SELECT skey, svalue, updated_at FROM settings') as $r) {
            $rows[(string) $r['skey']] = $r;
        }
    } catch (Throwable) {
    }

    $out = [];
    foreach (N4_SETTINGS as $key => $meta) {
        $raw = $rows[$key]['svalue'] ?? $meta['default'];
        $out[] = [
            'key'        => $key,
            'label'      => $meta['label'],
            'type'       => $meta['type'],
            'value'      => match ($meta['type']) {
                'bool' => ((string) $raw === '1'),
                'int'  => (int) $raw,
                default => (string) $raw,
            },
            'updated_at' => $rows[$key]['updated_at'] ?? null,
        ];
    }

    Response::ok([
        'settings' => $out,
        'runtime'  => [
            'brand'          => (string) Config::get('app.brand', 'N4 Core VPN'),
            'timezone'       => (string) Config::get('app.timezone', 'Asia/Yangon'),
            'server_time'    => date('Y-m-d H:i:s'),
            'php_version'    => PHP_VERSION,
            'telegram_ready' => Telegram::enabled(),
            'backup_ready'   => is_dir(Config::storagePath('backups'))
                                && is_writable(Config::storagePath('backups')),
            'config_locked'  => !is_writable(__DIR__ . '/../../config'),
        ],
    ]);
}

if ($method !== 'POST') {
    Response::methodNotAllowed(['GET', 'POST']);
}

// -------------------------------------------------------------- WRITE
Auth::require('settings.write');
Auth::requireCsrf();
RateLimiter::hit('admin_write', Request::ip());

$data = Request::body();
if (!$data) {
    Response::error('Nothing to save', 422);
}

$saved   = [];
$skipped = [];

foreach ($data as $key => $value) {
    if (!isset(N4_SETTINGS[$key])) {
        $skipped[] = (string) $key;
        continue;
    }
    $meta = N4_SETTINGS[$key];

    switch ($meta['type']) {
        case 'bool':
            $store = Request::bool($data, (string) $key, false) ? '1' : '0';
            break;

        case 'int':
            $store = (string) Request::int(
                $data,
                (string) $key,
                (int) $meta['default'],
                $meta['min'] ?? null,
                $meta['max'] ?? null
            );
            break;

        case 'time':
            $t = trim((string) $value);
            if (!preg_match('/^([01]\d|2[0-3]):([0-5]\d)$/', $t)) {
                Response::error("Setting '$key' must be HH:MM (24-hour)", 422);
            }
            $store = $t;
            break;

        default: // text
            $store = mb_substr(trim((string) $value), 0, (int) ($meta['max'] ?? 300));
            break;
    }

    Config::putSetting((string) $key, $store);
    $saved[(string) $key] = $store;
}

if (!$saved) {
    Response::error('No recognised settings in the request', 422);
}

Audit::log('settings.update', 'settings', null, ['changed' => array_keys($saved)]);

// Maintenance mode is a big deal — always announce it in Telegram.
if (array_key_exists('maintenance_mode', $saved)) {
    $on = $saved['maintenance_mode'] === '1';
    $me = Auth::currentAdmin();
    Notifier::securityAlert(
        ($on ? '🛠 <b>Maintenance mode ON</b>' : '✅ <b>Maintenance mode OFF</b>')
        . "\nBy: <b>" . Telegram::esc((string) ($me['username'] ?? '?')) . '</b>'
    );
}

Response::ok(['saved' => array_keys($saved), 'ignored' => $skipped]);
