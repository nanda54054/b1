<?php
/**
 * POST /api/admin/login.php
 * Body: { "username": "...", "password": "..." }
 *
 * Returns { token, csrf, expires_at, admin{ id, username, display_name,
 *           role, must_change_password, permissions[] } }
 *
 * The dashboard stores the token in sessionStorage (not localStorage) and
 * sends it as X-Admin-Token, plus csrf as X-CSRF-Token on every write.
 */
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

if (Request::method() !== 'POST') {
    Response::methodNotAllowed(['POST']);
}

$data = Request::body();
Request::requireFields($data, ['username', 'password']);

$result = Auth::login(
    Request::str($data, 'username', 64),
    (string) ($data['password'] ?? '')
);

// Lets the dashboard calibrate its relative-time clock ("5m ago") against the
// server's timezone right away, instead of waiting for the next session ping.
$result['server_time'] = date('Y-m-d H:i:s');

Response::ok($result);
