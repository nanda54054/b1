<?php
/**
 * Registered app devices — SUPER ADMIN ONLY.
 *
 * GET  /api/admin/devices.php?page=1&per_page=50&filter=&q=
 * GET  /api/admin/devices.php?view=summary
 * POST /api/admin/devices.php?action=ban     { device_id, reason }
 * POST /api/admin/devices.php?action=unban   { device_id }
 *
 * ---------------------------------------------------------------------
 * Why this screen matters more than any client-side check
 * ---------------------------------------------------------------------
 *
 * Every local anti-tamper measure can eventually be patched — that is the
 * honest position taken throughout this codebase. What cannot be patched is
 * a ban applied here, because the device is refused by the server.
 *
 * The device id survives "Clear data", uninstall and reinstall (it is
 * derived from ANDROID_ID + package + signing certificate), so a ban sticks
 * to the phone rather than to an install. Short of a factory reset, a banned
 * device stays banned.
 *
 * The two columns to watch:
 *
 *   cert_sha256  — anything other than your official certificate is a
 *                  re-signed, i.e. modified, build
 *   req_count    — a device an order of magnitude above the median is
 *                  scraping, not browsing
 */
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

$method = Request::method();

// ==================================================================
// Ban / unban
// ==================================================================
if ($method === 'POST') {
    Auth::require('audit.read');   // super-admin only, same gate as audit
    Auth::requireCsrf();

    $action = (string) Request::query('action', '');
    $data   = Request::body();

    $deviceId = Request::str($data, 'device_id', 128);
    if ($deviceId === '') {
        Response::error('device_id is required', 422);
    }

    $exists = Db::one('SELECT device_id FROM app_devices WHERE device_id = ?', [$deviceId]);
    if ($exists === null) {
        Response::error('No such device', 404);
    }

    if ($action === 'ban') {
        $reason = Request::str($data, 'reason', 255);
        if ($reason === '') {
            $reason = 'Manual ban by administrator';
        }

        Db::run(
            'UPDATE app_devices SET banned = 1, ban_reason = ?, banned_at = NOW() WHERE device_id = ?',
            [$reason, $deviceId]
        );

        // Kill any live VIP session on that device too, otherwise the ban
        // does not take effect until the current 30-day token expires.
        Db::run(
            'UPDATE vip_sessions SET revoked_at = NOW() WHERE device_id = ? AND revoked_at IS NULL',
            [$deviceId]
        );

        Audit::log('device.ban', 'app_device', $deviceId, ['reason' => $reason]);
        Response::ok(['banned' => true]);
    }

    if ($action === 'unban') {
        Db::run(
            'UPDATE app_devices SET banned = 0, ban_reason = NULL, banned_at = NULL WHERE device_id = ?',
            [$deviceId]
        );
        Audit::log('device.unban', 'app_device', $deviceId);
        Response::ok(['banned' => false]);
    }

    Response::error('Unknown action', 400);
}

if ($method !== 'GET') {
    Response::methodNotAllowed(['GET', 'POST']);
}

Auth::require('audit.read');

$expectedCert = strtolower(trim((string) Config::get('security.expected_cert_sha256', '')));

// ==================================================================
// Summary
// ==================================================================
if ((string) Request::query('view', '') === 'summary') {
    $total   = (int) Db::value('SELECT COUNT(*) FROM app_devices');
    $banned  = (int) Db::value('SELECT COUNT(*) FROM app_devices WHERE banned = 1');
    $active  = (int) Db::value(
        'SELECT COUNT(*) FROM app_devices WHERE last_seen_at > DATE_SUB(NOW(), INTERVAL 7 DAY)'
    );

    // Devices whose certificate is not the official one — i.e. modified
    // builds that registered before the pin was enabled, or while it was off.
    $modded = 0;
    if ($expectedCert !== '') {
        $modded = (int) Db::value(
            'SELECT COUNT(*) FROM app_devices
              WHERE cert_sha256 IS NOT NULL AND cert_sha256 <> ?',
            [$expectedCert]
        );
    }

    Response::ok([
        'total'          => $total,
        'banned'         => $banned,
        'active_7d'      => $active,
        'modified_certs' => $modded,
        'enforcing'      => (bool) Config::get('security.require_device_auth', false),
        'cert_pinned'    => $expectedCert !== '',
    ]);
}

// ==================================================================
// List
// ==================================================================
$page    = max(1, Request::int($_GET, 'page', 1));
$perPage = Request::int($_GET, 'per_page', 50, 1, 200);
$filter  = (string) Request::query('filter', '');
$q       = trim((string) Request::query('q', ''));

$where  = [];
$params = [];

switch ($filter) {
    case 'banned':
        $where[] = 'banned = 1';
        break;
    case 'modified':
        // Re-signed builds.
        if ($expectedCert !== '') {
            $where[] = 'cert_sha256 IS NOT NULL AND cert_sha256 <> ?';
            $params[] = $expectedCert;
        }
        break;
    case 'rooted':
        $where[] = "integrity_flags LIKE '%\"rooted\":true%'";
        break;
    case 'instrumented':
        // Frida / Xposed — the signal most worth reviewing by hand.
        $where[] = "integrity_flags LIKE '%\"instrumented\":true%'";
        break;
    case 'heavy':
        $where[] = 'req_count > 5000';
        break;
}

if ($q !== '') {
    $where[] = '(device_id LIKE ? OR last_ip LIKE ? OR model LIKE ?)';
    $like = '%' . $q . '%';
    array_push($params, $like, $like, $like);
}

$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$total = (int) Db::value("SELECT COUNT(*) FROM app_devices {$whereSql}", $params);

$offset = ($page - 1) * $perPage;
$rows = Db::all(
    "SELECT device_id, cert_sha256, app_version, platform, model, os_version,
            integrity_flags, created_at, last_seen_at, last_ip, req_count,
            banned, ban_reason, banned_at
       FROM app_devices
       {$whereSql}
      ORDER BY last_seen_at DESC, created_at DESC
      LIMIT {$perPage} OFFSET {$offset}",
    $params
);

foreach ($rows as &$r) {
    $r['req_count'] = (int) $r['req_count'];
    $r['banned']    = (int) $r['banned'] === 1;

    $flags = json_decode((string) ($r['integrity_flags'] ?? ''), true);
    $r['integrity'] = is_array($flags) ? $flags : [];
    unset($r['integrity_flags']);

    // Pre-computed so the dashboard does not have to know the expected
    // certificate to colour the row.
    $r['cert_ok'] = $expectedCert === ''
        || $r['cert_sha256'] === null
        || strtolower((string) $r['cert_sha256']) === $expectedCert;

    // Never ship the full secret-adjacent identifier to the browser in a
    // form that invites copy-paste into a support chat.
    $r['device_short'] = substr((string) $r['device_id'], 0, 16) . '…';
}
unset($r);

Response::ok([
    'devices'  => $rows,
    'total'    => $total,
    'page'     => $page,
    'per_page' => $perPage,
    'pages'    => (int) ceil($total / max(1, $perPage)),
]);
