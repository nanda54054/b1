<?php
/**
 * GET /api/admin/stats.php
 * Dashboard overview: counters, expiring accounts, recent logins, and
 * (for Super Admins) the audit feed. One request instead of five, so the
 * dashboard paints fast.
 */
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

if (Request::method() !== 'GET') {
    Response::methodNotAllowed(['GET']);
}

$admin = Auth::require('stats.read');
$isSuper = Auth::can('audit.read');

$out = [];

// ---- VIP scoping -----------------------------------------------------
// A plain admin's dashboard must count only the accounts they own, or the
// totals would leak how many customers the other admins have.
[$vipScope, $vipParams] = Auth::vipScopeSql('a');
$vipWhere = $vipScope !== '' ? ' AND ' . $vipScope : '';   // for queries that already have a WHERE
$vipOnly  = $vipScope !== '' ? ' WHERE ' . $vipScope : ''; // for queries that have none

/** COUNT(*) over vip_accounts with the scope applied. */
$vipCount = static function (string $extra = '') use ($vipScope, $vipParams): int {
    $sql = 'SELECT COUNT(*) FROM vip_accounts a';
    $conds = [];
    if ($extra !== '') {
        $conds[] = $extra;
    }
    if ($vipScope !== '') {
        $conds[] = $vipScope;
    }
    if ($conds) {
        $sql .= ' WHERE ' . implode(' AND ', $conds);
    }
    return (int) Db::value($sql, $vipParams);
};

/** Devices / sessions belong to the accounts, so they inherit the scope. */
$childCount = static function (string $table) use ($vipScope, $vipParams): int {
    $sql = 'SELECT COUNT(*) FROM ' . $table . ' x';
    $conds = [];
    if ($table === 'vip_sessions') {
        $conds[] = 'x.revoked_at IS NULL AND x.expires_at > NOW()';
    }
    if ($vipScope !== '') {
        $conds[] = 'EXISTS (SELECT 1 FROM vip_accounts a WHERE a.id = x.account_id AND ' . $vipScope . ')';
    }
    if ($conds) {
        $sql .= ' WHERE ' . implode(' AND ', $conds);
    }
    return (int) Db::value($sql, $vipParams);
};

// ---- Counters -------------------------------------------------------
$out['counters'] = [
    'servers_total'    => (int) Db::value('SELECT COUNT(*) FROM servers'),
    'servers_enabled'  => (int) Db::value('SELECT COUNT(*) FROM servers WHERE is_enabled = 1'),
    'servers_free'     => (int) Db::value('SELECT COUNT(*) FROM servers WHERE tier = \'free\' AND is_enabled = 1'),
    'servers_vip'      => (int) Db::value('SELECT COUNT(*) FROM servers WHERE tier = \'vip\' AND is_enabled = 1'),
    'locations_total'  => (int) Db::value('SELECT COUNT(*) FROM locations'),
    'locations_active' => (int) Db::value('SELECT COUNT(*) FROM locations WHERE is_enabled = 1'),
    'plans_active'     => (int) Db::value('SELECT COUNT(*) FROM vip_plans WHERE is_enabled = 1'),
    'vip_total'        => $vipCount(),
    'vip_active'       => $vipCount('a.is_active = 1 AND a.expires_at > NOW()'),
    'vip_expired'      => $vipCount('a.expires_at <= NOW()'),
    'vip_disabled'     => $vipCount('a.is_active = 0'),
    'devices_bound'    => $childCount('vip_devices'),
    'sessions_live'    => $childCount('vip_sessions'),
];

// ---- Accounts expiring in the next 7 days ---------------------------
$out['expiring_soon'] = Db::all(
    'SELECT a.id, a.username, a.plan_name, a.expires_at,
            TIMESTAMPDIFF(HOUR, NOW(), a.expires_at) AS hours_left
     FROM vip_accounts a
     WHERE a.is_active = 1 AND a.expires_at > NOW()
       AND a.expires_at <= DATE_ADD(NOW(), INTERVAL 7 DAY)' . $vipWhere . '
     ORDER BY a.expires_at ASC
     LIMIT 25',
    $vipParams
);
foreach ($out['expiring_soon'] as &$e) {
    $e['hours_left'] = (int) $e['hours_left'];
    $e['days_left']  = (int) floor(((int) $e['hours_left']) / 24);
}
unset($e);

// ---- Signups / activity trend (last 14 days) ------------------------
$out['vip_trend'] = Db::all(
    'SELECT DATE(a.created_at) AS day, COUNT(*) AS count
     FROM vip_accounts a
     WHERE a.created_at >= DATE_SUB(CURDATE(), INTERVAL 13 DAY)' . $vipWhere . '
     GROUP BY DATE(a.created_at)
     ORDER BY day ASC',
    $vipParams
);
foreach ($out['vip_trend'] as &$t) {
    $t['count'] = (int) $t['count'];
}
unset($t);

// ---- Servers per region (for the dashboard chart) -------------------
$out['by_region'] = Db::all(
    'SELECT l.country_code, l.flag_emoji, l.name,
            COUNT(s.id) AS total,
            SUM(CASE WHEN s.tier = \'vip\' THEN 1 ELSE 0 END) AS vip
     FROM locations l
     LEFT JOIN servers s ON s.location_id = l.id AND s.is_enabled = 1
     WHERE l.is_enabled = 1
     GROUP BY l.id
     HAVING total > 0
     ORDER BY total DESC
     LIMIT 15'
);
foreach ($out['by_region'] as &$b) {
    $b['total'] = (int) $b['total'];
    $b['vip']   = (int) $b['vip'];
}
unset($b);

// ---- Security overview (super admin only) ---------------------------
if ($isSuper) {
    $out['recent_logins'] = Db::all(
        'SELECT kind, username, ip, reason, user_agent, created_at
         FROM login_events
         ORDER BY id DESC LIMIT 20'
    );

    $out['security'] = [
        'failed_24h'      => (int) Db::value(
            'SELECT COUNT(*) FROM login_events
             WHERE kind IN (\'admin_failed\', \'admin_locked\') AND created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)'
        ),
        'vip_failed_24h'  => (int) Db::value(
            'SELECT COUNT(*) FROM login_events
             WHERE kind = \'vip_failed\' AND created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)'
        ),
        'locked_admins'   => (int) Db::value(
            'SELECT COUNT(*) FROM admin_users WHERE locked_until IS NOT NULL AND locked_until > NOW()'
        ),
        'blocked_buckets' => (int) Db::value(
            'SELECT COUNT(*) FROM rate_limits WHERE blocked_until IS NOT NULL AND blocked_until > NOW()'
        ),
        'admins_total'    => (int) Db::value('SELECT COUNT(*) FROM admin_users WHERE is_active = 1'),
    ];

    $out['recent_audit'] = Db::all(
        'SELECT actor_type, actor_name, action, entity_type, entity_id, ip, created_at
         FROM audit_log ORDER BY id DESC LIMIT 20'
    );

    // A delivered archive is stored with status='sent', so the "last backup"
    // card must treat both 'ok' and 'sent' as success. Falling back to the
    // newest row of any status keeps a failure visible when there is nothing
    // good to show.
    $lastBackup = Db::one(
        "SELECT filename, kind, scope, size_bytes, status, delivered_tg, created_at
         FROM backups WHERE status IN ('ok','sent') ORDER BY id DESC LIMIT 1"
    ) ?: Db::one(
        'SELECT filename, kind, scope, size_bytes, status, delivered_tg, created_at
         FROM backups ORDER BY id DESC LIMIT 1'
    );
    $out['last_backup'] = $lastBackup ?: null;
    if ($out['last_backup']) {
        $out['last_backup']['size_human'] = Backup::human((int) $lastBackup['size_bytes']);
        $out['last_backup']['success']    = in_array((string) $lastBackup['status'], ['ok', 'sent'], true);
    }

    $out['telegram'] = [
        'configured' => Telegram::enabled(),
        'admins'     => (int) Db::value('SELECT COUNT(*) FROM telegram_admins WHERE is_active = 1'),
    ];
}

$out['server_time'] = date('Y-m-d H:i:s');
$out['timezone']    = (string) Config::get('app.timezone');

Response::ok($out);
