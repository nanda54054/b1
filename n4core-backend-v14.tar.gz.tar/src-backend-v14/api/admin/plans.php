<?php
/**
 * Admin VIP Plans / Pricing — SUPER ADMIN ONLY for writes.
 * (Regular Admins can read plans, because they need them when creating
 *  or extending VIP accounts, but they cannot change prices.)
 *
 * GET    /api/admin/plans.php
 * POST   /api/admin/plans.php
 * PUT    /api/admin/plans.php?id=UUID
 * DELETE /api/admin/plans.php?id=UUID
 */
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

$method = Request::method();
$id     = Request::id(Request::query('id'));

// ---------------------------------------------------------------- READ
if ($method === 'GET') {
    Auth::require('plan.read');

    $rows = Db::all(
        'SELECT p.*,
                (SELECT COUNT(*) FROM vip_accounts a WHERE a.plan_id = p.id) AS accounts_using
         FROM vip_plans p
         ORDER BY p.sort_order ASC'
    );
    foreach ($rows as &$r) {
        $r['device_limit']   = (int) $r['device_limit'];
        $r['duration_days']  = (int) $r['duration_days'];
        $r['sort_order']     = (int) $r['sort_order'];
        $r['is_popular']     = (int) $r['is_popular'];
        $r['is_enabled']     = (int) $r['is_enabled'];
        $r['accounts_using'] = (int) $r['accounts_using'];
        $r['price_amount']   = $r['price_amount'] !== null ? (float) $r['price_amount'] : null;
    }
    unset($r);

    Response::ok(['plans' => $rows]);
}

if (!in_array($method, ['POST', 'PUT', 'DELETE'], true)) {
    Response::methodNotAllowed(['GET', 'POST', 'PUT', 'DELETE']);
}

Auth::require('plan.write');
Auth::requireCsrf();
RateLimiter::hit('admin_write', Request::ip());

/** Builds "5,000 MMK / month" style labels when the admin leaves it blank. */
function auto_price_label(?float $amount, string $currency, int $days): string
{
    if ($amount === null || $amount <= 0) {
        return '';
    }
    $pretty = number_format($amount, fmod($amount, 1.0) === 0.0 ? 0 : 2);
    $period = match (true) {
        $days <= 1                 => 'day',
        $days <= 7                 => 'week',
        $days >= 28 && $days <= 31 => 'month',
        $days >= 88 && $days <= 95 => '3 months',
        $days >= 175 && $days <= 190 => '6 months',
        $days >= 360 && $days <= 370 => 'year',
        default                    => $days . ' days',
    };
    return "{$pretty} {$currency} / {$period}";
}

// -------------------------------------------------------------- CREATE
if ($method === 'POST') {
    $data = Request::body();
    Request::requireFields($data, ['name', 'device_limit', 'duration_days']);

    $devices  = Request::int($data, 'device_limit', 1, 1, 100);
    $days     = Request::int($data, 'duration_days', 30, 1, 3650);
    $currency = strtoupper(Request::str($data, 'currency', 8)) ?: 'MMK';
    $amountIn = $data['price_amount'] ?? null;
    $amount   = is_numeric($amountIn) ? round((float) $amountIn, 2) : null;
    if ($amount !== null && ($amount < 0 || $amount > 99999999)) {
        Response::error('price_amount is out of range', 422);
    }

    $label = Request::str($data, 'price_label', 50);
    if ($label === '') {
        $label = auto_price_label($amount, $currency, $days);
    }

    $newId = Crypto::uuid4();
    Db::run(
        'INSERT INTO vip_plans
           (id, name, device_limit, duration_days, price_label, price_amount,
            currency, is_popular, is_enabled, sort_order)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [
            $newId,
            Request::str($data, 'name', 100),
            $devices,
            $days,
            $label,
            $amount,
            $currency,
            Request::bool($data, 'is_popular', false) ? 1 : 0,
            Request::bool($data, 'is_enabled', true) ? 1 : 0,
            Request::int($data, 'sort_order', 0, 0, 100000),
        ]
    );

    Audit::log('plan.create', 'vip_plan', $newId, [
        'name' => Request::str($data, 'name', 100),
        'devices' => $devices, 'days' => $days, 'price' => $label,
    ]);

    Response::ok(['id' => $newId, 'price_label' => $label], 201);
}

// -------------------------------------------------------------- UPDATE
if ($method === 'PUT') {
    if ($id === null) {
        Response::error('Missing or invalid id', 422);
    }
    $existing = Db::one('SELECT * FROM vip_plans WHERE id = ?', [$id]);
    if (!$existing) {
        Response::error('Plan not found', 404);
    }

    $data   = Request::body();
    $fields = [];
    $params = [];

    if (array_key_exists('name', $data)) {
        $fields[] = 'name = ?';
        $params[] = Request::str($data, 'name', 100);
    }
    if (array_key_exists('device_limit', $data)) {
        $fields[] = 'device_limit = ?';
        $params[] = Request::int($data, 'device_limit', 1, 1, 100);
    }
    if (array_key_exists('duration_days', $data)) {
        $fields[] = 'duration_days = ?';
        $params[] = Request::int($data, 'duration_days', 30, 1, 3650);
    }
    if (array_key_exists('currency', $data)) {
        $fields[] = 'currency = ?';
        $params[] = strtoupper(Request::str($data, 'currency', 8)) ?: 'MMK';
    }
    if (array_key_exists('price_amount', $data)) {
        $a = $data['price_amount'];
        $amount = is_numeric($a) ? round((float) $a, 2) : null;
        if ($amount !== null && ($amount < 0 || $amount > 99999999)) {
            Response::error('price_amount is out of range', 422);
        }
        $fields[] = 'price_amount = ?';
        $params[] = $amount;
    }
    if (array_key_exists('price_label', $data)) {
        $label = Request::str($data, 'price_label', 50);
        if ($label === '') {
            $amount = array_key_exists('price_amount', $data) && is_numeric($data['price_amount'])
                ? (float) $data['price_amount']
                : ($existing['price_amount'] !== null ? (float) $existing['price_amount'] : null);
            $currency = array_key_exists('currency', $data)
                ? strtoupper(Request::str($data, 'currency', 8))
                : (string) $existing['currency'];
            $days = array_key_exists('duration_days', $data)
                ? Request::int($data, 'duration_days', 30, 1, 3650)
                : (int) $existing['duration_days'];
            $label = auto_price_label($amount, $currency ?: 'MMK', $days);
        }
        $fields[] = 'price_label = ?';
        $params[] = $label;
    }
    if (array_key_exists('is_popular', $data)) {
        $fields[] = 'is_popular = ?';
        $params[] = Request::bool($data, 'is_popular', false) ? 1 : 0;
    }
    if (array_key_exists('is_enabled', $data)) {
        $fields[] = 'is_enabled = ?';
        $params[] = Request::bool($data, 'is_enabled', true) ? 1 : 0;
    }
    if (array_key_exists('sort_order', $data)) {
        $fields[] = 'sort_order = ?';
        $params[] = Request::int($data, 'sort_order', 0, 0, 100000);
    }

    if (!$fields) {
        Response::error('No fields to update', 422);
    }

    $params[] = $id;
    Db::run('UPDATE vip_plans SET ' . implode(', ', $fields) . ' WHERE id = ?', $params);

    Audit::log('plan.update', 'vip_plan', $id, [
        'name' => $existing['name'],
        'changed' => array_map(fn($f) => explode(' ', $f)[0], $fields),
    ]);

    Response::ok(['updated' => true]);
}

// -------------------------------------------------------------- DELETE
if ($method === 'DELETE') {
    if ($id === null) {
        Response::error('Missing or invalid id', 422);
    }
    $existing = Db::one('SELECT name FROM vip_plans WHERE id = ?', [$id]);
    if (!$existing) {
        Response::error('Plan not found', 404);
    }

    // Accounts keep working (plan_name is denormalised on the account),
    // we just unlink them so nothing points at a missing row.
    Db::run('UPDATE vip_accounts SET plan_id = NULL WHERE plan_id = ?', [$id]);
    Db::run('DELETE FROM vip_plans WHERE id = ?', [$id]);

    Audit::log('plan.delete', 'vip_plan', $id, $existing);
    Response::ok(['deleted' => true]);
}

Response::error('Unknown action', 400);
