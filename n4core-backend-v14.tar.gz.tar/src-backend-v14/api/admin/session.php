<?php
/**
 * Session utilities for the dashboard.
 *
 * GET  /api/admin/session.php            -> who am I + permissions (session refresh)
 * POST /api/admin/session.php?action=logout
 * POST /api/admin/session.php?action=logout_all   -> kill every session of this admin
 * POST /api/admin/session.php?action=password     -> change own password
 *      { current_password, new_password }
 */
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

$method = Request::method();
$action = (string) Request::query('action', '');

// ---------------------------------------------------------------- GET
if ($method === 'GET') {
    $admin = Auth::requireAdmin();

    // Live counters so the dashboard header is useful at a glance.
    $stats = [];
    try {
        // The VIP count honours row-level scoping, otherwise a plain admin
        // could infer how many customers the other admins hold.
        [$vipScope, $vipParams] = Auth::vipScopeSql('a');
        $stats = [
            'servers'      => (int) Db::value('SELECT COUNT(*) FROM servers'),
            'vip_accounts' => (int) Db::value(
                'SELECT COUNT(*) FROM vip_accounts a'
                . ($vipScope !== '' ? ' WHERE ' . $vipScope : ''),
                $vipParams
            ),
        ];
    } catch (Throwable) {
    }

    Response::ok([
        'admin' => [
            'id'                   => (int) $admin['admin_id'],
            'username'             => $admin['username'],
            'display_name'         => $admin['display_name'],
            'role'                 => $admin['role'],
            'must_change_password' => (bool) (int) $admin['must_change_password'],
            'permissions'          => Auth::permissionsFor((string) $admin['role']),
            // Lets the UI say "your accounts" instead of "all accounts".
            'vip_scoped'           => Auth::vipScopedToSelf(),
        ],
        'expires_at' => $admin['expires_at'],
        'stats'      => $stats,
        'brand'      => (string) Config::get('app.brand', 'N4 Core VPN'),
        'timezone'   => (string) Config::get('app.timezone', 'Asia/Yangon'),
        // Lets the dashboard calibrate relative times ('5m ago') against the
        // server clock instead of the viewer's, which may be in another zone.
        'server_time' => date('Y-m-d H:i:s'),
    ]);
}

if ($method !== 'POST') {
    Response::methodNotAllowed(['GET', 'POST']);
}

// ------------------------------------------------------------- LOGOUT
if ($action === 'logout') {
    $admin = Auth::currentAdmin();
    if ($admin) {
        Audit::log('admin.logout', 'admin_user', (string) $admin['admin_id']);
    }
    Auth::logout();
    Response::ok(['logged_out' => true]);
}

if ($action === 'logout_all') {
    $admin = Auth::requireAdmin();
    Auth::revokeAllFor((int) $admin['admin_id']);
    Audit::log('admin.logout_all', 'admin_user', (string) $admin['admin_id']);
    Response::ok(['logged_out' => true]);
}

// ---------------------------------------------------------- PASSWORD
if ($action === 'password') {
    // Deliberately uses the special 'self.password' capability so an
    // admin flagged must_change_password can still get through here.
    $admin = Auth::require('self.password');
    Auth::requireCsrf();

    $data = Request::body();
    Request::requireFields($data, ['current_password', 'new_password']);

    $current = (string) $data['current_password'];
    $new     = (string) $data['new_password'];

    RateLimiter::hit('admin_write', Request::ip() . ':pw');

    $row = Db::one('SELECT password_hash FROM admin_users WHERE id = ?', [$admin['admin_id']]);
    if (!$row || !Crypto::verifySecret($current, (string) $row['password_hash'])) {
        Logger::warn('password_change_bad_current', ['admin' => $admin['username']]);
        Response::error('Current password is incorrect', 401);
    }

    if (Crypto::equals($current, $new)) {
        Response::error('New password must be different from the current one', 422);
    }

    $problem = Auth::validatePassword($new);
    if ($problem !== null) {
        Response::error($problem, 422);
    }

    Db::run(
        'UPDATE admin_users
         SET password_hash = ?, must_change_password = 0, password_changed_at = NOW()
         WHERE id = ?',
        [Crypto::hashSecret($new), $admin['admin_id']]
    );

    // Changing a password invalidates every other session for safety.
    Db::run(
        'UPDATE admin_sessions SET revoked_at = NOW()
         WHERE admin_id = ? AND id <> ? AND revoked_at IS NULL',
        [$admin['admin_id'], $admin['session_id']]
    );

    Audit::log('admin.password_changed', 'admin_user', (string) $admin['admin_id']);
    Notifier::securityAlert(
        "🔑 <b>Password changed</b>\n"
        . "User: <code>" . Telegram::esc((string) $admin['username']) . "</code>\n"
        . "Role: " . Telegram::esc((string) $admin['role']) . "\n"
        . "IP: <code>" . Telegram::esc(Request::ip()) . "</code>"
    );

    Response::ok(['changed' => true]);
}

Response::error('Unknown action', 400);
