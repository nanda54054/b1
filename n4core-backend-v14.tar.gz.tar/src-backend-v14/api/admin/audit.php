<?php
/**
 * Audit trail + login history — SUPER ADMIN ONLY.
 *
 * GET /api/admin/audit.php?page=1&per_page=50&action=&actor=&q=
 * GET /api/admin/audit.php?view=logins&page=1&kind=
 * GET /api/admin/audit.php?view=sessions          live admin sessions
 * GET /api/admin/audit.php?view=blocks            active rate-limit blocks
 * POST /api/admin/audit.php?action=clear_block    { bucket }
 */
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

$method = Request::method();
$view   = (string) Request::query('view', 'audit');

// ------------------------------------------------------- clear a block
if ($method === 'POST') {
    Auth::require('audit.read');
    Auth::requireCsrf();

    if ((string) Request::query('action', '') !== 'clear_block') {
        Response::error('Unknown action', 400);
    }

    $data   = Request::body();
    $bucket = Request::str($data, 'bucket', 160);
    if ($bucket === '') {
        Response::error('bucket is required', 422);
    }

    Db::run('DELETE FROM rate_limits WHERE bucket = ?', [$bucket]);

    // Unlocking a bucket for an admin username should also clear the
    // per-account lockout, otherwise the admin is still stuck.
    if (str_starts_with($bucket, 'admin_login:')) {
        Db::run('UPDATE admin_users SET failed_attempts = 0, locked_until = NULL WHERE locked_until IS NOT NULL');
    }

    Audit::log('security.clear_block', 'rate_limit', $bucket);
    Response::ok(['cleared' => true]);
}

if ($method !== 'GET') {
    Response::methodNotAllowed(['GET', 'POST']);
}

Auth::require('audit.read');

$page    = max(1, (int) (Request::query('page') ?? '1'));
$perPage = (int) (Request::query('per_page') ?? '50');
$perPage = max(10, min(200, $perPage));
$offset  = ($page - 1) * $perPage;

// ------------------------------------------------------- live sessions
if ($view === 'sessions') {
    $rows = Db::all(
        'SELECT s.id, s.ip, s.user_agent, s.created_at, s.last_seen_at,
                s.expires_at, s.absolute_expires_at,
                a.id AS admin_id, a.username, a.role
         FROM admin_sessions s
         JOIN admin_users a ON a.id = s.admin_id
         WHERE s.revoked_at IS NULL AND s.expires_at > NOW()
         ORDER BY s.last_seen_at DESC
         LIMIT 100'
    );
    foreach ($rows as &$r) {
        $r['id']       = (int) $r['id'];
        $r['admin_id'] = (int) $r['admin_id'];
    }
    unset($r);

    Response::ok(['sessions' => $rows]);
}

// -------------------------------------------------- rate-limit blocks
if ($view === 'blocks') {
    $rows = Db::all(
        'SELECT bucket, hits, window_start, blocked_until, updated_at
         FROM rate_limits
         WHERE blocked_until IS NOT NULL AND blocked_until > NOW()
         ORDER BY blocked_until DESC
         LIMIT 100'
    );
    foreach ($rows as &$r) {
        $r['hits'] = (int) $r['hits'];
        [$profile, $key] = array_pad(explode(':', (string) $r['bucket'], 2), 2, '');
        $r['profile'] = $profile;
        $r['key']     = $key;
    }
    unset($r);

    $locked = Db::all(
        'SELECT id, username, role, failed_attempts, locked_until
         FROM admin_users
         WHERE locked_until IS NOT NULL AND locked_until > NOW()'
    );
    foreach ($locked as &$l) {
        $l['id']              = (int) $l['id'];
        $l['failed_attempts'] = (int) $l['failed_attempts'];
    }
    unset($l);

    Response::ok(['blocks' => $rows, 'locked_admins' => $locked]);
}

// ------------------------------------------------------ login history
if ($view === 'logins') {
    $where  = [];
    $params = [];

    $kind = (string) Request::query('kind', '');
    if ($kind !== '' && in_array($kind, ['admin_success', 'admin_failed', 'admin_locked', 'vip_success', 'vip_failed'], true)) {
        $where[]  = 'kind = ?';
        $params[] = $kind;
    }
    $q = trim((string) Request::query('q', ''));
    if ($q !== '') {
        $where[]  = '(username LIKE ? OR ip LIKE ?)';
        $params[] = '%' . $q . '%';
        $params[] = '%' . $q . '%';
    }

    $sqlWhere = $where ? 'WHERE ' . implode(' AND ', $where) : '';
    $total    = (int) Db::value("SELECT COUNT(*) FROM login_events $sqlWhere", $params);

    $rows = Db::all(
        "SELECT id, kind, username, admin_id, ip, user_agent, reason, created_at
         FROM login_events $sqlWhere
         ORDER BY id DESC
         LIMIT $perPage OFFSET $offset",
        $params
    );
    foreach ($rows as &$r) {
        $r['id'] = (int) $r['id'];
    }
    unset($r);

    Response::ok([
        'logins' => $rows,
        'page'   => $page,
        'per_page' => $perPage,
        'total'  => $total,
        'pages'  => (int) ceil($total / $perPage),
    ]);
}

// ---------------------------------------------------------- audit feed
$where  = [];
$params = [];

$actionFilter = trim((string) Request::query('action', ''));
if ($actionFilter !== '' && $actionFilter !== 'clear_block') {
    $where[]  = 'action LIKE ?';
    $params[] = $actionFilter . '%';
}
$actor = trim((string) Request::query('actor', ''));
if ($actor !== '') {
    $where[]  = 'actor_name LIKE ?';
    $params[] = '%' . $actor . '%';
}
$q = trim((string) Request::query('q', ''));
if ($q !== '') {
    $where[]  = '(entity_id LIKE ? OR detail LIKE ? OR ip LIKE ?)';
    $params[] = '%' . $q . '%';
    $params[] = '%' . $q . '%';
    $params[] = '%' . $q . '%';
}

$sqlWhere = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$total    = (int) Db::value("SELECT COUNT(*) FROM audit_log $sqlWhere", $params);

$rows = Db::all(
    "SELECT id, actor_type, actor_id, actor_name, action, entity_type,
            entity_id, detail, ip, user_agent, created_at
     FROM audit_log $sqlWhere
     ORDER BY id DESC
     LIMIT $perPage OFFSET $offset",
    $params
);

foreach ($rows as &$r) {
    $r['id'] = (int) $r['id'];
    // detail is stored as JSON text; decode so the UI does not have to.
    if (!empty($r['detail'])) {
        $decoded = json_decode((string) $r['detail'], true);
        $r['detail'] = is_array($decoded) ? $decoded : ['raw' => $r['detail']];
    } else {
        $r['detail'] = null;
    }
}
unset($r);

// Distinct action prefixes so the UI can build a filter dropdown.
$actions = [];
foreach (Db::all('SELECT DISTINCT action FROM audit_log ORDER BY action ASC LIMIT 200') as $a) {
    $actions[] = (string) $a['action'];
}

Response::ok([
    'entries'  => $rows,
    'actions'  => $actions,
    'page'     => $page,
    'per_page' => $perPage,
    'total'    => $total,
    'pages'    => (int) ceil($total / $perPage),
]);
