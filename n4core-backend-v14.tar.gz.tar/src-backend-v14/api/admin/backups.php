<?php
/**
 * Backup control — SUPER ADMIN ONLY.
 *
 * GET    /api/admin/backups.php                    catalogue + disk usage
 * POST   /api/admin/backups.php?action=run         { scope: full|db|files, send_telegram? }
 * GET    /api/admin/backups.php?action=download&file=NAME
 * DELETE /api/admin/backups.php?file=NAME
 *
 * "Manual backup" in the dashboard and "/backup" in Telegram both land
 * on the same engine (core/Backup.php), so the archives are identical.
 */
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

$method = Request::method();
$action = (string) Request::query('action', '');

/** Filenames only — never a path. Blocks traversal outright. */
function backup_safe_name(?string $raw): string
{
    $name = basename(trim((string) $raw));
    if ($name === '' || !preg_match('/^n4core-[A-Za-z0-9._-]{4,180}$/', $name)) {
        Response::error('Invalid backup filename', 422);
    }
    return $name;
}

// ---------------------------------------------------------------- READ
if ($method === 'GET' && $action === '') {
    Auth::require('backup.run');

    $rows = Backup::listRecent(30);
    $dir  = Config::storagePath('backups');

    $onDisk = [];
    foreach (glob($dir . '/n4core-*') ?: [] as $f) {
        if (is_file($f)) {
            $onDisk[basename($f)] = ['size' => (int) filesize($f), 'mtime' => (int) filemtime($f)];
        }
    }

    $list = [];
    foreach ($rows as $r) {
        $name = (string) $r['filename'];
        $list[] = [
            'id'           => (int) $r['id'],
            'filename'     => $name,
            'kind'         => $r['kind'],
            'scope'        => $r['scope'],
            'size_bytes'   => (int) $r['size_bytes'],
            'size_human'   => Backup::human((int) $r['size_bytes']),
            'sha256'       => $r['sha256'],
            'encrypted'    => (int) $r['encrypted'] === 1,
            'status'       => $r['status'],
            // 'sent' means "archived AND delivered to Telegram" — still a
            // success. Exposing an explicit flag keeps the UI from having to
            // know the ENUM values.
            'success'      => in_array((string) $r['status'], ['ok', 'sent'], true),
            'error'        => $r['error'],
            'triggered_by' => $r['triggered_by'],
            'delivered_tg' => (int) $r['delivered_tg'] === 1,
            'created_at'   => $r['created_at'],
            'available'    => isset($onDisk[$name]),
        ];
        unset($onDisk[$name]);
    }

    // Archives present on disk but missing from the table (e.g. restored
    // from another server) still deserve to be listed and downloadable.
    foreach ($onDisk as $name => $info) {
        $list[] = [
            'id' => 0, 'filename' => $name, 'kind' => 'manual', 'scope' => 'full',
            'size_bytes' => $info['size'], 'size_human' => Backup::human($info['size']),
            'sha256' => null, 'encrypted' => str_ends_with($name, '.enc'),
            'status' => 'ok', 'success' => true, 'error' => null, 'triggered_by' => 'unknown',
            'delivered_tg' => false,
            'created_at' => date('Y-m-d H:i:s', $info['mtime']),
            'available' => true, 'orphan' => true,
        ];
    }

    usort($list, fn($a, $b) => strcmp((string) $b['created_at'], (string) $a['created_at']));

    $totalBytes = 0;
    foreach (glob($dir . '/n4core-*') ?: [] as $f) {
        $totalBytes += is_file($f) ? (int) filesize($f) : 0;
    }

    Response::ok([
        'backups' => $list,
        'storage' => [
            'path'        => 'storage/backups',
            'total_bytes' => $totalBytes,
            'total_human' => Backup::human($totalBytes),
            'free_human'  => Backup::human((int) (@disk_free_space($dir) ?: 0)),
            'writable'    => is_dir($dir) && is_writable($dir),
        ],
        'schedule' => [
            'auto_enabled'   => Config::settingBool('backup_auto_enabled', true),
            'time'           => (string) Config::setting('backup_auto_time', '00:00'),
            'timezone'       => (string) Config::get('app.timezone', 'Asia/Yangon'),
            'retention_days' => (int) Config::setting('backup_retention_days', '14'),
            'encrypt'        => (bool) Config::get('backup.encrypt', true),
            'telegram'       => Telegram::enabled() && Config::settingBool('backup_send_telegram', true),
        ],
    ]);
}

// ------------------------------------------------------------ DOWNLOAD
if ($method === 'GET' && $action === 'download') {
    $admin = Auth::require('backup.run');
    $name  = backup_safe_name(Request::query('file'));
    $path  = Config::storagePath('backups') . '/' . $name;

    if (!is_file($path)) {
        Response::error('Backup file not found', 404);
    }

    Audit::log('backup.download', 'backup', $name, ['size' => filesize($path)]);
    Notifier::securityAlert(
        '📥 Backup downloaded: <code>' . Telegram::esc($name) . '</code>'
        . "\nBy: <b>" . Telegram::esc((string) $admin['username']) . '</b>'
        . "\nIP: <code>" . Telegram::esc(Request::ip()) . '</code>'
    );

    // Raw file response — bypasses the JSON envelope on purpose.
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $name . '"');
    header('Content-Length: ' . filesize($path));
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-store, private');
    readfile($path);
    exit;
}

// ----------------------------------------------------------- RUN / DEL
if ($method === 'POST' && $action === 'run') {
    $admin = Auth::require('backup.run');
    Auth::requireCsrf();
    RateLimiter::hit('admin_write', Request::ip());

    $data  = Request::body();
    $scope = Request::enum($data, 'scope', ['full', 'db', 'files'], 'full');
    $send  = Request::bool($data, 'send_telegram', true);

    @set_time_limit(600);

    $by     = 'admin:' . (string) $admin['username'];
    $result = Backup::create($scope, 'manual', $by);

    if (!$result['ok']) {
        Audit::log('backup.failed', 'backup', null, ['scope' => $scope, 'error' => $result['error']]);
        Response::error('Backup failed: ' . (string) $result['error'], 500);
    }

    Audit::log('backup.create', 'backup', $result['filename'], [
        'scope' => $scope,
        'size'  => Backup::human($result['size']),
    ]);

    $delivered = false;
    if ($send && Telegram::enabled() && Config::settingBool('backup_send_telegram', true)) {
        $delivered = Backup::deliver(
            $result,
            '💾 <b>Manual Backup</b> by <b>' . Telegram::esc((string) $admin['username']) . '</b>'
        );
    }

    Backup::prune();

    Response::ok([
        'filename'   => $result['filename'],
        'size_bytes' => $result['size'],
        'size_human' => Backup::human($result['size']),
        'sha256'     => $result['sha256'],
        'encrypted'  => $result['encrypted'],
        'scope'      => $scope,
        'telegram'   => $delivered,
    ], 201);
}

if ($method === 'DELETE') {
    $admin = Auth::require('backup.run');
    Auth::requireCsrf();

    $name = backup_safe_name(Request::query('file'));
    $path = Config::storagePath('backups') . '/' . $name;

    if (is_file($path) && !@unlink($path)) {
        Response::error('Could not delete the file (permissions?)', 500);
    }
    try {
        Db::run('DELETE FROM backups WHERE filename = ?', [$name]);
    } catch (Throwable) {
    }

    Audit::log('backup.delete', 'backup', $name);
    Response::ok(['deleted' => true]);
}

Response::methodNotAllowed(['GET', 'POST', 'DELETE']);
