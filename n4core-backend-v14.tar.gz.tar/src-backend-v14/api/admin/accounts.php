<?php
/**
 * Admin VIP Accounts — available to BOTH roles (this is the Admin role's
 * whole job). Deleting an account stays Super-Admin-only.
 *
 * GET    /api/admin/accounts.php                          list (+ device usage)
 * GET    /api/admin/accounts.php?id=UUID&action=reveal    read back the access code
 * POST   /api/admin/accounts.php                           create
 * PUT    /api/admin/accounts.php?id=UUID                   update basics
 * POST   /api/admin/accounts.php?id=UUID&action=extend     { days } | { plan_id }
 * POST   /api/admin/accounts.php?id=UUID&action=reset_code  new access code
 * POST   /api/admin/accounts.php?id=UUID&action=unbind_all  drop bound devices
 * POST   /api/admin/accounts.php?action=purge_expired      delete long-expired (super admin)
 * DELETE /api/admin/accounts.php?id=UUID                   delete (super admin)
 */
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

$method = Request::method();
$action = (string) Request::query('action', '');
$id     = Request::id(Request::query('id'));

// ---------------------------------------------------------------- READ
if ($method === 'GET') {
    $admin = Auth::require('vip.read');

    // ---- Reveal a single access code (audited every time) -----------
    if ($action === 'reveal') {
        if ($id === null) {
            Response::error('Missing or invalid id', 422);
        }
        RateLimiter::hit('admin_write', Request::ip() . ':reveal');

        $row = Db::one(
            'SELECT username, access_code, access_code_enc, created_by FROM vip_accounts WHERE id = ?',
            [$id]
        );
        if (!$row) {
            Response::error('Account not found', 404);
        }
        // A scoped admin must not read another admin's customer credential.
        Auth::requireVipAccess($row);

        $code = Crypto::decrypt($row['access_code_enc']);
        if ($code === null && (string) $row['access_code'] !== '') {
            $code = (string) $row['access_code']; // pre-migration row
        }

        // Reading a customer credential is a sensitive action: log it.
        Audit::log('vip.code_revealed', 'vip_account', $id, ['username' => $row['username']]);

        if ($code === null) {
            Response::error(
                'This code cannot be shown (it is stored hashed only). Use "Reset Code" to issue a new one.',
                409
            );
        }

        Response::ok(['username' => $row['username'], 'access_code' => $code]);
    }

    // ---- List ------------------------------------------------------
    $search = trim((string) Request::query('q', ''));
    $status = (string) Request::query('status', '');   // active|expired|disabled
    $params = [];
    $where  = [];

    if ($search !== '') {
        $where[] = '(a.username LIKE ? OR a.note LIKE ? OR a.plan_name LIKE ?)';
        $like = '%' . str_replace(['%', '_'], ['\%', '\_'], $search) . '%';
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
    }
    if ($status === 'active') {
        $where[] = 'a.is_active = 1 AND a.expires_at > NOW()';
    } elseif ($status === 'expired') {
        $where[] = 'a.expires_at <= NOW()';
    } elseif ($status === 'disabled') {
        $where[] = 'a.is_active = 0';
    }

    // Row-level isolation: a plain admin only ever lists their own rows.
    [$scopeSql, $scopeParams] = Auth::vipScopeSql('a');
    if ($scopeSql !== '') {
        $where[] = $scopeSql;
        $params  = array_merge($params, $scopeParams);
    }

    $sql = 'SELECT a.id, a.username, a.device_limit, a.plan_id, a.plan_name, a.is_active,
                   a.note, a.price, a.expires_at, a.created_at, a.last_login_at, a.locked_until,
                   (SELECT COUNT(*) FROM vip_devices d WHERE d.account_id = a.id) AS devices_used,
                   (SELECT COUNT(*) FROM vip_sessions s
                     WHERE s.account_id = a.id AND s.revoked_at IS NULL AND s.expires_at > NOW()) AS active_sessions,
                   (a.access_code_enc IS NOT NULL OR a.access_code <> \'\') AS code_readable
            FROM vip_accounts a';
    if ($where) {
        $sql .= ' WHERE ' . implode(' AND ', $where);
    }
    $sql .= ' ORDER BY a.created_at DESC LIMIT 1000';

    $rows = Db::all($sql, $params);
    foreach ($rows as &$r) {
        $r['device_limit']    = (int) $r['device_limit'];
        $r['devices_used']    = (int) $r['devices_used'];
        $r['active_sessions'] = (int) $r['active_sessions'];
        $r['is_active']       = (int) $r['is_active'];
        $r['code_readable']   = (int) $r['code_readable'];
        $r['expired']         = strtotime((string) $r['expires_at']) < time();
        $r['days_left']       = (int) floor((strtotime((string) $r['expires_at']) - time()) / 86400);
        // Access codes are never included in list payloads.
    }
    unset($r);

    Response::ok(['accounts' => $rows]);
}

if (!in_array($method, ['POST', 'PUT', 'DELETE'], true)) {
    Response::methodNotAllowed(['GET', 'POST', 'PUT', 'DELETE']);
}

// ------------------------------------------------------ PURGE EXPIRED
// Bulk delete of accounts that expired more than `vip_purge_grace_days`
// ago — the same rule the nightly cron applies, run on demand.
//
// Two deliberate safety choices:
//   1. vip.delete, so an Admin-role operator cannot mass-delete.
//   2. The grace window is honoured here too. A "delete everything that
//      says expired" button would wipe accounts that expired an hour ago
//      and are about to be renewed.
if ($method === 'POST' && $id === null && $action === 'purge_expired') {
    $admin = Auth::require('vip.delete');   // super admin only
    Auth::requireCsrf();
    RateLimiter::hit('admin_write', Request::ip() . ':purge');

    $grace = (int) Config::setting('vip_purge_grace_days', 1);
    if ($grace < 0) {
        $grace = 0;
    }

    // A scoped admin only ever sees (and so only ever purges) their own rows.
    [$scopeSql, $scopeParams] = Auth::vipScopeSql('a');
    $where  = 'a.expires_at < DATE_SUB(NOW(), INTERVAL ? DAY)';
    $params = [$grace];
    if ($scopeSql !== '') {
        $where .= ' AND ' . $scopeSql;
        $params = array_merge($params, $scopeParams);
    }

    // Read first so the audit entry names what went, not just how many.
    $doomed = Db::all(
        "SELECT a.id, a.username, a.plan_name, a.expires_at
         FROM vip_accounts a WHERE {$where}
         ORDER BY a.expires_at ASC LIMIT 500",
        $params
    );

    if (!$doomed) {
        Response::ok(['deleted' => 0, 'accounts' => [], 'grace_days' => $grace]);
    }

    $ids   = array_column($doomed, 'id');
    $marks = implode(',', array_fill(0, count($ids), '?'));
    // Devices and sessions go with it: both FK to vip_accounts ON DELETE CASCADE.
    Db::run("DELETE FROM vip_accounts WHERE id IN ({$marks})", $ids);

    foreach ($doomed as $d) {
        Audit::log('vip.delete', 'vip_account', (string) $d['id'], [
            'username' => $d['username'],
            'plan'     => $d['plan_name'],
            'expired'  => $d['expires_at'],
            'reason'   => 'purge_expired',
        ]);
    }

    Response::ok([
        'deleted'    => count($ids),
        'accounts'   => array_column($doomed, 'username'),
        'grace_days' => $grace,
    ]);
}

// -------------------------------------------------------------- CREATE
if ($method === 'POST' && $id === null && $action === '') {
    $admin = Auth::require('vip.write');
    Auth::requireCsrf();
    RateLimiter::hit('admin_write', Request::ip());

    $data = Request::body();
    Request::requireFields($data, ['username']);

    $username = Request::str($data, 'username', 64);
    if (!preg_match('/^[A-Za-z0-9._@-]{3,64}$/', $username)) {
        Response::error('Username must be 3-64 characters (letters, numbers, . _ - @ only)', 422);
    }

    if (Db::value('SELECT 1 FROM vip_accounts WHERE username = ?', [$username])) {
        Response::error('Username already exists', 409);
    }

    // Plan-driven defaults; explicit values win.
    $planId   = Request::id(Request::str($data, 'plan_id', 36));
    $planName = null;
    $devices  = null;
    $days     = null;

    if ($planId !== null) {
        $plan = Db::one('SELECT * FROM vip_plans WHERE id = ?', [$planId]);
        if (!$plan) {
            Response::error('Plan not found', 404);
        }
        $planName = (string) $plan['name'];
        $devices  = (int) $plan['device_limit'];
        $days     = (int) $plan['duration_days'];
    }

    if (array_key_exists('device_limit', $data)) {
        $devices = Request::int($data, 'device_limit', $devices ?? 1, 1, 100);
    }
    if (array_key_exists('duration_days', $data)) {
        $days = Request::int($data, 'duration_days', $days ?? 30, 1, 3650);
    }
    if (array_key_exists('plan_name', $data)) {
        $planName = Request::str($data, 'plan_name', 100) ?: $planName;
    }

    $devices ??= 1;
    $days    ??= 30;

    // Auto-generate a code when none was supplied.
    $code = Request::str($data, 'access_code', 64);
    $generated = false;
    if ($code === '') {
        // Six digits. Customers have to read this off a slip and type it on a
        // phone keypad, and a 16-character mixed-case string was being written
        // down wrong. Brute force is held off by the per-account lockout, not
        // by the length — see Crypto::numericCode().
        $code = Crypto::numericCode(6);
        $generated = true;
    } elseif (strlen($code) < 6) {
        Response::error('Access code must be at least 6 characters', 422);
    }

    $newId     = Crypto::uuid4();
    $expiresAt = date('Y-m-d H:i:s', time() + $days * 86400);

    try {
        Db::run(
            'INSERT INTO vip_accounts
               (id, username, access_code, access_code_hash, access_code_enc,
                device_limit, plan_id, plan_name, is_active, note, price, created_by, expires_at)
             VALUES (?, ?, \'\', ?, ?, ?, ?, ?, 1, ?, ?, ?, ?)',
            [
                $newId,
                $username,
                Crypto::hashSecret($code),
                Crypto::encrypt($code),
                $devices,
                $planId,
                $planName,
                Request::str($data, 'note', 255) ?: null,
                // Free text on purpose: "267", "267 Ks", "KPay 5000" are all
                // things a seller actually types. Never used in arithmetic.
                Request::str($data, 'price', 64) ?: null,
                (int) $admin['admin_id'],
                $expiresAt,
            ]
        );
    } catch (PDOException $e) {
        if ($e->getCode() === '23000') {
            Response::error('Username already exists', 409);
        }
        throw $e;
    }

    Audit::log('vip.create', 'vip_account', $newId, [
        'username' => $username, 'devices' => $devices,
        'days' => $days, 'plan' => $planName, 'code_generated' => $generated,
    ]);

    Response::ok([
        'id'          => $newId,
        'username'    => $username,
        'access_code' => $code,   // returned once so the admin can hand it over
        'expires_at'  => $expiresAt,
        'device_limit' => $devices,
        'plan_name'   => $planName,
        // Echoed back so the receipt can show it without a second request.
        'price'       => Request::str($data, 'price', 64) ?: null,
        'generated'   => $generated,
    ], 201);
}

if ($id === null) {
    Response::error('Missing or invalid id', 422);
}

$account = Db::one('SELECT * FROM vip_accounts WHERE id = ?', [$id]);
if (!$account) {
    Response::error('Account not found', 404);
}

// Every mutation below (update / extend / reset_code / unbind_all / delete)
// funnels through here, so one guard covers them all.
Auth::requireVipAccess($account);

// -------------------------------------------------------------- UPDATE
if ($method === 'PUT') {
    Auth::require('vip.write');
    Auth::requireCsrf();
    RateLimiter::hit('admin_write', Request::ip());

    $data   = Request::body();
    $fields = [];
    $params = [];

    if (array_key_exists('username', $data)) {
        $newName = Request::str($data, 'username', 64);
        if (!preg_match('/^[A-Za-z0-9._@-]{3,64}$/', $newName)) {
            Response::error('Username must be 3-64 characters (letters, numbers, . _ - @ only)', 422);
        }
        if (Db::value('SELECT 1 FROM vip_accounts WHERE username = ? AND id <> ?', [$newName, $id])) {
            Response::error('Username already exists', 409);
        }
        $fields[] = 'username = ?';
        $params[] = $newName;
    }
    if (array_key_exists('device_limit', $data)) {
        $newLimit = Request::int($data, 'device_limit', (int) $account['device_limit'], 1, 100);
        // Lowering the limit below the bound-device count would silently
        // lock the customer out, so refuse and tell the admin to unbind.
        $bound = (int) Db::value('SELECT COUNT(*) FROM vip_devices WHERE account_id = ?', [$id]);
        if ($newLimit < $bound) {
            Response::error(
                "This account has {$bound} device(s) bound. Unbind some devices before lowering the limit to {$newLimit}.",
                409
            );
        }
        $fields[] = 'device_limit = ?';
        $params[] = $newLimit;
    }
    if (array_key_exists('note', $data)) {
        $fields[] = 'note = ?';
        $params[] = Request::str($data, 'note', 255) ?: null;
    }
    if (array_key_exists('price', $data)) {
        $fields[] = 'price = ?';
        $params[] = Request::str($data, 'price', 64) ?: null;
    }
    if (array_key_exists('is_active', $data)) {
        $active = Request::bool($data, 'is_active', true);
        $fields[] = 'is_active = ?';
        $params[] = $active ? 1 : 0;
        // Disabling must take effect immediately, not at token expiry.
        if (!$active) {
            Db::run(
                'UPDATE vip_sessions SET revoked_at = NOW() WHERE account_id = ? AND revoked_at IS NULL',
                [$id]
            );
        }
    }
    if (array_key_exists('plan_name', $data)) {
        $fields[] = 'plan_name = ?';
        $params[] = Request::str($data, 'plan_name', 100) ?: null;
    }
    if (array_key_exists('expires_at', $data)) {
        $raw = Request::str($data, 'expires_at', 32);
        $ts = strtotime($raw);
        if ($ts === false) {
            Response::error('expires_at must be a valid date (YYYY-MM-DD)', 422);
        }
        $fields[] = 'expires_at = ?';
        $params[] = date('Y-m-d H:i:s', $ts);
    }
    // Clearing a lockout is a normal support action.
    if (Request::bool($data, 'unlock', false)) {
        $fields[] = 'locked_until = NULL';
        $fields[] = 'failed_attempts = 0';
    }

    if (!$fields) {
        Response::error('No fields to update', 422);
    }

    $params[] = $id;
    Db::run('UPDATE vip_accounts SET ' . implode(', ', $fields) . ' WHERE id = ?', $params);

    Audit::log('vip.update', 'vip_account', $id, [
        'username' => $account['username'],
        'changed'  => array_map(fn($f) => trim(explode('=', $f)[0]), $fields),
    ]);

    Response::ok(['updated' => true]);
}

// -------------------------------------------------------------- EXTEND
if ($method === 'POST' && $action === 'extend') {
    Auth::require('vip.write');
    Auth::requireCsrf();
    RateLimiter::hit('admin_write', Request::ip());

    $data = Request::body();
    $days = null;

    if (!empty($data['plan_id'])) {
        $planId = Request::id(Request::str($data, 'plan_id', 36));
        $plan = $planId !== null ? Db::one('SELECT * FROM vip_plans WHERE id = ?', [$planId]) : null;
        if (!$plan) {
            Response::error('Plan not found', 404);
        }
        $days = (int) $plan['duration_days'];
        // Applying a plan also syncs its device limit + label.
        Db::run(
            'UPDATE vip_accounts SET device_limit = ?, plan_name = ?, plan_id = ? WHERE id = ?',
            [(int) $plan['device_limit'], $plan['name'], $plan['id'], $id]
        );
    } elseif (isset($data['days'])) {
        $days = Request::int($data, 'days', 30, 1, 3650);
    } else {
        Response::error('Provide either days or plan_id', 422);
    }

    // Extend from the later of (now, current expiry) so remaining time is
    // never lost — unchanged v1 behaviour.
    $base      = max(time(), strtotime((string) $account['expires_at']));
    $newExpiry = date('Y-m-d H:i:s', $base + $days * 86400);

    Db::run(
        'UPDATE vip_accounts SET expires_at = ?, is_active = 1, locked_until = NULL, failed_attempts = 0 WHERE id = ?',
        [$newExpiry, $id]
    );

    Audit::log('vip.extend', 'vip_account', $id, [
        'username' => $account['username'], 'days' => $days,
        'old_expiry' => $account['expires_at'], 'new_expiry' => $newExpiry,
    ]);

    Response::ok(['expires_at' => $newExpiry, 'days_added' => $days]);
}

// ---------------------------------------------------------- RESET CODE
if ($method === 'POST' && $action === 'reset_code') {
    Auth::require('vip.write');
    Auth::requireCsrf();
    RateLimiter::hit('admin_write', Request::ip());

    $data = Request::body();
    $code = Request::str($data, 'access_code', 64);
    $generated = false;
    if ($code === '') {
        // Six digits. Customers have to read this off a slip and type it on a
        // phone keypad, and a 16-character mixed-case string was being written
        // down wrong. Brute force is held off by the per-account lockout, not
        // by the length — see Crypto::numericCode().
        $code = Crypto::numericCode(6);
        $generated = true;
    } elseif (strlen($code) < 6) {
        Response::error('Access code must be at least 6 characters', 422);
    }

    Db::run(
        'UPDATE vip_accounts
         SET access_code = \'\', access_code_hash = ?, access_code_enc = ?,
             failed_attempts = 0, locked_until = NULL
         WHERE id = ?',
        [Crypto::hashSecret($code), Crypto::encrypt($code), $id]
    );

    // The old code must stop working everywhere at once.
    Db::run('UPDATE vip_sessions SET revoked_at = NOW() WHERE account_id = ? AND revoked_at IS NULL', [$id]);

    Audit::log('vip.reset_code', 'vip_account', $id, [
        'username' => $account['username'], 'generated' => $generated,
    ]);

    Response::ok([
        'access_code' => $code,
        'generated'   => $generated,
        'note'        => 'All existing app sessions for this account have been signed out.',
    ]);
}

// ---------------------------------------------------------- UNBIND ALL
if ($method === 'POST' && $action === 'unbind_all') {
    Auth::require('vip.write');
    Auth::requireCsrf();

    $removed = Db::run('DELETE FROM vip_devices WHERE account_id = ?', [$id]);
    Db::run('UPDATE vip_sessions SET revoked_at = NOW() WHERE account_id = ? AND revoked_at IS NULL', [$id]);

    Audit::log('vip.unbind_all', 'vip_account', $id, [
        'username' => $account['username'], 'devices_removed' => $removed,
    ]);

    Response::ok(['unbound' => true, 'devices_removed' => $removed]);
}

// -------------------------------------------------------------- DELETE
if ($method === 'DELETE') {
    Auth::require('vip.delete');   // super admin only
    Auth::requireCsrf();

    Db::run('DELETE FROM vip_accounts WHERE id = ?', [$id]);

    Audit::log('vip.delete', 'vip_account', $id, [
        'username' => $account['username'], 'plan' => $account['plan_name'],
    ]);

    Response::ok(['deleted' => true]);
}

Response::error('Unknown action', 400);
