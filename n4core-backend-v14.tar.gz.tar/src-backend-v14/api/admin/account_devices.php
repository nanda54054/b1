<?php
/**
 * Bound-device management for a VIP account.
 *
 * GET    /api/admin/account_devices.php?account_id=UUID
 * DELETE /api/admin/account_devices.php?account_id=UUID&device_id=XXX
 */
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

$method    = Request::method();
// The dashboard sends ?id=, the documented name is ?account_id=. Accept both
// rather than break one of the two callers.
$accountId = Request::id(Request::query('account_id') ?? Request::query('id'));

if ($accountId === null) {
    Response::error('Missing or invalid account_id', 422);
}

/**
 * Both verbs need the same ownership check, and it must run AFTER the
 * capability gate so an anonymous caller still gets 401 first.
 */
function n4_guard_account(string $accountId): array
{
    $row = Db::one('SELECT id, username, created_by FROM vip_accounts WHERE id = ?', [$accountId]);
    if (!$row) {
        Response::error('Account not found', 404);
    }
    Auth::requireVipAccess($row);
    return $row;
}

if ($method === 'GET') {
    Auth::require('vip.read');
    n4_guard_account($accountId);

    $rows = Db::all(
        'SELECT d.id, d.device_id, d.device_label, d.last_ip, d.first_seen_at, d.last_seen_at,
                (SELECT COUNT(*) FROM vip_sessions s
                  WHERE s.account_id = d.account_id AND s.device_id = d.device_id
                    AND s.revoked_at IS NULL AND s.expires_at > NOW()) AS active_sessions
         FROM vip_devices d
         WHERE d.account_id = ?
         ORDER BY d.last_seen_at DESC',
        [$accountId]
    );

    foreach ($rows as &$r) {
        $r['active_sessions'] = (int) $r['active_sessions'];
        // Device ids are opaque UUIDs; show a short form in the UI.
        $r['device_short'] = substr((string) $r['device_id'], 0, 8) . '…';
    }
    unset($r);

    Response::ok(['devices' => $rows]);
}

if ($method === 'DELETE') {
    Auth::require('vip.write');
    Auth::requireCsrf();
    $guarded = n4_guard_account($accountId);

    $deviceId = Request::query('device_id');
    if ($deviceId === null || trim($deviceId) === '' || strlen($deviceId) > 128) {
        Response::error('Missing or invalid device_id', 422);
    }
    $deviceId = trim($deviceId);

    $removed = Db::run(
        'DELETE FROM vip_devices WHERE account_id = ? AND device_id = ?',
        [$accountId, $deviceId]
    );
    if ($removed === 0) {
        Response::error('Device not found for this account', 404);
    }

    // Kill that device's sessions so the slot is genuinely free.
    Db::run(
        'UPDATE vip_sessions SET revoked_at = NOW()
         WHERE account_id = ? AND device_id = ? AND revoked_at IS NULL',
        [$accountId, $deviceId]
    );

    Audit::log('vip.unbind_device', 'vip_account', $accountId, [
        'username' => $guarded['username'],
        'device'   => substr($deviceId, 0, 12) . '…',
    ]);

    Response::ok(['deleted' => true]);
}

Response::methodNotAllowed(['GET', 'DELETE']);
