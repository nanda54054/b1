<?php
/**
 * Admin Servers CRUD — SUPER ADMIN ONLY for writes.
 *
 * GET    /api/admin/servers.php                  list all (+ location info)
 * POST   /api/admin/servers.php                  create
 * POST   /api/admin/servers.php?action=parse     parse a config URL (no write)
 * POST   /api/admin/servers.php?action=bulk      bulk import many links
 * POST   /api/admin/servers.php?action=reorder   { ids: [...] }
 * PUT    /api/admin/servers.php?id=UUID          update
 * DELETE /api/admin/servers.php?id=UUID          delete
 *
 * Headers: X-Admin-Token (+ X-CSRF-Token on writes)
 */
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

$method = Request::method();
$action = (string) Request::query('action', '');
$id     = Request::id(Request::query('id'));

$PROTOCOLS = ConfigParser::DB_PROTOCOLS;
$TIERS     = ['free', 'vip'];

// ---------------------------------------------------------------- READ
if ($method === 'GET') {
    Auth::require('server.read');

    $rows = Db::all(
        'SELECT s.*, l.name AS location_name, l.country_code, l.flag_emoji
         FROM servers s
         JOIN locations l ON l.id = s.location_id
         ORDER BY s.tier ASC, s.sort_order ASC, s.name ASC'
    );

    // Admins (non-super) may see the catalog but not the connection
    // secrets — least privilege, since they only manage VIP accounts.
    $canSeeSecrets = Auth::can('server.write');
    foreach ($rows as &$r) {
        $r['port']         = (int) $r['port'];
        $r['load_percent'] = (int) $r['load_percent'];
        $r['sort_order']   = (int) $r['sort_order'];
        $r['is_enabled']   = (int) $r['is_enabled'];
        $r['parsed_meta']  = $r['parsed_meta'] !== null ? json_decode((string) $r['parsed_meta'], true) : null;
        if (!$canSeeSecrets) {
            $r['raw_config'] = '';
            $r['config_hidden'] = true;
        }
    }
    unset($r);

    Response::ok(['servers' => $rows]);
}

if (!in_array($method, ['POST', 'PUT', 'DELETE'], true)) {
    Response::methodNotAllowed(['GET', 'POST', 'PUT', 'DELETE']);
}

// --------------------------------------------------------------- PARSE
// Read-level capability: parsing performs no writes, and letting an
// Admin preview a link is harmless.
if ($method === 'POST' && $action === 'parse') {
    Auth::require('server.read');
    Auth::requireCsrf();
    RateLimiter::hit('admin_write', Request::ip());

    $data = Request::body();
    $raw  = Request::text($data, 'raw_config', 65535);
    if (trim($raw) === '') {
        Response::error('Paste a config URL or WireGuard config first', 422);
    }

    $parsed = ConfigParser::parse($raw);

    // Map the detected country to an existing location row so the form can
    // preselect it; offer to create it when it is missing.
    $suggestion = null;
    if (!empty($parsed['country_code'])) {
        $loc = Db::one(
            'SELECT id, name, country_code, flag_emoji, is_enabled FROM locations WHERE country_code = ?',
            [$parsed['country_code']]
        );
        if ($loc) {
            $suggestion = [
                'exists'       => true,
                'location_id'  => $loc['id'],
                'name'         => $loc['name'],
                'country_code' => $loc['country_code'],
                'flag_emoji'   => $loc['flag_emoji'],
                'is_enabled'   => (int) $loc['is_enabled'],
            ];
        } else {
            $preset = Locations::preset((string) $parsed['country_code']);
            $suggestion = [
                'exists'       => false,
                'country_code' => $parsed['country_code'],
                'name'         => $preset['name'] ?? $parsed['country_code'],
                'flag_emoji'   => $preset['flag'] ?? Locations::flagFor((string) $parsed['country_code']),
            ];
        }
    }

    Response::ok([
        'parsed'   => $parsed,
        'location' => $suggestion,
    ]);
}

// -------------------------------------------------------------- CREATE
if ($method === 'POST' && $action === '' && $id === null) {
    $admin = Auth::require('server.write');
    Auth::requireCsrf();
    RateLimiter::hit('admin_write', Request::ip());

    $data = Request::body();
    Request::requireFields($data, ['name', 'location_id', 'protocol', 'tier']);

    $locationId = Request::id(Request::str($data, 'location_id', 36));
    if ($locationId === null || !Db::value('SELECT 1 FROM locations WHERE id = ?', [$locationId])) {
        Response::error('Unknown location', 422);
    }

    $protocol = Request::enum($data, 'protocol', $PROTOCOLS, 'vmess');
    $tier     = Request::enum($data, 'tier', $TIERS, 'free');
    $raw      = Request::text($data, 'raw_config', 65535);

    if (trim($raw) === '') {
        Response::error('raw_config is required — the app cannot connect without it', 422);
    }

    // Re-parse server-side so stored metadata always matches the config,
    // regardless of what the browser sent.
    $parsed  = ConfigParser::parse($raw);
    $address = Request::str($data, 'address', 255) ?: $parsed['address'];
    $port    = Request::int($data, 'port', $parsed['port'], 0, 65535);

    if ($address === '') {
        Response::error('Address could not be determined — check the config', 422);
    }
    if ($port <= 0) {
        Response::error('Port could not be determined — check the config', 422);
    }

    $newId = Crypto::uuid4();
    Db::run(
        'INSERT INTO servers
           (id, name, location_id, protocol, tier, address, port, raw_config,
            network, security, sni, parsed_meta, load_percent, sort_order, is_enabled)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [
            $newId,
            Request::str($data, 'name', 100),
            $locationId,
            $protocol,
            $tier,
            $address,
            $port,
            $raw,
            $parsed['network'],
            $parsed['security'],
            $parsed['sni'] !== '' ? $parsed['sni'] : null,
            $parsed['meta'] ? json_encode($parsed['meta'], JSON_UNESCAPED_UNICODE) : null,
            Request::int($data, 'load_percent', 0, 0, 100),
            Request::int($data, 'sort_order', 0, 0, 100000),
            Request::bool($data, 'is_enabled', true) ? 1 : 0,
        ]
    );

    Audit::log('server.create', 'server', $newId, [
        'name' => Request::str($data, 'name', 100),
        'protocol' => $protocol,
        'tier' => $tier,
        'address' => $address,
        'port' => $port,
    ]);

    Response::ok(['id' => $newId, 'parsed' => $parsed], 201);
}

// ---------------------------------------------------------- BULK IMPORT
if ($method === 'POST' && $action === 'bulk') {
    Auth::require('server.write');
    Auth::requireCsrf();
    RateLimiter::hit('admin_write', Request::ip());

    $data = Request::body();
    $blob = Request::text($data, 'blob', 200000);
    $links = ConfigParser::splitLinks($blob);

    if (!$links) {
        Response::error('No valid share-links found in that text', 422);
    }
    if (count($links) > 200) {
        $links = array_slice($links, 0, 200);
    }

    $defaultTier  = Request::enum($data, 'tier', $TIERS, 'free');
    $autoLocation = Request::bool($data, 'auto_create_locations', true);
    $fallbackLoc  = Request::id(Request::str($data, 'location_id', 36));

    $created = [];
    $skipped = [];

    foreach ($links as $idx => $link) {
        $p = ConfigParser::parse($link);
        if (!$p['ok']) {
            $skipped[] = ['link' => mb_substr($link, 0, 60) . '…', 'reason' => $p['warnings'][0] ?? 'unparseable'];
            continue;
        }

        // Resolve the location.
        $locId = null;
        if (!empty($p['country_code'])) {
            $locId = Db::value('SELECT id FROM locations WHERE country_code = ?', [$p['country_code']]);
            if (!$locId && $autoLocation) {
                $locId = Locations::ensure((string) $p['country_code']);
            }
        }
        if (!$locId) {
            $locId = $fallbackLoc;
        }
        if (!$locId) {
            $skipped[] = ['link' => mb_substr($link, 0, 60) . '…', 'reason' => 'no region detected (pick a fallback region)'];
            continue;
        }

        // Skip exact duplicates (same protocol+address+port).
        $dupe = Db::value(
            'SELECT id FROM servers WHERE protocol = ? AND address = ? AND port = ? LIMIT 1',
            [$p['protocol'], $p['address'], $p['port']]
        );
        if ($dupe) {
            $skipped[] = ['link' => mb_substr($link, 0, 60) . '…', 'reason' => 'already exists'];
            continue;
        }

        $name = $p['name'] !== '' ? $p['name'] : strtoupper((string) $p['country_code']) . ' ' . str_pad((string) ($idx + 1), 2, '0', STR_PAD_LEFT);
        $sid  = Crypto::uuid4();

        Db::run(
            'INSERT INTO servers
               (id, name, location_id, protocol, tier, address, port, raw_config,
                network, security, sni, parsed_meta, sort_order, is_enabled)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)',
            [
                $sid, mb_substr($name, 0, 100), $locId, $p['protocol'], $defaultTier,
                $p['address'], $p['port'], $link,
                $p['network'], $p['security'],
                $p['sni'] !== '' ? $p['sni'] : null,
                $p['meta'] ? json_encode($p['meta'], JSON_UNESCAPED_UNICODE) : null,
                $idx,
            ]
        );

        $created[] = [
            'id' => $sid, 'name' => $name, 'protocol' => $p['protocol'],
            'address' => $p['address'], 'port' => $p['port'],
            'country_code' => $p['country_code'],
        ];
    }

    Audit::log('server.bulk_import', 'server', null, [
        'created' => count($created), 'skipped' => count($skipped), 'tier' => $defaultTier,
    ]);

    Response::ok(['created' => $created, 'skipped' => $skipped, 'total' => count($links)]);
}

// ------------------------------------------------------------- REORDER
if ($method === 'POST' && $action === 'reorder') {
    Auth::require('server.write');
    Auth::requireCsrf();

    $data = Request::body();
    $ids = is_array($data['ids'] ?? null) ? $data['ids'] : [];
    if (!$ids) {
        Response::error('ids must be a non-empty array', 422);
    }

    Db::tx(function () use ($ids): void {
        $i = 0;
        foreach ($ids as $sid) {
            $clean = Request::id(is_string($sid) ? $sid : null);
            if ($clean === null) {
                continue;
            }
            Db::run('UPDATE servers SET sort_order = ? WHERE id = ?', [$i++, $clean]);
        }
    });

    Audit::log('server.reorder', 'server', null, ['count' => count($ids)]);
    Response::ok(['reordered' => true]);
}

// -------------------------------------------------------------- UPDATE
if ($method === 'PUT') {
    Auth::require('server.write');
    Auth::requireCsrf();
    RateLimiter::hit('admin_write', Request::ip());

    if ($id === null) {
        Response::error('Missing or invalid id', 422);
    }
    $existing = Db::one('SELECT * FROM servers WHERE id = ?', [$id]);
    if (!$existing) {
        Response::error('Server not found', 404);
    }

    $data = Request::body();
    $fields = [];
    $params = [];

    if (array_key_exists('name', $data)) {
        $fields[] = 'name = ?';
        $params[] = Request::str($data, 'name', 100);
    }
    if (array_key_exists('location_id', $data)) {
        $loc = Request::id(Request::str($data, 'location_id', 36));
        if ($loc === null || !Db::value('SELECT 1 FROM locations WHERE id = ?', [$loc])) {
            Response::error('Unknown location', 422);
        }
        $fields[] = 'location_id = ?';
        $params[] = $loc;
    }
    if (array_key_exists('protocol', $data)) {
        $fields[] = 'protocol = ?';
        $params[] = Request::enum($data, 'protocol', $PROTOCOLS, (string) $existing['protocol']);
    }
    if (array_key_exists('tier', $data)) {
        $fields[] = 'tier = ?';
        $params[] = Request::enum($data, 'tier', $TIERS, (string) $existing['tier']);
    }
    if (array_key_exists('load_percent', $data)) {
        $fields[] = 'load_percent = ?';
        $params[] = Request::int($data, 'load_percent', 0, 0, 100);
    }
    if (array_key_exists('sort_order', $data)) {
        $fields[] = 'sort_order = ?';
        $params[] = Request::int($data, 'sort_order', 0, 0, 100000);
    }
    if (array_key_exists('is_enabled', $data)) {
        $fields[] = 'is_enabled = ?';
        $params[] = Request::bool($data, 'is_enabled', true) ? 1 : 0;
    }

    // When the config changes, re-derive the metadata from it.
    if (array_key_exists('raw_config', $data)) {
        $raw = Request::text($data, 'raw_config', 65535);
        if (trim($raw) === '') {
            Response::error('raw_config cannot be empty', 422);
        }
        $p = ConfigParser::parse($raw);

        $fields[] = 'raw_config = ?';
        $params[] = $raw;
        $fields[] = 'network = ?';
        $params[] = $p['network'];
        $fields[] = 'security = ?';
        $params[] = $p['security'];
        $fields[] = 'sni = ?';
        $params[] = $p['sni'] !== '' ? $p['sni'] : null;
        $fields[] = 'parsed_meta = ?';
        $params[] = $p['meta'] ? json_encode($p['meta'], JSON_UNESCAPED_UNICODE) : null;

        // Only auto-update address/port when the caller did not send them.
        if (!array_key_exists('address', $data) && $p['address'] !== '') {
            $fields[] = 'address = ?';
            $params[] = $p['address'];
        }
        if (!array_key_exists('port', $data) && $p['port'] > 0) {
            $fields[] = 'port = ?';
            $params[] = $p['port'];
        }
    }

    if (array_key_exists('address', $data)) {
        $fields[] = 'address = ?';
        $params[] = Request::str($data, 'address', 255);
    }
    if (array_key_exists('port', $data)) {
        $fields[] = 'port = ?';
        $params[] = Request::int($data, 'port', 0, 0, 65535);
    }

    if (!$fields) {
        Response::error('No fields to update', 422);
    }

    $params[] = $id;
    Db::run('UPDATE servers SET ' . implode(', ', $fields) . ' WHERE id = ?', $params);

    Audit::log('server.update', 'server', $id, [
        'changed' => array_map(fn($f) => explode(' ', $f)[0], $fields),
        'name'    => $existing['name'],
    ]);

    Response::ok(['updated' => true]);
}

// -------------------------------------------------------------- DELETE
if ($method === 'DELETE') {
    Auth::require('server.write');
    Auth::requireCsrf();

    if ($id === null) {
        Response::error('Missing or invalid id', 422);
    }
    $existing = Db::one('SELECT name, protocol, address, port, tier FROM servers WHERE id = ?', [$id]);
    if (!$existing) {
        Response::error('Server not found', 404);
    }

    Db::run('DELETE FROM servers WHERE id = ?', [$id]);
    Audit::log('server.delete', 'server', $id, $existing);

    Response::ok(['deleted' => true]);
}

Response::error('Unknown action', 400);
