<?php
/**
 * Admin account management — SUPER ADMIN ONLY.
 *
 * Note: the primary way to create admins is the Telegram bot (as you
 * asked). These endpoints let a Super Admin see the list, disable an
 * account, force a password reset, or revoke sessions from the browser.
 * Creating a brand-new admin from the web UI is deliberately allowed only
 * for Super Admins, and every action is mirrored to Telegram.
 *
 * GET    /api/admin/admins.php                        list admins
 * POST   /api/admin/admins.php                         create { username, role, display_name? }
 * PUT    /api/admin/admins.php?id=N                    { role?, is_active?, display_name? }
 * POST   /api/admin/admins.php?id=N&action=reset_password
 * POST   /api/admin/admins.php?id=N&action=revoke      kill all their sessions
 * DELETE /api/admin/admins.php?id=N                    delete
 */
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

$method = Request::method();
$action = (string) Request::query('action', '');
$idRaw  = Request::query('id');
$id     = ($idRaw !== null && ctype_digit($idRaw)) ? (int) $idRaw : null;

// ---------------------------------------------------------------- READ
if ($method === 'GET') {
    Auth::require('admin.read');

    $rows = Db::all(
        'SELECT a.id, a.username, a.display_name, a.role, a.is_active,
                a.telegram_user_id, a.must_change_password, a.last_login_at,
                a.last_login_ip, a.locked_until, a.created_at, a.password_changed_at,
                (SELECT COUNT(*) FROM admin_sessions s
                  WHERE s.admin_id = a.id AND s.revoked_at IS NULL AND s.expires_at > NOW()) AS active_sessions
         FROM admin_users a
         ORDER BY (a.role = \'super_admin\') DESC, a.username ASC'
    );

    foreach ($rows as &$r) {
        $r['id']                   = (int) $r['id'];
        $r['is_active']            = (int) $r['is_active'];
        $r['must_change_password'] = (int) $r['must_change_password'];
        $r['active_sessions']      = (int) $r['active_sessions'];
        $r['locked']               = !empty($r['locked_until']) && strtotime((string) $r['locked_until']) > time();
    }
    unset($r);

    Response::ok(['admins' => $rows]);
}

if (!in_array($method, ['POST', 'PUT', 'DELETE'], true)) {
    Response::methodNotAllowed(['GET', 'POST', 'PUT', 'DELETE']);
}

$me = Auth::require('admin.write');
Auth::requireCsrf();
RateLimiter::hit('admin_write', Request::ip());

// -------------------------------------------------------------- CREATE
if ($method === 'POST' && $id === null && $action === '') {
    $data = Request::body();
    Request::requireFields($data, ['username', 'role']);

    $username = Request::str($data, 'username', 64);
    if (!preg_match('/^[A-Za-z0-9._-]{3,64}$/', $username)) {
        Response::error('Username must be 3-64 characters (letters, numbers, . _ - only)', 422);
    }

    $role = Request::enum($data, 'role', [Auth::ROLE_SUPER, Auth::ROLE_ADMIN], Auth::ROLE_ADMIN);

    if (Db::value('SELECT 1 FROM admin_users WHERE username = ?', [$username])) {
        Response::error('Username already exists', 409);
    }

    // A one-time password is generated and shown once. Nobody — not even
    // the creator — can read it back afterwards.
    $password = Crypto::strongPassword(16);

    $newId = null;
    Db::tx(function () use (&$newId, $username, $password, $role, $data, $me): void {
        Db::run(
            'INSERT INTO admin_users
               (username, password_hash, display_name, role, is_active, must_change_password, created_by_tg_id)
             VALUES (?, ?, ?, ?, 1, 1, NULL)',
            [
                $username,
                Crypto::hashSecret($password),
                Request::str($data, 'display_name', 128) ?: null,
                $role,
            ]
        );
        $newId = (int) Db::pdo()->lastInsertId();
    });

    Audit::log('admin.create', 'admin_user', (string) $newId, ['username' => $username, 'role' => $role]);

    Notifier::adminChange(
        "➕ <b>Admin account created</b>\n"
        . "━━━━━━━━━━━━━━━━━━\n"
        . "Username: <code>" . Telegram::esc($username) . "</code>\n"
        . "Role: " . ($role === Auth::ROLE_SUPER ? '👑 Super Admin' : '👤 Admin') . "\n"
        . "Created by: <code>" . Telegram::esc((string) $me['username']) . "</code> (web dashboard)"
    );

    Response::ok([
        'id'                   => $newId,
        'username'             => $username,
        'role'                 => $role,
        'password'             => $password,
        'must_change_password' => true,
        'note'                 => 'Save this password now — it cannot be shown again. The user must change it at first login.',
    ], 201);
}

if ($id === null) {
    Response::error('Missing or invalid id', 422);
}

$target = Db::one('SELECT * FROM admin_users WHERE id = ?', [$id]);
if (!$target) {
    Response::error('Admin not found', 404);
}

/**
 * Guard: the system must never end up with zero usable Super Admins,
 * and an admin must not be able to lock themselves out by accident.
 */
function assert_not_last_super(int $targetId, string $what): void
{
    $target = Db::one('SELECT role, is_active FROM admin_users WHERE id = ?', [$targetId]);
    if (!$target || $target['role'] !== Auth::ROLE_SUPER) {
        return;
    }
    $others = (int) Db::value(
        'SELECT COUNT(*) FROM admin_users WHERE role = ? AND is_active = 1 AND id <> ?',
        [Auth::ROLE_SUPER, $targetId]
    );
    if ($others === 0) {
        Response::error("Cannot {$what}: this is the last active Super Admin.", 409);
    }
}

// -------------------------------------------------------------- UPDATE
if ($method === 'PUT') {
    $data   = Request::body();
    $fields = [];
    $params = [];

    if (array_key_exists('role', $data)) {
        $newRole = Request::enum($data, 'role', [Auth::ROLE_SUPER, Auth::ROLE_ADMIN], (string) $target['role']);
        if ($newRole !== $target['role']) {
            if ($newRole === Auth::ROLE_ADMIN) {
                assert_not_last_super($id, 'demote this account');
            }
            if ($id === (int) $me['admin_id'] && $newRole === Auth::ROLE_ADMIN) {
                Response::error('You cannot demote your own account.', 409);
            }
            $fields[] = 'role = ?';
            $params[] = $newRole;
        }
    }

    if (array_key_exists('is_active', $data)) {
        $active = Request::bool($data, 'is_active', true);
        if (!$active) {
            if ($id === (int) $me['admin_id']) {
                Response::error('You cannot disable your own account.', 409);
            }
            assert_not_last_super($id, 'disable this account');
        }
        $fields[] = 'is_active = ?';
        $params[] = $active ? 1 : 0;
        if (!$active) {
            Auth::revokeAllFor($id);
        }
    }

    if (array_key_exists('display_name', $data)) {
        $fields[] = 'display_name = ?';
        $params[] = Request::str($data, 'display_name', 128) ?: null;
    }

    if (Request::bool($data, 'unlock', false)) {
        $fields[] = 'locked_until = NULL';
        $fields[] = 'failed_attempts = 0';
    }

    if (!$fields) {
        Response::error('No fields to update', 422);
    }

    $params[] = $id;
    Db::run('UPDATE admin_users SET ' . implode(', ', $fields) . ' WHERE id = ?', $params);

    Audit::log('admin.update', 'admin_user', (string) $id, [
        'username' => $target['username'],
        'changed'  => array_map(fn($f) => trim(explode('=', $f)[0]), $fields),
    ]);

    Notifier::adminChange(
        "✏️ <b>Admin account updated</b>\n"
        . "User: <code>" . Telegram::esc((string) $target['username']) . "</code>\n"
        . "By: <code>" . Telegram::esc((string) $me['username']) . "</code>"
    );

    Response::ok(['updated' => true]);
}

// ------------------------------------------------------ RESET PASSWORD
if ($method === 'POST' && $action === 'reset_password') {
    $password = Crypto::strongPassword(16);

    Db::run(
        'UPDATE admin_users
         SET password_hash = ?, must_change_password = 1, failed_attempts = 0, locked_until = NULL
         WHERE id = ?',
        [Crypto::hashSecret($password), $id]
    );
    Auth::revokeAllFor($id);

    Audit::log('admin.reset_password', 'admin_user', (string) $id, ['username' => $target['username']]);

    Notifier::adminChange(
        "🔑 <b>Admin password reset</b>\n"
        . "User: <code>" . Telegram::esc((string) $target['username']) . "</code>\n"
        . "By: <code>" . Telegram::esc((string) $me['username']) . "</code>\n"
        . "All their sessions were signed out."
    );

    Response::ok([
        'password' => $password,
        'note'     => 'Save this password now — it cannot be shown again. All their sessions were signed out.',
    ]);
}

// -------------------------------------------------------------- REVOKE
if ($method === 'POST' && $action === 'revoke') {
    Auth::revokeAllFor($id);
    Audit::log('admin.revoke_sessions', 'admin_user', (string) $id, ['username' => $target['username']]);
    Response::ok(['revoked' => true]);
}

// -------------------------------------------------------------- DELETE
if ($method === 'DELETE') {
    if ($id === (int) $me['admin_id']) {
        Response::error('You cannot delete your own account.', 409);
    }
    assert_not_last_super($id, 'delete this account');

    Db::run('DELETE FROM admin_users WHERE id = ?', [$id]);

    Audit::log('admin.delete', 'admin_user', (string) $id, [
        'username' => $target['username'], 'role' => $target['role'],
    ]);

    Notifier::adminChange(
        "🗑 <b>Admin account deleted</b>\n"
        . "User: <code>" . Telegram::esc((string) $target['username']) . "</code>\n"
        . "By: <code>" . Telegram::esc((string) $me['username']) . "</code>"
    );

    Response::ok(['deleted' => true]);
}

Response::error('Unknown action', 400);
