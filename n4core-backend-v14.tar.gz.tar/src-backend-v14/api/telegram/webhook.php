<?php
/**
 * Telegram webhook receiver.
 *
 * Set it up with:   php bin/setup_webhook.php https://your-domain.com
 *
 * Security
 *  - the URL contains a secret path segment (?s=...) AND
 *  - Telegram's X-Telegram-Bot-Api-Secret-Token header is verified.
 * Both must match telegram.webhook_secret, so a leaked URL in an access
 * log is not enough to inject fake updates.
 *
 * Always answers 200 quickly — Telegram retries on anything else, which
 * would replay commands.
 */
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

// Telegram only ever POSTs.
if (Request::method() !== 'POST') {
    http_response_code(200);
    echo 'ok';
    exit;
}

$expected = (string) Config::get('telegram.webhook_secret', '');
if ($expected === '' || str_starts_with($expected, 'CHANGE_ME')) {
    Logger::error('webhook_secret_unset', []);
    http_response_code(200);
    echo 'ok';
    exit;
}

$headerSecret = Request::header('X-Telegram-Bot-Api-Secret-Token') ?? '';
$pathSecret   = (string) (Request::query('s') ?? '');

$headerOk = $headerSecret !== '' && Crypto::equals($expected, $headerSecret);
$pathOk   = $pathSecret !== '' && Crypto::equals($expected, $pathSecret);

if (!$headerOk && !$pathOk) {
    Logger::warn('webhook_bad_secret', ['ip' => Request::ip()]);
    // Deliberately vague, and still 200 so Telegram does not hammer us.
    http_response_code(200);
    echo 'ok';
    exit;
}

$raw = file_get_contents('php://input', false, null, 0, 262144);
$update = json_decode((string) $raw, true);

if (!is_array($update)) {
    http_response_code(200);
    echo 'ok';
    exit;
}

// Answer Telegram first, then work — long jobs like /backup must not
// cause a webhook timeout and a duplicate delivery.
http_response_code(200);
header('Content-Type: text/plain');
header('Content-Length: 2');
echo 'ok';

if (function_exists('fastcgi_finish_request')) {
    fastcgi_finish_request();
} elseif (function_exists('litespeed_finish_request')) {
    litespeed_finish_request();
} else {
    while (ob_get_level() > 0) {
        ob_end_flush();
    }
    flush();
}

ignore_user_abort(true);
@set_time_limit(900);

try {
    Bot::handleUpdate($update);
} catch (Throwable $e) {
    Logger::error('webhook_failed', ['msg' => $e->getMessage()]);
}
