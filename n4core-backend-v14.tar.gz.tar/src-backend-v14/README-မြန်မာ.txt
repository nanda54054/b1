═══════════════════════════════════════════════════════════════════
   N4 Core VPN — Backend & Admin Dashboard  v2.1
   အမြန်ဖတ်ရန် လက်စွဲ (မြန်မာ)
   ရက်စွဲ : 2026-08-29
═══════════════════════════════════════════════════════════════════

မင်္ဂလာပါ။
ဒီ ZIP ထဲမှာ N4 Core VPN ရဲ့ Backend (API) + Admin Dashboard
အပြီးအစီး ပါဝင်ပါတယ်။ Domain / VPS ပြောင်းရန် Bash Script ၂ ခုနဲ့
မြန်မာလို Step-by-Step လက်စွဲပါ ပါပါတယ်။


┌─────────────────────────────────────────────────────────────────┐
│  ★★★  ဘယ်ကနေ စရမလဲ?  ★★★                                      │
└─────────────────────────────────────────────────────────────────┘

  ➊  docs/GUIDE-MM.md  ကို ဖွင့်ဖတ်ပါ   ← အပြည့်အစုံ လက်စွဲ
      (Markdown viewer / VS Code / GitHub မှာ ဖွင့်ရင် လှပါတယ်)

  ➋  လုပ်စရာ ၃ ခုပဲ ရှိပါတယ် :

      A) Patch တင်ခြင်း      → GUIDE-MM.md  အပိုင်း ၁
      B) Domain ပြောင်းခြင်း  → GUIDE-MM.md  အပိုင်း ၂
      C) VPS ပြောင်းခြင်း     → GUIDE-MM.md  အပိုင်း ၃


┌─────────────────────────────────────────────────────────────────┐
│  ZIP ထဲမှာ ဘာတွေပါလဲ                                            │
└─────────────────────────────────────────────────────────────────┘

  README-မြန်မာ.txt          ← ဒီ file (အမြန်ဖတ်ရန်)

  docs/
    GUIDE-MM.md              ← ★ အပြည့်အစုံ လက်စွဲ (အပိုင်း ၀-၉)
    INSTALL.md               ← ပထမဆုံး install အတွက်

  deploy/
    n4core-domain.sh         ← ★ Domain ပြောင်းရန် Script
    n4core-migrate-vps.sh    ← ★ VPS ပြောင်းရန် Script
    nginx/n4core.conf        ← nginx နမူနာ
    apache/n4core.conf       ← apache နမူနာ
    systemd/                 ← Auto Backup timer + Bot service
    n4core.cron              ← crontab နမူနာ

  config/config.sample.php   ← Config နမူနာ
  core/                      ← Library ၁၅ ဖိုင်
  api/                       ← API endpoint အားလုံး
  admin/                     ← Dashboard (HTML/CSS/JS)
  bin/                       ← CLI tools
  sql/                       ← Database schema
  storage/                   ← backups / logs (အလွတ်)


┌─────────────────────────────────────────────────────────────────┐
│  ⚠️  အရေးကြီး သတိထားရမယ့် အချက် ၃ ချက်                          │
└─────────────────────────────────────────────────────────────────┘

  ⓵  config/config.php  ကို ZIP ထဲ မထည့်ထားပါ
      (တကယ့် password / key တွေ ပါတာမို့ လုံခြုံရေးအတွက်)
      → VPS ပေါ်မှာ ရှိပြီးသားကို ဆက်သုံးပါ
      → အသစ် install မှသာ config.sample.php ကို copy ယူပါ

  ⓶  Domain / VPS ပြောင်းရင် GitHub n4core-config.json ကို
      မဖြစ်မနေ ပြင်ရမယ် — မပြင်ရင် App က မသိပါဘူး
      → GUIDE-MM.md အပိုင်း ၄ ကို ဖတ်ပါ

  ⓷  App source code ကို ဘာမှ ပြင်စရာ မလိုပါဘူး
      Backend ကို API contract အတိအကျ ထားပြီး ရေးထားပါတယ်။
      APK အသစ် ထုတ်စရာ မလိုပါ။


┌─────────────────────────────────────────────────────────────────┐
│  A) Patch တင်ခြင်း — အမြန် ၅ ဆင့်                                │
└─────────────────────────────────────────────────────────────────┘

  ဘာအတွက်လဲ?
    • Backup က Telegram ပို့ပြီးပေမယ့် Dashboard မှာ အနီ "failed"
      ပြနေတဲ့ ပြဿနာ ဖြေရှင်း
    • Admin role တွေ VIP account ခွဲထားခြင်း (role isolation)
    • Admin ကိုယ်တိုင် password ပြောင်းလို့ ရအောင်

  1) ssh root@core.nandaxr.tech
     cd /var/www/n4core

  2) မူရင်း backup ယူ
     STAMP=$(date +%F-%H%M%S)
     mkdir -p /root/n4core-before-patch-$STAMP
     cp -a core/Auth.php core/Bot.php api/admin/*.php \
           admin/assets/js/app.js /root/n4core-before-patch-$STAMP/

  3) ZIP ထဲက file ၁၀ ခုကို တင် (GUIDE-MM.md အပိုင်း ၁.၃ ကြည့်)

  4) permission + syntax စစ်
     chown -R www-data:www-data core api admin bin
     php -l core/Auth.php && php -l api/admin/backups.php

  5) reload + browser cache ရှင်း
     systemctl reload php8.1-fpm
     → Dashboard မှာ Ctrl+Shift+R

  ✅ Backups page မှာ အစိမ်း "delivered" / "stored" ပြရင် ပြီးပါပြီ


┌─────────────────────────────────────────────────────────────────┐
│  B) Domain ပြောင်းခြင်း — အမြန် ၄ ဆင့်                           │
└─────────────────────────────────────────────────────────────────┘

  1) Script တင်ပြီး executable လုပ်
     scp deploy/n4core-domain.sh root@VPS:/var/www/n4core/deploy/
     chmod +x /var/www/n4core/deploy/n4core-domain.sh

  2) DNS ကို အရင် ချိန် (A record → VPS IP)
     curl -s https://api.ipify.org        # VPS IP သိရန်
     dig +short core.newdomain.com        # ရောက်ပြီလား စစ်

  3) စမ်းကြည့် ➜ တကယ် run
     sudo ./deploy/n4core-domain.sh core.newdomain.com --dry-run
     sudo ./deploy/n4core-domain.sh core.newdomain.com --ssl

  4) GitHub n4core-config.json ပြင်
     {
       "api_base_url": "https://core.newdomain.com/api",
       "maintenance": false,
       "message": ""
     }

  Script က အလိုအလျောက် လုပ်ပေးတာ ၇ ဆင့် :
     ၁ config.php + vhost backup ယူ
     ၂ nginx vhost အသစ် ရေး (+ ထပ်နေတဲ့ vhost disable)
     ၃ CORS origin ပြောင်း
     ၄ Let's Encrypt SSL ထုတ်
     ၅ nginx + php-fpm reload
     ၆ Telegram webhook ပြန်မှတ်ပုံတင်
     ၇ Health check ၈ ခု စစ်

  အခြား option :
     --show      လက်ရှိ အခြေအနေ ပြရုံ
     --dry-run   စမ်းရုံ (ဘာမှ မပြောင်း)
     --app-dir   path မတူရင်


┌─────────────────────────────────────────────────────────────────┐
│  C) VPS ပြောင်းခြင်း — အမြန် ၅ ဆင့်                              │
└─────────────────────────────────────────────────────────────────┘

  [VPS အိုကြီး မှာ]

  1) စစ်ပါ
     cd /var/www/n4core
     chmod +x deploy/n4core-migrate-vps.sh
     sudo ./deploy/n4core-migrate-vps.sh check

  2) Package ထုတ်ပါ
     sudo ./deploy/n4core-migrate-vps.sh export
     → /root/n4core-migrate-<ရက်စွဲ>.tar.gz.enc ရလာမယ်

  3) Decrypt key ကို ကူးထားပါ (မရှိရင် ဖြေလို့ မရဘူး!)
     grep encryption_key /var/www/n4core/config/config.php

  [VPS အသစ် မှာ]

  4) File ၂ ခု ပို့ပြီး import
     scp n4core-migrate-*.enc     root@NEW_VPS:/root/
     scp n4core-migrate-vps.sh    root@NEW_VPS:/root/

     ssh root@NEW_VPS
     chmod +x /root/n4core-migrate-vps.sh
     sudo /root/n4core-migrate-vps.sh import /root/n4core-migrate-*.enc

  5) Domain ချိန်ပြီး GitHub ပြင်
     cd /var/www/n4core
     sudo ./deploy/n4core-domain.sh core.nandaxr.tech --ssl

  ⚠️  .enc file ကို tar -xzf နဲ့ တိုက်ရိုက် ဖြေလို့ မရပါ
      (encrypt ထားတာမို့) — import command ကိုသာ သုံးပါ

  import က အလိုအလျောက် လုပ်ပေးတာ ၈ ဆင့် :
     ၁ Decrypt + ဖြေ
     ၂ ဖိုင်တွေ ပြည့်စုံလား စစ်
     ၃ MANIFEST ပြ (ဘယ် server ကလာလဲ)
     ၄ package တွေ install (nginx, php, mariadb ...)
     ၅ Code ထည့် (အိုတာကို .old-<ရက်စွဲ> လုပ်)
     ၆ Database + user ဖန်တီး → dump import
     ၇ Permission ချိန် + systemd timer တင်
     ၈ Health check + DB row count ပြ


┌─────────────────────────────────────────────────────────────────┐
│  လုံခြုံရေး — တစ်ခါတည်း လုပ်ထားရမယ့်                             │
└─────────────────────────────────────────────────────────────────┘

  cd /var/www/n4core

  # VIP code/token hash လုပ်
  sudo -u www-data php bin/migrate.php --hash-codes --hash-tokens
  sudo -u www-data php bin/migrate.php --status      # still plain: 0

  # dl folder ဖျက် (public ကနေ code မကူးလို့ရအောင်)
  rm -rf dl

  # config backup + lock
  cp config/config.php /root/n4core-config-$(date +%F).php
  chmod 600 /root/n4core-config-*.php
  chmod 400 config/config.php

  # permission
  chown -R www-data:www-data .
  find . -type d -exec chmod 750 {} \;
  find . -type f -exec chmod 640 {} \;
  chmod -R 770 storage
  chmod 750 bin/*.php deploy/*.sh
  chmod 400 config/config.php

  # firewall
  ufw allow 22/tcp && ufw allow 80/tcp && ufw allow 443/tcp
  ufw --force enable

  # စစ်ဆေးမှု ၅ ခု
  D=https://core.nandaxr.tech
  curl -so /dev/null -w "config  %{http_code}\n" $D/config/config.php   # 403/404
  curl -so /dev/null -w "core    %{http_code}\n" $D/core/Auth.php       # 403/404
  curl -so /dev/null -w "storage %{http_code}\n" $D/storage/            # 403/404
  curl -so /dev/null -w "admin   %{http_code}\n" $D/admin/              # 200
  curl -s $D/api/public/plans.php | head -c 12                          # {"ok":true

  ⚠️ config က 200 ပြရင် အလွန်အန္တရာယ်ကြီး
     → sudo ./deploy/n4core-domain.sh core.nandaxr.tech --ssl  ပြန် run ပါ


┌─────────────────────────────────────────────────────────────────┐
│  Backup Status နားလည်ခြင်း                                       │
└─────────────────────────────────────────────────────────────────┘

  🟢 stored      = ဖိတ်ပြီး၊ server ပေါ် သိမ်းထားပြီး
  🟢 delivered   = ဖိတ်ပြီး၊ Telegram ကိုပါ ပို့ပြီး  ← အောင်မြင်
  🟡 missing     = record ရှိပေမယ့် file ပျောက်နေတယ်
  🔵 sending…    = Telegram ကို ပို့နေတယ်
  🔴 failed      = မအောင်မြင်ဘူး

  Manual backup ၃ နည်း :
     Dashboard → Backups → Run Backup
     Telegram  → /backup  (သို့) /backup db  (သို့) /backup files
     Terminal  → sudo -u www-data php bin/cron.php

  Auto backup : နေ့စဉ် ရန်ကုန်စံတော်ချိန် ၁၂:၀၀ AM
     systemctl list-timers | grep n4core


┌─────────────────────────────────────────────────────────────────┐
│  Telegram Bot Command (Owner : 5567910560)                       │
└─────────────────────────────────────────────────────────────────┘

  /status   Server အခြေအနေ      /backup    Manual backup
  /vip      VIP စာရင်း           /backups   Backup ၂၀ ခု
  /servers  Server စာရင်း        /addadmin  Admin ဖန်တီး
  /logins   Login မှတ်တမ်း       /deladmin  Admin ဖျက်
  /alerts   Alarm on/off        /role      Role ပြောင်း
  /admins   Admin စာရင်း         /resetpw   Password reset
  /whoami   ကိုယ့် ID ပြ          /revoke    Session ရုပ်သိမ်း
  /help     Command စာရင်း       /unlock    Lock ဖြေ

  Bot အလုပ်မလုပ်ရင် :
     sudo -u www-data php bin/setup_webhook.php --info
     sudo -u www-data php bin/setup_webhook.php https://core.nandaxr.tech


┌─────────────────────────────────────────────────────────────────┐
│  ပြဿနာ ဖြေရှင်းနည်း အမြန်                                        │
└─────────────────────────────────────────────────────────────────┘

  Dashboard အဖြူထူထူ
     systemctl restart php8.1-fpm nginx
     tail -50 /var/log/nginx/error.log

  502 Bad Gateway  (php-fpm socket မတူတာ)
     ls /run/php/
     sudo ./deploy/n4core-domain.sh core.nandaxr.tech

  App မှာ Server မပြ
     curl -s https://raw.githubusercontent.com/USER/REPO/main/n4core-config.json
     curl -s https://core.nandaxr.tech/api/public/servers.php | head -c 100

  Password မေ့
     sudo -u www-data php bin/create_admin.php --username owner --reset

  Account lock
     Telegram က  /unlock  သုံးပါ

  ➜ ပိုအသေးစိတ် — GUIDE-MM.md အပိုင်း ၈ ကို ဖတ်ပါ


┌─────────────────────────────────────────────────────────────────┐
│  မှတ်စု                                                          │
└─────────────────────────────────────────────────────────────────┘

  App path        /var/www/n4core
  Dashboard       core.nandaxr.tech/admin/
  API base        core.nandaxr.tech/api
  Database        n4core_db  (user: n4core_user)
  PHP-FPM         php8.1-fpm
  nginx vhost     /etc/nginx/sites-available/n4core.conf
  Telegram Bot    @CoreVN4NBOT
  Owner ID        5567910560
  Timezone        Asia/Yangon
  Auto backup     နေ့စဉ် 00:00 YGN
  Config backup   /root/n4core-config-*.php

═══════════════════════════════════════════════════════════════════
  N4 Core VPN Backend v2.1  —  2026-08-29
  ★ အသေးစိတ် အားလုံး docs/GUIDE-MM.md ထဲ ရှိပါတယ် ★
═══════════════════════════════════════════════════════════════════
