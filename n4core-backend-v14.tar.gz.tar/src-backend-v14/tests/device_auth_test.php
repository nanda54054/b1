<?php
declare(strict_types=1);
/**
 * Attack-simulation test for core/DeviceAuth.php.
 *
 *     php tests/device_auth_test.php
 *
 * Exercises the REAL production class (required unmodified below) against an
 * in-memory SQLite database, with thin stubs standing in for Db/Config/Crypto
 * so no MySQL, no config.php and no network are needed. Safe to run anywhere,
 * including on a laptop before deploying.
 *
 * Every scenario below is a real attack this feature exists to stop, most of
 * all #5 — modify the APK in MT Manager, re-sign it, and try to use it.
 *
 * Exit code 0 = all defences holding. Run it after ANY change to
 * DeviceAuth.php, and especially before enabling require_device_auth.
 */
$OFFICIAL_CERT = 'a9f71f873dcee4adb1f51f924a78bd8acc29c55ea1ec6b675bf2014a1d8a81c1';
$ATTACKER_CERT = 'deadbeef1111111111111111111111111111111111111111111111111111beef';
$BOOTSTRAP     = 'super_secret_bootstrap_value_from_keygen';

$pdo = new PDO('sqlite::memory:');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->exec('CREATE TABLE app_devices (device_id TEXT PRIMARY KEY, secret_enc TEXT, cert_sha256 TEXT,
  app_version TEXT, platform TEXT, model TEXT, os_version TEXT, integrity_flags TEXT,
  created_at TEXT, last_seen_at TEXT, last_ip TEXT, req_count INTEGER DEFAULT 0,
  banned INTEGER DEFAULT 0, ban_reason TEXT, banned_at TEXT)');
$pdo->exec('CREATE TABLE app_nonces (nonce TEXT PRIMARY KEY, device_id TEXT, used_at TEXT)');

final class Request {
    public static string $method='GET'; public static string $body=''; public static array $headers=[];
    public static function method(): string { return self::$method; }
    public static function rawBody(): string { return self::$body; }
    public static function ip(): string { return '203.0.113.7'; }
    public static function header(string $n): ?string { return self::$headers[$n] ?? null; }
    public static function body(): array { return json_decode(self::$body,true) ?: []; }
    public static function str(array $d,string $k,int $m=255,string $x=''): string { $v=$d[$k]??$x; return is_scalar($v)?substr((string)$v,0,$m):$x; }
    public static function int(array $d,string $k,int $x=0,?int $a=null,?int $b=null): int { return (int)($d[$k]??$x); }
}
final class ApiExit extends RuntimeException { public string $err; public int $status;
    public function __construct(string $e,int $c){ $this->err=$e; $this->status=$c; parent::__construct($e);} }
final class Response { public static function error(string $m,int $c=400,array $e=[]): never { throw new ApiExit($m,$c); } }
final class Config {
    public static array $v=[];
    public static function get(string $p, mixed $d=null): mixed { return self::$v[$p] ?? $d; }
}
final class Crypto {
    public static function token(int $b=32): string { return bin2hex(random_bytes($b)); }
    public static function encrypt(string $p): string { return 'v1.'.base64_encode($p); }
    public static function decrypt(?string $p): ?string { return ($p===null||$p==='')?null:base64_decode(substr($p,3)); }
}
final class Db {
    public static PDO $pdo;
    private static function q(string $s,array $p){ $s=str_replace('NOW()',"datetime('now')",$s);
        // MySQL upsert -> SQLite equivalent. Applied ONLY to app_devices:
        // app_nonces MUST keep its strict INSERT so a duplicate primary key
        // still throws, which is the whole replay-detection mechanism.
        if (str_contains($s,'ON DUPLICATE KEY UPDATE')) {
            $s=preg_replace('/ON DUPLICATE KEY UPDATE.*/s','',$s);
            $s=str_replace('INSERT INTO','INSERT OR REPLACE INTO',$s);
        }
        $st=self::$pdo->prepare($s); $st->execute($p); return $st; }
    public static function one($s,$p=[]){ $r=self::q($s,$p)->fetch(PDO::FETCH_ASSOC); return $r===false?null:$r; }
    public static function all($s,$p=[]){ return self::q($s,$p)->fetchAll(PDO::FETCH_ASSOC); }
    public static function run($s,$p=[]){ return self::q($s,$p)->rowCount(); }
    public static function value($s,$p=[]){ return self::q($s,$p)->fetchColumn(); }
}
final class Logger { public static function warn($e,$c=[]){} public static function error($e,$c=[]){} }
final class Audit { public static function log(...$a){} }
final class RateLimiter { public static function hit($n,$k){} }
final class Notifier { public static array $alerts=[]; public static function securityAlert($m){ self::$alerts[]=$m; } }

Db::$pdo = $pdo;
Config::$v = [
    'security.app_bootstrap_secret' => $BOOTSTRAP,
    'security.expected_cert_sha256' => $OFFICIAL_CERT,
    'security.require_device_auth'  => true,
];

require __DIR__ . '/../core/DeviceAuth.php';

// ---- helpers that mimic the Flutter app exactly ----------------------
function appRegister(string $deviceId, string $cert, string $bootstrap, bool $debuggable=false): array {
    $ts = time();
    $regKey = $cert === '' ? $bootstrap : hash_hmac('sha256', $cert, $bootstrap);
    $sig = hash_hmac('sha256', $deviceId."\n".$ts."\n".$cert, $regKey);
    return ['device_id'=>$deviceId,'timestamp'=>$ts,'signature'=>$sig,'platform'=>'android',
            'model'=>'SM-A536E','os_version'=>'14','app_version'=>'1.1.0',
            'integrity'=>['cert_sha256'=>$cert,'signer_count'=>1,'debuggable'=>$debuggable,
                          'rooted'=>false,'instrumented'=>false,'cloned'=>false,'installer'=>'']];
}
function appSignRequest(string $deviceId,string $secret,string $method,string $path,array $query=[],string $body=''): void {
    $ts=time(); $nonce=bin2hex(random_bytes(16));
    ksort($query); $parts=[]; foreach($query as $k=>$v){$parts[]="$k=$v";}
    $canonical=implode("\n",[strtoupper($method),$path,implode('&',$parts),hash('sha256',$body),(string)$ts,$nonce]);
    Request::$method=$method; Request::$body=$body;
    $_GET=$query; $_SERVER['REQUEST_URI']=$path.($query?'?'.http_build_query($query):'');
    Request::$headers=['X-Device-Id'=>$deviceId,'X-Timestamp'=>(string)$ts,
                       'X-Nonce'=>$nonce,'X-Sig'=>hash_hmac('sha256',$canonical,$secret)];
}
function reset_static(){ $r=new ReflectionClass('DeviceAuth');
    foreach(['resolved'=>false,'device'=>null,'failure'=>null] as $k=>$v){ $p=$r->getProperty($k); $p->setAccessible(true); $p->setValue(null,$v);} }
function attempt(callable $fn): array { reset_static(); try { return ['ok'=>true,'val'=>$fn()]; } catch(ApiExit $e){ return ['ok'=>false,'err'=>$e->err,'code'=>$e->status]; } }

$pass=0;$fail=0;
function check(string $label,bool $cond,string $detail=''){ global $pass,$fail;
    if($cond){$pass++; echo "  ✅ $label\n";} else {$fail++; echo "  ❌ $label  $detail\n";} }

echo "\n═══ 1. GENUINE APP ═══\n";
$deviceId = hash('sha256','genuine-phone');
$r = attempt(fn()=>DeviceAuth::register(appRegister($deviceId,$OFFICIAL_CERT,$BOOTSTRAP)));
check('genuine build registers', $r['ok'], $r['err']??'');
$secret = $r['val'] ?? '';
check('received a 64-hex device secret', strlen($secret)===64);
$stored = $pdo->query("SELECT secret_enc FROM app_devices")->fetchColumn();
check('secret stored ENCRYPTED (not plaintext)', $stored!==$secret && str_starts_with((string)$stored,'v1.'));

echo "\n═══ 2. SIGNED REQUESTS ═══\n";
appSignRequest($deviceId,$secret,'GET','/api/public/servers.php');
$r=attempt(function(){ DeviceAuth::require(); return true; });
check('correctly signed request ACCEPTED', $r['ok'], $r['err']??'');

appSignRequest($deviceId,$secret,'GET','/api/public/servers.php');
$good=Request::$headers['X-Sig'];
Request::$headers['X-Sig']=str_repeat('0',64);
$r=attempt(function(){ DeviceAuth::require(); return true; });
check('forged signature REJECTED', !$r['ok'] && $r['err']==='invalid_signature', json_encode($r));

echo "\n═══ 3. curl WITH NO HEADERS (the original hole) ═══\n";
Request::$headers=[]; Request::$method='GET'; $_GET=[]; $_SERVER['REQUEST_URI']='/api/public/servers.php';
$r=attempt(function(){ DeviceAuth::require(); return true; });
check('bare curl REJECTED with 401', !$r['ok'] && $r['code']===401, json_encode($r));

echo "\n═══ 4. REPLAY ATTACK ═══\n";
appSignRequest($deviceId,$secret,'GET','/api/public/servers.php');
$captured=Request::$headers; $capturedUri=$_SERVER['REQUEST_URI'];
$r=attempt(function(){ DeviceAuth::require(); return true; });
check('original request accepted', $r['ok'], $r['err']??'');
Request::$headers=$captured; $_SERVER['REQUEST_URI']=$capturedUri;
$r=attempt(function(){ DeviceAuth::require(); return true; });
check('REPLAYED identical request REJECTED', !$r['ok'] && $r['err']==='replay_detected', json_encode($r));

echo "\n═══ 5. MODDED / RE-SIGNED APK (the owner's attack) ═══\n";
$moddedId = hash('sha256','modded-phone');
// Attacker mods APK, must re-sign -> different cert. Derives key from THEIR cert.
$r = attempt(fn()=>DeviceAuth::register(appRegister($moddedId,$ATTACKER_CERT,$BOOTSTRAP)));
check('re-signed APK REFUSED registration', !$r['ok'] && $r['code']===401, json_encode($r));
check('Telegram security alert fired', count(Notifier::$alerts)>0);

// Attacker steals bootstrap secret AND lies about cert, but signs with real bootstrap
$r = attempt(fn()=>DeviceAuth::register(appRegister($moddedId,$ATTACKER_CERT,'wrong_secret')));
check('wrong bootstrap secret REFUSED', !$r['ok'] && $r['err']==='invalid_signature');

// Debuggable rebuild carrying the correct cert
$r = attempt(fn()=>DeviceAuth::register(appRegister($moddedId,$OFFICIAL_CERT,$BOOTSTRAP,true)));
check('debuggable build REFUSED', !$r['ok'] && $r['code']===401, json_encode($r));

echo "\n═══ 6. CLOCK SKEW ═══\n";
$body=appRegister($deviceId,$OFFICIAL_CERT,$BOOTSTRAP); $body['timestamp']=time()-99999;
$r=attempt(fn()=>DeviceAuth::register($body));
check('stale timestamp REFUSED (clock_skew)', !$r['ok'] && $r['err']==='clock_skew', json_encode($r));

echo "\n═══ 7. BAN ENFORCEMENT ═══\n";
$pdo->exec("UPDATE app_devices SET banned=1 WHERE device_id='$deviceId'");
appSignRequest($deviceId,$secret,'GET','/api/public/servers.php');
$r=attempt(function(){ DeviceAuth::require(); return true; });
check('banned device BLOCKED even with valid signature', !$r['ok'] && $r['err']==='device_banned', json_encode($r));

echo "\n═══ 8. UNREGISTERED DEVICE ═══\n";
appSignRequest(hash('sha256','never-seen'),'whatever','GET','/api/public/servers.php');
$r=attempt(function(){ DeviceAuth::require(); return true; });
check('unknown device -> device_not_registered (self-heal)', !$r['ok'] && $r['err']==='device_not_registered', json_encode($r));

echo "\n═══ 9. DUAL DISTRIBUTION (Play Store + direct download) ═══\n";
// Google Play App Signing re-signs the uploaded AAB with Google's own key,
// so the SAME app reports a different certificate depending on where the
// user installed it from. Both must be accepted, and only those two.
$PLAY_CERT = '3b21c4d5e6f70819a2b3c4d5e6f708192a3b4c5d6e7f8091a2b3c4d5e6f70819';
Config::$v['security.expected_cert_sha256'] = [$OFFICIAL_CERT, $PLAY_CERT];

$directId = hash('sha256','direct-download-phone');
$r = attempt(fn()=>DeviceAuth::register(appRegister($directId,$OFFICIAL_CERT,$BOOTSTRAP)));
check('direct-download cert ACCEPTED', $r['ok'] && strlen($r['val'])>=32, json_encode($r));

$playId = hash('sha256','play-store-phone');
$r = attempt(fn()=>DeviceAuth::register(appRegister($playId,$PLAY_CERT,$BOOTSTRAP)));
check('Play App Signing cert ACCEPTED', $r['ok'] && strlen($r['val'])>=32, json_encode($r));

// Widening the pin must NOT weaken it: a third, unknown key still fails.
$r = attempt(fn()=>DeviceAuth::register(appRegister(hash('sha256','mod2'),$ATTACKER_CERT,$BOOTSTRAP)));
check('attacker cert STILL REFUSED with 2 pins', !$r['ok'] && $r['code']===401, json_encode($r));

// A malformed pin must be dropped, never treated as "matches anything".
Config::$v['security.expected_cert_sha256'] = ['NOT-A-HASH', $OFFICIAL_CERT];
$r = attempt(fn()=>DeviceAuth::register(appRegister(hash('sha256','mod3'),$ATTACKER_CERT,$BOOTSTRAP)));
check('malformed pin entry ignored, attacker still refused', !$r['ok'] && $r['code']===401, json_encode($r));

// Backwards compatibility: a plain string still works.
Config::$v['security.expected_cert_sha256'] = $OFFICIAL_CERT;
$r = attempt(fn()=>DeviceAuth::register(appRegister(hash('sha256','legacy'),$OFFICIAL_CERT,$BOOTSTRAP)));
check('single string pin still supported', $r['ok'], json_encode($r));

echo "\n".str_repeat('═',56)."\n";
echo $fail===0 ? "🎉 ALL $pass CHECKS PASSED\n" : "❌ $fail FAILED / $pass passed\n";
exit($fail===0?0:1);
