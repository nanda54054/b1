/* ==========================================================================
   N4 Core VPN — Admin dashboard core runtime
   --------------------------------------------------------------------------
   Provides: Theme, Store, Api, UI (toast/modal/confirm), fmt helpers.
   Vanilla ES2019. No bundler, no dependencies.
   ========================================================================== */
'use strict';

/* ------------------------------------------------------------------ Theme */
const Theme = (() => {
  const KEY = 'n4.theme';
  const root = document.documentElement;

  function apply(mode) {
    // mode: 'dark' | 'light' | 'auto'
    const resolved = mode === 'auto'
      ? (window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark')
      : mode;

    root.setAttribute('data-theme', resolved);
    root.style.colorScheme = resolved;

    // keep the mobile browser chrome in step with the page
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', resolved === 'light' ? '#f4f6fa' : '#0c1017');

    document.querySelectorAll('[data-theme-btn]').forEach(b => {
      b.classList.toggle('on', b.dataset.themeBtn === mode);
    });
  }

  function set(mode) {
    try { localStorage.setItem(KEY, mode); } catch (_) {}
    apply(mode);
  }

  function get() {
    try { return localStorage.getItem(KEY) || 'auto'; } catch (_) { return 'auto'; }
  }

  function init() {
    apply(get());
    // follow the OS only while in auto mode
    const mq = window.matchMedia('(prefers-color-scheme: light)');
    const onChange = () => { if (get() === 'auto') apply('auto'); };
    mq.addEventListener ? mq.addEventListener('change', onChange) : mq.addListener(onChange);
  }

  return { init, set, get };
})();

// Paint the theme before first frame so there is never a white flash.
Theme.init();

/* ------------------------------------------------------------------ Store */
const Store = (() => {
  const K = { token: 'n4.token', csrf: 'n4.csrf' };

  // localStorage, not sessionStorage: on Android the browser drops
  // sessionStorage when the tab is backgrounded and reclaimed, which logged
  // the operator out constantly. The server still enforces the real
  // lifetimes (sliding idle + absolute cap), so persisting the token here
  // does not extend how long it is valid — it only stops the token being
  // thrown away while it is still good.
  return {
    get token() { try { return localStorage.getItem(K.token) || ''; } catch (_) { return ''; } },
    get csrf()  { try { return localStorage.getItem(K.csrf)  || ''; } catch (_) { return ''; } },
    save(token, csrf) {
      try {
        localStorage.setItem(K.token, token);
        localStorage.setItem(K.csrf, csrf);
      } catch (_) {}
    },
    clear() {
      try { localStorage.removeItem(K.token); localStorage.removeItem(K.csrf); } catch (_) {}
      // Older builds stored these in sessionStorage; clear both so a logout
      // cannot leave a stale token behind in the other bucket.
      try { sessionStorage.removeItem(K.token); sessionStorage.removeItem(K.csrf); } catch (_) {}
    },
  };
})();

/* -------------------------------------------------------------------- Api */
const Api = (() => {
  // The dashboard is served from /admin/, the API lives at /api/.
  const BASE = (location.pathname.replace(/\/admin\/?.*$/, '') || '') + '/api';

  class ApiError extends Error {
    constructor(msg, status, payload) {
      super(msg);
      this.status = status;
      this.payload = payload || {};
    }
  }

  async function call(path, opts) {
    opts = opts || {};
    const method = (opts.method || 'GET').toUpperCase();
    const headers = { 'Accept': 'application/json' };

    if (Store.token) headers['X-Admin-Token'] = Store.token;
    // Only mutations need the CSRF token.
    if (method !== 'GET' && Store.csrf) headers['X-CSRF-Token'] = Store.csrf;

    const init = { method, headers, cache: 'no-store' };
    if (opts.body !== undefined) {
      headers['Content-Type'] = 'application/json';
      init.body = JSON.stringify(opts.body);
    }

    let res;
    try {
      res = await fetch(BASE + path, init);
    } catch (e) {
      throw new ApiError('Network unreachable — check your connection.', 0);
    }

    // Endpoints that stream a file (backup download) bypass the JSON envelope.
    const ctype = res.headers.get('Content-Type') || '';
    if (!ctype.includes('json')) {
      if (!res.ok) throw new ApiError('Request failed (' + res.status + ')', res.status);
      return res;
    }

    let json = null;
    try { json = await res.json(); } catch (_) {}

    if (!json || typeof json !== 'object') {
      throw new ApiError('Malformed server response.', res.status);
    }

    if (json.ok === true) return json.data === undefined ? {} : json.data;

    const msg = json.error || 'Request failed';

    // ---- global auth handling ------------------------------------------
    if (res.status === 401) {
      Store.clear();
      document.dispatchEvent(new CustomEvent('n4:signed-out', { detail: { reason: msg } }));
    }
    if (res.status === 428 || json.must_change_password) {
      document.dispatchEvent(new CustomEvent('n4:must-change-password'));
    }
    if (res.status === 419) {
      // CSRF drifted — safest recovery is a fresh sign-in.
      Store.clear();
      document.dispatchEvent(new CustomEvent('n4:signed-out', { detail: { reason: 'Session expired.' } }));
    }

    throw new ApiError(msg, res.status, json);
  }

  return {
    ApiError,
    base: BASE,
    get:  (p)     => call(p, { method: 'GET' }),
    post: (p, b)  => call(p, { method: 'POST', body: b || {} }),
    put:  (p, b)  => call(p, { method: 'PUT',  body: b || {} }),
    del:  (p, b)  => call(p, { method: 'DELETE', body: b || {} }),
    raw:  call,
  };
})();

/* --------------------------------------------------------------------- UI */
const UI = (() => {
  /* --- escaping: every value from the API goes through this ------------- */
  function esc(v) {
    if (v === null || v === undefined) return '';
    return String(v)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  /* --- toast ----------------------------------------------------------- */
  const ICONS = { ok: '✔', warn: '⚠', danger: '✕', info: 'ℹ' };

  function toast(msg, kind, ms) {
    kind = kind || 'info';
    const host = document.getElementById('toasts');
    if (!host) return;

    const el = document.createElement('div');
    el.className = 'toast ' + kind;
    el.setAttribute('role', kind === 'danger' ? 'alert' : 'status');
    el.innerHTML = '<span class="ico">' + (ICONS[kind] || ICONS.info) + '</span>' +
                   '<span class="msg">' + esc(msg) + '</span>';
    host.appendChild(el);

    const life = ms || (kind === 'danger' ? 6500 : 3600);
    setTimeout(() => {
      el.classList.add('out');
      setTimeout(() => el.remove(), 200);
    }, life);
  }

  /* --- modal ----------------------------------------------------------- */
  let openModals = 0;

  function modal(opts) {
    // opts: { title, sub, body(HTML), foot(HTML), wide, onMount(root, close) }
    const back = document.createElement('div');
    back.className = 'modal-back';
    back.innerHTML =
      '<div class="modal' + (opts.wide ? ' wide' : '') + '" role="dialog" aria-modal="true">' +
        '<div class="modal-head">' +
          '<div><h3>' + esc(opts.title || '') + '</h3>' +
          (opts.sub ? '<div class="sub">' + esc(opts.sub) + '</div>' : '') + '</div>' +
          '<button class="x" type="button" aria-label="Close">&times;</button>' +
        '</div>' +
        '<div class="modal-body">' + (opts.body || '') + '</div>' +
        (opts.foot ? '<div class="modal-foot">' + opts.foot + '</div>' : '') +
      '</div>';

    function close() {
      back.remove();
      if (--openModals <= 0) { openModals = 0; document.body.style.overflow = ''; }
      document.removeEventListener('keydown', onKey);
    }
    function onKey(e) { if (e.key === 'Escape') close(); }

    back.querySelector('.x').addEventListener('click', close);
    back.addEventListener('mousedown', e => { if (e.target === back) close(); });
    document.addEventListener('keydown', onKey);

    document.body.appendChild(back);
    openModals++;
    document.body.style.overflow = 'hidden';

    if (opts.onMount) opts.onMount(back, close);

    // focus the first sensible control
    const first = back.querySelector('input:not([type=hidden]),select,textarea,button.btn-primary');
    if (first) setTimeout(() => first.focus(), 40);

    return { root: back, close };
  }

  /* --- confirm --------------------------------------------------------- */
  function confirm(opts) {
    return new Promise(resolve => {
      let done = false;
      const m = modal({
        title: opts.title || 'Are you sure?',
        body: '<div class="alert ' + (opts.kind || 'warn') + '">' +
                '<span class="ico">' + (opts.kind === 'danger' ? '⚠' : 'ℹ') + '</span>' +
                '<div>' + (opts.html || esc(opts.message || '')) + '</div>' +
              '</div>' +
              (opts.detail ? '<p class="muted" style="margin:0;font-size:12.5px">' + esc(opts.detail) + '</p>' : ''),
        foot: '<button class="btn" data-no type="button">' + esc(opts.cancelText || 'Cancel') + '</button>' +
              '<button class="btn ' + (opts.kind === 'danger' ? 'btn-danger' : 'btn-primary') + '" data-yes type="button">' +
                esc(opts.okText || 'Confirm') + '</button>',
        onMount(root, close) {
          root.querySelector('[data-yes]').addEventListener('click', () => { done = true; close(); resolve(true); });
          root.querySelector('[data-no]').addEventListener('click', close);
        },
      });
      // Closing by X / Esc / backdrop counts as "no".
      const obs = new MutationObserver(() => {
        if (!document.body.contains(m.root)) { obs.disconnect(); if (!done) resolve(false); }
      });
      obs.observe(document.body, { childList: true });
    });
  }

  /* --- button busy state ---------------------------------------------- */
  /**
   * Toggle a button's loading state.
   *   UI.busy(btn, true) / UI.busy(btn, false)  — explicit form
   *   const done = UI.busy(btn); ... done();    — scoped form
   * Called with one argument it turns loading ON and hands back the undo.
   */
  function busy(btn, on) {
    const scoped = arguments.length < 2;
    const state  = scoped ? true : !!on;

    if (btn) {
      btn.classList.toggle('loading', state);
      btn.disabled = state;
    }
    // Always return a callable so `done()` can never throw.
    return () => busy(btn, false);
  }

  /* --- clipboard ------------------------------------------------------- */
  async function copy(text, label) {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
      } else {
        // http:// fallback — clipboard API is unavailable without TLS
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.cssText = 'position:fixed;opacity:0;top:0';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        ta.remove();
      }
      toast((label || 'Copied') + ' to clipboard', 'ok', 2000);
    } catch (_) {
      toast('Could not copy — please select and copy manually.', 'warn');
    }
  }

  /* --- skeleton rows --------------------------------------------------- */
  function skeletonRows(cols, rows) {
    let out = '';
    for (let r = 0; r < (rows || 4); r++) {
      out += '<tr>';
      for (let c = 0; c < cols; c++) {
        out += '<td><div class="skeleton" style="width:' + (45 + ((r * 7 + c * 13) % 45)) + '%"></div></td>';
      }
      out += '</tr>';
    }
    return out;
  }

  function empty(icon, title, msg) {
    return '<div class="empty"><span class="ico">' + icon + '</span>' +
           '<b>' + esc(title) + '</b><p>' + esc(msg || '') + '</p></div>';
  }

  /* --- delegated click routing ---------------------------------------- */
  function on(root, selector, handler) {
    root.addEventListener('click', e => {
      const t = e.target.closest(selector);
      if (t && root.contains(t)) handler(t, e);
    });
  }

  return { esc, toast, modal, confirm, busy, copy, skeletonRows, empty, on };
})();

/* ------------------------------------------------------------------- fmt */
const fmt = (() => {
  /* ------------------------------------------------------------------------
     The API returns timestamps as bare "YYYY-MM-DD HH:MM:SS" strings in the
     SERVER's timezone (Asia/Yangon by default) with no offset marker. A
     browser in another timezone would read those digits as its own local
     time and every "x ago" would be wrong by the zone difference.

     So we keep a skew: (server wall clock - viewer wall clock) in ms, set
     once from the session/settings payload. `now()` then answers "what time
     is it, expressed on the server's clock", which is the same scale the
     parsed timestamps live on.
     --------------------------------------------------------------------- */
  let skew = 0;

  /** Feed this the server's own "YYYY-MM-DD HH:MM:SS" to calibrate. */
  function syncClock(serverTime) {
    const d = parse(serverTime);
    if (!d) return;
    skew = d.getTime() - Date.now();
  }

  /** "Now" on the server's clock. */
  function now() { return Date.now() + skew; }

  function num(n) {
    n = Number(n || 0);
    return n.toLocaleString('en-US');
  }

  function bytes(b) {
    b = Number(b || 0);
    const u = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0;
    while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
    return (i === 0 ? b : b.toFixed(1)) + ' ' + u[i];
  }

  /** Parses "YYYY-MM-DD HH:MM:SS" as a *local* (server-timezone) wall clock. */
  function parse(s) {
    if (!s) return null;
    if (s instanceof Date) return s;
    const m = String(s).match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?/);
    if (m) return new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0));
    const d = new Date(s);
    return isNaN(d) ? null : d;
  }

  const MON = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

  function date(s) {
    const d = parse(s);
    if (!d) return '—';
    return d.getDate() + ' ' + MON[d.getMonth()] + ' ' + d.getFullYear();
  }

  function dateTime(s) {
    const d = parse(s);
    if (!d) return '—';
    const p = n => String(n).padStart(2, '0');
    return date(s) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  }

  function ago(s) {
    const d = parse(s);
    if (!d) return '—';
    let sec = Math.floor((now() - d.getTime()) / 1000);
    const future = sec < 0;
    sec = Math.abs(sec);

    let out;
    if (sec < 45)          out = 'just now';
    else if (sec < 5400)   out = Math.round(sec / 60) + 'm';
    else if (sec < 172800) out = Math.round(sec / 3600) + 'h';
    else if (sec < 2592000)out = Math.round(sec / 86400) + 'd';
    else                   return date(s);

    if (out === 'just now') return out;
    return future ? 'in ' + out : out + ' ago';
  }

  /** Days until an expiry date; negative when already past. */
  function daysLeft(s) {
    const d = parse(s);
    if (!d) return null;
    return Math.ceil((d.getTime() - now()) / 86400000);
  }

  function expiryPill(s) {
    const n = daysLeft(s);
    if (n === null) return '<span class="pill">no expiry</span>';
    if (n < 0)   return '<span class="pill danger">expired ' + Math.abs(n) + 'd ago</span>';
    if (n === 0) return '<span class="pill danger">expires today</span>';
    if (n <= 7)  return '<span class="pill warn">' + n + ' days left</span>';
    return '<span class="pill ok">' + n + ' days left</span>';
  }

  return { num, bytes, parse, date, dateTime, ago, daysLeft, expiryPill,
           syncClock, now };
})();
