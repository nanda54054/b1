/* ==========================================================================
   N4 Core VPN — Admin dashboard application
   --------------------------------------------------------------------------
   Structure:
     App        – boot, auth, routing, capability gating
     Dashboard  – stats overview
     Accounts   – VIP account management        (Super Admin + Admin)
     Plans      – VIP price management          (Super Admin only)
     Servers    – server add/edit/bulk import   (Super Admin only)
     Locations  – region management             (Super Admin only)
     Admins     – admin management              (Super Admin only)
     Backups    – manual backup + download      (Super Admin only)
     Security   – logins / audit / sessions     (Super Admin only)
     Settings   – runtime settings              (Super Admin only)
   ========================================================================== */
'use strict';

const App = (() => {
  let me = null;              // { id, username, display_name, role, permissions[] }
  let current = 'dashboard';

  const TITLES = {
    dashboard: ['Dashboard',      'Live overview'],
    accounts:  ['VIP Accounts',   'Create, extend and manage app users'],
    plans:     ['VIP Prices',     'Plans shown inside the app'],
    servers:   ['Servers',        'Paste any config URL — fields auto-fill'],
    locations: ['Regions',        'Country groups for the server list'],
    admins:    ['Admins',         'Dashboard access control'],
    backups:   ['Backups',        'Database + files archives'],
    security:  ['Security',       'Sign-ins, audit trail and blocks'],
    settings:  ['Settings',       'Runtime configuration'],
  };

  /* ------------------------------------------------------------- helpers */
  function can(cap) { return !!(me && me.permissions && me.permissions.indexOf(cap) > -1); }
  function isSuper() { return !!(me && me.role === 'super_admin'); }
  function user() { return me; }

  /** Hides every element whose data-cap the current admin lacks. */
  function applyCaps() {
    document.querySelectorAll('[data-cap]').forEach(el => {
      el.classList.toggle('hidden', !can(el.dataset.cap));
    });
  }

  /* ------------------------------------------------------------- routing */
  function go(page) {
    if (!TITLES[page]) page = 'dashboard';

    const btn = document.querySelector('.nav-item[data-page="' + page + '"]');
    if (btn && btn.classList.contains('hidden')) page = 'dashboard';

    current = page;

    document.querySelectorAll('.nav-item').forEach(b =>
      b.classList.toggle('active', b.dataset.page === page));
    document.querySelectorAll('.page').forEach(s =>
      s.classList.toggle('on', s.dataset.page === page));

    document.getElementById('page-title').textContent = TITLES[page][0];
    document.getElementById('page-sub').textContent   = TITLES[page][1];

    closeDrawer();
    try { history.replaceState(null, '', '#' + page); } catch (_) {}

    load(page);
  }

  function load(page) {
    const map = {
      dashboard: Dashboard, accounts: Accounts, plans: Plans,
      servers: Servers, locations: Locations, admins: Admins,
      backups: Backups, security: Security, settings: Settings,
    };
    const mod = map[page];
    if (mod && mod.load) {
      Promise.resolve(mod.load()).catch(err => {
        if (err && err.status === 401) return;   // handled globally
        UI.toast((err && err.message) || 'Failed to load', 'danger');
      });
    }
  }

  function refresh() { load(current); }

  /* ------------------------------------------------------------- drawer */
  function openDrawer() {
    document.getElementById('sidebar').classList.add('open');
    if (!document.querySelector('.scrim')) {
      const s = document.createElement('div');
      s.className = 'scrim';
      s.addEventListener('click', closeDrawer);
      document.body.appendChild(s);
    }
  }
  function closeDrawer() {
    document.getElementById('sidebar').classList.remove('open');
    const s = document.querySelector('.scrim');
    if (s) s.remove();
  }

  /* ---------------------------------------------------------------- auth */
  function showLogin(msg) {
    me = null;
    document.getElementById('app-view').classList.remove('on');
    document.getElementById('login-view').style.display = '';
    const box = document.getElementById('login-alert');
    box.innerHTML = msg
      ? '<div class="alert warn"><span class="ico">⚠</span><div>' + UI.esc(msg) + '</div></div>'
      : '';
    const u = document.getElementById('lg-user');
    if (u) setTimeout(() => u.focus(), 60);
  }

  function showApp() {
    document.getElementById('login-view').style.display = 'none';
    document.getElementById('app-view').classList.add('on');
  }

  function paintWho() {
    const name = me.display_name || me.username;
    document.getElementById('who-name').textContent = name;
    document.getElementById('who-role').textContent =
      me.role === 'super_admin' ? 'Super Admin' : 'Admin';
    document.getElementById('who-av').textContent =
      (name.charAt(0) || '?').toUpperCase();
  }

  async function bootSession() {
    const data = await Api.get('/admin/session.php');
    me = data.admin;

    // Align "x ago" with the server's timezone before anything renders.
    if (data.server_time) fmt.syncClock(data.server_time);

    applyCaps();
    paintWho();

    if (data.brand) document.getElementById('brand-name').textContent = data.brand;
    if (data.stats) {
      document.getElementById('badge-srv').textContent = fmt.num(data.stats.servers);
      document.getElementById('badge-vip').textContent = fmt.num(data.stats.vip_accounts);
    }

    showApp();

    if (me.must_change_password) {
      forcePasswordChange();
      return;
    }
    go((location.hash || '').replace('#', '') || 'dashboard');
  }

  async function doLogin(e) {
    e.preventDefault();
    const btn = document.getElementById('lg-btn');
    const username = document.getElementById('lg-user').value.trim();
    const password = document.getElementById('lg-pass').value;
    if (!username || !password) return;

    UI.busy(btn, true);
    document.getElementById('login-alert').innerHTML = '';

    try {
      const d = await Api.post('/admin/login.php', { username, password });
      Store.save(d.token, d.csrf);
      me = d.admin;

      // Align "x ago" with the server's timezone before anything renders.
      if (d.server_time) fmt.syncClock(d.server_time);

      applyCaps();
      paintWho();
      showApp();
      document.getElementById('lg-pass').value = '';

      if (me.must_change_password) { forcePasswordChange(); return; }

      UI.toast('Welcome back, ' + (me.display_name || me.username), 'ok');
      go('dashboard');
    } catch (err) {
      const box = document.getElementById('login-alert');
      box.innerHTML = '<div class="alert danger"><span class="ico">✕</span><div>' +
                      UI.esc(err.message || 'Sign-in failed') + '</div></div>';
      document.getElementById('lg-pass').select();
    } finally {
      UI.busy(btn, false);
    }
  }

  async function logout(all) {
    try { await Api.post('/admin/session.php?action=' + (all ? 'logout_all' : 'logout')); } catch (_) {}
    Store.clear();
    showLogin('You have been signed out.');
  }

  /* --------------------------------------------- forced password change */
  function forcePasswordChange() {
    UI.modal({
      title: 'Change your password',
      sub: 'Required before you can continue',
      body:
        '<div class="alert warn"><span class="ico">⚠</span><div>' +
          '<b>First sign-in detected.</b>' +
          'Your temporary password must be replaced before the dashboard unlocks.' +
        '</div></div>' +
        pwFormHtml(),
      foot: '<button class="btn btn-primary" data-save type="button">Set new password</button>',
      onMount(root, close) {
        wirePwForm(root, close, true);
      },
    });
  }

  function pwFormHtml() {
    return '' +
      '<div class="field"><label>Current password</label>' +
        '<input class="input" data-cur type="password" autocomplete="current-password"></div>' +
      '<div class="field"><label>New password</label>' +
        '<input class="input" data-new type="password" autocomplete="new-password">' +
        '<div class="hint">At least 10 characters with upper case, lower case and a digit.</div></div>' +
      '<div class="field"><label>Repeat new password</label>' +
        '<input class="input" data-new2 type="password" autocomplete="new-password"></div>' +
      '<div data-pw-msg></div>';
  }

  function wirePwForm(root, close, forced) {
    const btn  = root.querySelector('[data-save]');
    const msg  = root.querySelector('[data-pw-msg]');

    // A forced change has no escape hatch — remove the close affordances.
    if (forced) {
      const x = root.querySelector('.modal-head .x');
      if (x) x.remove();
    }

    btn.addEventListener('click', async () => {
      const cur  = root.querySelector('[data-cur]').value;
      const nw   = root.querySelector('[data-new]').value;
      const nw2  = root.querySelector('[data-new2]').value;
      msg.innerHTML = '';

      if (nw !== nw2) {
        msg.innerHTML = '<div class="alert danger"><span class="ico">✕</span><div>The new passwords do not match.</div></div>';
        return;
      }
      UI.busy(btn, true);
      try {
        await Api.post('/admin/session.php?action=password', {
          current_password: cur, new_password: nw,
        });
        UI.toast('Password updated. Other sessions were signed out.', 'ok');
        close();
        if (forced) { me.must_change_password = false; go('dashboard'); }
      } catch (err) {
        msg.innerHTML = '<div class="alert danger"><span class="ico">✕</span><div>' +
                        UI.esc(err.message) + '</div></div>';
      } finally {
        UI.busy(btn, false);
      }
    });

    root.addEventListener('keydown', e => { if (e.key === 'Enter') btn.click(); });
  }

  function changePassword() {
    UI.modal({
      title: 'Change password',
      body: pwFormHtml(),
      foot: '<button class="btn" data-x type="button">Cancel</button>' +
            '<button class="btn btn-primary" data-save type="button">Update</button>',
      onMount(root, close) {
        root.querySelector('[data-x]').addEventListener('click', close);
        wirePwForm(root, close, false);
      },
    });
  }

  /* ---------------------------------------------------------------- boot */
  function bindShell() {
    document.getElementById('login-form').addEventListener('submit', doLogin);

    document.querySelectorAll('[data-theme-btn]').forEach(b =>
      b.addEventListener('click', () => Theme.set(b.dataset.themeBtn)));

    document.getElementById('nav').addEventListener('click', e => {
      const b = e.target.closest('.nav-item');
      if (b) go(b.dataset.page);
    });

    document.getElementById('burger').addEventListener('click', openDrawer);
    document.getElementById('btn-refresh').addEventListener('click', () => {
      refresh();
      UI.toast('Refreshed', 'ok', 1400);
    });

    document.getElementById('btn-logout').addEventListener('click', async () => {
      const ok = await UI.confirm({
        title: 'Sign out?',
        message: 'You will need your password to sign back in.',
        okText: 'Sign out',
      });
      if (ok) logout(false);
    });

    document.getElementById('who-name').addEventListener('click', changePassword);
    document.getElementById('who-name').style.cursor = 'pointer';
    document.getElementById('who-name').title = 'Change password';

    document.getElementById('pages').addEventListener('click', e => {
      const g = e.target.closest('[data-goto]');
      if (g) go(g.dataset.goto);
    });

    document.addEventListener('n4:signed-out', e => {
      showLogin((e.detail && e.detail.reason) || 'Your session has expired.');
    });

    window.addEventListener('hashchange', () => {
      const p = (location.hash || '').replace('#', '');
      if (p && p !== current && me) go(p);
    });

    // keyboard: "/" focuses the nearest search box
    document.addEventListener('keydown', e => {
      if (e.key === '/' && !/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) {
        const box = document.querySelector('.page.on input[type=text], .page.on .input[placeholder*="Search"]');
        if (box) { e.preventDefault(); box.focus(); }
      }
    });
  }

  async function boot() {
    bindShell();
    if (!Store.token) { showLogin(); return; }
    try {
      await bootSession();
    } catch (_) {
      Store.clear();
      showLogin();
    }
  }

  return { boot, go, refresh, can, isSuper, user, changePassword, logout, applyCaps };
})();

/* ==========================================================================
   DASHBOARD
   ========================================================================== */
const Dashboard = (() => {

  function tile(kind, key, val, detail) {
    return '<div class="stat ' + kind + '">' +
             '<div class="k">' + key + '</div>' +
             '<div class="v">' + val + '</div>' +
             (detail ? '<div class="d">' + detail + '</div>' : '') +
           '</div>';
  }

  async function load() {
    const host = document.getElementById('dash-stats');
    host.innerHTML = '<div class="stat"><div class="skeleton" style="width:60%"></div>' +
                     '<div class="skeleton" style="width:40%;height:24px;margin-top:9px"></div></div>'.repeat(4);

    const d = await Api.get('/admin/stats.php');
    const c = d.counters || {};

    // ---- tiles ---------------------------------------------------------
    host.innerHTML =
      tile('vip', 'VIP accounts', fmt.num(c.vip_active),
           fmt.num(c.vip_total) + ' total · ' + fmt.num(c.vip_expired) + ' expired' +
           (c.vip_disabled ? ' · ' + fmt.num(c.vip_disabled) + ' disabled' : '')) +
      tile('', 'Servers', fmt.num(c.servers_enabled),
           fmt.num(c.servers_vip) + ' VIP · ' + fmt.num(c.servers_free) + ' free' +
           (c.servers_total !== c.servers_enabled
             ? ' · ' + fmt.num(c.servers_total - c.servers_enabled) + ' off' : '')) +
      tile('ok', 'Live app sessions', fmt.num(c.sessions_live),
           fmt.num(c.devices_bound) + ' devices bound') +
      tile('', 'Regions', fmt.num(c.locations_active),
           fmt.num(c.plans_active) + ' price plans active');

    // ---- alerts --------------------------------------------------------
    const alerts = [];
    if (d.last_backup) {
      const age = fmt.daysLeft(d.last_backup.created_at);
      if (age !== null && age < -2) {
        alerts.push(['warn', '⚠', 'Last backup was ' + fmt.ago(d.last_backup.created_at) +
                     '. Check that the cron job is running.']);
      }
    } else if (App.can('backup.run')) {
      alerts.push(['warn', '⚠', 'No backup has been taken yet. ' +
                   'Run one from the Backups page or send /backup to your Telegram bot.']);
    }
    if (d.telegram && d.telegram.ready === false && App.isSuper()) {
      alerts.push(['info', 'ℹ', 'Telegram bot is not configured — login alarms and ' +
                   'auto-backup delivery are inactive.']);
    }
    if (d.security && d.security.failed_logins_24h > 10) {
      alerts.push(['danger', '⚠', fmt.num(d.security.failed_logins_24h) +
                   ' failed sign-in attempts in the last 24 hours.']);
    }
    document.getElementById('dash-alerts').innerHTML = alerts.map(a =>
      '<div class="alert ' + a[0] + '"><span class="ico">' + a[1] + '</span><div>' +
      UI.esc(a[2]) + '</div></div>').join('');

    // ---- expiring soon -------------------------------------------------
    const exp = d.expiring_soon || [];
    document.getElementById('dash-expiring').innerHTML = exp.length
      ? '<table class="tbl"><thead><tr><th>Username</th><th>Plan</th><th>Expires</th></tr></thead><tbody>' +
        exp.map(r =>
          '<tr><td><b>' + UI.esc(r.username) + '</b></td>' +
          '<td class="muted">' + UI.esc(r.plan_name || '—') + '</td>' +
          '<td>' + fmt.expiryPill(r.expires_at) + '</td></tr>').join('') +
        '</tbody></table>'
      : UI.empty('✓', 'Nothing expiring', 'No VIP account expires in the next 7 days.');

    // ---- by region -----------------------------------------------------
    const reg = d.by_region || [];
    const max = reg.reduce((m, r) => Math.max(m, +r.total || 0), 1);
    document.getElementById('dash-regions').innerHTML = reg.length
      ? '<table class="tbl"><thead><tr><th>Region</th><th style="width:44%">Servers</th><th class="num">VIP</th></tr></thead><tbody>' +
        reg.map(r =>
          '<tr><td><span class="flag">' + UI.esc(r.flag_emoji || '') + '</span>' +
              UI.esc(r.name || r.country_code) + '</td>' +
          '<td><div class="bar" title="' + r.total + ' servers"><i style="width:' +
              Math.round((+r.total / max) * 100) + '%"></i></div></td>' +
          '<td class="num">' + fmt.num(r.vip) + ' / ' + fmt.num(r.total) + '</td></tr>').join('') +
        '</tbody></table>'
      : UI.empty('◍', 'No servers yet', 'Add your first server to see regions here.');

    // ---- recent logins (super only) ------------------------------------
    const lg = d.recent_logins || [];
    const el = document.getElementById('dash-logins');
    if (el) {
      el.innerHTML = lg.length
        ? '<table class="tbl"><thead><tr><th>Result</th><th>User</th><th>IP</th><th>When</th></tr></thead><tbody>' +
          lg.slice(0, 8).map(r => Security.loginRow(r)).join('') + '</tbody></table>'
        : UI.empty('◭', 'No sign-ins recorded', '');
    }
  }

  // `tile` is reused by the Backups page for its stat strip.
  return { load, tile };
})();


/* ==========================================================================
   VIP ACCOUNTS
   ========================================================================== */
const Accounts = (() => {
  let rows = [];
  let plans = [];
  let bound = false;
  let timer = null;

  function statusPill(r) {
    if (!r.is_active) return '<span class="pill danger"><span class="dot"></span>disabled</span>';
    if (r.expired)    return '<span class="pill danger"><span class="dot"></span>expired</span>';
    if (r.locked_until && fmt.parse(r.locked_until) > new Date())
      return '<span class="pill warn"><span class="dot"></span>locked</span>';
    return '<span class="pill ok"><span class="dot"></span>active</span>';
  }

  function render() {
    const host = document.getElementById('acc-list');

    // When isolation is on, say so once — otherwise a scoped admin cannot
    // tell an empty list apart from a broken one.
    const scopeNote = App.user() && App.user().vip_scoped
      ? '<div class="alert" style="margin-bottom:12px"><span class="ico">◐</span>' +
          '<div><b>Your accounts only.</b> ' +
          'Accounts created by other admins are hidden by policy.</div></div>'
      : '';

    if (!rows.length) {
      host.innerHTML = scopeNote + UI.empty('◉', 'No VIP accounts found',
        'Create one with the “New VIP” button, or clear your filters.');
      return;
    }

    host.innerHTML = scopeNote +
      '<table class="tbl"><thead><tr>' +
        '<th>Username</th><th>Plan</th><th>Devices</th><th>Status</th>' +
        '<th>Expires</th><th>Last login</th><th></th>' +
      '</tr></thead><tbody>' +
      rows.map(r => {
        const pct = r.device_limit ? Math.min(100, Math.round(r.devices_used / r.device_limit * 100)) : 0;
        const cls = pct >= 100 ? 'danger' : pct >= 70 ? 'warn' : '';
        return '<tr data-id="' + UI.esc(r.id) + '">' +
          '<td><b>' + UI.esc(r.username) + '</b>' +
            (r.note ? '<div class="muted trunc" style="font-size:11.5px">' + UI.esc(r.note) + '</div>' : '') +
          '</td>' +
          '<td class="muted">' + UI.esc(r.plan_name || '—') + '</td>' +
          '<td style="min-width:96px">' +
            '<div style="font-size:12px;margin-bottom:3px">' + r.devices_used + ' / ' + r.device_limit +
              (r.active_sessions ? ' <span class="muted">(' + r.active_sessions + ' live)</span>' : '') + '</div>' +
            '<div class="bar"><i class="' + cls + '" style="width:' + pct + '%"></i></div>' +
          '</td>' +
          '<td>' + statusPill(r) + '</td>' +
          '<td>' + fmt.expiryPill(r.expires_at) + '</td>' +
          '<td class="muted" style="font-size:12.5px">' +
            (r.last_login_at ? fmt.ago(r.last_login_at) : 'never') + '</td>' +
          '<td class="act">' +
            '<button class="btn btn-xs" data-act="reveal" title="Show access code">🔑</button>' +
            '<button class="btn btn-xs" data-act="extend" title="Extend">＋</button>' +
            '<button class="btn btn-xs" data-act="devices" title="Devices">▤</button>' +
            '<button class="btn btn-xs" data-act="edit" title="Edit">✎</button>' +
            (App.can('vip.delete')
              ? '<button class="btn btn-xs btn-danger" data-act="del" title="Delete">✕</button>' : '') +
          '</td></tr>';
      }).join('') + '</tbody></table>';
  }

  async function load() {
    const host = document.getElementById('acc-list');
    host.innerHTML = '<table class="tbl"><tbody>' + UI.skeletonRows(6, 5) + '</tbody></table>';

    const q = document.getElementById('acc-q').value.trim();
    const st = document.getElementById('acc-status').value;
    const qs = [];
    if (q)  qs.push('q=' + encodeURIComponent(q));
    if (st) qs.push('status=' + encodeURIComponent(st));

    const d = await Api.get('/admin/accounts.php' + (qs.length ? '?' + qs.join('&') : ''));
    rows = d.accounts || [];
    render();
    bind();
  }

  async function ensurePlans() {
    if (plans.length) return plans;
    try {
      const d = await Api.get('/admin/plans.php');
      plans = (d.plans || []).filter(p => p.is_active !== 0);
    } catch (_) { plans = []; }
    return plans;
  }

  function bind() {
    if (bound) return;
    bound = true;

    const debounce = () => { clearTimeout(timer); timer = setTimeout(() => load(), 300); };
    document.getElementById('acc-q').addEventListener('input', debounce);
    document.getElementById('acc-status').addEventListener('change', () => load());
    document.getElementById('acc-new').addEventListener('click', () => form(null));

    // Bulk delete of long-expired accounts. Shown only to an operator who
    // can already delete a single account — the button is not an alternative
    // route around that permission, and the API enforces it independently.
    const purge = document.getElementById('acc-purge');
    if (purge && App.can('vip.delete')) {
      purge.hidden = false;
      purge.addEventListener('click', async () => {
        const ok = await UI.confirm({
          title: 'Delete expired accounts?',
          html: '<b>This cannot be undone.</b>Every account that expired more than the ' +
                'grace period ago is removed, along with its bound devices and sessions. ' +
                'Accounts that expired today are kept so a renewal can still reuse them.',
          kind: 'danger', okText: 'Delete expired',
        });
        if (!ok) return;
        UI.busy(purge, true);
        try {
          const d = await Api.post('/admin/accounts.php?action=purge_expired', {});
          UI.toast(d.deleted
            ? d.deleted + ' expired account' + (d.deleted === 1 ? '' : 's') + ' deleted'
            : 'No accounts are past the ' + d.grace_days + '-day grace period', d.deleted ? 'ok' : '');
          await load();
        } catch (e) { UI.toast(e.message, 'danger'); }
        UI.busy(purge, false);
      });
    }

    UI.on(document.getElementById('acc-list'), '[data-act]', btn => {
      const id = btn.closest('tr').dataset.id;
      const row = rows.find(r => r.id === id);
      const act = btn.dataset.act;
      if (act === 'reveal')  reveal(row);
      if (act === 'extend')  extend(row);
      if (act === 'devices') devices(row);
      if (act === 'edit')    form(row);
      if (act === 'del')     remove(row);
    });
  }

  /* ---- reveal access code ------------------------------------------- */
  async function reveal(r) {
    try {
      const d = await Api.get('/admin/accounts.php?action=reveal&id=' + encodeURIComponent(r.id));
      UI.modal({
        title: 'Access code',
        sub: r.username,
        body:
          '<div class="alert warn"><span class="ico">⚠</span><div>' +
            'Share this only with the account owner. Viewing it has been recorded in the audit trail.' +
          '</div></div>' +
          '<div class="copy-row"><code id="rv-code">' + UI.esc(d.access_code) + '</code>' +
            '<button class="btn btn-sm" data-copy type="button">Copy</button></div>',
        foot: '<button class="btn" data-x type="button">Close</button>',
        onMount(root, close) {
          root.querySelector('[data-x]').addEventListener('click', close);
          root.querySelector('[data-copy]').addEventListener('click',
            () => UI.copy(d.access_code, 'Access code'));
        },
      });
    } catch (e) { UI.toast(e.message, 'danger'); }
  }

  /* ---- extend -------------------------------------------------------- */
  function extend(r) {
    UI.modal({
      title: 'Extend subscription',
      sub: r.username + ' — currently ' + (r.expired ? 'expired' : r.days_left + ' days left'),
      body:
        '<div class="field"><label>Add days</label>' +
          '<div class="chips" style="margin-bottom:8px">' +
            [7, 30, 60, 90, 180, 365].map(n =>
              '<button class="btn btn-sm" data-days="' + n + '" type="button">+' + n + 'd</button>').join('') +
          '</div>' +
          '<input class="input" data-d type="number" min="1" max="3650" value="30">' +
          '<div class="hint">Counted from the current expiry date, or from today if already expired.</div>' +
        '</div>',
      foot: '<button class="btn" data-x type="button">Cancel</button>' +
            '<button class="btn btn-primary" data-ok type="button">Extend</button>',
      onMount(root, close) {
        const inp = root.querySelector('[data-d]');
        root.querySelectorAll('[data-days]').forEach(b =>
          b.addEventListener('click', () => { inp.value = b.dataset.days; }));
        root.querySelector('[data-x]').addEventListener('click', close);
        root.querySelector('[data-ok]').addEventListener('click', async e => {
          UI.busy(e.target, true);
          try {
            const d = await Api.post('/admin/accounts.php?action=extend&id=' + encodeURIComponent(r.id),
                                     { days: parseInt(inp.value, 10) || 30 });
            UI.toast('Extended to ' + fmt.date(d.expires_at), 'ok');
            close(); load();
          } catch (err) { UI.toast(err.message, 'danger'); UI.busy(e.target, false); }
        });
      },
    });
  }

  /* ---- devices ------------------------------------------------------- */
  async function devices(r) {
    const m = UI.modal({
      title: 'Bound devices',
      sub: r.username + ' — limit ' + r.device_limit,
      body: '<div id="dv-body"><table class="tbl"><tbody>' + UI.skeletonRows(3, 3) + '</tbody></table></div>',
      foot: '<button class="btn btn-danger" data-unbind type="button">Unbind all</button>' +
            '<button class="btn" data-x type="button">Close</button>',
      wide: true,
      onMount(root, close) {
        root.querySelector('[data-x]').addEventListener('click', close);
        root.querySelector('[data-unbind]').addEventListener('click', async () => {
          const ok = await UI.confirm({
            title: 'Unbind all devices?',
            message: 'The user will be signed out everywhere and can log in again on new devices.',
            kind: 'danger', okText: 'Unbind all',
          });
          if (!ok) return;
          try {
            await Api.post('/admin/accounts.php?action=unbind_all&id=' + encodeURIComponent(r.id));
            UI.toast('All devices unbound', 'ok');
            close(); load();
          } catch (e) { UI.toast(e.message, 'danger'); }
        });
      },
    });

    async function paint() {
      const body = m.root.querySelector('#dv-body');
      try {
        const d = await Api.get('/admin/account_devices.php?id=' + encodeURIComponent(r.id));
        const list = d.devices || [];
        body.innerHTML = list.length
          ? '<table class="tbl"><thead><tr><th>Device</th><th>First seen</th><th>Last seen</th><th></th></tr></thead><tbody>' +
            list.map(x =>
              '<tr><td class="mono trunc" title="' + UI.esc(x.device_id) + '">' +
                  UI.esc(x.device_label || x.device_id) + '</td>' +
              '<td class="muted">' + fmt.dateTime(x.created_at) + '</td>' +
              '<td class="muted">' + fmt.ago(x.last_seen_at) + '</td>' +
              '<td class="act"><button class="btn btn-xs btn-danger" data-dv="' +
                  UI.esc(x.device_id) + '">Unbind</button></td></tr>').join('') +
            '</tbody></table>'
          : UI.empty('▤', 'No devices bound', 'This account has never signed in from the app.');

        UI.on(body, '[data-dv]', async b => {
          try {
            await Api.del('/admin/account_devices.php?id=' + encodeURIComponent(r.id) +
                          '&device_id=' + encodeURIComponent(b.dataset.dv));
            UI.toast('Device unbound', 'ok');
            paint();
          } catch (e) { UI.toast(e.message, 'danger'); }
        });
      } catch (e) {
        body.innerHTML = '<div class="alert danger"><span class="ico">✕</span><div>' +
                         UI.esc(e.message) + '</div></div>';
      }
    }
    paint();
  }

  /* ---- create / edit -------------------------------------------------- */
  async function form(r) {
    const editing = !!r;
    await ensurePlans();

    const planOpts = '<option value="">— No plan (manual) —</option>' +
      plans.map(p => '<option value="' + UI.esc(p.id) + '"' +
        (r && r.plan_id === p.id ? ' selected' : '') + '>' +
        UI.esc(p.name) + ' · ' + p.device_limit + ' device(s) · ' + p.duration_days + 'd</option>').join('');

    UI.modal({
      title: editing ? 'Edit VIP account' : 'New VIP account',
      sub: editing ? r.username : 'The app signs in with username + access code',
      body:
        '<div class="row"><div class="field"><label>Username</label>' +
          '<input class="input" data-u value="' + UI.esc(r ? r.username : '') + '" ' +
          'autocapitalize="none" spellcheck="false"></div>' +
        '<div class="field"><label>Plan</label><select class="select" data-plan>' + planOpts + '</select></div></div>' +

        '<div class="row"><div class="field"><label>Device limit</label>' +
          '<input class="input" data-dl type="number" min="1" max="100" value="' +
          (r ? r.device_limit : 1) + '"></div>' +
        '<div class="field"><label>' + (editing ? 'Expires at' : 'Duration (days)') + '</label>' +
          (editing
            ? '<input class="input" data-exp type="date" value="' +
              UI.esc(String(r.expires_at || '').slice(0, 10)) + '">'
            : '<input class="input" data-days type="number" min="1" max="3650" value="30">') +
        '</div></div>' +

        // One-tap durations. Typing 365 on a phone keypad is the slowest part
        // of creating an account, and these four cover almost every sale.
        (editing ? '' :
          '<div class="field dur-chips">' +
            [30, 90, 180, 365].map(d =>
              '<button class="btn btn-sm" data-dur="' + d + '" type="button">' +
                d + ' D</button>').join('') +
          '</div>') +

        (editing ? '' :
          '<div class="field"><label>Access code <span class="muted">(optional)</span></label>' +
            '<div class="copy-row plain">' +
              '<input class="input mono" data-code placeholder="Leave blank to auto-generate" ' +
              'autocapitalize="characters" spellcheck="false">' +
              '<button class="btn btn-sm" data-gen type="button">AUTO</button>' +
            '</div></div>') +

        // Pre-filled from the plan's own rate x the duration, so the usual
        // sale needs no typing at all. Still free text, not type=number:
        // once an operator overrides it they write "8000 Ks" or "KPay 5000",
        // and the value is only ever displayed, never summed.
        '<div class="field"><label>Collected price <span class="muted">(MMK)</span>' +
          '<span class="muted" data-price-hint style="float:right;font-weight:400"></span></label>' +
          '<div class="copy-row plain">' +
            '<input class="input" data-price maxlength="64" inputmode="text" ' +
            'value="' + UI.esc(r ? (r.price || '') : '') + '">' +
            '<button class="btn btn-sm" data-price-auto type="button" title="Recalculate from the plan rate">AUTO</button>' +
          '</div></div>' +

        '<div class="field"><label>Note <span class="muted">(internal)</span></label>' +
          '<input class="input" data-note maxlength="255" value="' + UI.esc(r ? (r.note || '') : '') + '"></div>' +

        (editing
          ? '<div class="field"><label class="switch">' +
              '<input type="checkbox" data-active' + (r.is_active ? ' checked' : '') + '>' +
              '<span class="track"></span><span class="lbl">Account enabled</span></label></div>' +
            (r.locked_until
              ? '<div class="field"><label class="switch"><input type="checkbox" data-unlock>' +
                '<span class="track"></span><span class="lbl">Clear failed-attempt lockout</span></label></div>'
              : '')
          : '') +
        '<div data-msg></div>',
      foot: (editing
              ? '<button class="btn" data-reset type="button">Reset code</button>' : '') +
            '<button class="btn" data-x type="button">Cancel</button>' +
            '<button class="btn btn-primary" data-ok type="button">' +
              (editing ? 'Save changes' : 'Create account') + '</button>',
      onMount(root, close) {
        const msg = root.querySelector('[data-msg]');
        root.querySelector('[data-x]').addEventListener('click', close);

        // picking a plan pre-fills the limit + duration
        const sel = root.querySelector('[data-plan]');
        sel.addEventListener('change', () => {
          const p = plans.find(x => x.id === sel.value);
          if (!p) return;
          root.querySelector('[data-dl]').value = p.device_limit;
          const dd = root.querySelector('[data-days]');
          if (dd) dd.value = p.duration_days;
          syncDur();
          syncPrice();
        });

        // Duration chips write into the same [data-days] input the submit
        // handler already reads, so nothing downstream changes.
        const daysEl = root.querySelector('[data-days]');

        function syncDur() {
          if (!daysEl) return;
          const v = daysEl.value.trim();
          root.querySelectorAll('[data-dur]').forEach(b => {
            b.classList.toggle('btn-primary', b.dataset.dur === v);
          });
        }

        if (daysEl) {
          root.querySelectorAll('[data-dur]').forEach(b => {
            b.addEventListener('click', () => {
              daysEl.value = b.dataset.dur;
              syncDur();
              syncPrice();     // 90 days costs three times 30 days
            });
          });
          daysEl.addEventListener('input', () => { syncDur(); syncPrice(); });
          syncDur();
        }

        /* ---- price, derived from the plan rate ---------------------------
           The plan already stores what it sells for and over how many days,
           so the amount for any duration is just that rate pro-rated. The
           operator only touches the field when a particular sale differs
           from the list price.

           `touched` is the whole point: once they type in the box we stop
           overwriting it, otherwise picking a duration chip afterwards would
           silently throw away the number they just entered. */
        const priceEl   = root.querySelector('[data-price]');
        const priceHint = root.querySelector('[data-price-hint]');
        let priceTouched = editing && !!(r && r.price);

        function planRate() {
          const p = plans.find(x => x.id === sel.value);
          if (!p || !p.price_amount || !p.duration_days) return null;
          return { per: p.price_amount / p.duration_days, plan: p };
        }

        function calcPrice() {
          const rate = planRate();
          if (!rate) return null;
          const days = parseInt(daysEl ? daysEl.value : (r ? 30 : 30), 10) || 0;
          if (days <= 0) return null;
          // Rounded to whole kyat — nobody collects a fraction of one.
          return String(Math.round(rate.per * days));
        }

        function syncPrice(force) {
          const rate = planRate();
          if (priceHint) {
            priceHint.textContent = rate
              ? Math.round(rate.per * rate.plan.duration_days) + ' / ' + rate.plan.duration_days + 'd rate'
              : 'No rate set on this plan';
          }
          if (!priceEl) return;
          if (priceTouched && !force) return;
          const v = calcPrice();
          if (v !== null) priceEl.value = v;
        }

        if (priceEl) {
          priceEl.addEventListener('input', () => { priceTouched = true; });
          const pa = root.querySelector('[data-price-auto]');
          if (pa) {
            pa.addEventListener('click', () => {
              priceTouched = false;
              syncPrice(true);
              if (!calcPrice()) {
                UI.toast('Set a price on the plan first (Plans page)', 'warn');
              }
            });
          }
        }

        syncPrice();

        // Generate a code in the browser so the operator can read it out
        // before saving. Leaving the field blank still lets the server
        // generate one — this only makes the value visible up front.
        const genBtn = root.querySelector('[data-gen]');
        if (genBtn) {
          genBtn.addEventListener('click', () => {
            // No I/O/0/1: these are the characters users misread when a code
            // is dictated over the phone or copied by hand.
            const AB = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
            const buf = new Uint32Array(16);
            crypto.getRandomValues(buf);
            let out = '';
            for (let i = 0; i < 16; i++) {
              out += AB[buf[i] % AB.length];
              if (i % 4 === 3 && i !== 15) out += '-';
            }
            root.querySelector('[data-code]').value = out;
          });
        }

        if (editing) {
          root.querySelector('[data-reset]').addEventListener('click', async () => {
            const ok = await UI.confirm({
              title: 'Reset access code?',
              message: 'A new code is generated and every app session for this account is signed out.',
              kind: 'danger', okText: 'Reset code',
            });
            if (!ok) return;
            try {
              const d = await Api.post('/admin/accounts.php?action=reset_code&id=' + encodeURIComponent(r.id));
              close();
              UI.modal({
                title: 'New access code',
                sub: r.username,
                body: '<div class="alert warn"><span class="ico">⚠</span><div>' +
                        'All app sessions for this account were signed out. Send the new code to the user.' +
                      '</div></div>' +
                      '<div class="copy-row"><code>' + UI.esc(d.access_code) + '</code>' +
                      '<button class="btn btn-sm" data-c type="button">Copy</button></div>',
                foot: '<button class="btn btn-primary" data-x2 type="button">Done</button>',
                onMount(r2, c2) {
                  r2.querySelector('[data-c]').addEventListener('click', () => UI.copy(d.access_code, 'Access code'));
                  r2.querySelector('[data-x2]').addEventListener('click', c2);
                },
              });
              load();
            } catch (e) { UI.toast(e.message, 'danger'); }
          });
        }

        root.querySelector('[data-ok]').addEventListener('click', async e => {
          const body = {
            username:     root.querySelector('[data-u]').value.trim(),
            plan_id:      sel.value || null,
            device_limit: parseInt(root.querySelector('[data-dl]').value, 10) || 1,
            note:         root.querySelector('[data-note]').value.trim(),
            price:        root.querySelector('[data-price]').value.trim(),
          };
          const planObj = plans.find(x => x.id === sel.value);
          if (planObj) body.plan_name = planObj.name;

          if (editing) {
            body.expires_at = root.querySelector('[data-exp]').value;
            body.is_active  = root.querySelector('[data-active]').checked;
            const un = root.querySelector('[data-unlock]');
            if (un && un.checked) body.unlock = true;
          } else {
            body.duration_days = parseInt(root.querySelector('[data-days]').value, 10) || 30;
            const code = root.querySelector('[data-code]').value.trim();
            if (code) body.access_code = code;
          }

          msg.innerHTML = '';
          UI.busy(e.target, true);
          try {
            if (editing) {
              await Api.put('/admin/accounts.php?id=' + encodeURIComponent(r.id), body);
              UI.toast('Account updated', 'ok');
              close(); load();
            } else {
              const d = await Api.post('/admin/accounts.php', body);
              close();

              // The sale slip. Built from what the create call already
              // returned, so nothing here re-requests the access code — it
              // exists in this closure and nowhere else, and once this modal
              // is dismissed only an audited reveal can show it again.
              const slip = {
                username: d.username,
                password: d.access_code,
                expires:  fmt.date(d.expires_at),
                plan:     d.plan_name || '',
                devices:  d.device_limit,
                price:    d.price || '',
                issued:   fmt.dateTime(new Date()),
              };

              UI.modal({
                title: 'VIP account created',
                sub: d.username,
                body: Receipt.previewHtml(slip) +
                      '<div class="alert ok" style="margin-top:12px"><span class="ico">✔</span><div>' +
                        'Save the slip or copy the two values now — the access code cannot be shown ' +
                        'again later without an audited reveal.' +
                      '</div></div>',
                foot: '<button class="btn btn-ok" data-img type="button">🖼 Save image</button>' +
                      '<button class="btn" data-txt type="button">⧉ Copy text</button>' +
                      '<button class="btn btn-primary" data-x2 type="button">Done</button>',
                onMount(r2, c2) {
                  r2.querySelector('[data-img]').addEventListener('click', () => Receipt.save(slip));
                  r2.querySelector('[data-txt]').addEventListener('click', () => Receipt.copyText(slip));
                  r2.querySelector('[data-x2]').addEventListener('click', c2);
                },
              });
              load();
            }
          } catch (err) {
            msg.innerHTML = '<div class="alert danger"><span class="ico">✕</span><div>' +
                            UI.esc(err.message) + '</div></div>';
            UI.busy(e.target, false);
          }
        });
      },
    });
  }

  /* ---- delete -------------------------------------------------------- */
  async function remove(r) {
    const ok = await UI.confirm({
      title: 'Delete “' + r.username + '”?',
      html: '<b>This cannot be undone.</b>The account, its bound devices and all app sessions are removed permanently.',
      kind: 'danger', okText: 'Delete account',
    });
    if (!ok) return;
    try {
      await Api.del('/admin/accounts.php?id=' + encodeURIComponent(r.id));
      UI.toast('Account deleted', 'ok');
      load();
    } catch (e) { UI.toast(e.message, 'danger'); }
  }

  return { load };
})();


/* ==========================================================================
   VIP PRICES (plans)
   ========================================================================== */
const Plans = (() => {
  let rows = [];
  let bound = false;

  function render() {
    const host = document.getElementById('plan-list');
    if (!rows.length) {
      host.innerHTML = UI.empty('◎', 'No plans yet',
        'Add a plan so the app can show your VIP pricing.');
      return;
    }
    host.innerHTML =
      '<table class="tbl"><thead><tr><th>Plan</th><th>Price</th><th>Devices</th>' +
      '<th>Duration</th><th>Popular</th><th>Status</th><th></th></tr></thead><tbody>' +
      rows.map(r =>
        '<tr data-id="' + UI.esc(r.id) + '">' +
        '<td><b>' + UI.esc(r.name) + '</b>' +
          (r.accounts_using
            ? '<div class="muted" style="font-size:11.5px">' +
              fmt.num(r.accounts_using) + ' account' + (r.accounts_using === 1 ? '' : 's') +
              ' using this</div>'
            : '') + '</td>' +
        '<td><b>' + UI.esc(r.price_label || '—') + '</b></td>' +
        '<td>' + r.device_limit + '</td>' +
        '<td>' + r.duration_days + ' days</td>' +
        '<td>' + (r.is_popular ? '<span class="pill vip">★ popular</span>' : '<span class="muted">—</span>') + '</td>' +
        '<td>' + (r.is_enabled
          ? '<span class="pill ok"><span class="dot"></span>live</span>'
          : '<span class="pill"><span class="dot"></span>hidden</span>') + '</td>' +
        '<td class="act">' +
          '<button class="btn btn-xs" data-act="edit">✎ Edit</button>' +
          '<button class="btn btn-xs btn-danger" data-act="del">✕</button>' +
        '</td></tr>').join('') + '</tbody></table>';
  }

  async function load() {
    const host = document.getElementById('plan-list');
    host.innerHTML = '<table class="tbl"><tbody>' + UI.skeletonRows(6, 3) + '</tbody></table>';
    const d = await Api.get('/admin/plans.php');
    rows = d.plans || [];
    render();
    if (!bound) {
      bound = true;
      document.getElementById('plan-new').addEventListener('click', () => form(null));
      UI.on(document.getElementById('plan-list'), '[data-act]', b => {
        const r = rows.find(x => x.id === b.closest('tr').dataset.id);
        if (b.dataset.act === 'edit') form(r); else remove(r);
      });
    }
  }

  function form(r) {
    const editing = !!r;
    UI.modal({
      title: editing ? 'Edit plan' : 'New plan',
      sub: 'Shown in the app’s VIP purchase screen',
      body:
        '<div class="field"><label>Plan name</label>' +
          '<input class="input" data-name maxlength="100" value="' + UI.esc(r ? r.name : '') + '" ' +
          'placeholder="e.g. 1 Month VIP"></div>' +

        '<div class="row"><div class="field"><label>Price amount</label>' +
          '<input class="input" data-amt type="number" min="0" step="0.01" value="' +
          UI.esc(r ? (r.price_amount || '') : '') + '" placeholder="10000"></div>' +
        '<div class="field"><label>Currency</label>' +
          '<input class="input" data-cur maxlength="8" value="' +
          UI.esc(r ? (r.currency || 'MMK') : 'MMK') + '"></div></div>' +

        '<div class="field"><label>Price label <span class="muted">(optional override)</span></label>' +
          '<input class="input" data-label maxlength="60" value="' +
          UI.esc(r ? (r.price_label || '') : '') + '" placeholder="Auto-generated from amount + currency">' +
          '<div class="hint">Leave blank and the label is built for you, e.g. “10,000 MMK”.</div></div>' +

        '<div class="row"><div class="field"><label>Device limit</label>' +
          '<input class="input" data-dl type="number" min="1" max="100" value="' +
          (r ? r.device_limit : 1) + '"></div>' +
        '<div class="field"><label>Duration (days)</label>' +
          '<input class="input" data-dd type="number" min="1" max="3650" value="' +
          (r ? r.duration_days : 30) + '"></div></div>' +

        '<div class="row"><div class="field"><label class="switch">' +
          '<input type="checkbox" data-pop' + (r && r.is_popular ? ' checked' : '') + '>' +
          '<span class="track"></span><span class="lbl">Mark as popular ★</span></label></div>' +
        '<div class="field"><label class="switch">' +
          '<input type="checkbox" data-act2' + (!r || r.is_enabled ? ' checked' : '') + '>' +
          '<span class="track"></span><span class="lbl">Visible in app</span></label></div></div>' +
        '<div data-msg></div>',
      foot: '<button class="btn" data-x type="button">Cancel</button>' +
            '<button class="btn btn-primary" data-ok type="button">' +
              (editing ? 'Save' : 'Create plan') + '</button>',
      onMount(root, close) {
        const msg = root.querySelector('[data-msg]');
        root.querySelector('[data-x]').addEventListener('click', close);
        root.querySelector('[data-ok]').addEventListener('click', async e => {
          const body = {
            name:         root.querySelector('[data-name]').value.trim(),
            price_amount: parseFloat(root.querySelector('[data-amt]').value) || 0,
            currency:     root.querySelector('[data-cur]').value.trim() || 'MMK',
            price_label:  root.querySelector('[data-label]').value.trim(),
            device_limit: parseInt(root.querySelector('[data-dl]').value, 10) || 1,
            duration_days:parseInt(root.querySelector('[data-dd]').value, 10) || 30,
            is_popular:   root.querySelector('[data-pop]').checked,
            is_enabled:   root.querySelector('[data-act2]').checked,
          };
          msg.innerHTML = '';
          UI.busy(e.target, true);
          try {
            if (editing) await Api.put('/admin/plans.php?id=' + encodeURIComponent(r.id), body);
            else         await Api.post('/admin/plans.php', body);
            UI.toast(editing ? 'Plan updated' : 'Plan created', 'ok');
            close(); load();
          } catch (err) {
            msg.innerHTML = '<div class="alert danger"><span class="ico">✕</span><div>' +
                            UI.esc(err.message) + '</div></div>';
            UI.busy(e.target, false);
          }
        });
      },
    });
  }

  async function remove(r) {
    const ok = await UI.confirm({
      title: 'Delete plan “' + r.name + '”?',
      message: 'Existing VIP accounts keep working — they store their own device limit and expiry.',
      kind: 'danger', okText: 'Delete',
    });
    if (!ok) return;
    try {
      await Api.del('/admin/plans.php?id=' + encodeURIComponent(r.id));
      UI.toast('Plan deleted', 'ok'); load();
    } catch (e) { UI.toast(e.message, 'danger'); }
  }

  return { load };
})();


/* ==========================================================================
   SERVERS — paste any config URL, fields auto-fill
   ========================================================================== */
const Servers = (() => {
  let rows = [];
  let locs = [];
  let bound = false;
  let timer = null;

  const PROTOCOLS = ['vmess', 'vless', 'trojan', 'shadowsocks', 'socks', 'wireguard'];

  function visible() {
    const q = document.getElementById('srv-q').value.trim().toLowerCase();
    const t = document.getElementById('srv-tier').value;
    return rows.filter(r => {
      if (t && r.tier !== t) return false;
      if (!q) return true;
      return (r.name + ' ' + r.address + ' ' + r.protocol + ' ' +
              (r.location_name || '')).toLowerCase().indexOf(q) > -1;
    });
  }

  function render() {
    const host = document.getElementById('srv-list');
    const list = visible();
    if (!list.length) {
      host.innerHTML = UI.empty('▤', 'No servers found',
        rows.length ? 'Try clearing your filters.'
                    : 'Click “Add server” and paste any config URL — the fields fill themselves.');
      return;
    }
    // A compact one-line-per-server list. The old 8-column table forced a
    // horizontal scroll on a phone, which made every row look oversized;
    // secondary details are folded into a single sub-line instead.
    host.innerHTML =
      '<div class="srv-rows">' +
      list.map(r =>
        '<div class="srv-row' + (r.is_enabled ? '' : ' off') + '" data-id="' + UI.esc(r.id) + '">' +
          '<span class="srv-flag">' + UI.esc(r.flag_emoji || '🌐') + '</span>' +
          '<div class="srv-main">' +
            '<div class="srv-name">' + UI.esc(r.name) +
              (r.tier === 'vip' ? '<span class="pill vip sm">★</span>' : '') +
              (r.is_enabled ? '' : '<span class="pill danger sm">off</span>') +
            '</div>' +
            '<div class="srv-sub mono" title="' + UI.esc(r.address) + ':' + r.port + '">' +
              UI.esc(r.protocol) + ' · ' + UI.esc(r.address) + ':' + r.port +
            '</div>' +
          '</div>' +
          '<div class="srv-load" title="Load ' + r.load_percent + '%">' +
            '<div class="bar"><i class="' +
              (r.load_percent >= 80 ? 'danger' : r.load_percent >= 50 ? 'warn' : '') +
              '" style="width:' + r.load_percent + '%"></i></div>' +
          '</div>' +
          '<div class="srv-act">' +
            (r.config_hidden ? '' :
              '<button class="btn btn-xs" data-act="cfg" title="View config">◉</button>') +
            '<button class="btn btn-xs" data-act="edit" title="Edit">✎</button>' +
            '<button class="btn btn-xs btn-danger" data-act="del" title="Delete">✕</button>' +
          '</div>' +
        '</div>').join('') + '</div>';
  }

  /* ------------------------------------------- view the stored config */
  // Previously a config vanished the moment it was saved: the list never
  // showed it and the edit form deliberately opens its textarea empty (so
  // that saving without typing keeps the config unchanged). Admins had no
  // way to confirm what was actually stored.
  function viewConfig(r) {
    if (!r) return;
    if (!r.raw_config) {
      UI.toast('Your role cannot view connection secrets.', 'warn');
      return;
    }
    UI.modal({
      title: 'Stored config',
      sub: r.name,
      wide: true,
      body:
        '<div class="field">' +
          '<label>' + UI.esc(r.protocol) + ' · ' + UI.esc(r.address) + ':' + r.port + '</label>' +
          '<textarea class="textarea mono" rows="8" readonly data-cfg>' +
            UI.esc(r.raw_config) + '</textarea>' +
          '<div class="hint">This is exactly what the app receives. Read-only — ' +
            'use Edit to replace it.</div>' +
        '</div>',
      foot: '<button class="btn" data-x type="button">Close</button>' +
            '<button class="btn btn-primary" data-copy type="button">Copy</button>',
      onMount(root, close) {
        root.querySelector('[data-x]').addEventListener('click', close);
        root.querySelector('[data-copy]').addEventListener('click',
          () => UI.copy(r.raw_config, 'Config'));
      },
    });
  }

  async function load() {
    const host = document.getElementById('srv-list');
    host.innerHTML = '<table class="tbl"><tbody>' + UI.skeletonRows(7, 3) + '</tbody></table>';
    const [s, l] = await Promise.all([
      Api.get('/admin/servers.php'),
      Api.get('/admin/locations.php'),
    ]);
    rows = s.servers || [];
    locs = l.locations || [];
    render();
    if (!bound) {
      bound = true;
      const deb = () => { clearTimeout(timer); timer = setTimeout(render, 180); };
      document.getElementById('srv-q').addEventListener('input', deb);
      document.getElementById('srv-tier').addEventListener('change', render);
      document.getElementById('srv-new').addEventListener('click', () => form(null));
      document.getElementById('srv-bulk').addEventListener('click', bulk);
      UI.on(document.getElementById('srv-list'), '[data-act]', b => {
        const r = rows.find(x => x.id === b.closest('[data-id]').dataset.id);
        if (b.dataset.act === 'cfg') viewConfig(r);
        else if (b.dataset.act === 'edit') form(r);
        else remove(r);
      });
    }
  }

  function locOptions(selected) {
    return '<option value="">— Choose region —</option>' +
      locs.map(l => '<option value="' + UI.esc(l.id) + '"' +
        (selected === l.id ? ' selected' : '') + '>' +
        (l.flag_emoji ? l.flag_emoji + ' ' : '') + UI.esc(l.name) +
        ' (' + UI.esc(l.country_code) + ')</option>').join('');
  }

  /* ---------------------------------------------------- add / edit form */
  function form(r) {
    const editing = !!r;

    UI.modal({
      title: editing ? 'Edit server' : 'Add server',
      sub: editing ? r.name : 'Paste a config URL and every field fills automatically',
      wide: true,
      body:
        (editing ? '' :
        '<div class="field">' +
          '<label>Config / share link <span class="muted">— any protocol</span></label>' +
          '<textarea class="textarea mono" data-raw rows="4" placeholder="vmess:// · vless:// · trojan:// · ss:// · ssr:// · socks5:// · hysteria2:// · tuic:// · WireGuard .conf · Xray JSON · host:port"></textarea>' +
          '<div class="hint">Paste and the Region, Protocol, Address and Port below are detected for you.</div>' +
        '</div>' +
        '<div data-sniff></div>') +

        '<div class="row"><div class="field"><label>Server name</label>' +
          '<input class="input" data-name maxlength="100" value="' + UI.esc(r ? r.name : '') + '"></div>' +
        '<div class="field"><label>Region</label>' +
          '<select class="select" data-loc>' + locOptions(r ? r.location_id : '') + '</select></div></div>' +

        '<div class="row"><div class="field"><label>Protocol</label>' +
          '<select class="select" data-proto>' +
            PROTOCOLS.map(p => '<option value="' + p + '"' +
              (r && r.protocol === p ? ' selected' : '') + '>' + p + '</option>').join('') +
          '</select></div>' +
        '<div class="field"><label>Address (or IP)</label>' +
          '<input class="input mono" data-addr maxlength="255" value="' + UI.esc(r ? r.address : '') + '"></div>' +
        '<div class="field" style="max-width:120px"><label>Port</label>' +
          '<input class="input mono" data-port type="number" min="0" max="65535" value="' +
          (r ? r.port : '') + '"></div></div>' +

        '<div class="row"><div class="field"><label>Tier</label>' +
          '<select class="select" data-tier>' +
            '<option value="free"' + (r && r.tier === 'free' ? ' selected' : '') + '>Free — everyone</option>' +
            '<option value="vip"' + (!r || r.tier === 'vip' ? ' selected' : '') + '>VIP — signed-in users only</option>' +
          '</select></div>' +
        '<div class="field"><label>Load %</label>' +
          '<input class="input" data-load type="number" min="0" max="100" value="' +
          (r ? r.load_percent : 0) + '"></div>' +
        '<div class="field"><label>Sort order</label>' +
          '<input class="input" data-sort type="number" min="0" value="' +
          (r ? r.sort_order : 0) + '"></div></div>' +

        (editing
          ? (r.raw_config
              ? '<div class="field"><label>Currently stored config</label>' +
                '<textarea class="textarea mono" rows="3" readonly>' +
                  UI.esc(r.raw_config) + '</textarea></div>'
              : '') +
            '<div class="field"><label>Replace config <span class="muted">— leave blank to keep the one above</span></label>' +
            '<textarea class="textarea mono" data-raw rows="3" placeholder="Paste a new config to replace the stored one"></textarea></div>'
          : '') +

        '<div class="field"><label class="switch">' +
          '<input type="checkbox" data-en' + (!r || r.is_enabled ? ' checked' : '') + '>' +
          '<span class="track"></span><span class="lbl">Enabled — visible in the app</span></label></div>' +
        '<div data-msg></div>',
      foot: '<button class="btn" data-x type="button">Cancel</button>' +
            '<button class="btn btn-primary" data-ok type="button">' +
              (editing ? 'Save changes' : 'Add server') + '</button>',
      onMount(root, close) {
        const raw   = root.querySelector('[data-raw]');
        const msg   = root.querySelector('[data-msg]');
        const sniff = root.querySelector('[data-sniff]');
        root.querySelector('[data-x]').addEventListener('click', close);

        /* ---- the auto-fill engine ------------------------------------ */
        let sniffTimer = null;
        let lastServerParse = '';

        function setIf(sel, val, force) {
          const el = root.querySelector(sel);
          if (!el) return;
          // never clobber something the admin typed themselves
          if (force || !el.value || el.dataset.auto === '1') {
            if (val !== '' && val !== 0 && val !== null && val !== undefined) {
              el.value = val;
              el.dataset.auto = '1';
              el.style.transition = 'background .5s';
              el.style.background = 'var(--ok-soft)';
              setTimeout(() => { el.style.background = ''; }, 600);
            }
          }
        }

        function showSniff(p, source) {
          if (!sniff) return;
          if (!p) { sniff.innerHTML = ''; return; }
          const cc = p.country_code || '';
          const known = cc ? locs.find(l => l.country_code === cc) : null;
          sniff.innerHTML =
            '<div class="alert ok"><span class="ico">✔</span><div>' +
              '<b>Detected' + (source === 'server' ? ' (verified by server)' : '') + '</b>' +
              '<div class="chips" style="margin-top:5px">' +
                (p.protocol ? '<span class="pill brand">' + UI.esc(p.protocol) + '</span>' : '') +
                (cc ? '<span class="pill">' + LinkSniff.flag(cc) + ' ' + UI.esc(cc) +
                      (known ? '' : ' — new region') + '</span>' : '') +
                (p.address ? '<span class="pill">' + UI.esc(p.address) + ':' + (p.port || '?') + '</span>' : '') +
                (p.network ? '<span class="pill">' + UI.esc(p.network) + '</span>' : '') +
                (p.security ? '<span class="pill">' + UI.esc(p.security) + '</span>' : '') +
              '</div>' +
            '</div></div>';
        }

        function applyParse(p, source) {
          if (!p) return;
          setIf('[data-addr]', p.address || '');
          setIf('[data-port]', p.port || '');
          if (p.protocol) {
            const sel = root.querySelector('[data-proto]');
            if (Array.prototype.some.call(sel.options, o => o.value === p.protocol)) sel.value = p.protocol;
          }
          if (p.label) setIf('[data-name]', p.label);
          // region match by country code
          if (p.country_code) {
            const hit = locs.find(l => l.country_code === p.country_code);
            if (hit) setIf('[data-loc]', hit.id);
          }
          // fall back to a readable name
          if (!root.querySelector('[data-name]').value && p.address) {
            setIf('[data-name]', (p.country_code ? p.country_code + ' ' : '') + p.address);
          }
          showSniff(p, source);
        }

        /** Server-side authoritative parse — overwrites the local guess. */
        async function serverParse(text) {
          if (text === lastServerParse) return;
          lastServerParse = text;
          try {
            const d = await Api.post('/admin/servers.php?action=parse', { raw_config: text });
            if (d.parsed) {
              applyParse(d.parsed, 'server');
              // the server also tells us whether the region already exists
              if (d.location && d.location.exists && d.location.location_id) {
                setIf('[data-loc]', d.location.location_id, true);
              } else if (d.location && d.location.country_code) {
                sniff.insertAdjacentHTML('beforeend',
                  '<div class="alert info"><span class="ico">ℹ</span><div>' +
                    'Region <b>' + UI.esc(d.location.flag_emoji || '') + ' ' +
                    UI.esc(d.location.name || d.location.country_code) + '</b> does not exist yet — ' +
                    'it will be created automatically when you save.' +
                  '</div></div>');
              }
            }
          } catch (_) { /* local guess stands */ }
        }

        if (raw) {
          const onInput = () => {
            const text = raw.value.trim();
            if (!text) { showSniff(null); return; }
            // instant local guess
            try { applyParse(LinkSniff.parse(text), 'local'); } catch (_) {}
            // then confirm with the server
            clearTimeout(sniffTimer);
            sniffTimer = setTimeout(() => serverParse(text), 420);
          };
          raw.addEventListener('input', onInput);
          raw.addEventListener('paste', () => setTimeout(onInput, 10));
        }

        // typing in a field marks it manual so auto-fill stops touching it
        ['[data-name]', '[data-addr]', '[data-port]', '[data-loc]', '[data-proto]'].forEach(sel => {
          const el = root.querySelector(sel);
          if (el) el.addEventListener('input', () => { el.dataset.auto = '0'; });
        });

        /* ---- save ---------------------------------------------------- */
        root.querySelector('[data-ok]').addEventListener('click', async e => {
          const body = {
            name:         root.querySelector('[data-name]').value.trim(),
            location_id:  root.querySelector('[data-loc]').value || null,
            protocol:     root.querySelector('[data-proto]').value,
            tier:         root.querySelector('[data-tier]').value,
            address:      root.querySelector('[data-addr]').value.trim(),
            port:         parseInt(root.querySelector('[data-port]').value, 10) || 0,
            load_percent: parseInt(root.querySelector('[data-load]').value, 10) || 0,
            sort_order:   parseInt(root.querySelector('[data-sort]').value, 10) || 0,
            is_enabled:   root.querySelector('[data-en]').checked,
          };
          if (raw && raw.value.trim()) body.raw_config = raw.value.trim();
          if (!editing) body.auto_create_locations = true;

          msg.innerHTML = '';
          UI.busy(e.target, true);
          try {
            if (editing) await Api.put('/admin/servers.php?id=' + encodeURIComponent(r.id), body);
            else         await Api.post('/admin/servers.php', body);
            UI.toast(editing ? 'Server updated' : 'Server added', 'ok');
            close(); load();
          } catch (err) {
            msg.innerHTML = '<div class="alert danger"><span class="ico">✕</span><div>' +
                            UI.esc(err.message) + '</div></div>';
            UI.busy(e.target, false);
          }
        });
      },
    });
  }

  /* ------------------------------------------------------- bulk import */
  function bulk() {
    UI.modal({
      title: 'Bulk import servers',
      sub: 'One link per line, or paste a whole base64 subscription',
      wide: true,
      body:
        '<div class="field">' +
          '<label>Share links</label>' +
          '<textarea class="textarea mono" data-blob rows="10" ' +
            'placeholder="vmess://...&#10;vless://...&#10;trojan://...&#10;ss://...&#10;&#10;or a base64 subscription blob"></textarea>' +
          '<div class="hint" data-count>Up to 200 links per import.</div>' +
        '</div>' +
        '<div class="row"><div class="field"><label>Tier for all imported</label>' +
          '<select class="select" data-tier>' +
            '<option value="vip" selected>VIP — signed-in users only</option>' +
            '<option value="free">Free — everyone</option>' +
          '</select></div>' +
        '<div class="field"><label>Fallback region</label>' +
          '<select class="select" data-loc>' + locOptions('') + '</select>' +
          '<div class="hint">Used only when a link’s country cannot be detected.</div></div></div>' +
        '<div class="field"><label class="switch">' +
          '<input type="checkbox" data-auto checked><span class="track"></span>' +
          '<span class="lbl">Create missing regions automatically</span></label></div>' +
        '<div data-msg></div>',
      foot: '<button class="btn" data-x type="button">Cancel</button>' +
            '<button class="btn btn-primary" data-ok type="button">Import</button>',
      onMount(root, close) {
        const blob  = root.querySelector('[data-blob]');
        const count = root.querySelector('[data-count]');
        const msg   = root.querySelector('[data-msg]');

        const recount = () => {
          const n = LinkSniff.countLinks(blob.value);
          count.textContent = n
            ? n + ' link' + (n === 1 ? '' : 's') + ' detected' + (n > 200 ? ' — only the first 200 are imported' : '')
            : 'Up to 200 links per import.';
          count.style.color = n > 200 ? 'var(--warn)' : '';
        };
        blob.addEventListener('input', recount);
        blob.addEventListener('paste', () => setTimeout(recount, 10));

        root.querySelector('[data-x]').addEventListener('click', close);
        root.querySelector('[data-ok]').addEventListener('click', async e => {
          const text = blob.value.trim();
          if (!text) { blob.focus(); return; }

          msg.innerHTML = '';
          UI.busy(e.target, true);
          try {
            const d = await Api.post('/admin/servers.php?action=bulk', {
              blob: text,
              tier: root.querySelector('[data-tier]').value,
              location_id: root.querySelector('[data-loc]').value || null,
              auto_create_locations: root.querySelector('[data-auto]').checked,
            });
            const created = d.created || [];
            const skipped = d.skipped || [];
            close();
            UI.modal({
              title: 'Import finished',
              sub: created.length + ' added · ' + skipped.length + ' skipped',
              wide: true,
              body:
                (created.length
                  ? '<div class="alert ok"><span class="ico">✔</span><div><b>' + created.length +
                    ' server(s) added.</b>They are live in the app immediately.</div></div>' +
                    '<div class="table-wrap"><table class="tbl"><thead><tr><th>Name</th><th>Protocol</th>' +
                    '<th>Address</th><th>Region</th></tr></thead><tbody>' +
                    created.map(c =>
                      '<tr><td>' + UI.esc(c.name) + '</td>' +
                      '<td><span class="pill brand">' + UI.esc(c.protocol) + '</span></td>' +
                      '<td class="mono trunc">' + UI.esc(c.address) + ':' + c.port + '</td>' +
                      '<td>' + LinkSniff.flag(c.country_code) + ' ' + UI.esc(c.country_code || '—') +
                      '</td></tr>').join('') +
                    '</tbody></table></div>'
                  : '<div class="alert warn"><span class="ico">⚠</span><div>Nothing was imported.</div></div>') +
                (skipped.length
                  ? '<div class="alert warn mt12"><span class="ico">⚠</span><div><b>' + skipped.length +
                    ' skipped</b>' + UI.esc(skipped.map(s => (s.reason || s)).join(', ')).slice(0, 400) +
                    '</div></div>'
                  : ''),
              foot: '<button class="btn btn-primary" data-x2 type="button">Done</button>',
              onMount(r2, c2) { r2.querySelector('[data-x2]').addEventListener('click', c2); },
            });
            load();
          } catch (err) {
            msg.innerHTML = '<div class="alert danger"><span class="ico">✕</span><div>' +
                            UI.esc(err.message) + '</div></div>';
            UI.busy(e.target, false);
          }
        });
      },
    });
  }

  async function remove(r) {
    const ok = await UI.confirm({
      title: 'Delete “' + r.name + '”?',
      message: 'The server disappears from the app immediately.',
      kind: 'danger', okText: 'Delete server',
    });
    if (!ok) return;
    try {
      await Api.del('/admin/servers.php?id=' + encodeURIComponent(r.id));
      UI.toast('Server deleted', 'ok'); load();
    } catch (e) { UI.toast(e.message, 'danger'); }
  }

  return { load };
})();


/* ==========================================================================
   REGIONS (locations)
   ========================================================================== */
const Locations = (() => {
  let rows = [];
  let bound = false;

  async function load() {
    const host = document.getElementById('loc-list');
    host.innerHTML = '<table class="tbl"><tbody>' + UI.skeletonRows(5, 4) + '</tbody></table>';
    const d = await Api.get('/admin/locations.php');
    rows = d.locations || [];

    host.innerHTML = rows.length
      ? '<table class="tbl"><thead><tr><th>Region</th><th>Code</th><th>Servers</th>' +
        '<th>Order</th><th>Status</th><th></th></tr></thead><tbody>' +
        rows.map(r =>
          '<tr data-id="' + UI.esc(r.id) + '">' +
          '<td><span class="flag">' + UI.esc(r.flag_emoji || '') + '</span><b>' +
              UI.esc(r.name) + '</b></td>' +
          '<td class="mono">' + UI.esc(r.country_code) + '</td>' +
          '<td>' + fmt.num(r.server_count) +
              (r.vip_count ? ' <span class="muted">(' + r.vip_count + ' VIP)</span>' : '') + '</td>' +
          '<td>' + r.sort_order + '</td>' +
          '<td>' + (r.is_enabled
            ? '<span class="pill ok"><span class="dot"></span>visible</span>'
            : '<span class="pill"><span class="dot"></span>hidden</span>') + '</td>' +
          '<td class="act">' +
            '<button class="btn btn-xs" data-act="edit">✎</button>' +
            '<button class="btn btn-xs btn-danger" data-act="del">✕</button>' +
          '</td></tr>').join('') + '</tbody></table>'
      : UI.empty('◍', 'No regions yet', 'Use “Add from presets” for a quick start.');

    if (!bound) {
      bound = true;
      document.getElementById('loc-new').addEventListener('click', () => form(null));
      document.getElementById('loc-presets').addEventListener('click', presets);
      UI.on(host, '[data-act]', b => {
        const r = rows.find(x => x.id === b.closest('tr').dataset.id);
        if (b.dataset.act === 'edit') form(r); else remove(r);
      });
    }
  }

  function form(r) {
    const editing = !!r;
    UI.modal({
      title: editing ? 'Edit region' : 'New region',
      body:
        '<div class="row"><div class="field"><label>Display name</label>' +
          '<input class="input" data-name maxlength="100" value="' + UI.esc(r ? r.name : '') + '" ' +
          'placeholder="e.g. Singapore"></div>' +
        '<div class="field" style="max-width:130px"><label>Country code</label>' +
          '<input class="input mono" data-cc maxlength="2" value="' + UI.esc(r ? r.country_code : '') + '" ' +
          'placeholder="SG" style="text-transform:uppercase"></div></div>' +
        '<div class="row"><div class="field"><label>Flag emoji</label>' +
          '<input class="input" data-flag maxlength="8" value="' + UI.esc(r ? (r.flag_emoji || '') : '') + '" ' +
          'placeholder="Auto from country code"></div>' +
        '<div class="field"><label>Sort order</label>' +
          '<input class="input" data-sort type="number" min="0" value="' + (r ? r.sort_order : 0) + '"></div></div>' +
        '<div class="field"><label class="switch">' +
          '<input type="checkbox" data-en' + (!r || r.is_enabled ? ' checked' : '') + '>' +
          '<span class="track"></span><span class="lbl">Visible in app</span></label></div>' +
        '<div data-msg></div>',
      foot: '<button class="btn" data-x type="button">Cancel</button>' +
            '<button class="btn btn-primary" data-ok type="button">' +
              (editing ? 'Save' : 'Create') + '</button>',
      onMount(root, close) {
        const msg = root.querySelector('[data-msg]');
        const cc  = root.querySelector('[data-cc]');
        const fl  = root.querySelector('[data-flag]');

        // typing a country code fills the flag for you
        cc.addEventListener('input', () => {
          cc.value = cc.value.toUpperCase().replace(/[^A-Z]/g, '').slice(0, 2);
          if (cc.value.length === 2 && !fl.value) {
            const f = LinkSniff.flag(cc.value);
            if (f) fl.value = f;
          }
        });

        root.querySelector('[data-x]').addEventListener('click', close);
        root.querySelector('[data-ok]').addEventListener('click', async e => {
          const body = {
            name:         root.querySelector('[data-name]').value.trim(),
            country_code: cc.value.trim().toUpperCase(),
            flag_emoji:   fl.value.trim(),
            sort_order:   parseInt(root.querySelector('[data-sort]').value, 10) || 0,
            is_enabled:   root.querySelector('[data-en]').checked,
          };
          msg.innerHTML = '';
          UI.busy(e.target, true);
          try {
            if (editing) await Api.put('/admin/locations.php?id=' + encodeURIComponent(r.id), body);
            else         await Api.post('/admin/locations.php', body);
            UI.toast(editing ? 'Region updated' : 'Region created', 'ok');
            close(); load();
          } catch (err) {
            msg.innerHTML = '<div class="alert danger"><span class="ico">✕</span><div>' +
                            UI.esc(err.message) + '</div></div>';
            UI.busy(e.target, false);
          }
        });
      },
    });
  }

  async function presets() {
    let list = [];
    try {
      const d = await Api.get('/admin/locations.php?action=presets');
      list = d.presets || [];
    } catch (e) { UI.toast(e.message, 'danger'); return; }

    const have = rows.map(r => r.country_code);
    UI.modal({
      title: 'Add regions from presets',
      sub: 'Tick the countries you serve',
      wide: true,
      body:
        '<div class="chips" data-picks style="max-height:340px;overflow-y:auto">' +
          list.map(p => {
            const owned = have.indexOf(p.country_code) > -1;
            return '<label class="btn btn-sm' + (owned ? ' btn-ghost' : '') + '" ' +
                   'style="cursor:' + (owned ? 'default' : 'pointer') + ';opacity:' + (owned ? '.45' : '1') + '">' +
                   '<input type="checkbox" value="' + UI.esc(p.country_code) + '"' +
                   (owned ? ' disabled' : '') + ' style="margin-right:5px">' +
                   UI.esc(p.flag_emoji || '') + ' ' + UI.esc(p.name) + '</label>';
          }).join('') +
        '</div><div data-msg class="mt12"></div>',
      foot: '<button class="btn" data-x type="button">Cancel</button>' +
            '<button class="btn btn-primary" data-ok type="button">Add selected</button>',
      onMount(root, close) {
        const msg = root.querySelector('[data-msg]');
        root.querySelector('[data-x]').addEventListener('click', close);
        root.querySelector('[data-ok]').addEventListener('click', async e => {
          const codes = Array.prototype.slice
            .call(root.querySelectorAll('[data-picks] input:checked'))
            .map(i => i.value);
          if (!codes.length) { UI.toast('Nothing selected', 'warn'); return; }
          UI.busy(e.target, true);
          try {
            const d = await Api.post('/admin/locations.php?action=bulk', { country_codes: codes });
            UI.toast((d.inserted_or_updated || codes.length) + ' region(s) added', 'ok');
            close(); load();
          } catch (err) {
            msg.innerHTML = '<div class="alert danger"><span class="ico">✕</span><div>' +
                            UI.esc(err.message) + '</div></div>';
            UI.busy(e.target, false);
          }
        });
      },
    });
  }

  async function remove(r) {
    const ok = await UI.confirm({
      title: 'Delete region “' + r.name + '”?',
      html: r.server_count
        ? '<b>' + r.server_count + ' server(s) will be deleted too.</b>They vanish from the app immediately.'
        : 'This region has no servers.',
      kind: 'danger', okText: 'Delete region',
    });
    if (!ok) return;
    try {
      const d = await Api.del('/admin/locations.php?id=' + encodeURIComponent(r.id));
      UI.toast('Region deleted' + (d.servers_removed ? ' with ' + d.servers_removed + ' server(s)' : ''), 'ok');
      load();
    } catch (e) { UI.toast(e.message, 'danger'); }
  }

  return { load };
})();


/* ==========================================================================
   ADMINS  (Super Admin only)
   ========================================================================== */
const Admins = (() => {
  let rows = [];
  let bound = false;

  function rolePill(role) {
    return role === 'super_admin'
      ? '<span class="pill vip">★ Super Admin</span>'
      : '<span class="pill brand">Admin</span>';
  }

  async function load() {
    const host = document.getElementById('adm-list');
    host.innerHTML = '<table class="tbl"><tbody>' + UI.skeletonRows(6, 3) + '</tbody></table>';
    const d = await Api.get('/admin/admins.php');
    rows = d.admins || [];

    const meId = App.user() ? App.user().id : 0;

    host.innerHTML =
      '<table class="tbl"><thead><tr><th>Admin</th><th>Role</th><th>Status</th>' +
      '<th>Last login</th><th>Sessions</th><th></th></tr></thead><tbody>' +
      rows.map(r => {
        const self = r.id === meId;
        return '<tr data-id="' + r.id + '">' +
          '<td><b>' + UI.esc(r.display_name || r.username) + '</b>' +
            (self ? ' <span class="pill">you</span>' : '') +
            '<div class="muted mono" style="font-size:11.5px">' + UI.esc(r.username) + '</div></td>' +
          '<td>' + rolePill(r.role) + '</td>' +
          '<td>' +
            (r.is_active
              ? (r.must_change_password
                  ? '<span class="pill warn"><span class="dot"></span>password pending</span>'
                  : '<span class="pill ok"><span class="dot"></span>active</span>')
              : '<span class="pill danger"><span class="dot"></span>disabled</span>') +
            (r.locked_until && fmt.parse(r.locked_until) > new Date()
              ? ' <span class="pill warn">locked</span>' : '') +
          '</td>' +
          '<td class="muted" style="font-size:12.5px">' +
            (r.last_login_at ? fmt.ago(r.last_login_at) : 'never') + '</td>' +
          '<td>' + fmt.num(r.active_sessions || 0) + '</td>' +
          '<td class="act">' +
            '<button class="btn btn-xs" data-act="edit" title="Edit">✎</button>' +
            '<button class="btn btn-xs" data-act="pw" title="Reset password">🔑</button>' +
            (r.active_sessions
              ? '<button class="btn btn-xs" data-act="revoke" title="Sign out everywhere">⏻</button>' : '') +
            (self ? '' : '<button class="btn btn-xs btn-danger" data-act="del" title="Delete">✕</button>') +
          '</td></tr>';
      }).join('') + '</tbody></table>';

    if (!bound) {
      bound = true;
      document.getElementById('adm-new').addEventListener('click', () => form(null));
      UI.on(host, '[data-act]', b => {
        const r = rows.find(x => String(x.id) === b.closest('tr').dataset.id);
        const a = b.dataset.act;
        if (a === 'edit')   form(r);
        if (a === 'pw')     resetPw(r);
        if (a === 'revoke') revoke(r);
        if (a === 'del')    remove(r);
      });
    }
  }

  function showPassword(title, username, password, note) {
    UI.modal({
      title: title,
      sub: username,
      body:
        '<div class="alert warn"><span class="ico">⚠</span><div>' +
          '<b>Copy this now — it is shown only once.</b>' + UI.esc(note || '') +
        '</div></div>' +
        '<dl class="kv" style="margin-bottom:12px">' +
          '<dt>Username</dt><dd class="mono">' + UI.esc(username) + '</dd></dl>' +
        '<div class="copy-row"><code>' + UI.esc(password) + '</code>' +
          '<button class="btn btn-sm" data-c type="button">Copy</button></div>',
      foot: '<button class="btn btn-primary" data-x type="button">Done</button>',
      onMount(root, close) {
        root.querySelector('[data-c]').addEventListener('click',
          () => UI.copy(username + ' / ' + password, 'Credentials'));
        root.querySelector('[data-x]').addEventListener('click', close);
      },
    });
  }

  function form(r) {
    const editing = !!r;
    UI.modal({
      title: editing ? 'Edit admin' : 'New admin',
      sub: editing ? r.username : 'A one-time password is generated for you',
      body:
        '<div class="row"><div class="field"><label>Username</label>' +
          '<input class="input mono" data-u maxlength="32" value="' + UI.esc(r ? r.username : '') + '" ' +
          (editing ? 'readonly' : '') + ' autocapitalize="none" spellcheck="false" ' +
          'placeholder="lowercase, 3–32 chars"></div>' +
        '<div class="field"><label>Display name</label>' +
          '<input class="input" data-dn maxlength="64" value="' +
          UI.esc(r ? (r.display_name || '') : '') + '"></div></div>' +

        '<div class="field"><label>Role</label><select class="select" data-role>' +
          '<option value="admin"' + (r && r.role === 'admin' ? ' selected' : '') + '>' +
            'Admin — VIP accounts only</option>' +
          '<option value="super_admin"' + (r && r.role === 'super_admin' ? ' selected' : '') + '>' +
            'Super Admin — full access</option>' +
        '</select>' +
        '<div class="hint">Admins cannot add servers, change prices, or view server configs.</div></div>' +

        '<div class="field"><label>Telegram ID <span class="muted">(optional)</span></label>' +
          '<input class="input mono" data-tg value="' + UI.esc(r ? (r.telegram_id || '') : '') + '" ' +
          'placeholder="e.g. 5567910560">' +
          '<div class="hint">Grants this person access to the management bot.</div></div>' +

        (editing
          ? '<div class="field"><label class="switch">' +
              '<input type="checkbox" data-en' + (r.is_active ? ' checked' : '') + '>' +
              '<span class="track"></span><span class="lbl">Account enabled</span></label></div>'
          : '') +
        '<div data-msg></div>',
      foot: '<button class="btn" data-x type="button">Cancel</button>' +
            '<button class="btn btn-primary" data-ok type="button">' +
              (editing ? 'Save' : 'Create admin') + '</button>',
      onMount(root, close) {
        const msg = root.querySelector('[data-msg]');
        const u = root.querySelector('[data-u]');
        if (!editing) {
          u.addEventListener('input', () => {
            u.value = u.value.toLowerCase().replace(/[^a-z0-9._-]/g, '');
          });
        }
        root.querySelector('[data-x]').addEventListener('click', close);
        root.querySelector('[data-ok]').addEventListener('click', async e => {
          const body = {
            username:     u.value.trim(),
            display_name: root.querySelector('[data-dn]').value.trim(),
            role:         root.querySelector('[data-role]').value,
            telegram_id:  root.querySelector('[data-tg]').value.trim() || null,
          };
          if (editing) body.is_active = root.querySelector('[data-en]').checked;

          msg.innerHTML = '';
          UI.busy(e.target, true);
          try {
            if (editing) {
              await Api.put('/admin/admins.php?id=' + r.id, body);
              UI.toast('Admin updated', 'ok');
              close(); load();
            } else {
              const d = await Api.post('/admin/admins.php', body);
              close();
              showPassword('Admin created', d.username, d.password, d.note);
              load();
            }
          } catch (err) {
            msg.innerHTML = '<div class="alert danger"><span class="ico">✕</span><div>' +
                            UI.esc(err.message) + '</div></div>';
            UI.busy(e.target, false);
          }
        });
      },
    });
  }

  async function resetPw(r) {
    const ok = await UI.confirm({
      title: 'Reset password for “' + r.username + '”?',
      message: 'A new one-time password is generated and all their sessions are signed out.',
      kind: 'danger', okText: 'Reset password',
    });
    if (!ok) return;
    try {
      const d = await Api.post('/admin/admins.php?action=reset_password&id=' + r.id);
      showPassword('Password reset', r.username, d.password, d.note);
      load();
    } catch (e) { UI.toast(e.message, 'danger'); }
  }

  async function revoke(r) {
    const ok = await UI.confirm({
      title: 'Sign out “' + r.username + '” everywhere?',
      message: 'They will need to sign in again. App users are unaffected.',
      okText: 'Sign out',
    });
    if (!ok) return;
    try {
      await Api.post('/admin/admins.php?action=revoke&id=' + r.id);
      UI.toast('Sessions revoked', 'ok'); load();
    } catch (e) { UI.toast(e.message, 'danger'); }
  }

  async function remove(r) {
    const ok = await UI.confirm({
      title: 'Delete admin “' + r.username + '”?',
      html: '<b>This cannot be undone.</b>Their audit history is preserved.',
      kind: 'danger', okText: 'Delete admin',
    });
    if (!ok) return;
    try {
      await Api.del('/admin/admins.php?id=' + r.id);
      UI.toast('Admin deleted', 'ok'); load();
    } catch (e) { UI.toast(e.message, 'danger'); }
  }

  return { load };
})();

/* ==========================================================================
   Backups  —  manual + scheduled archive management
   ========================================================================== */
const Backups = (() => {
  let bound = false;

  function scopePill(s) {
    const m = { full: ['vip', 'Full'], db: ['info', 'Database'], files: ['', 'Files'] };
    const [cls, label] = m[s] || ['', s || '—'];
    return '<span class="pill ' + cls + '">' + UI.esc(label) + '</span>';
  }

  // The database column is ENUM('ok','failed','sending','sent'). A row that
  // was successfully shipped to Telegram is rewritten to 'sent' — that is a
  // SUCCESS. The old check accepted only 'ok', so every delivered archive was
  // painted red "failed" while still carrying its own "✈ sent" badge.
  const OK_STATUS = { ok: 1, sent: 1 };

  function isGood(r) {
    return r.success === true || !!OK_STATUS[String(r.status || '').toLowerCase()];
  }

  function statusPill(r) {
    const st = String(r.status || '').toLowerCase();

    if (isGood(r)) {
      if (!r.available) {
        return '<span class="pill warn" title="Row exists but the file is gone from disk">missing</span>';
      }
      return st === 'sent'
        ? '<span class="pill ok" title="Archived and delivered to Telegram">delivered</span>'
        : '<span class="pill ok">stored</span>';
    }
    if (st === 'sending' || st === 'running') {
      return '<span class="pill info">sending…</span>';
    }
    return '<span class="pill danger" title="' + UI.esc(r.error || 'Backup failed') + '">failed</span>';
  }

  function row(r) {
    const tags = [];
    if (r.encrypted)    tags.push('<span class="pill sm ok" title="AES-256-GCM encrypted">🔒 enc</span>');
    if (r.delivered_tg) tags.push('<span class="pill sm info" title="Sent to Telegram">✈ sent</span>');
    if (r.orphan)       tags.push('<span class="pill sm warn" title="Found on disk, not in the database">orphan</span>');

    return '<tr>' +
      '<td><div class="mono" style="font-size:12px;word-break:break-all">' + UI.esc(r.filename) + '</div>' +
        (tags.length ? '<div class="chips mt4">' + tags.join('') + '</div>' : '') +
      '</td>' +
      '<td>' + scopePill(r.scope) + '<div class="muted sm mt4">' + UI.esc(r.kind || '') + '</div></td>' +
      '<td class="nowrap">' + UI.esc(r.size_human || '—') + '</td>' +
      '<td class="nowrap">' + statusPill(r) + '</td>' +
      '<td class="nowrap"><div>' + fmt.dateTime(r.created_at) + '</div>' +
        '<div class="muted sm">' + fmt.ago(r.created_at) + '</div></td>' +
      '<td class="muted sm">' + UI.esc(r.triggered_by || '—') + '</td>' +
      '<td class="right nowrap">' +
        (r.available
          ? '<button class="btn btn-sm" data-dl="' + UI.esc(r.filename) + '" title="Download">⤓</button>'
          : '') +
        (r.sha256
          ? ' <button class="btn btn-sm btn-ghost" data-sha="' + UI.esc(r.sha256) +
            '" data-f="' + UI.esc(r.filename) + '" title="Checksum">#</button>'
          : '') +
        ' <button class="btn btn-sm btn-ghost danger" data-del="' + UI.esc(r.filename) + '" title="Delete">✕</button>' +
      '</td></tr>';
  }

  async function load() {
    const list  = document.getElementById('bk-list');
    const stats = document.getElementById('bk-stats');
    if (!list) return;
    list.innerHTML = UI.skeletonRows(7, 4);

    const d = await Api.get('/admin/backups.php');
    const s = d.storage || {};
    const sc = d.schedule || {};
    // "Last backup" must count a delivered archive too, otherwise the card
    // reads "Never" even though archives exist on disk.
    const last = (d.backups || []).find(b => isGood(b) && b.available)
              || (d.backups || []).find(isGood);

    if (stats) {
      stats.innerHTML =
        Dashboard.tile(
          sc.auto_enabled ? 'ok' : 'warn',
          'Daily schedule',
          sc.auto_enabled ? (sc.time || '00:00') : 'Off',
          sc.auto_enabled ? (sc.timezone || 'Asia/Yangon') : 'Enable it in Settings'
        ) +
        Dashboard.tile(
          last ? 'info' : 'danger',
          'Last backup',
          last ? fmt.ago(last.created_at) : 'Never',
          last ? last.size_human + ' · ' + (last.scope || '') : 'Run one now'
        ) +
        Dashboard.tile(
          s.writable ? 'vip' : 'danger',
          'Storage used',
          s.total_human || '0 B',
          s.writable ? (s.free_human || '') + ' free' : 'NOT WRITABLE'
        );
    }

    const rows = d.backups || [];
    list.innerHTML = rows.length
      ? '<table class="tbl"><thead><tr>' +
        '<th>Archive</th><th>Scope</th><th>Size</th><th>Status</th>' +
        '<th>Created</th><th>By</th><th class="right">Actions</th>' +
        '</tr></thead><tbody>' + rows.map(row).join('') + '</tbody></table>'
      : UI.empty('▣', 'No backups yet', 'Run a full backup to create your first archive.');

    if (!bound) {
      bound = true;

      document.querySelectorAll('[data-bk-run]').forEach(btn => {
        btn.addEventListener('click', () => run(btn.dataset.bkRun, btn));
      });

      UI.on(list, '[data-dl]', (el) => download(el.dataset.dl, el));
      UI.on(list, '[data-sha]', (el) => {
        UI.modal({
          title: 'SHA-256 checksum',
          sub: el.dataset.f,
          body: '<p class="muted">Verify the archive after download:</p>' +
                '<div class="copy-row"><code class="mono grow" style="word-break:break-all">' +
                UI.esc(el.dataset.sha) + '</code>' +
                '<button class="btn btn-sm" data-copy="' + UI.esc(el.dataset.sha) + '">Copy</button></div>' +
                '<p class="muted sm mt12">On the VPS: <code>sha256sum ' + UI.esc(el.dataset.f) + '</code></p>',
        });
      });
      UI.on(list, '[data-del]', (el) => remove(el.dataset.del));
      UI.on(document.body, '[data-copy]', (el) => UI.copy(el.dataset.copy));
    }
  }

  async function run(scope, btn) {
    const labels = {
      full: 'Full backup', db: 'Database only',
      files: 'Files only', both: 'Full + Database',
    };
    const ok = await UI.confirm({
      title: 'Run ' + (labels[scope] || scope) + '?',
      message: scope === 'both'
        ? 'Creates two archives: a full panel backup, and a small database-only ' +
          'archive for importing onto a freshly installed VPS.'
        : scope === 'full'
          ? 'This archives the database and all application files. It may take a moment on a large install.'
          : 'This creates a new archive now.',
      okText: 'Run backup',
    });
    if (!ok) return;

    // "both" is a UI convenience, not a server scope — the endpoint only
    // knows full/db/files, so run them in sequence.
    const scopes = scope === 'both' ? ['full', 'db'] : [scope];
    const done = UI.busy(btn);
    const made = [];

    try {
      for (const s of scopes) {
        const d = await Api.post('/admin/backups.php?action=run', { scope: s, send_telegram: true });
        made.push(s.toUpperCase() + ' ' + (d.size_human || '') + (d.telegram ? ' ✈' : ''));
      }
      UI.toast('Backup created — ' + made.join('  ·  '), 'ok');
      load();
    } catch (e) {
      // Report what did land before the failure, so a half-done "both" run
      // is not mistaken for a total loss.
      UI.toast(
        made.length ? 'Created ' + made.join(', ') + ' — then failed: ' + e.message : e.message,
        'danger'
      );
      load();
    } finally {
      done();
    }
  }

  async function download(name, btn) {
    const done = UI.busy(btn);
    try {
      const res = await Api.raw(
        '/admin/backups.php?action=download&file=' + encodeURIComponent(name),
        { method: 'GET' }
      );
      // Non-JSON responses come back as the raw Response object.
      const blob = await res.blob();
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement('a');
      a.href = url; a.download = name;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
      UI.toast('Download started', 'ok');
    } catch (e) {
      UI.toast(e.message || 'Download failed', 'danger');
    } finally {
      done();
    }
  }

  async function remove(name) {
    const ok = await UI.confirm({
      title: 'Delete this archive?',
      html: '<code class="mono sm">' + UI.esc(name) + '</code>' +
            '<b class="block mt8">The file is erased from the VPS permanently.</b>',
      kind: 'danger', okText: 'Delete',
    });
    if (!ok) return;
    try {
      await Api.del('/admin/backups.php?file=' + encodeURIComponent(name));
      UI.toast('Archive deleted', 'ok'); load();
    } catch (e) { UI.toast(e.message, 'danger'); }
  }

  return { load };
})();

/* ==========================================================================
   Security  —  sign-in history, audit trail, live sessions, blocks
   ========================================================================== */
const Security = (() => {
  let bound = false;
  let tab    = 'logins';
  let page   = 1;
  let q      = '';

  const KIND = {
    admin_success: ['ok',     'Dashboard sign-in'],
    admin_failed:  ['danger', 'Dashboard FAILED'],
    admin_locked:  ['danger', 'Account locked'],
    vip_success:   ['info',   'App sign-in'],
    vip_failed:    ['warn',   'App failed'],
  };

  function device(ua) {
    const s = String(ua || '');
    if (!s) return 'unknown';
    if (/okhttp|Dart|Flutter/i.test(s))  return '📱 N4 Core app';
    if (/curl|wget|python/i.test(s))     return '⌨ CLI / script';
    if (/Android/i.test(s))              return '📱 Android browser';
    if (/iPhone|iPad|iOS/i.test(s))      return '📱 iOS';
    if (/Windows/i.test(s))              return '🖥 Windows';
    if (/Macintosh|Mac OS/i.test(s))     return '🖥 macOS';
    if (/Linux/i.test(s))                return '🖥 Linux';
    return 'other';
  }

  /* Shared with the Dashboard "Recent sign-ins" card. */
  function loginRow(r) {
    const [cls, label] = KIND[r.kind] || ['', r.kind || '—'];
    return '<tr>' +
      '<td><span class="pill ' + cls + '">' + UI.esc(label) + '</span>' +
        (r.reason ? '<div class="muted sm mt4">' + UI.esc(r.reason) + '</div>' : '') +
      '</td>' +
      '<td><b>' + UI.esc(r.username || '—') + '</b></td>' +
      '<td class="mono sm nowrap">' + UI.esc(r.ip || '—') + '</td>' +
      '<td class="muted sm nowrap" title="' + UI.esc(r.user_agent || '') + '">' +
        UI.esc(device(r.user_agent)) + '</td>' +
      '<td class="nowrap"><div>' + fmt.dateTime(r.created_at) + '</div>' +
        '<div class="muted sm">' + fmt.ago(r.created_at) + '</div></td>' +
      '</tr>';
  }

  function auditRow(r) {
    const [group] = String(r.action || '').split('.');
    const tone = { admin: 'info', server: '', vip: 'vip', plan: 'ok',
                   security: 'danger', backup: 'warn', location: '', settings: 'info' }[group] || '';
    let detail = '';
    if (r.detail && typeof r.detail === 'object') {
      detail = Object.keys(r.detail).slice(0, 5).map(k => {
        let v = r.detail[k];
        if (v === null || v === undefined) v = '—';
        else if (typeof v === 'object') v = JSON.stringify(v);
        else if (typeof v === 'boolean') v = v ? 'yes' : 'no';
        return '<span class="pill sm">' + UI.esc(k) + ': ' + UI.esc(String(v)) + '</span>';
      }).join(' ');
    }
    return '<tr>' +
      '<td><span class="pill ' + tone + '">' + UI.esc(r.action || '') + '</span></td>' +
      '<td><b>' + UI.esc(r.actor_name || '—') + '</b>' +
        '<div class="muted sm">' + UI.esc(r.actor_type || '') + '</div></td>' +
      '<td>' + (r.entity_type
        ? '<span class="muted sm">' + UI.esc(r.entity_type) + '</span>' +
          (r.entity_id ? '<div class="mono sm" style="word-break:break-all">' +
            UI.esc(String(r.entity_id).slice(0, 20)) + '</div>' : '')
        : '<span class="muted">—</span>') + '</td>' +
      '<td>' + (detail ? '<div class="chips">' + detail + '</div>' : '<span class="muted">—</span>') + '</td>' +
      '<td class="mono sm nowrap">' + UI.esc(r.ip || '—') + '</td>' +
      '<td class="nowrap"><div>' + fmt.dateTime(r.created_at) + '</div>' +
        '<div class="muted sm">' + fmt.ago(r.created_at) + '</div></td>' +
      '</tr>';
  }

  function sessionRow(r) {
    const me = App.user();
    const isMe = me && me.id === r.admin_id;
    return '<tr>' +
      '<td><b>' + UI.esc(r.username || '') + '</b>' +
        (isMe ? ' <span class="pill sm info">this device</span>' : '') +
        '<div class="muted sm">' + UI.esc(r.role || '') + '</div></td>' +
      '<td class="mono sm nowrap">' + UI.esc(r.ip || '—') + '</td>' +
      '<td class="muted sm nowrap" title="' + UI.esc(r.user_agent || '') + '">' +
        UI.esc(device(r.user_agent)) + '</td>' +
      '<td class="nowrap">' + fmt.ago(r.last_seen_at) + '</td>' +
      '<td class="nowrap"><div>idle ends ' + fmt.dateTime(r.expires_at) + '</div>' +
        '<div class="muted sm">hard ' + fmt.dateTime(r.absolute_expires_at) + '</div></td>' +
      '<td class="right nowrap">' +
        (isMe ? '<span class="muted sm">—</span>'
              : '<button class="btn btn-sm btn-ghost danger" data-kill="' + r.admin_id +
                '" data-u="' + UI.esc(r.username || '') + '">Sign out</button>') +
      '</td></tr>';
  }

  async function load() {
    const list = document.getElementById('sec-list');
    if (!list) return;
    list.innerHTML = UI.skeletonRows(6, 5);

    if (!bound) {
      bound = true;
      document.querySelectorAll('[data-sec-tab]').forEach(btn => {
        btn.addEventListener('click', () => {
          tab = btn.dataset.secTab; page = 1;
          document.querySelectorAll('[data-sec-tab]').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          load();
        });
      });
      const qi = document.getElementById('sec-q');
      if (qi) {
        let t = null;
        qi.addEventListener('input', () => {
          clearTimeout(t);
          t = setTimeout(() => { q = qi.value.trim(); page = 1; load(); }, 300);
        });
      }
      UI.on(list, '[data-kill]', (el) => killSessions(el.dataset.kill, el.dataset.u));
      UI.on(list, '[data-unblock]', (el) => unblock(el.dataset.unblock));
    }

    const pager = document.getElementById('sec-pager');
    if (pager) pager.innerHTML = '';

    // ------------------------------------------------ live sessions
    if (tab === 'sessions') {
      const d = await Api.get('/admin/audit.php?view=sessions');
      const rows = d.sessions || [];
      list.innerHTML = rows.length
        ? '<table class="tbl"><thead><tr><th>Admin</th><th>IP</th><th>Device</th>' +
          '<th>Last seen</th><th>Expires</th><th class="right"></th></tr></thead><tbody>' +
          rows.map(sessionRow).join('') + '</tbody></table>'
        : UI.empty('◉', 'No active sessions', '');
      return;
    }

    // ------------------------------------------ blocks and lockouts
    if (tab === 'blocks') {
      const d = await Api.get('/admin/audit.php?view=blocks');
      const blocks = d.blocks || [];
      const locked = d.locked_admins || [];
      let html = '';

      if (locked.length) {
        html += '<div class="pad12"><h4 class="mb8">Locked admin accounts</h4>' +
          '<table class="tbl"><thead><tr><th>Admin</th><th>Failed attempts</th>' +
          '<th>Locked until</th></tr></thead><tbody>' +
          locked.map(l =>
            '<tr><td><b>' + UI.esc(l.username) + '</b>' +
              '<div class="muted sm">' + UI.esc(l.role) + '</div></td>' +
            '<td><span class="pill danger">' + l.failed_attempts + '</span></td>' +
            '<td class="nowrap">' + fmt.dateTime(l.locked_until) +
              '<div class="muted sm">unlock via Telegram /unlock</div></td></tr>'
          ).join('') + '</tbody></table></div>';
      }

      html += '<div class="pad12"><h4 class="mb8">Rate-limit blocks</h4>' +
        (blocks.length
          ? '<table class="tbl"><thead><tr><th>Profile</th><th>Source</th><th>Hits</th>' +
            '<th>Blocked until</th><th class="right"></th></tr></thead><tbody>' +
            blocks.map(b =>
              '<tr><td><span class="pill warn">' + UI.esc(b.profile || '') + '</span></td>' +
              '<td class="mono sm">' + UI.esc(b.key || '') + '</td>' +
              '<td>' + b.hits + '</td>' +
              '<td class="nowrap">' + fmt.dateTime(b.blocked_until) +
                '<div class="muted sm">' + fmt.ago(b.blocked_until) + '</div></td>' +
              '<td class="right"><button class="btn btn-sm" data-unblock="' +
                UI.esc(b.bucket) + '">Clear</button></td></tr>'
            ).join('') + '</tbody></table>'
          : UI.empty('✓', 'Nothing is blocked', 'No IP or account is currently rate-limited.')) +
        '</div>';

      list.innerHTML = html;
      return;
    }

    // -------------------------------------------------- login history
    if (tab === 'logins') {
      const d = await Api.get('/admin/audit.php?view=logins&page=' + page +
                              (q ? '&q=' + encodeURIComponent(q) : ''));
      const rows = d.logins || [];
      list.innerHTML = rows.length
        ? '<table class="tbl"><thead><tr><th>Event</th><th>Username</th><th>IP</th>' +
          '<th>Device</th><th>When</th></tr></thead><tbody>' +
          rows.map(loginRow).join('') + '</tbody></table>'
        : UI.empty('◭', 'No sign-in events', q ? 'Nothing matches “' + UI.esc(q) + '”.' : '');
      paginate(d);
      return;
    }

    // ---------------------------------------------------- audit trail
    const d = await Api.get('/admin/audit.php?page=' + page +
                            (q ? '&q=' + encodeURIComponent(q) : ''));
    const rows = d.entries || [];
    list.innerHTML = rows.length
      ? '<table class="tbl"><thead><tr><th>Action</th><th>Actor</th><th>Target</th>' +
        '<th>Detail</th><th>IP</th><th>When</th></tr></thead><tbody>' +
        rows.map(auditRow).join('') + '</tbody></table>'
      : UI.empty('▤', 'No audit entries', q ? 'Nothing matches “' + UI.esc(q) + '”.' : '');
    paginate(d);
  }

  function paginate(d) {
    const host = document.getElementById('sec-pager');
    if (!host) return;
    const pages = d.pages || 1;
    if (pages <= 1) { host.innerHTML = ''; return; }

    const cur = d.page || 1;
    host.innerHTML =
      '<button class="btn btn-sm" data-pg="' + (cur - 1) + '"' +
        (cur <= 1 ? ' disabled' : '') + '>← Prev</button>' +
      '<span class="muted sm" style="padding:0 10px">Page ' + cur + ' of ' + pages +
        ' · ' + fmt.num(d.total || 0) + ' records</span>' +
      '<button class="btn btn-sm" data-pg="' + (cur + 1) + '"' +
        (cur >= pages ? ' disabled' : '') + '>Next →</button>';

    host.querySelectorAll('[data-pg]').forEach(b => {
      b.addEventListener('click', () => {
        const n = parseInt(b.dataset.pg, 10);
        if (n >= 1 && n <= pages) { page = n; load(); }
      });
    });
  }

  async function killSessions(adminId, username) {
    const ok = await UI.confirm({
      title: 'Sign out “' + username + '” everywhere?',
      message: 'All of their dashboard sessions end immediately. App users are unaffected.',
      okText: 'Sign out',
    });
    if (!ok) return;
    try {
      await Api.post('/admin/admins.php?action=revoke&id=' + adminId);
      UI.toast('Sessions revoked', 'ok'); load();
    } catch (e) { UI.toast(e.message, 'danger'); }
  }

  async function unblock(bucket) {
    try {
      await Api.post('/admin/audit.php?action=clear_block', { bucket: bucket });
      UI.toast('Block cleared', 'ok'); load();
    } catch (e) { UI.toast(e.message, 'danger'); }
  }

  return { load, loginRow };
})();

/* ==========================================================================
   Settings  —  runtime configuration (no restart required)
   ========================================================================== */
const Settings = (() => {
  let original = {};

  function field(s) {
    const id = 'set-' + s.key;
    const label = UI.esc(s.label || s.key);

    if (s.type === 'bool') {
      // The CSS toggle needs the <input> immediately followed by .track
      // (it styles `input:checked + .track`), then the text label.
      return '<div class="field"><label class="switch" for="' + id + '">' +
        '<input type="checkbox" id="' + id + '" data-k="' + UI.esc(s.key) +
          '" data-t="bool"' + (s.value ? ' checked' : '') + '>' +
        '<span class="track"></span>' +
        '<span class="lbl">' + label +
          '<span class="mono sm muted block">' + UI.esc(s.key) + '</span></span>' +
      '</label></div>';
    }

    const input = (() => {
      if (s.type === 'int') {
        return '<input class="input" type="number" min="1" id="' + id + '" data-k="' +
          UI.esc(s.key) + '" data-t="int" value="' + UI.esc(String(s.value ?? '')) + '">';
      }
      if (s.type === 'time') {
        return '<input class="input" type="time" id="' + id + '" data-k="' + UI.esc(s.key) +
          '" data-t="time" value="' + UI.esc(String(s.value ?? '00:00')) + '">';
      }
      return '<textarea class="textarea" rows="2" id="' + id + '" data-k="' + UI.esc(s.key) +
        '" data-t="text">' + UI.esc(String(s.value ?? '')) + '</textarea>';
    })();

    return '<div class="field"><label for="' + id + '">' + label +
      '<span class="mono sm muted block">' + UI.esc(s.key) + '</span></label>' + input + '</div>';
  }

  function runtimeBlock(rt) {
    const yn = (v, good, bad) =>
      v ? '<span class="pill ok">' + (good || 'ready') + '</span>'
        : '<span class="pill warn">' + (bad || 'not configured') + '</span>';

    const row = (k, v) => '<dt>' + k + '</dt><dd>' + v + '</dd>';

    return '<dl class="kv">' +
      row('Brand',          UI.esc(rt.brand || '—')) +
      row('Timezone',       UI.esc(rt.timezone || '—')) +
      row('Server time',    '<span class="mono">' + UI.esc(rt.server_time || '—') + '</span>') +
      row('PHP',            '<span class="mono">' + UI.esc(rt.php_version || '—') + '</span>') +
      row('Telegram bot',   yn(rt.telegram_ready)) +
      row('Backup storage', yn(rt.backup_ready, 'writable', 'not writable')) +
      row('Config file',
        rt.config_locked
          ? '<span class="pill ok">locked (read-only)</span>'
          : '<span class="pill warn" title="chmod 400 config/config.php on the VPS">writable</span>') +
    '</dl>' +
    '<div class="alert info mt12"><span class="ico">\u2139</span><div>' +
      '<b>App compatibility is locked.</b>' +
      'These settings never change the public API response shape, so the published ' +
      'N4 Core app keeps working without an update.</div></div>';
  }

  async function load() {
    const form = document.getElementById('set-form');
    const rtEl = document.getElementById('set-runtime');
    if (!form) return;

    form.innerHTML = '<div class="skeleton" style="height:52px"></div>'.repeat(5);
    if (rtEl) rtEl.innerHTML = '<div class="skeleton" style="height:180px"></div>';

    const d  = await Api.get('/admin/settings.php');
    const st = d.settings || [];

    original = {};
    st.forEach(s => { original[s.key] = s.value; });

    // Keep the relative-time clock in step with the server.
    if (d.runtime && d.runtime.server_time) fmt.syncClock(d.runtime.server_time);

    form.innerHTML =
      st.map(field).join('') +
      '<div class="toolbar mt12" style="padding:0">' +
        '<div class="grow muted sm" id="set-dirty">No unsaved changes</div>' +
        '<button class="btn" type="button" data-set-reset>Reset</button>' +
        '<button class="btn btn-primary" type="button" data-set-save>Save changes</button>' +
      '</div>';

    if (rtEl) rtEl.innerHTML = runtimeBlock(d.runtime || {});

    const dirtyEl = form.querySelector('#set-dirty');
    const mark = () => {
      const n = Object.keys(collect()).length;
      dirtyEl.textContent = n ? n + ' unsaved change' + (n > 1 ? 's' : '') : 'No unsaved changes';
      dirtyEl.className = 'grow sm ' + (n ? 'warn-text' : 'muted');
    };
    form.querySelectorAll('[data-k]').forEach(el => {
      el.addEventListener('input',  mark);
      el.addEventListener('change', mark);
    });

    form.querySelector('[data-set-save]').addEventListener('click', (e) => save(e.currentTarget));
    form.querySelector('[data-set-reset]').addEventListener('click', () => load());
  }

  /* Only send the keys that actually changed. */
  function collect() {
    const out = {};
    document.querySelectorAll('#set-form [data-k]').forEach(el => {
      const key = el.dataset.k;
      const val = el.dataset.t === 'bool'
        ? el.checked
        : el.dataset.t === 'int' ? parseInt(el.value, 10) || 0 : el.value;
      const before = original[key];
      const same = el.dataset.t === 'bool'
        ? Boolean(before) === val
        : String(before ?? '') === String(val);
      if (!same) out[key] = val;
    });
    return out;
  }

  async function save(btn) {
    const payload = collect();
    const keys = Object.keys(payload);
    if (!keys.length) { UI.toast('Nothing to save', 'info'); return; }

    // Turning off the daily backup deserves a second look.
    if (payload.backup_auto_enabled === false) {
      const ok = await UI.confirm({
        title: 'Disable automatic daily backup?',
        message: 'Nightly 00:00 Yangon backups will stop. You would have to run them manually.',
        kind: 'danger', okText: 'Disable anyway',
      });
      if (!ok) return;
    }

    const done = UI.busy(btn);
    try {
      const d = await Api.post('/admin/settings.php', payload);
      UI.toast('Saved ' + (d.updated ? d.updated.length : keys.length) + ' setting(s)', 'ok');
      load();
      App.refreshBrand && App.refreshBrand();
    } catch (e) {
      UI.toast(e.message, 'danger');
    } finally {
      done();
    }
  }

  return { load };
})();


/* ==========================================================================
   Boot
   ========================================================================== */
document.addEventListener('DOMContentLoaded', () => App.boot());
