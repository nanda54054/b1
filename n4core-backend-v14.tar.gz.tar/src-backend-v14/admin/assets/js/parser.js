/* ==========================================================================
   N4 Core VPN — client-side share-link sniffer
   --------------------------------------------------------------------------
   Purpose: the instant that an admin pastes a config URL we want the
   Region / Protocol / Address / Port boxes to fill in with zero latency.

   This is a PREVIEW ONLY. The authoritative parse always happens server-side
   in core/ConfigParser.php via  servers.php?action=parse  — the server value
   overwrites whatever we guess here. That keeps one source of truth while
   still feeling instantaneous on a slow connection.
   ========================================================================== */
'use strict';

const LinkSniff = (() => {

  /* ------------------------------------------------ base64 (URL-safe too) */
  function b64(s) {
    if (!s) return null;
    let t = String(s).trim().replace(/-/g, '+').replace(/_/g, '/').replace(/\s+/g, '');
    while (t.length % 4) t += '=';
    try {
      // decodeURIComponent+escape round-trip gives us correct UTF-8
      return decodeURIComponent(Array.prototype.map
        .call(atob(t), c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
        .join(''));
    } catch (_) {
      try { return atob(t); } catch (_) { return null; }
    }
  }

  /* --------------------------------------------------- region dictionary */
  // Only the common ones — the server knows all 48+. Enough for instant feel.
  const FLAGS = {
    SG: '🇸🇬', JP: '🇯🇵', US: '🇺🇸', GB: '🇬🇧', DE: '🇩🇪', NL: '🇳🇱',
    HK: '🇭🇰', TW: '🇹🇼', KR: '🇰🇷', TH: '🇹🇭', MY: '🇲🇾', VN: '🇻🇳',
    IN: '🇮🇳', ID: '🇮🇩', PH: '🇵🇭', MM: '🇲🇲', FR: '🇫🇷', CA: '🇨🇦',
    AU: '🇦🇺', RU: '🇷🇺', TR: '🇹🇷', AE: '🇦🇪', BR: '🇧🇷', CN: '🇨🇳',
    FI: '🇫🇮', SE: '🇸🇪', CH: '🇨🇭', PL: '🇵🇱', IT: '🇮🇹', ES: '🇪🇸',
  };

  const WORDS = [
    [/\b(singapore|sgp?|sing)\b/i,                 'SG'],
    [/\b(japan|tokyo|osaka|jpn?|nrt|hnd|kix)\b/i,  'JP'],
    [/\b(united states|usa?|america|new ?york|los ?angeles|dallas|miami|seattle|chicago|nyc|lax|sfo|ash)\b/i, 'US'],
    [/\b(united kingdom|uk|england|london|gbr?|lhr)\b/i, 'GB'],
    [/\b(germany|deutsch|frankfurt|berlin|deu?|fra)\b/i, 'DE'],
    [/\b(netherland|holland|amsterdam|nld?|ams)\b/i,'NL'],
    [/\b(hong ?kong|hkg?)\b/i,                     'HK'],
    [/\b(taiwan|taipei|twn?)\b/i,                  'TW'],
    [/\b(korea|seoul|kor?|icn)\b/i,                'KR'],
    [/\b(thailand|bangkok|bkk|tha?)\b/i,           'TH'],
    [/\b(malaysia|kuala ?lumpur|mys?|kul)\b/i,     'MY'],
    [/\b(vietnam|hanoi|saigon|vnm?)\b/i,           'VN'],
    [/\b(india|mumbai|delhi|ind?|bom)\b/i,         'IN'],
    [/\b(indonesia|jakarta|idn?|cgk)\b/i,          'ID'],
    [/\b(philippin|manila|phl?)\b/i,               'PH'],
    [/\b(myanmar|burma|yangon|rangoon|mmr?|rgn)\b/i,'MM'],
    [/\b(france|paris|fra?nce|cdg)\b/i,            'FR'],
    [/\b(canada|toronto|montreal|can?|yyz)\b/i,    'CA'],
    [/\b(australia|sydney|melbourne|aus?|syd)\b/i, 'AU'],
    [/\b(russia|moscow|rus?)\b/i,                  'RU'],
    [/\b(turkey|turkiye|istanbul|tur?)\b/i,        'TR'],
    [/\b(emirates|dubai|abu ?dhabi|uae|are)\b/i,   'AE'],
    [/\b(brazil|sao ?paulo|bra?zil)\b/i,           'BR'],
    [/\b(china|shanghai|beijing|chn)\b/i,          'CN'],
    [/\b(finland|helsinki|fin)\b/i,                'FI'],
    [/\b(sweden|stockholm|swe)\b/i,                'SE'],
    [/\b(switzerland|zurich|geneva|che)\b/i,       'CH'],
    [/\b(poland|warsaw|pol)\b/i,                   'PL'],
    [/\b(italy|milan|rome|ita)\b/i,                'IT'],
    [/\b(spain|madrid|esp)\b/i,                    'ES'],
  ];

  const TLD = {
    sg: 'SG', jp: 'JP', us: 'US', uk: 'GB', de: 'DE', nl: 'NL', hk: 'HK',
    tw: 'TW', kr: 'KR', th: 'TH', my: 'MY', vn: 'VN', in: 'IN', id: 'ID',
    ph: 'PH', mm: 'MM', fr: 'FR', ca: 'CA', au: 'AU', ru: 'RU', tr: 'TR',
    ae: 'AE', br: 'BR', cn: 'CN', fi: 'FI', se: 'SE', ch: 'CH', pl: 'PL',
    it: 'IT', es: 'ES',
  };

  /** Best-effort country code from a label + hostname. */
  function region(label, host) {
    const hay = (label || '') + ' ' + (host || '');

    // 1. an actual flag emoji in the remark is the strongest signal
    const em = hay.match(/[\u{1F1E6}-\u{1F1FF}]{2}/u);
    if (em) {
      const cc = Array.from(em[0])
        .map(c => String.fromCharCode(c.codePointAt(0) - 0x1F1E6 + 65)).join('');
      if (FLAGS[cc]) return cc;
    }
    // 2. words / cities / airport codes
    for (const [re, cc] of WORDS) if (re.test(hay)) return cc;
    // 3. ccTLD
    const m = String(host || '').match(/\.([a-z]{2})$/i);
    if (m && TLD[m[1].toLowerCase()]) return TLD[m[1].toLowerCase()];
    return '';
  }

  function flag(cc) { return FLAGS[cc] || ''; }

  /* ----------------------------------------------------------- utilities */
  function splitHostPort(hp) {
    hp = String(hp || '').trim();
    // bracketed IPv6 -> [::1]:443
    let m = hp.match(/^\[([^\]]+)\]:(\d{1,5})$/);
    if (m) return { address: m[1], port: +m[2] };
    m = hp.match(/^\[([^\]]+)\]$/);
    if (m) return { address: m[1], port: 0 };
    // bare IPv6 (more than one colon and no port form)
    if ((hp.match(/:/g) || []).length > 1) return { address: hp, port: 0 };
    m = hp.match(/^(.+?):(\d{1,5})$/);
    if (m) return { address: m[1], port: +m[2] };
    return { address: hp, port: 0 };
  }

  function tag(link) {
    const i = link.indexOf('#');
    if (i < 0) return '';
    try { return decodeURIComponent(link.slice(i + 1)); }
    catch (_) { return link.slice(i + 1); }
  }

  function stripTag(link) {
    const i = link.indexOf('#');
    return i < 0 ? link : link.slice(0, i);
  }

  /* --------------------------------------------------------------- vmess */
  function vmess(link) {
    const payload = stripTag(link).slice('vmess://'.length);
    const dec = b64(payload);

    if (dec && dec.trim().charAt(0) === '{') {
      let j;
      try { j = JSON.parse(dec); } catch (_) { j = null; }
      if (j) {
        const label = j.ps || j.remarks || tag(link) || '';
        const host = String(j.add || j.address || '');
        return {
          protocol: 'vmess',
          address: host,
          port: parseInt(j.port, 10) || 0,
          label,
          network: j.net || j.network || '',
          security: j.tls || '',
          country_code: region(label, host),
        };
      }
    }
    // URL-shaped variant: vmess://uuid@host:port?...
    return loose(link, 'vmess');
  }

  /* ------------------------------------------------------------ ss / ssr */
  function ss(link) {
    let body = stripTag(link).slice('ss://'.length);
    const label = tag(link);

    // SIP002: ss://base64(method:pass)@host:port
    let at = body.lastIndexOf('@');
    if (at > -1) {
      const hp = splitHostPort(body.slice(at + 1).split('?')[0].split('/')[0]);
      return { protocol: 'shadowsocks', address: hp.address, port: hp.port, label,
               country_code: region(label, hp.address) };
    }
    // legacy: ss://base64(method:pass@host:port)
    const dec = b64(body.split('?')[0]);
    if (dec) {
      at = dec.lastIndexOf('@');
      if (at > -1) {
        const hp = splitHostPort(dec.slice(at + 1));
        return { protocol: 'shadowsocks', address: hp.address, port: hp.port, label,
                 country_code: region(label, hp.address) };
      }
    }
    return null;
  }

  function ssr(link) {
    const dec = b64(stripTag(link).slice('ssr://'.length));
    if (!dec) return null;
    // host:port:proto:method:obfs:base64pass/?params
    const parts = dec.split(':');
    if (parts.length < 2) return null;
    const label = tag(link);
    return { protocol: 'shadowsocks', address: parts[0], port: parseInt(parts[1], 10) || 0,
             label, country_code: region(label, parts[0]) };
  }

  /* --------------------------------------------------- generic URL forms */
  const MAP = {
    vless: 'vless', trojan: 'trojan', socks: 'socks', socks5: 'socks',
    http: 'socks', https: 'socks', hysteria: 'hysteria', hysteria2: 'hysteria2',
    hy2: 'hysteria2', tuic: 'tuic', vmess: 'vmess',
  };

  function loose(link, forceProto) {
    const m = String(link).match(/^([a-z0-9+.-]+):\/\/(.*)$/i);
    if (!m) return null;

    const scheme = m[1].toLowerCase();
    const proto = forceProto || MAP[scheme];
    if (!proto) return null;

    let rest = m[2];
    const label = tag(link);
    rest = stripTag(rest);

    const q = rest.indexOf('?');
    let query = '';
    if (q > -1) { query = rest.slice(q + 1); rest = rest.slice(0, q); }

    rest = rest.split('/')[0];
    const at = rest.lastIndexOf('@');
    if (at > -1) rest = rest.slice(at + 1);

    const hp = splitHostPort(rest);
    if (!hp.address) return null;

    const params = {};
    query.split('&').forEach(p => {
      if (!p) return;
      const i = p.indexOf('=');
      const k = decodeURIComponent(i < 0 ? p : p.slice(0, i));
      const v = i < 0 ? '' : decodeURIComponent(p.slice(i + 1).replace(/\+/g, ' '));
      params[k.toLowerCase()] = v;
    });

    // SNI/host headers are often the only place a region name appears
    const hint = [label, params.sni, params.host, params.peer].filter(Boolean).join(' ');

    return {
      protocol: proto,
      address: hp.address,
      port: hp.port || (params.port ? +params.port : 0),
      label,
      network: params.type || params.net || '',
      security: params.security || '',
      country_code: region(hint, hp.address),
    };
  }

  /* ----------------------------------------------------------- wireguard */
  function wireguard(text) {
    if (!/\[interface\]/i.test(text)) return null;
    const ep = text.match(/^\s*Endpoint\s*=\s*(.+?)\s*$/im);
    const label = (text.match(/^\s*#\s*(.+?)\s*$/m) || [])[1] || '';
    if (!ep) return { protocol: 'wireguard', address: '', port: 0, label, country_code: region(label, '') };
    const hp = splitHostPort(ep[1]);
    return { protocol: 'wireguard', address: hp.address, port: hp.port || 51820,
             label, country_code: region(label, hp.address) };
  }

  /* ---------------------------------------------------------------- json */
  function json(text) {
    let j;
    try { j = JSON.parse(text); } catch (_) { return null; }

    const outs = j.outbounds || (j.outbound ? [j.outbound] : (Array.isArray(j) ? j : [j]));
    for (const o of outs) {
      if (!o || typeof o !== 'object') continue;
      const proto = MAP[String(o.protocol || o.type || '').toLowerCase()];
      const vnext = (o.settings && (o.settings.vnext || o.settings.servers)) || o.server || [];
      const first = Array.isArray(vnext) ? vnext[0] : vnext;
      if (!proto || !first) continue;
      const host = first.address || first.server || '';
      const label = o.tag || '';
      return { protocol: proto, address: host, port: parseInt(first.port, 10) || 0,
               label, country_code: region(label, host) };
    }
    return null;
  }

  /* ------------------------------------------------------------ dispatch */
  /**
   * Sniffs a single pasted blob.
   * @returns {null|{protocol,address,port,label,country_code,network?,security?}}
   */
  function parse(text) {
    text = String(text || '').trim();
    if (!text) return null;

    if (/^vmess:\/\//i.test(text))  return vmess(text);
    if (/^ssr:\/\//i.test(text))    return ssr(text);
    if (/^ss:\/\//i.test(text))     return ss(text);
    if (/^[a-z0-9+.-]+:\/\//i.test(text)) return loose(text);

    if (/\[interface\]/i.test(text)) return wireguard(text);
    if (text.charAt(0) === '{' || text.charAt(0) === '[') return json(text);

    // bare host:port
    const bare = text.match(/^([a-z0-9.\-_]+|\[[0-9a-f:]+\]):(\d{1,5})$/i);
    if (bare) {
      const hp = splitHostPort(text);
      return { protocol: '', address: hp.address, port: hp.port, label: '',
               country_code: region('', hp.address) };
    }
    return null;
  }

  /** Counts how many share-links a bulk blob appears to contain. */
  function countLinks(blob) {
    blob = String(blob || '').trim();
    if (!blob) return 0;

    // whole-body base64 subscription?
    if (!/:\/\//.test(blob) && !/\[interface\]/i.test(blob)) {
      const dec = b64(blob);
      if (dec && dec.indexOf('://') > -1) blob = dec;
    }
    const m = blob.match(/[a-z0-9+.-]+:\/\/\S+/gi);
    return m ? m.length : 0;
  }

  return { parse, countLinks, region, flag, splitHostPort, b64 };
})();
