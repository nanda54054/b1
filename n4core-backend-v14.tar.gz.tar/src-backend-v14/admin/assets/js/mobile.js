/* ============================================================================
   N4 Core Admin — mobile behaviour layer
   ----------------------------------------------------------------------------
   Loaded LAST, after app.js. It adds phone behaviour without editing app.js:

     1. A bottom navigation bar built from the existing .nav-item buttons, so
        permissions (data-cap), page names and badges stay in one place.
     2. data-label stamping on table cells, which lets mobile.css redraw every
        <table class="tbl"> as a vertical card list. app.js keeps emitting the
        same table markup it always did.

   Everything is a no-op above 900px and on desktop.
   ========================================================================== */
(function () {
  'use strict';

  var MQ = window.matchMedia ? window.matchMedia('(max-width: 900px)') : null;
  function isPhone() { return MQ ? MQ.matches : window.innerWidth <= 900; }

  /* ==========================================================================
     1. BOTTOM NAVIGATION
     --------------------------------------------------------------------------
     Four real pages plus a "More" button that opens the existing sidebar
     drawer. The four are the ones the owner actually uses day to day; every
     other page is still reachable from More, so nothing is lost.

     Each button mirrors a real .nav-item, and clicking it clicks that item.
     That means routing, permission gating and the active class all keep
     running through app.js — this bar is only a second set of handles.
     ========================================================================== */
  var PRIMARY = [
    { page: 'dashboard', icon: '\u25C8', label: 'Home' },
    { page: 'accounts',  icon: '\u25C9', label: 'VIP' },
    { page: 'servers',   icon: '\u25A4', label: 'Servers' },
    { page: 'locations', icon: '\u25CD', label: 'Regions' }
  ];

  var bar = null;

  function navItem(page) {
    return document.querySelector('.nav-item[data-page="' + page + '"]');
  }

  function buildBar() {
    if (bar) return bar;

    bar = document.createElement('nav');
    bar.className = 'botnav';
    bar.setAttribute('aria-label', 'Main');

    PRIMARY.forEach(function (item) {
      var src = navItem(item.page);
      if (!src) return;                   // page not in this build

      var b = document.createElement('button');
      b.type = 'button';
      b.dataset.page = item.page;
      b.innerHTML =
        '<span class="ico">' + item.icon + '</span>' +
        '<span class="lbl"></span>' +
        '<span class="badge zero" hidden>0</span>';
      b.querySelector('.lbl').textContent = item.label;

      b.addEventListener('click', function () {
        // Delegate to the sidebar button so app.js owns routing.
        src.click();
      });

      bar.appendChild(b);
    });

    var more = document.createElement('button');
    more.type = 'button';
    more.dataset.more = '1';
    more.innerHTML =
      '<span class="ico">\u2261</span><span class="lbl">More</span>';
    more.addEventListener('click', function () {
      var burger = document.getElementById('burger');
      if (burger) burger.click();
    });
    bar.appendChild(more);

    document.getElementById('app-view').appendChild(bar);
    return bar;
  }

  /* Keep the bar in step with the sidebar: active page, badge counts, and
     whether a page is permitted at all. Cheap enough to just re-read. */
  function syncBar() {
    if (!bar) return;

    var openSidebar = document.getElementById('sidebar');
    var drawerOpen = !!(openSidebar && openSidebar.classList.contains('open'));
    var anyActive = false;

    Array.prototype.forEach.call(bar.querySelectorAll('button[data-page]'), function (b) {
      var src = navItem(b.dataset.page);
      if (!src) { b.hidden = true; return; }

      // A page the current admin cannot see is hidden in the sidebar; hide it
      // here too rather than showing a button that bounces to the dashboard.
      b.hidden = src.classList.contains('hidden');

      var active = !drawerOpen && src.classList.contains('active');
      b.classList.toggle('active', active);
      if (active) anyActive = true;

      var srcBadge = src.querySelector('.badge');
      var myBadge = b.querySelector('.badge');
      if (srcBadge && myBadge) {
        var n = (srcBadge.textContent || '').trim();
        myBadge.textContent = n;
        var zero = (n === '' || n === '0');
        myBadge.classList.toggle('zero', zero);
        myBadge.hidden = zero;
      }
    });

    // If the open page lives behind "More", light up More instead of nothing.
    var more = bar.querySelector('button[data-more]');
    if (more) more.classList.toggle('active', drawerOpen || !anyActive);
  }

  /* ==========================================================================
     2. TABLE -> CARD LIST LABELS
     --------------------------------------------------------------------------
     app.js renders tables as `<thead><tr><th>Name</th>...` + `<tbody>`. On a
     phone the header row is hidden, so each cell needs to carry its own label.
     We copy the header text onto every cell in the same column as data-label,
     and mobile.css draws it with ::before.

     Two extra marks:
       .m-title  the first cell, shown as the card heading (no label)
       .m-act    a trailing cell whose header is empty (the buttons column)
     ========================================================================== */
  function labelTable(tbl) {
    if (!tbl || tbl.dataset.mLabeled === '1') return;

    var head = tbl.querySelector('thead tr');
    if (!head) return;                    // skeleton table, nothing to copy

    var heads = Array.prototype.map.call(head.children, function (th) {
      return (th.textContent || '').trim();
    });
    if (!heads.length) return;

    var rows = tbl.querySelectorAll('tbody tr');
    Array.prototype.forEach.call(rows, function (tr) {
      if (tr.classList.contains('sk')) return;      // skeleton placeholder

      var cells = tr.children;
      var titleDone = false;

      for (var i = 0; i < cells.length; i++) {
        var td = cells[i];

        // A cell may span columns (used for "no results" rows). Those read
        // fine as-is, so leave them alone.
        if (td.colSpan && td.colSpan > 1) { td.setAttribute('data-label', ''); continue; }

        var label = heads[i] === undefined ? '' : heads[i];
        td.setAttribute('data-label', label);

        if (!titleDone && label !== '') {
          td.classList.add('m-title');
          titleDone = true;
        }
        /* Actions column. Most tables leave its header blank, but a few (e.g.
           Backups) label it "Actions", so keying off the blank header alone
           left those rows with unlabelled icon-only buttons. Detect it by
           content instead: a cell whose entire body is buttons. */
        if (isActionCell(td)) {
          td.classList.add('m-act');
          td.setAttribute('data-label', '');
          nameActions(td);
        }
      }
    });

    tbl.dataset.mLabeled = '1';
  }

  /* True when the cell holds nothing but buttons (plus whitespace). That is
     what an actions column looks like regardless of what its header says. */
  function isActionCell(td) {
    if (td.classList.contains('act')) return true;
    var btns = td.querySelectorAll('.btn, button, a.btn');
    if (!btns.length) return false;
    return (td.textContent || '').replace(/\s+/g, '').length <=
           Array.prototype.reduce.call(btns, function (n, b) {
             return n + (b.textContent || '').replace(/\s+/g, '').length;
           }, 0);
  }

  /* The desktop tables use icon-only action buttons (✎ ✕ 🔑) and rely on the
     title tooltip, which a touch screen has no way to show. On a phone the
     icon alone is a guessing game, especially for Delete sitting next to Edit.
     Add the word from title/data-act next to the icon. */
  var ACT_WORDS = {
    edit: 'Edit', del: 'Delete', reveal: 'Code', extend: 'Extend',
    devices: 'Devices', dv: 'Remove'
  };

  function nameActions(td) {
    Array.prototype.forEach.call(td.querySelectorAll('.btn'), function (btn) {
      if (btn.dataset.mNamed === '1') return;

      var word = '';
      var act = btn.dataset.act || '';
      if (ACT_WORDS[act]) {
        word = ACT_WORDS[act];
      } else if (btn.hasAttribute('data-dv')) {
        word = ACT_WORDS.dv;
      } else if (btn.title) {
        word = btn.title;
      }

      // Buttons that already carry their own words are left alone.
      if (!word || (btn.textContent || '').trim().length > 2) {
        btn.dataset.mNamed = '1';
        return;
      }

      var s = document.createElement('span');
      s.className = 'm-word';
      s.textContent = word;
      btn.appendChild(s);
      btn.dataset.mNamed = '1';
    });
  }

  function labelAll(root) {
    var scope = root && root.querySelectorAll ? root : document;
    Array.prototype.forEach.call(scope.querySelectorAll('table.tbl'), labelTable);
    if (scope !== document && scope.matches && scope.matches('table.tbl')) {
      labelTable(scope);
    }
  }

  /* app.js replaces innerHTML wholesale when a page loads, which wipes our
     data-label attributes along with the old rows. A MutationObserver is the
     only way to catch that without touching app.js. It is coalesced through
     requestAnimationFrame so a full page render costs one pass, not one per
     inserted node. */
  var pending = false;
  function schedule() {
    if (pending) return;
    pending = true;
    (window.requestAnimationFrame || window.setTimeout)(function () {
      pending = false;
      /* Only stamp on phones. On desktop the labels are harmless (CSS hides
         them) but nameActions() injects visible words next to the icons, so
         it must not run there. A resize into phone width re-runs enable(). */
      if (isPhone()) labelAll(document);
      syncBar();
    }, 16);
  }

  function observe() {
    if (!window.MutationObserver) return;
    var mo = new MutationObserver(function (records) {
      for (var i = 0; i < records.length; i++) {
        var r = records[i];
        if (r.type === 'childList' && (r.addedNodes.length || r.removedNodes.length)) {
          schedule();
          return;
        }
        if (r.type === 'attributes') { syncBar(); return; }
      }
    });
    mo.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['class']
    });
  }

  /* ==========================================================================
     3. WIRING
     ========================================================================== */
  function enable() {
    buildBar();
    labelAll(document);
    syncBar();
  }

  function apply() {
    if (isPhone()) {
      enable();
    } else if (bar) {
      // Leave the bar in the DOM; mobile.css hides it above 900px. Removing
      // and rebuilding on every rotation would just churn.
      syncBar();
    }
  }

  function boot() {
    var app = document.getElementById('app-view');
    if (!app) return;

    observe();
    apply();

    if (MQ) {
      if (MQ.addEventListener) MQ.addEventListener('change', apply);
      else if (MQ.addListener) MQ.addListener(apply);
    }
    window.addEventListener('hashchange', syncBar);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
