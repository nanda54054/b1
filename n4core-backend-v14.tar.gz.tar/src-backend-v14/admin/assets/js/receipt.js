/* =========================================================================
   N4 Core VPN — VIP sale receipt
   -------------------------------------------------------------------------
   Draws the "account created" slip an operator hands to a customer: the
   credentials, expiry and amount collected, as a PNG they can save to the
   phone gallery, plus a one-tap copy of username + password.

   Why a <canvas> and not html2canvas:

     - No third-party script. The panel currently ships zero external
       dependencies and loads nothing from a CDN. Pulling in a library to
       rasterise a box with six lines of text in it would hand a remote
       origin script access to a page that holds admin credentials — a bad
       trade for a rounded rectangle.
     - No off-screen DOM clone, so nothing can reflow mid-capture and there
       is no dependency on CSS variables resolving in a detached node.
     - Deterministic output: the slip looks identical on every device
       regardless of the viewer's font settings or dark-mode preference.

   Everything here is display-only. The access code is drawn from the value
   the create call already returned in memory; this file performs no I/O and
   never re-requests a credential.
   ========================================================================= */
'use strict';

const Receipt = (() => {

  /* Fixed design size. Rendered at 2x so it stays sharp on a phone. */
  const W = 760;          // logical px
  const SCALE = 2;
  const M = 40;           // outer margin (card edge)

  /* Dark "premium card" palette. The old slip was a white box with a
     coloured strip; this reads as a product rather than a printout, and the
     credentials sit on their own panel so they are the first thing the eye
     lands on. */
  const C = {
    bg1:     '#0b1220',      // shell gradient, top
    bg2:     '#111a2e',      // shell gradient, bottom
    card1:   '#16203a',      // card gradient
    card2:   '#101a30',
    hair:    'rgba(255,255,255,0.07)',
    hair2:   'rgba(255,255,255,0.12)',
    text:    '#f2f5fb',
    text2:   '#9fabc4',
    text3:   '#6b7893',
    brand:   '#4d8dff',
    brand2:  '#8b5cf6',
    cyan:    '#22d3ee',
    ok:      '#34d399',
    gold:    '#fbbf24',
    creds:   'rgba(77,141,255,0.10)',
  };

  const FONT = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", sans-serif';
  const MONO = 'ui-monospace, "SF Mono", SFMono-Regular, Menlo, Consolas, monospace';

  function font(size, weight, mono) {
    return (weight || 400) + ' ' + size + 'px ' + (mono ? MONO : FONT);
  }

  /* Rounded rect that also works on WebViews without roundRect(). */
  function rrect(ctx, x, y, w, h, r) {
    if (typeof ctx.roundRect === 'function') {
      ctx.beginPath();
      ctx.roundRect(x, y, w, h, r);
      return;
    }
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y,     x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x,     y + h, r);
    ctx.arcTo(x,     y + h, x,     y,     r);
    ctx.arcTo(x,     y,     x + w, y,     r);
    ctx.closePath();
  }

  /** Letter-spaced text — canvas has no letterSpacing on older WebViews. */
  function tracked(ctx, text, x, y, sp) {
    const str = String(text);
    let cx = x;
    for (let i = 0; i < str.length; i++) {
      ctx.fillText(str[i], cx, y);
      cx += ctx.measureText(str[i]).width + sp;
    }
    return cx - x - sp;
  }

  function trackedWidth(ctx, text, sp) {
    const str = String(text);
    let w = 0;
    for (let i = 0; i < str.length; i++) w += ctx.measureText(str[i]).width + sp;
    return w - sp;
  }

  /** The N4 diamond mark, drawn as a gradient lozenge with an inner cut. */
  function mark(ctx, cx, cy, r) {
    const g = ctx.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
    g.addColorStop(0, C.cyan);
    g.addColorStop(0.5, C.brand);
    g.addColorStop(1, C.brand2);

    ctx.save();
    ctx.shadowColor = 'rgba(77,141,255,0.55)';
    ctx.shadowBlur = 22;
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(cx, cy - r);
    ctx.lineTo(cx + r * 0.82, cy);
    ctx.lineTo(cx, cy + r);
    ctx.lineTo(cx - r * 0.82, cy);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    // inner facet, so the mark has some depth instead of reading as a blob
    ctx.fillStyle = 'rgba(11,18,32,0.55)';
    ctx.beginPath();
    ctx.moveTo(cx, cy - r * 0.44);
    ctx.lineTo(cx + r * 0.36, cy);
    ctx.lineTo(cx, cy + r * 0.44);
    ctx.lineTo(cx - r * 0.36, cy);
    ctx.closePath();
    ctx.fill();
  }

  /**
   * Render the slip.
   *
   * @param {object} d  { username, password, expires, plan, devices, price, issued }
   * @returns {HTMLCanvasElement}
   */
  function draw(d) {
    /* Detail rows below the credentials panel. Only what was actually
       supplied, so a slip without a plan or a price is not padded with
       em dashes. */
    const rows = [];
    if (d.plan)    rows.push(['PLAN',    String(d.plan),        C.text,  false]);
    if (d.devices) rows.push(['DEVICES', String(d.devices) + (String(d.devices) === '1' ? ' device' : ' devices'), C.text, false]);
    rows.push(['VALID UNTIL', String(d.expires || '—'), C.text, false]);
    if (d.price) {
      const p = String(d.price);
      rows.push(['AMOUNT PAID', /[^\d\s,.]/.test(p) ? p : p + ' MMK', C.ok, true]);
    }

    /* ------------------------------------------------------- geometry */
    const cardX = M;
    const cardW = W - M * 2;
    const HEAD  = 196;                    // brand block
    const CRED  = 216;                    // credentials panel
    const ROWH  = 54;
    const FOOT  = 102;
    const cardH = HEAD + CRED + 22 + rows.length * ROWH + FOOT;
    const H     = cardH + M * 2;

    const cv = document.createElement('canvas');
    cv.width  = W * SCALE;
    cv.height = H * SCALE;
    const ctx = cv.getContext('2d');
    ctx.scale(SCALE, SCALE);
    ctx.textBaseline = 'alphabetic';

    /* ------------------------------------------------------- backdrop */
    const shell = ctx.createLinearGradient(0, 0, W, H);
    shell.addColorStop(0, C.bg1);
    shell.addColorStop(1, C.bg2);
    ctx.fillStyle = shell;
    ctx.fillRect(0, 0, W, H);

    // Two soft colour blooms, so the background is not flat black.
    const bloom = (x, y, r, col) => {
      const rg = ctx.createRadialGradient(x, y, 0, x, y, r);
      rg.addColorStop(0, col);
      rg.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = rg;
      ctx.fillRect(0, 0, W, H);
    };
    bloom(W * 0.15, 40, 320, 'rgba(77,141,255,0.20)');
    bloom(W * 0.9, H - 60, 300, 'rgba(139,92,246,0.16)');

    /* ----------------------------------------------------------- card */
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,0.5)';
    ctx.shadowBlur = 30;
    ctx.shadowOffsetY = 10;
    const cg = ctx.createLinearGradient(cardX, M, cardX + cardW, M + cardH);
    cg.addColorStop(0, C.card1);
    cg.addColorStop(1, C.card2);
    ctx.fillStyle = cg;
    rrect(ctx, cardX, M, cardW, cardH, 30);
    ctx.fill();
    ctx.restore();

    // hairline border
    ctx.strokeStyle = C.hair2;
    ctx.lineWidth = 1;
    rrect(ctx, cardX + 0.5, M + 0.5, cardW - 1, cardH - 1, 30);
    ctx.stroke();

    // Accent strip along the top, clipped to the card's rounded corners.
    ctx.save();
    rrect(ctx, cardX, M, cardW, cardH, 30);
    ctx.clip();
    const strip = ctx.createLinearGradient(cardX, 0, cardX + cardW, 0);
    strip.addColorStop(0,    C.cyan);
    strip.addColorStop(0.45, C.brand);
    strip.addColorStop(1,    C.brand2);
    ctx.fillStyle = strip;
    ctx.fillRect(cardX, M, cardW, 5);
    ctx.restore();

    /* ------------------------------------------------------ brand head */
    let y = M + 52;
    mark(ctx, W / 2, y + 8, 26);

    y += 74;
    ctx.textAlign = 'center';
    ctx.fillStyle = C.text;
    ctx.font = font(35, 800);
    const titleSp = 1.6;
    tracked(ctx, 'N4 CORE VPN',
      W / 2 - trackedWidth(ctx, 'N4 CORE VPN', titleSp) / 2, y, titleSp);

    y += 22;
    ctx.fillStyle = C.text3;
    ctx.font = font(13, 600);
    const sub = 'PREMIUM ACCESS RECEIPT';
    tracked(ctx, sub, W / 2 - trackedWidth(ctx, sub, 2.4) / 2, y, 2.4);

    /* Status pill */
    y += 34;
    ctx.font = font(13, 700);
    const pillTxt = 'VIP ACTIVE';
    const pillW = trackedWidth(ctx, pillTxt, 1.4) + 60;
    const pillX = W / 2 - pillW / 2;
    ctx.fillStyle = 'rgba(52,211,153,0.13)';
    rrect(ctx, pillX, y - 17, pillW, 30, 15);
    ctx.fill();
    ctx.strokeStyle = 'rgba(52,211,153,0.34)';
    rrect(ctx, pillX + 0.5, y - 16.5, pillW - 1, 29, 14.5);
    ctx.stroke();
    // live dot
    ctx.fillStyle = C.ok;
    ctx.beginPath();
    ctx.arc(pillX + 22, y - 2.5, 4.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = C.ok;
    ctx.textAlign = 'left';
    tracked(ctx, pillTxt, pillX + 36, y + 2, 1.4);

    /* ------------------------------------------- credentials panel */
    y = M + HEAD + 6;
    const cpX = cardX + 26;
    const cpW = cardW - 52;

    ctx.fillStyle = C.creds;
    rrect(ctx, cpX, y, cpW, CRED - 26, 20);
    ctx.fill();
    ctx.strokeStyle = 'rgba(77,141,255,0.26)';
    rrect(ctx, cpX + 0.5, y + 0.5, cpW - 1, CRED - 27, 20);
    ctx.stroke();

    /* Username / password, stacked and left-aligned. Big monospace so the
       customer can read the digits off a phone screen at arm's length. */
    const field = (label, value, top, colour) => {
      ctx.textAlign = 'left';
      ctx.fillStyle = C.text3;
      ctx.font = font(11.5, 700);
      tracked(ctx, label, cpX + 26, top, 1.9);

      ctx.fillStyle = colour;
      ctx.font = font(34, 700, true);
      ctx.fillText(String(value == null || value === '' ? '—' : value), cpX + 26, top + 39);
    };

    field('USERNAME', d.username, y + 38, C.text);

    // divider between the two fields
    ctx.strokeStyle = C.hair;
    ctx.beginPath();
    ctx.moveTo(cpX + 26, y + 100);
    ctx.lineTo(cpX + cpW - 26, y + 100);
    ctx.stroke();

    field('PASSWORD', d.password, y + 133, C.gold);

    /* -------------------------------------------------------- detail rows */
    y = M + HEAD + CRED + 16;
    rows.forEach((r, i) => {
      const ry = y + i * ROWH;

      ctx.textAlign = 'left';
      ctx.fillStyle = C.text3;
      ctx.font = font(11.5, 700);
      tracked(ctx, r[0], cardX + 34, ry, 1.7);

      ctx.textAlign = 'right';
      ctx.fillStyle = r[2];
      ctx.font = font(r[3] ? 21 : 18, r[3] ? 800 : 650);
      ctx.fillText(r[1], cardX + cardW - 34, ry);

      if (i < rows.length - 1) {
        ctx.strokeStyle = C.hair;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(cardX + 34, ry + 20);
        ctx.lineTo(cardX + cardW - 34, ry + 20);
        ctx.stroke();
      }
    });

    /* ------------------------------------------------------------ footer */
    let fy = y + rows.length * ROWH - 8;

    // perforation, so the bottom reads as a tear-off stub
    ctx.save();
    rrect(ctx, cardX, M, cardW, cardH, 30);
    ctx.clip();
    ctx.fillStyle = C.bg1;
    ctx.beginPath(); ctx.arc(cardX, fy, 13, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(cardX + cardW, fy, 13, 0, Math.PI * 2); ctx.fill();
    ctx.restore();

    ctx.strokeStyle = C.hair2;
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 6]);
    ctx.beginPath();
    ctx.moveTo(cardX + 20, fy);
    ctx.lineTo(cardX + cardW - 20, fy);
    ctx.stroke();
    ctx.setLineDash([]);

    fy += 40;
    ctx.textAlign = 'center';
    ctx.fillStyle = C.text2;
    ctx.font = font(17, 650);
    ctx.fillText('Thank you for choosing N4 Core VPN', W / 2, fy);

    fy += 26;
    ctx.fillStyle = C.text3;
    ctx.font = font(13, 500);
    ctx.fillText('Keep this slip safe · Do not share your password', W / 2, fy);

    if (d.issued) {
      fy += 24;
      ctx.fillStyle = 'rgba(107,120,147,0.75)';
      ctx.font = font(12, 500);
      ctx.fillText('Issued ' + d.issued, W / 2, fy);
    }

    return cv;
  }

  /**
   * Save the slip as a PNG.
   *
   * Uses a Blob URL rather than a data: URL — a data: URL for a 700x800@2x
   * PNG is a ~1 MB string, and Android Chrome refuses to download those
   * past a size limit, which is exactly the platform this is for.
   */
  function save(d) {
    let cv;
    try {
      cv = draw(d);
    } catch (e) {
      UI.toast('Could not render the receipt image.', 'warn');
      return;
    }

    const name = 'N4_VIP_' + String(d.username || 'account').replace(/[^\w.-]/g, '_') + '.png';

    const trigger = url => {
      const a = document.createElement('a');
      a.href = url;
      a.download = name;
      document.body.appendChild(a);
      a.click();
      a.remove();
    };

    if (cv.toBlob) {
      cv.toBlob(blob => {
        if (!blob) { UI.toast('Could not create the image.', 'warn'); return; }
        const url = URL.createObjectURL(blob);
        trigger(url);
        // Revoked on a delay: revoking immediately can cancel the download
        // on some Android WebViews before it has started reading.
        setTimeout(() => URL.revokeObjectURL(url), 60000);
        UI.toast('Image saved to gallery', 'ok');
      }, 'image/png');
    } else {
      trigger(cv.toDataURL('image/png'));
      UI.toast('Image saved', 'ok');
    }
  }

  /** Copy the two values the customer actually needs, in the old format. */
  function copyText(d) {
    UI.copy(
      'Username: ' + d.username + '\nPassword: ' + d.password,
      'Username & password'
    );
  }

  /**
   * Preview markup for the modal.
   *
   * Mirrors the PNG rather than the dashboard: same dark card, same order,
   * same emphasis, so what the operator approves on screen is what the
   * customer receives. Colours are inline-fixed for the same reason the
   * canvas ones are — the slip does not follow the panel's theme.
   */
  function previewHtml(d) {
    const row = (k, v, cls) =>
      '<div class="rcp-row"><span class="rcp-k">' + UI.esc(k) + '</span>' +
      '<span class="rcp-v' + (cls ? ' ' + cls : '') + '">' + UI.esc(v) + '</span></div>';

    const amount = d.price
      ? (/[^\d\s,.]/.test(String(d.price)) ? String(d.price) : String(d.price) + ' MMK')
      : '';

    return '<div class="rcp">' +
        '<div class="rcp-head">' +
          '<div class="rcp-mark"></div>' +
          '<b>N4 CORE VPN</b>' +
          '<span class="rcp-sub">PREMIUM ACCESS RECEIPT</span>' +
          '<span class="rcp-tag"><i></i>VIP ACTIVE</span>' +
        '</div>' +

        '<div class="rcp-creds">' +
          '<div class="rcp-f"><span class="rcp-fk">USERNAME</span>' +
            '<span class="rcp-fv">' + UI.esc(d.username) + '</span></div>' +
          '<div class="rcp-f"><span class="rcp-fk">PASSWORD</span>' +
            '<span class="rcp-fv gold">' + UI.esc(d.password) + '</span></div>' +
        '</div>' +

        (d.plan    ? row('PLAN', d.plan) : '') +
        (d.devices ? row('DEVICES', String(d.devices) +
                     (String(d.devices) === '1' ? ' device' : ' devices')) : '') +
        row('VALID UNTIL', d.expires) +
        (amount ? row('AMOUNT PAID', amount, 'ok') : '') +

        '<div class="rcp-foot">Thank you for choosing N4 Core VPN' +
          '<span>Keep this slip safe \u00b7 Do not share your password</span></div>' +
      '</div>';
  }

  return { draw, save, copyText, previewHtml };
})();
