#!/usr/bin/env bash
#
# ============================================================================
#  N4 Core — Menu (တစ်ခုတည်းနဲ့ အားလုံး)
# ============================================================================
#  sudo ./n4core.sh
#
#  Command တွေ မမှတ်ရပါ။ နံပါတ် ရွေးရုံပါ။
# ============================================================================

set -uo pipefail

APP_DIR="${N4_APP_DIR:-}"
# readlink -f, not plain dirname: once the /usr/local/bin/n4core shortcut is
# installed, BASH_SOURCE[0] is the symlink, so dirname alone yields
# /usr/local/bin and the app directory is never found.
SELF_DIR="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}" 2>/dev/null \
  || printf '%s' "${BASH_SOURCE[0]}")")" && pwd)"

if [ -t 1 ]; then
  R=$'\e[31m'; G=$'\e[32m'; Y=$'\e[33m'; B=$'\e[34m'; C=$'\e[36m'; W=$'\e[1m'; D=$'\e[2m'; N=$'\e[0m'
else
  R=""; G=""; Y=""; B=""; C=""; W=""; D=""; N=""
fi

ok()   { printf '%s✅ %s%s\n' "$G" "$*" "$N"; }
warn() { printf '%s⚠️  %s%s\n' "$Y" "$*" "$N"; }
err()  { printf '%s❌ %s%s\n' "$R" "$*" "$N" >&2; }
info() { printf '   %s\n' "$*"; }
hr()   { printf '%s──────────────────────────────────────────────%s\n' "$C" "$N"; }
die()  { err "$*"; exit 1; }

[ "$(id -u)" = "0" ] || die "root လိုပါတယ်:  sudo ./n4core.sh"

# ---------------------------------------------------------------- app dir ရှာ
find_app() {
  [ -n "$APP_DIR" ] && [ -f "$APP_DIR/core/bootstrap.php" ] && return 0

  # ဒီ script က app dir ထဲမှာ ရှိနေတာ အများဆုံးပါ
  if [ -f "$SELF_DIR/core/bootstrap.php" ]; then APP_DIR="$SELF_DIR"; return 0; fi

  local c
  for c in /var/www/n4core /var/www/n4core_backend_v2 /var/www/html/n4core; do
    [ -f "$c/core/bootstrap.php" ] && { APP_DIR="$c"; return 0; }
  done

  # nginx root ကနေ
  c="$(grep -rhoP '^\s*root\s+\K[^;]+' /etc/nginx/sites-enabled/ /etc/nginx/conf.d/ 2>/dev/null \
       | tr -d ' ' | while read -r p; do [ -f "$p/core/bootstrap.php" ] && echo "$p" && break; done)"
  [ -n "$c" ] && { APP_DIR="$c"; return 0; }

  c="$(find /var/www /srv /opt -maxdepth 4 -type f -path '*/core/bootstrap.php' 2>/dev/null | head -1)"
  [ -n "$c" ] && { APP_DIR="$(dirname "$(dirname "$c")")"; return 0; }

  return 1
}

find_app || die "App directory မတွေ့ပါ။  N4_APP_DIR=/path/to/app sudo ./n4core.sh"

cd "$APP_DIR" || die "$APP_DIR ထဲ ဝင်လို့မရ"

# ---------------------------------------------------------------- config ဖတ်
cfg() {
  php -r '
    $c = @require $argv[1]; if (!is_array($c)) exit(1);
    $v = $c; foreach (explode(".", $argv[2]) as $k) {
      if (!is_array($v) || !array_key_exists($k, $v)) exit(1);
      $v = $v[$k];
    }
    echo is_bool($v) ? ($v ? "true" : "false") : (is_scalar($v) ? (string)$v : "");
  ' "$APP_DIR/config/config.php" "$1" 2>/dev/null
}

pause() { echo; printf '%sEnter ခလုတ် နှိပ်ပါ...%s' "$D" "$N"; read -r _; }

# ---------------------------------------------------------------- အခြေအနေ
show_status() {
  clear 2>/dev/null || printf '\n\n'
  hr
  printf '%s  N4 Core — Backend & Dashboard%s\n' "$W" "$N"
  hr
  info "တည်နေရာ : $APP_DIR"

  local phpv; phpv="$(php -r 'echo PHP_VERSION;' 2>/dev/null || echo '?')"
  info "PHP     : $phpv"

  # DB
  if php -r '
      require "'"$APP_DIR"'/core/bootstrap.php";
      Db::one("SELECT 1");
    ' >/dev/null 2>&1; then
    printf '   Database: %sချိတ်ဆက်ရ%s\n' "$G" "$N"
  else
    printf '   Database: %sချိတ်ဆက်လို့မရ%s\n' "$R" "$N"
  fi

  # device-auth
  local da; da="$(cfg security.require_device_auth)"
  case "$da" in
    true)  printf '   App စစ်ဆေးမှု: %sဖွင့်%s (signature ပါတဲ့ app သာ ရ)\n' "$G" "$N" ;;
    false) printf '   App စစ်ဆေးမှု: %sပိတ်%s (app အားလုံး ရ)\n' "$Y" "$N" ;;
    *)     printf '   App စစ်ဆေးမှု: %sမသတ်မှတ်ရသေး%s\n' "$R" "$N" ;;
  esac

  # secret
  local sec; sec="$(cfg security.app_bootstrap_secret)"
  case "$sec" in
    '')          printf '   App secret   : %sမရှိ%s\n' "$R" "$N" ;;
    CHANGE_ME*)  printf '   App secret   : %sမသတ်မှတ်ရသေး%s\n' "$Y" "$N" ;;
    *)           printf '   App secret   : %sရှိ%s (%d လုံး)\n' "$G" "$N" "${#sec}" ;;
  esac
  hr
}

# ---------------------------------------------------------------- menu
menu() {
  echo
  printf '%s  ဘာလုပ်မလဲ%s\n\n' "$W" "$N"
  printf '   %s1%s  Code အသစ် တင်            (update package)\n' "$C" "$N"
  printf '   %s2%s  App စစ်ဆေးမှု ဖွင့်/ပိတ်\n' "$C" "$N"
  printf '   %s3%s  APK ဆောက်ရန် secret ကြည့်\n' "$C" "$N"
  echo
  printf '   %s4%s  Admin အသစ် ဖန်တီး\n' "$C" "$N"
  printf '   %s5%s  Backup ယူ\n' "$C" "$N"
  printf '   %s6%s  Database အသစ်ပြောင်း      (migrate)\n' "$C" "$N"
  echo
  printf '   %s7%s  အားလုံး စစ်ဆေး           (health check)\n' "$C" "$N"
  printf '   %s8%s  နောက်ဆုံး update ပြန်ရုပ်  (rollback)\n' "$C" "$N"
  printf '   %s9%s  VPS အသစ်ကို ရွှေ့          (migrate)\n' "$C" "$N"
  echo
  printf '   %s10%s Security fix အကုန် တင်     (all fix)\n' "$C" "$N"
  printf '   %s11%s Security စစ်ရုံ           (check only)\n' "$C" "$N"
  echo
  printf '   %s0%s  ထွက်\n' "$D" "$N"
  echo
  printf '%sနံပါတ် ရွေးပါ: %s' "$W" "$N"
}

# ============================================================================
#  ၁ — code တင်
# ============================================================================
do_update() {
  hr
  printf '%s ၁. Code အသစ် တင်%s\n' "$W" "$N"
  hr
  local up="$APP_DIR/deploy/n4core-update.sh"
  [ -f "$up" ] || { err "deploy/n4core-update.sh မရှိပါ"; return; }

  # tarball ရှာ
  local found=()
  local d f
  for d in "$PWD" /root /tmp /home/*; do
    for f in "$d"/n4core-update*.tar.gz; do
      [ -f "$f" ] && found+=("$f")
    done
  done

  local pkg=""
  if [ "${#found[@]}" -eq 1 ]; then
    pkg="${found[0]}"
    info "တွေ့တဲ့ package: $pkg"
    printf '%sဒါကို သုံးမလား? [Y/n] %s' "$W" "$N"
    local a; read -r a
    case "$a" in [nN]*) pkg="" ;; esac
  elif [ "${#found[@]}" -gt 1 ]; then
    info "package အများကြီး တွေ့တယ်:"
    local i=1
    for f in "${found[@]}"; do printf '     %d) %s\n' "$i" "$f"; i=$((i+1)); done
    printf '%sနံပါတ် ရွေးပါ (0 = လက်နဲ့ရိုက်): %s' "$W" "$N"
    local a; read -r a
    if [ "$a" -ge 1 ] 2>/dev/null && [ "$a" -le "${#found[@]}" ]; then
      pkg="${found[$((a-1))]}"
    fi
  fi

  if [ -z "$pkg" ]; then
    printf '%sPackage path ရိုက်ပါ: %s' "$W" "$N"
    read -r pkg
  fi
  [ -f "$pkg" ] || { err "'$pkg' မတွေ့ပါ"; return; }

  echo
  info "အရင် ဘာပြောင်းမလဲ ပြပါမယ် (ဘာမှ မပြောင်းပါ)"
  echo
  bash "$up" "$pkg" --app-dir "$APP_DIR" --dry-run

  echo
  printf '%sတကယ် တင်မလား? [y/N] %s' "$W" "$N"
  local a; read -r a
  case "$a" in
    [yY]*) echo; bash "$up" "$pkg" --app-dir "$APP_DIR" --yes ;;
    *)     info "ရပ်လိုက်ပါတယ်" ;;
  esac
}

# ============================================================================
#  ၂ — device-auth ဖွင့်/ပိတ်
# ============================================================================
do_toggle_auth() {
  hr
  printf '%s ၂. App စစ်ဆေးမှု%s\n' "$W" "$N"
  hr

  local da; da="$(cfg security.require_device_auth)"
  local up="$APP_DIR/deploy/n4core-update.sh"

  if [ "$da" = "true" ]; then
    info "အခု: ဖွင့်ထားတယ်"
    echo
    warn "ပိတ်လိုက်ရင် signature မပါတဲ့ app တွေလည်း ရသွားမယ် (လုံခြုံမှု နည်းမယ်)"
    printf '%sပိတ်မလား? [y/N] %s' "$W" "$N"
    local a; read -r a
    case "$a" in [yY]*) ;; *) info "ရပ်လိုက်ပါတယ်"; return ;; esac

    cp -p "$APP_DIR/config/config.php" "$APP_DIR/config/config.php.bak-$(date +%s)"
    chmod 600 "$APP_DIR/config/config.php"
    php -r '
      $f=$argv[1]; $s=file_get_contents($f);
      $n=preg_replace("/(\x27require_device_auth\x27\s*=>\s*)true/","$1false",$s,1,$c);
      if(!$c) exit(1); file_put_contents($f,$n);
    ' "$APP_DIR/config/config.php" && ok "ပိတ်လိုက်ပါပြီ" || err "ပြောင်းလို့မရ"
    chown www-data:www-data "$APP_DIR/config/config.php" 2>/dev/null
    chmod 400 "$APP_DIR/config/config.php"
  else
    info "အခု: ပိတ်ထားတယ်"
    echo
    [ -f "$up" ] || { err "deploy/n4core-update.sh မရှိပါ"; return; }
    bash "$up" --enable-device-auth --app-dir "$APP_DIR"
  fi
}

# ============================================================================
#  ၃ — secret ကြည့်
# ============================================================================
do_secret() {
  hr
  printf '%s ၃. APK ဆောက်ရန် secret%s\n' "$W" "$N"
  hr

  local sec; sec="$(cfg security.app_bootstrap_secret)"
  case "$sec" in
    '')         err "secret မရှိပါ — အရင် '၁' နဲ့ code တင်ပါ"; return ;;
    CHANGE_ME*) err "secret မသတ်မှတ်ရသေးပါ"
                info "ဒါကို run ပါ:  cd $APP_DIR && php bin/setup_device_auth.php --secret-only"
                return ;;
  esac

  echo
  printf '%s  ဒီ command ကို ကွန်ပျူတာမှာ run ပါ%s\n\n' "$W" "$N"
  printf '%s  flutter build apk --release \\\n    --dart-define=N4_BOOTSTRAP_SECRET=%s%s\n' "$C" "$sec" "$N"
  echo
  warn "ဒီ secret က server နဲ့ app တူရမယ်။ မတူရင် app က ဘာမှ အလုပ်မလုပ်ဘူး။"
  warn "လူတခြားကို မပြပါနဲ့။"
}

# ============================================================================
#  ၄ — admin
# ============================================================================
do_admin() {
  hr
  printf '%s ၄. Admin အသစ်%s\n' "$W" "$N"
  hr
  [ -f "$APP_DIR/bin/create_admin.php" ] || { err "bin/create_admin.php မရှိပါ"; return; }
  php "$APP_DIR/bin/create_admin.php"
}

# ============================================================================
#  ၅ — backup
# ============================================================================
do_backup() {
  hr
  printf '%s ၅. Backup%s\n' "$W" "$N"
  hr
  [ -f "$APP_DIR/core/Backup.php" ] || { err "core/Backup.php မရှိပါ"; return; }

  printf '   1) Database ပဲ\n   2) File ပဲ\n   3) အားလုံး\n\n'
  printf '%sရွေးပါ [3]: %s' "$W" "$N"
  local a; read -r a
  local scope
  case "${a:-3}" in
    1) scope="db" ;;
    2) scope="files" ;;
    *) scope="full" ;;
  esac

  echo
  info "Backup ယူနေတယ် ($scope) — ခဏ စောင့်ပါ..."

  # Backup::create() ကို တိုက်ရိုက် ခေါ်တယ်။ cron.php က --force-backup ပဲ
  # လက်ခံတာမို့ scope ရွေးလို့ မရဘူး။
  php -r '
    require $argv[1] . "/core/bootstrap.php";
    try {
      $r = Backup::create($argv[2], "manual", "n4core.sh");
      printf("%s\n", $r["path"] ?? "(path မရ)");
      if (isset($r["bytes"])) printf("အရွယ်: %s\n", Backup::human((int)$r["bytes"]));
      exit(0);
    } catch (Throwable $e) {
      fwrite(STDERR, "အမှား: " . $e->getMessage() . "\n");
      exit(1);
    }
  ' "$APP_DIR" "$scope" && ok "ပြီးပါပြီ" || err "Backup မရပါ"

  echo
  info "Backup တွေ ရှိတဲ့နေရာ: $APP_DIR/storage/backups/"
  ls -lh "$APP_DIR/storage/backups/" 2>/dev/null | tail -6
}

# ============================================================================
#  ၆ — migrate
# ============================================================================
do_migrate() {
  hr
  printf '%s ၆. Database အသစ်ပြောင်း%s\n' "$W" "$N"
  hr
  [ -f "$APP_DIR/bin/migrate.php" ] || { err "bin/migrate.php မရှိပါ"; return; }

  info "အရင် အခြေအနေ ကြည့်ပါမယ်"
  echo
  php "$APP_DIR/bin/migrate.php" --status 2>&1 | tail -20

  echo
  printf '   1) လိုအပ်တာ အားလုံး လုပ် (--all)\n'
  printf '   2) Device-auth table ပဲ\n'
  printf '   3) VIP code/token ကို hash လုပ်\n'
  printf '   0) ဘာမှ မလုပ်\n\n'
  printf '%sရွေးပါ [0]: %s' "$W" "$N"
  local a; read -r a
  echo
  case "${a:-0}" in
    1) php "$APP_DIR/bin/migrate.php" --all ;;
    2) php "$APP_DIR/bin/migrate.php" --device-auth ;;
    3) warn "ဒါက ပြန်ရုပ်လို့ မရပါ။ Backup ယူပြီးလား?"
       printf '%sဆက်မလား? [y/N] %s' "$W" "$N"
       local b; read -r b
       case "$b" in [yY]*) php "$APP_DIR/bin/migrate.php" --hash-codes --hash-tokens ;;
                    *) info "ရပ်လိုက်ပါတယ်" ;; esac ;;
    *) info "ရပ်လိုက်ပါတယ်" ;;
  esac
}

# ============================================================================
#  ၇ — health check
# ============================================================================
do_health() {
  hr
  printf '%s ၇. အားလုံး စစ်ဆေး%s\n' "$W" "$N"
  hr

  local pass=0 fail=0
  t() {
    if eval "$2" >/dev/null 2>&1; then
      printf '   %s✅%s %s\n' "$G" "$N" "$1"; pass=$((pass+1))
    else
      printf '   %s❌%s %s\n' "$R" "$N" "$1"; fail=$((fail+1))
    fi
  }

  printf '\n%s  File%s\n' "$W" "$N"
  t "core/bootstrap.php"        "[ -f '$APP_DIR/core/bootstrap.php' ]"
  t "config/config.php"         "[ -f '$APP_DIR/config/config.php' ]"
  t "core/DeviceAuth.php"       "[ -f '$APP_DIR/core/DeviceAuth.php' ]"
  t "admin dashboard"           "[ -f '$APP_DIR/admin/index.html' ]"

  printf '\n%s  လုံခြုံမှု%s\n' "$W" "$N"
  t "config.php က 400"          "[ \"\$(stat -c %a '$APP_DIR/config/config.php')\" = 400 ]"
  t "storage/ ရေးလို့ရ"          "[ -w '$APP_DIR/storage' ]"

  printf '\n%s  Database%s\n' "$W" "$N"
  t "ချိတ်ဆက်ရ"                  "php -r 'require \"$APP_DIR/core/bootstrap.php\"; Db::one(\"SELECT 1\");'"
  local tb
  for tb in vip_accounts servers locations app_devices app_nonces admin_users; do
    t "table: $tb" "php -r 'require \"$APP_DIR/core/bootstrap.php\";
      \$r = Db::one(\"SELECT 1 FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?\", [\"$tb\"]);
      exit(\$r ? 0 : 1);'"
  done

  printf '\n%s  Website%s\n' "$W" "$N"
  local host; host="$(grep -rhoP '^\s*server_name\s+\K[^;]+' /etc/nginx/sites-enabled/ 2>/dev/null | tr -d ' ' | grep -v '^_$' | head -1)"

  # web server က ဘယ် port မှာ လဲ ရှာတယ်။ port 80 မှာ မရှိရင် မှန်းမကြံဘဲ
  # ကြားပြတာများ ပြပြီး အာရုံကို ပိုဆိုးတယ်။
  local port=""
  local p
  for p in 80 8080 5060; do
    if ss -ltn 2>/dev/null | grep -qE ":${p}[[:space:]]"; then port="$p"; break; fi
  done

  if [ -z "$port" ]; then
    printf '   %s⚠️%s  Web server မတွေ့ပါ — website စစ်ချက် ကြော်လိုက်တယ်\n' "$Y" "$N"
    echo; hr
    if [ "$fail" = 0 ]; then ok "File/DB အပိုင်း အားလုံး ကောင်းပါတယ် ($pass ချက်)"
    else warn "အောင်: $pass   မအောင်: $fail"; fi
    hr
    return
  fi

  local base="http://127.0.0.1:${port}"
  info "port $port မှာ စစ်တယ်"
  c() {
    # -L follows the http -> https redirect a normal TLS site issues, -k
    # accepts the certificate when we connect by IP. Without them every probe
    # comes back 301 and the report looks broken on a perfectly healthy site.
    local got; got="$(curl -sLk -o /dev/null -w '%{http_code}' --max-time 10 \
      ${host:+-H "Host: $host"} "$base$2" 2>/dev/null || echo 000)"
    if printf '%s' "$3" | grep -qw "$got"; then
      printf '   %s✅%s %-28s %s\n' "$G" "$N" "$1" "$got"; pass=$((pass+1))
    else
      printf '   %s❌%s %-28s %s (%s လိုတယ်)\n' "$R" "$N" "$1" "$got" "$3"; fail=$((fail+1))
    fi
  }
  c "Dashboard"        "/admin/"              "200"
  c "config.php ပိတ်"   "/config/config.php"   "403 404"
  c "core/ ပိတ်"        "/core/DeviceAuth.php" "403 404"

  local da; da="$(cfg security.require_device_auth)"
  if [ "$da" = "true" ]; then
    c "API (signature လို)" "/api/public/plans.php" "401"
  else
    c "API (ဖွင့်ထား)"      "/api/public/plans.php" "200"
  fi

  echo; hr
  if [ "$fail" = 0 ]; then
    ok "အားလုံး ကောင်းပါတယ် ($pass ချက်)"
  else
    warn "အောင်: $pass   မအောင်: $fail"
  fi
  hr
}

# ============================================================================
#  ၈ — rollback
# ============================================================================
do_rollback() {
  hr
  printf '%s ၈. နောက်ဆုံး update ပြန်ရုပ်%s\n' "$W" "$N"
  hr
  local up="$APP_DIR/deploy/n4core-update.sh"
  [ -f "$up" ] || { err "deploy/n4core-update.sh မရှိပါ"; return; }
  bash "$up" --rollback --app-dir "$APP_DIR"
}

# ============================================================================
#  ၉ — VPS အသစ်ကို ရွှေ့
# ============================================================================
do_migrate_vps() {
  hr
  printf '%s ၉. VPS အသစ်ကို ရွှေ့%s\n' "$W" "$N"
  hr
  local mv="$APP_DIR/deploy/n4core-migrate-vps.sh"
  [ -f "$mv" ] || { err "deploy/n4core-migrate-vps.sh မရှိပါ"; return; }
  echo
  printf '   %s1)%s VPS အဟောင်း — အားလုံး ထုတ်ယူ (export)\n' "$C" "$N"
  printf '   %s2)%s VPS အသစ်    — ပြန်သွင်း (import)\n' "$C" "$N"
  printf '   0) ဘာမှ မလုပ်\n\n'
  printf '%sနံပါတ်: %s' "$W" "$N"
  local c=""; read -r c || c="0"
  echo
  case "$c" in
    1) bash "$mv" export ;;
    2)
      printf '%sFile လမ်းကြောင်း (.tar.gz.enc): %s' "$W" "$N"
      local f=""; read -r f || f=""
      [ -n "$f" ] && [ -f "$f" ] || { err "File မတွေ့ပါ"; return; }
      bash "$mv" import "$f"
      ;;
    *) info "ရပ်လိုက်ပါတယ်။" ;;
  esac
}

# ============================================================================
#  ၁၀ — security fix အကုန် တင်
# ============================================================================
# Security audit ကနေ ထွက်လာတဲ့ ၆ ချက်ကို တခါတည်း တင်တယ်။ cert pin ဖွင့်ရင်
# pin မကိုက်တဲ့ APK အားလုံး register မရတော့တာမို့ ရွေးခိုင်းတယ် — App အသစ်
# မဖြန့်ရသေးဘဲ ဖွင့်လိုက်ရင် သုံးစွဲသူတွေ ပြုတ်ကုန်မယ်။
do_fixall() {
  hr
  printf '%s ၁၀. Security fix အကုန် တင်%s\n' "$W" "$N"
  hr
  local fx="$APP_DIR/deploy/n4core-fixall.sh"
  [ -f "$fx" ] || { err "deploy/n4core-fixall.sh မရှိပါ — SRC အသစ် တင်ပါ"; return; }

  echo
  printf '  ဒါက အောက်ပါအတိုင်း လုပ်မယ် —\n'
  printf '    • Backup ယူတယ် (config + DB)\n'
  printf '    • DeviceAuth.php အသစ် တင်တယ် (anti-tamper ပြန်အလုပ်လုပ်စေတယ်)\n'
  printf '    • HSTS header ထည့်တယ်\n'
  printf '    • Rate limit ၂ ခု ထပ်ထည့်တယ်\n'
  printf '    • VIP code plaintext ဖျက်တယ်\n'
  echo
  printf '   %s1)%s Cert pin ဖွင့်ပြီး တင်     (App build 8 ဖြန့်ပြီးမှ)\n' "$C" "$N"
  printf '   %s2)%s Cert pin မဖွင့်ဘဲ တင်     (အခု လုံခြုံတယ်)\n' "$C" "$N"
  printf '   0) ဘာမှ မလုပ်\n\n'
  printf '%sနံပါတ်: %s' "$W" "$N"
  local c=""; read -r c || c="0"
  echo

  case "$c" in
    1)
      printf '%sAPK cert SHA-256 (colon ပါလည်း ရတယ်): %s' "$W" "$N"
      local h=""; read -r h || h=""
      h="$(printf '%s' "$h" | tr -d '[:space:]:' | tr 'A-F' 'a-f')"
      if ! printf '%s' "$h" | grep -qE '^[a-f0-9]{64}$'; then
        err "hex ၆၄ လုံး ဖြစ်ရမယ် (အခု ${#h} လုံး)"
        return
      fi
      printf '%sPlay cert SHA-256 (မရှိရင် Enter): %s' "$W" "$N"
      local p=""; read -r p || p=""
      p="$(printf '%s' "$p" | tr -d '[:space:]:' | tr 'A-F' 'a-f')"
      echo
      if [ -n "$p" ]; then
        bash "$fx" "$h" "$p"
      else
        bash "$fx" "$h"
      fi
      ;;
    2) bash "$fx" --no-pin ;;
    *) info "ရပ်လိုက်ပါတယ်။" ;;
  esac
}

# ============================================================================
#  ၁၁ — security စစ်ရုံ
# ============================================================================
do_seccheck() {
  hr
  printf '%s ၁၁. Security စစ်ရုံ%s\n' "$W" "$N"
  hr
  local sc="$APP_DIR/deploy/n4core-secure.sh"
  [ -f "$sc" ] || { err "deploy/n4core-secure.sh မရှိပါ — SRC အသစ် တင်ပါ"; return; }
  echo
  info "ဘာမှ မပြင်ဘူး — အခုအခြေအနေ စစ်ရုံပဲ"
  echo
  bash "$sc" --check
}

# ============================================================================
#  Shortcut install
# ============================================================================
#
# Typing `sudo /var/www/n4core/n4core.sh` is a lot to remember and a lot to
# mistype. The first time this script runs it drops a symlink in
# /usr/local/bin, so from then on the operator just types `n4core` from any
# directory. Silent when it already exists or when the link cannot be made
# (read-only /usr, unusual PATH) — a missing shortcut is a convenience issue,
# never a reason to refuse to start.
install_shortcut() {
  local link="/usr/local/bin/n4core"
  local self="$APP_DIR/n4core.sh"

  [ -f "$self" ] || return 0
  # Already pointing at this exact script? Nothing to do.
  [ "$(readlink -f "$link" 2>/dev/null)" = "$(readlink -f "$self")" ] && return 0
  [ -w /usr/local/bin ] 2>/dev/null || return 0

  if ln -sfn "$self" "$link" 2>/dev/null; then
    printf '%s✅%s ခုကစပြီး %sn4core%s လို့ ရိုက်ရုံနဲ့ ဒီ menu တက်ပါမယ်\n\n' \
      "$G" "$N" "$W" "$N"
    sleep 2
  fi
}

install_shortcut

# ============================================================================
#  Loop
# ============================================================================
while true; do
  show_status
  menu
  read -r choice
  echo
  case "$choice" in
    1) do_update;      pause ;;
    2) do_toggle_auth; pause ;;
    3) do_secret;      pause ;;
    4) do_admin;       pause ;;
    5) do_backup;      pause ;;
    6) do_migrate;     pause ;;
    7) do_health;      pause ;;
    8) do_rollback;    pause ;;
    9) do_migrate_vps; pause ;;
    10) do_fixall;      pause ;;
    11) do_seccheck;    pause ;;
    0|q|Q) echo "ကောင်းပါတယ်။"; exit 0 ;;
    *) warn "နံပါတ် မှားပါတယ်"; sleep 1 ;;
  esac
done
