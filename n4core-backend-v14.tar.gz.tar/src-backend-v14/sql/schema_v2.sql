-- =====================================================================
-- N4 Core VPN — Backend Database Schema  v2 (hardened)
-- Target: MySQL 5.7+ / MariaDB 10.3+
--
-- Safe to run on a FRESH database, and safe to run on top of a v1
-- database (everything is IF NOT EXISTS / idempotent). To upgrade an
-- existing v1 install run sql/migrate_v1_to_v2.sql instead — it adds the
-- new columns to the tables you already have.
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- 1. admin_users  -> Dashboard login accounts (now role-aware + 2FA-ready)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS admin_users (
  id                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username           VARCHAR(64)  NOT NULL UNIQUE,
  password_hash      VARCHAR(255) NOT NULL,
  display_name       VARCHAR(128) DEFAULT NULL,
  role               ENUM('super_admin','admin') NOT NULL DEFAULT 'admin',
  is_active          TINYINT(1)   NOT NULL DEFAULT 1,

  -- Telegram binding: admins are created by the bot, so we remember who
  -- owns the account and where to send that person's alerts.
  telegram_user_id   BIGINT       DEFAULT NULL,
  created_by_tg_id   BIGINT       DEFAULT NULL,

  -- Forced password rotation on first login (bot-generated passwords).
  must_change_password TINYINT(1) NOT NULL DEFAULT 0,
  password_changed_at DATETIME    DEFAULT NULL,

  -- Brute-force lockout state.
  failed_attempts    INT UNSIGNED NOT NULL DEFAULT 0,
  locked_until       DATETIME     DEFAULT NULL,

  -- Optional TOTP secret (base32). NULL = 2FA disabled.
  totp_secret        VARCHAR(64)  DEFAULT NULL,

  last_login_at      DATETIME     DEFAULT NULL,
  last_login_ip      VARCHAR(45)  DEFAULT NULL,
  created_at         DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at         DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  INDEX idx_admin_users_role (role),
  INDEX idx_admin_users_tg (telegram_user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 2. admin_sessions -> tokens are stored HASHED (never in plain text)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS admin_sessions (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  admin_id      INT UNSIGNED NOT NULL,
  token_hash    CHAR(64)     NOT NULL UNIQUE,   -- sha256(token)
  csrf_hash     CHAR(64)     NOT NULL,          -- sha256(csrf token)
  ip            VARCHAR(45)  DEFAULT NULL,
  user_agent    VARCHAR(255) DEFAULT NULL,
  ua_hash       CHAR(64)     DEFAULT NULL,      -- binds session to client fingerprint
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at    DATETIME     NOT NULL,
  absolute_expires_at DATETIME NOT NULL,        -- hard cap, ignores activity
  revoked_at    DATETIME     DEFAULT NULL,
  CONSTRAINT fk_admin_sessions_admin FOREIGN KEY (admin_id) REFERENCES admin_users(id) ON DELETE CASCADE,
  INDEX idx_admin_sessions_expiry (expires_at),
  INDEX idx_admin_sessions_admin (admin_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 3. locations
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS locations (
  id            VARCHAR(36) PRIMARY KEY,
  name          VARCHAR(100) NOT NULL,
  country_code  VARCHAR(8)   NOT NULL,
  flag_emoji    VARCHAR(16)  NOT NULL,
  sort_order    INT          NOT NULL DEFAULT 0,
  is_enabled    TINYINT(1)   NOT NULL DEFAULT 1,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_locations_code (country_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 4. servers -> now stores parsed transport metadata from the URL parser
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS servers (
  id            VARCHAR(36) PRIMARY KEY,
  name          VARCHAR(100) NOT NULL,
  location_id   VARCHAR(36)  NOT NULL,
  protocol      ENUM('vmess','vless','trojan','shadowsocks','socks','wireguard') NOT NULL,
  tier          ENUM('free','vip') NOT NULL DEFAULT 'free',
  address       VARCHAR(255) NOT NULL DEFAULT '',
  port          INT          NOT NULL DEFAULT 0,
  raw_config    TEXT         NOT NULL,
  -- Parsed extras (display only; the app keeps using raw_config)
  network       VARCHAR(24)  DEFAULT NULL,   -- tcp | ws | grpc | h2 | kcp | quic
  security      VARCHAR(24)  DEFAULT NULL,   -- none | tls | reality | xtls
  sni           VARCHAR(255) DEFAULT NULL,
  parsed_meta   TEXT         DEFAULT NULL,   -- JSON blob of everything parsed
  load_percent  TINYINT UNSIGNED NOT NULL DEFAULT 0,
  sort_order    INT          NOT NULL DEFAULT 0,
  is_enabled    TINYINT(1)   NOT NULL DEFAULT 1,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_servers_location FOREIGN KEY (location_id) REFERENCES locations(id) ON DELETE CASCADE,
  INDEX idx_servers_tier (tier),
  INDEX idx_servers_enabled (is_enabled),
  INDEX idx_servers_location (location_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 5. vip_plans
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS vip_plans (
  id            VARCHAR(36) PRIMARY KEY,
  name          VARCHAR(100) NOT NULL,
  device_limit  INT          NOT NULL DEFAULT 1,
  duration_days INT          NOT NULL DEFAULT 30,
  price_label   VARCHAR(50)  NOT NULL DEFAULT '',
  price_amount  DECIMAL(12,2) DEFAULT NULL,   -- optional numeric price
  currency      VARCHAR(8)   DEFAULT 'MMK',
  is_popular    TINYINT(1)   NOT NULL DEFAULT 0,
  is_enabled    TINYINT(1)   NOT NULL DEFAULT 1,
  sort_order    INT          NOT NULL DEFAULT 0,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 6. vip_accounts -> access_code now ALSO stored hashed + encrypted
--    (hash for verification, encrypted copy so admins can still read it)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS vip_accounts (
  id                VARCHAR(36) PRIMARY KEY,
  username          VARCHAR(64)  NOT NULL UNIQUE,
  access_code       VARCHAR(64)  NOT NULL DEFAULT '',   -- legacy plain column (kept for v1 compat, blanked after migration)
  access_code_hash  VARCHAR(255) DEFAULT NULL,          -- password_hash() of the code
  access_code_enc   TEXT         DEFAULT NULL,          -- AES-256-GCM encrypted code (admin read-back)
  device_limit      INT          NOT NULL DEFAULT 1,
  plan_id           VARCHAR(36)  DEFAULT NULL,
  plan_name         VARCHAR(100) DEFAULT NULL,
  is_active         TINYINT(1)   NOT NULL DEFAULT 1,
  note              VARCHAR(255) DEFAULT NULL,
  price             VARCHAR(64)  DEFAULT NULL,          -- amount collected at sale (free text: "267", "267 Ks")
  created_by        INT UNSIGNED DEFAULT NULL,          -- admin_users.id
  failed_attempts   INT UNSIGNED NOT NULL DEFAULT 0,
  locked_until      DATETIME     DEFAULT NULL,
  last_login_at     DATETIME     DEFAULT NULL,
  expires_at        DATETIME     NOT NULL,
  created_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_vip_accounts_active (is_active),
  INDEX idx_vip_accounts_expiry (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 7. vip_devices
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS vip_devices (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  account_id    VARCHAR(36)  NOT NULL,
  device_id     VARCHAR(128) NOT NULL,
  device_label  VARCHAR(100) DEFAULT NULL,
  last_ip       VARCHAR(45)  DEFAULT NULL,
  first_seen_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_vip_devices_account FOREIGN KEY (account_id) REFERENCES vip_accounts(id) ON DELETE CASCADE,
  UNIQUE KEY uq_vip_devices_account_device (account_id, device_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 8. vip_sessions -> tokens hashed at rest here too
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS vip_sessions (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  account_id    VARCHAR(36)  NOT NULL,
  device_id     VARCHAR(128) NOT NULL,
  token         VARCHAR(128) DEFAULT NULL,   -- legacy plain column (v1 compat)
  token_hash    CHAR(64)     DEFAULT NULL,   -- sha256(token) — used by v2
  ip            VARCHAR(45)  DEFAULT NULL,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at    DATETIME     NOT NULL,
  revoked_at    DATETIME     DEFAULT NULL,
  CONSTRAINT fk_vip_sessions_account FOREIGN KEY (account_id) REFERENCES vip_accounts(id) ON DELETE CASCADE,
  UNIQUE KEY uq_vip_sessions_hash (token_hash),
  INDEX idx_vip_sessions_expiry (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 9. audit_log -> every admin mutation is recorded
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_log (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  actor_type    ENUM('admin','telegram','system','app') NOT NULL DEFAULT 'admin',
  actor_id      VARCHAR(64)  DEFAULT NULL,     -- admin id or telegram user id
  actor_name    VARCHAR(128) DEFAULT NULL,
  action        VARCHAR(64)  NOT NULL,         -- server.create, vip.extend, admin.login ...
  entity_type   VARCHAR(48)  DEFAULT NULL,
  entity_id     VARCHAR(64)  DEFAULT NULL,
  detail        TEXT         DEFAULT NULL,     -- JSON
  ip            VARCHAR(45)  DEFAULT NULL,
  user_agent    VARCHAR(255) DEFAULT NULL,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_audit_created (created_at),
  INDEX idx_audit_action (action),
  INDEX idx_audit_actor (actor_type, actor_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 10. rate_limits -> generic sliding-window counters (login, API, bot)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS rate_limits (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  bucket        VARCHAR(160) NOT NULL,        -- e.g. "admin_login:1.2.3.4"
  hits          INT UNSIGNED NOT NULL DEFAULT 1,
  window_start  DATETIME     NOT NULL,
  blocked_until DATETIME     DEFAULT NULL,
  updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_rate_bucket (bucket),
  INDEX idx_rate_window (window_start)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 11. login_events -> feeds the Telegram "login alarm" + dashboard
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS login_events (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kind          ENUM('admin_success','admin_failed','admin_locked','vip_success','vip_failed') NOT NULL,
  username      VARCHAR(64)  DEFAULT NULL,
  admin_id      INT UNSIGNED DEFAULT NULL,
  ip            VARCHAR(45)  DEFAULT NULL,
  country       VARCHAR(64)  DEFAULT NULL,
  user_agent    VARCHAR(255) DEFAULT NULL,
  reason        VARCHAR(96)  DEFAULT NULL,
  notified      TINYINT(1)   NOT NULL DEFAULT 0,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_login_events_created (created_at),
  INDEX idx_login_events_kind (kind)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 12. telegram_admins -> who may talk to the bot, and at what level
--     The OWNER row is seeded automatically from config.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS telegram_admins (
  id                BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  telegram_user_id  BIGINT       NOT NULL UNIQUE,
  telegram_username VARCHAR(64)  DEFAULT NULL,
  display_name      VARCHAR(128) DEFAULT NULL,
  role              ENUM('owner','super_admin','admin') NOT NULL DEFAULT 'admin',
  is_active         TINYINT(1)   NOT NULL DEFAULT 1,
  notify_login      TINYINT(1)   NOT NULL DEFAULT 1,
  notify_backup     TINYINT(1)   NOT NULL DEFAULT 1,
  notify_security   TINYINT(1)   NOT NULL DEFAULT 1,
  linked_admin_id   INT UNSIGNED DEFAULT NULL,
  last_seen_at      DATETIME     DEFAULT NULL,
  created_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 13. telegram_state -> per-chat conversation state for the bot wizard
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS telegram_state (
  chat_id       BIGINT       PRIMARY KEY,
  step          VARCHAR(64)  DEFAULT NULL,
  payload       TEXT         DEFAULT NULL,   -- JSON
  updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 14. telegram_updates -> de-duplicates getUpdates / webhook deliveries
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS telegram_updates (
  update_id     BIGINT       PRIMARY KEY,
  processed_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 15. backups -> catalogue of created archives (auto + manual)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS backups (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  filename      VARCHAR(255) NOT NULL,
  kind          ENUM('auto','manual') NOT NULL DEFAULT 'auto',
  scope         ENUM('full','db','files') NOT NULL DEFAULT 'full',
  size_bytes    BIGINT UNSIGNED NOT NULL DEFAULT 0,
  sha256        CHAR(64)     DEFAULT NULL,
  encrypted     TINYINT(1)   NOT NULL DEFAULT 0,
  status        ENUM('ok','failed','sending','sent') NOT NULL DEFAULT 'ok',
  error         VARCHAR(255) DEFAULT NULL,
  triggered_by  VARCHAR(128) DEFAULT NULL,   -- "cron" or telegram user
  delivered_tg  TINYINT(1)   NOT NULL DEFAULT 0,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_backups_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 16. settings -> runtime key/value config editable from the dashboard
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS settings (
  skey          VARCHAR(96)  PRIMARY KEY,
  svalue        TEXT         DEFAULT NULL,
  updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================================
-- SEED DATA (idempotent)
-- =====================================================================

-- Locations
INSERT INTO locations (id, name, country_code, flag_emoji, sort_order, is_enabled) VALUES
(UUID(), 'Singapore',      'SG', '🇸🇬', 1,  1),
(UUID(), 'Myanmar',        'MM', '🇲🇲', 2,  1),
(UUID(), 'Thailand',       'TH', '🇹🇭', 3,  1),
(UUID(), 'Japan',          'JP', '🇯🇵', 4,  1),
(UUID(), 'United States',  'US', '🇺🇸', 5,  1),
(UUID(), 'United Kingdom', 'GB', '🇬🇧', 6,  1),
(UUID(), 'Germany',        'DE', '🇩🇪', 7,  1),
(UUID(), 'South Korea',    'KR', '🇰🇷', 8,  1),
(UUID(), 'Hong Kong',      'HK', '🇭🇰', 9,  1),
(UUID(), 'India',          'IN', '🇮🇳', 10, 1)
ON DUPLICATE KEY UPDATE country_code = country_code;

-- VIP plans
INSERT INTO vip_plans (id, name, device_limit, duration_days, price_label, price_amount, currency, is_popular, is_enabled, sort_order)
SELECT UUID(), '1 Device Plan',  1, 30, '5,000 MMK / month',  5000,  'MMK', 0, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM vip_plans);
INSERT INTO vip_plans (id, name, device_limit, duration_days, price_label, price_amount, currency, is_popular, is_enabled, sort_order)
SELECT UUID(), '2 Devices Plan', 2, 30, '8,000 MMK / month',  8000,  'MMK', 1, 1, 2
WHERE (SELECT COUNT(*) FROM vip_plans) = 1;
INSERT INTO vip_plans (id, name, device_limit, duration_days, price_label, price_amount, currency, is_popular, is_enabled, sort_order)
SELECT UUID(), '3 Devices Plan', 3, 30, '11,000 MMK / month', 11000, 'MMK', 0, 1, 3
WHERE (SELECT COUNT(*) FROM vip_plans) = 2;

-- Default settings
INSERT INTO settings (skey, svalue) VALUES
('backup_auto_enabled',   '1'),
('backup_auto_time',      '00:00'),
('backup_retention_days', '14'),
('login_alert_enabled',   '1'),
('maintenance_mode',      '0'),
('maintenance_message',   ''),
-- Deleting expired VIP accounts. Off by default: a panel should not start
-- removing customer records on its own unless the operator asked for it.
('vip_auto_purge_expired', '0'),
('vip_purge_grace_days',   '1')
ON DUPLICATE KEY UPDATE skey = skey;
