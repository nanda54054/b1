-- =====================================================================
-- N4 Core VPN — backend v2.1 → v2.2
--
-- Adds per-device API authentication (anti-tamper / anti-scraping).
--
-- Safe to run more than once: every statement is IF NOT EXISTS. No
-- existing table is altered and no row is deleted, so nobody is logged
-- out and there is nothing to roll back except two DROP TABLEs.
--
--     mysql -u n4core_user -p n4core_db < sql/migrate_v21_to_v22.sql
--
-- or, preferred, via the CLI which also verifies the config:
--
--     php bin/migrate.php --device-auth
-- =====================================================================

-- ---------------------------------------------------------------------
-- Registered app installs.
--
-- One row per physical device. The device_id is a sha256 the app derives
-- from ANDROID_ID + package + signing certificate, so it survives "Clear
-- data" and reinstall — which is what makes a ban actually stick and what
-- stops one VIP plan being farmed across unlimited phones.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS app_devices (
  device_id        VARCHAR(128) NOT NULL PRIMARY KEY,

  -- AES-256-GCM (Crypto::encrypt), NOT a hash.
  --
  -- Verifying an HMAC requires recomputing it, which needs the secret
  -- itself; a one-way hash would be mathematically unusable here. The
  -- encryption key lives in config/config.php, outside the web root, so a
  -- database dump alone still yields nothing signable.
  secret_enc       TEXT         NOT NULL,

  -- Signing certificate the app reported at registration. A value other
  -- than the official one means the APK was re-signed, i.e. modified.
  cert_sha256      VARCHAR(64)  NULL,

  app_version      VARCHAR(32)  NULL,
  platform         VARCHAR(16)  NULL DEFAULT 'android',
  model            VARCHAR(64)  NULL,
  os_version       VARCHAR(32)  NULL,

  -- JSON: rooted / instrumented / cloned / installer / signer_count.
  -- Recorded, not enforced — see core/DeviceAuth.php for why root and
  -- cloning are reported rather than blocked.
  integrity_flags  TEXT         NULL,

  created_at       TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at     TIMESTAMP    NULL DEFAULT NULL,
  last_ip          VARCHAR(64)  NULL,
  req_count        BIGINT       NOT NULL DEFAULT 0,

  banned           TINYINT(1)   NOT NULL DEFAULT 0,
  ban_reason       VARCHAR(255) NULL,
  banned_at        TIMESTAMP    NULL DEFAULT NULL,

  INDEX idx_banned (banned),
  INDEX idx_last_seen (last_seen_at),
  INDEX idx_cert (cert_sha256),
  INDEX idx_req_count (req_count)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------------------------------------
-- Replay protection.
--
-- Each signed request carries a random nonce. Reusing one means the
-- request was captured and replayed, so the primary key doing the work is
-- the point: a duplicate INSERT fails and the request is rejected.
--
-- Pruned hourly by bin/cron.php (DeviceAuth::pruneNonces).
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS app_nonces (
  nonce      VARCHAR(64)  NOT NULL PRIMARY KEY,
  device_id  VARCHAR(128) NOT NULL,
  used_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,

  INDEX idx_used_at (used_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
