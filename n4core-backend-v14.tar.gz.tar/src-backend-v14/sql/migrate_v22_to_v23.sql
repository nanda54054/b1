-- =====================================================================
-- N4 Core VPN — backend v2.2 → v2.3
--
-- Two additions for the mobile admin panel:
--
--   1. vip_accounts.price — the amount collected when the account was
--      sold. Free text, not a number: sellers write "267", "267 Ks",
--      "paid via KPay", or leave it blank, and forcing DECIMAL here
--      would reject all but the first.
--
--   2. Settings for deleting expired accounts. Both default to OFF /
--      1 day, so applying this migration changes no behaviour until the
--      operator switches it on.
--
-- Safe to run more than once. The ALTER is guarded by a lookup in
-- information_schema, so a second run is a no-op rather than an error.
--
--     mysql -u n4core_user -p n4core_db < sql/migrate_v22_to_v23.sql
--
-- or, preferred, via the CLI:
--
--     php bin/migrate.php --receipt-price
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. vip_accounts.price
-- ---------------------------------------------------------------------
SET @add_price := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE vip_accounts ADD COLUMN price VARCHAR(64) DEFAULT NULL AFTER note',
    'DO 0'
  )
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME   = 'vip_accounts'
    AND COLUMN_NAME  = 'price'
);
PREPARE stmt FROM @add_price;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ---------------------------------------------------------------------
-- 2. Expiry-purge settings
--
-- vip_auto_purge_expired  '0' = cron never deletes an account (default)
-- vip_purge_grace_days    days AFTER expiry before a row may be deleted
--
-- ON DUPLICATE KEY UPDATE skey = skey keeps an operator's existing choice
-- instead of resetting it on every upgrade.
-- ---------------------------------------------------------------------
INSERT INTO settings (skey, svalue) VALUES
('vip_auto_purge_expired', '0'),
('vip_purge_grace_days',   '1')
ON DUPLICATE KEY UPDATE skey = skey;
