-- =====================================================================
-- N4 Core VPN — v1 -> v2 MIGRATION
-- =====================================================================
-- Run this on your EXISTING (v1) database. It is written so it can be
-- run more than once without breaking anything.
--
--   mysql -u USER -p DBNAME < sql/migrate_v1_to_v2.sql
--
-- Order of operations:
--   1. This file (adds columns + creates the new tables)
--   2. php bin/migrate.php            (backfills hashes/encryption)
--
-- Your existing servers, locations, plans, VIP accounts, devices and
-- sessions are PRESERVED. Nothing is dropped.
-- =====================================================================

SET NAMES utf8mb4;

-- MySQL/MariaDB has no "ADD COLUMN IF NOT EXISTS" everywhere, so we use a
-- tiny stored procedure to add columns/indexes only when missing.
DROP PROCEDURE IF EXISTS n4_add_col;
DELIMITER //
CREATE PROCEDURE n4_add_col(IN tbl VARCHAR(64), IN col VARCHAR(64), IN ddl TEXT)
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = tbl AND COLUMN_NAME = col
  ) THEN
    SET @s = CONCAT('ALTER TABLE `', tbl, '` ADD COLUMN ', ddl);
    PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
  END IF;
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS n4_add_idx;
DELIMITER //
CREATE PROCEDURE n4_add_idx(IN tbl VARCHAR(64), IN idx VARCHAR(64), IN ddl TEXT)
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = tbl AND INDEX_NAME = idx
  ) THEN
    SET @s = CONCAT('ALTER TABLE `', tbl, '` ADD ', ddl);
    PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
  END IF;
END //
DELIMITER ;

-- ---------------------------------------------------------------------
-- admin_users
-- ---------------------------------------------------------------------
CALL n4_add_col('admin_users','role',                 "role ENUM('super_admin','admin') NOT NULL DEFAULT 'admin'");
CALL n4_add_col('admin_users','telegram_user_id',     'telegram_user_id BIGINT DEFAULT NULL');
CALL n4_add_col('admin_users','created_by_tg_id',     'created_by_tg_id BIGINT DEFAULT NULL');
CALL n4_add_col('admin_users','must_change_password', 'must_change_password TINYINT(1) NOT NULL DEFAULT 0');
CALL n4_add_col('admin_users','password_changed_at',  'password_changed_at DATETIME DEFAULT NULL');
CALL n4_add_col('admin_users','failed_attempts',      'failed_attempts INT UNSIGNED NOT NULL DEFAULT 0');
CALL n4_add_col('admin_users','locked_until',         'locked_until DATETIME DEFAULT NULL');
CALL n4_add_col('admin_users','totp_secret',          'totp_secret VARCHAR(64) DEFAULT NULL');
CALL n4_add_col('admin_users','last_login_ip',        'last_login_ip VARCHAR(45) DEFAULT NULL');
CALL n4_add_col('admin_users','updated_at',           'updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP');
CALL n4_add_idx('admin_users','idx_admin_users_role', 'INDEX idx_admin_users_role (role)');
CALL n4_add_idx('admin_users','idx_admin_users_tg',   'INDEX idx_admin_users_tg (telegram_user_id)');

-- The single pre-existing v1 admin becomes the first Super Admin.
UPDATE admin_users SET role = 'super_admin'
WHERE id = (SELECT MIN(id) FROM (SELECT id FROM admin_users) x);

-- ---------------------------------------------------------------------
-- admin_sessions  (token -> token_hash)
-- ---------------------------------------------------------------------
CALL n4_add_col('admin_sessions','token_hash',          "token_hash CHAR(64) DEFAULT NULL");
CALL n4_add_col('admin_sessions','csrf_hash',           "csrf_hash CHAR(64) NOT NULL DEFAULT ''");
CALL n4_add_col('admin_sessions','ip',                  'ip VARCHAR(45) DEFAULT NULL');
CALL n4_add_col('admin_sessions','user_agent',          'user_agent VARCHAR(255) DEFAULT NULL');
CALL n4_add_col('admin_sessions','ua_hash',             'ua_hash CHAR(64) DEFAULT NULL');
CALL n4_add_col('admin_sessions','last_seen_at',        'last_seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP');
CALL n4_add_col('admin_sessions','absolute_expires_at', 'absolute_expires_at DATETIME NULL DEFAULT NULL');
CALL n4_add_col('admin_sessions','revoked_at',          'revoked_at DATETIME DEFAULT NULL');
CALL n4_add_idx('admin_sessions','uq_admin_sessions_hash','UNIQUE KEY uq_admin_sessions_hash (token_hash)');

-- v1 admin tokens were plain text and are no longer trusted: wipe them so
-- everyone re-authenticates against the hardened login once.
DELETE FROM admin_sessions;

-- v2 never writes the legacy plain `token` column, so it must not be
-- NOT NULL any more (v1 declared it NOT NULL UNIQUE). Drop the old unique
-- index too, otherwise every new row would collide on NULL/''.
ALTER TABLE admin_sessions MODIFY token VARCHAR(128) DEFAULT NULL;
DROP PROCEDURE IF EXISTS n4_drop_idx;
DELIMITER //
CREATE PROCEDURE n4_drop_idx(IN tbl VARCHAR(64), IN idx VARCHAR(64))
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = tbl AND INDEX_NAME = idx
  ) THEN
    SET @s = CONCAT('ALTER TABLE `', tbl, '` DROP INDEX `', idx, '`');
    PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
  END IF;
END //
DELIMITER ;
CALL n4_drop_idx('admin_sessions', 'token');
ALTER TABLE admin_sessions DROP COLUMN token;

-- ---------------------------------------------------------------------
-- servers  (parsed transport metadata)
-- ---------------------------------------------------------------------
CALL n4_add_col('servers','network',      'network VARCHAR(24) DEFAULT NULL');
CALL n4_add_col('servers','security',     'security VARCHAR(24) DEFAULT NULL');
CALL n4_add_col('servers','sni',          'sni VARCHAR(255) DEFAULT NULL');
CALL n4_add_col('servers','parsed_meta',  'parsed_meta TEXT DEFAULT NULL');
CALL n4_add_idx('servers','idx_servers_location', 'INDEX idx_servers_location (location_id)');

-- ---------------------------------------------------------------------
-- vip_plans
-- ---------------------------------------------------------------------
CALL n4_add_col('vip_plans','price_amount', 'price_amount DECIMAL(12,2) DEFAULT NULL');
CALL n4_add_col('vip_plans','currency',     "currency VARCHAR(8) DEFAULT 'MMK'");

-- ---------------------------------------------------------------------
-- vip_accounts  (hash + encrypted access code, lockout, plan link)
-- ---------------------------------------------------------------------
CALL n4_add_col('vip_accounts','access_code_hash', 'access_code_hash VARCHAR(255) DEFAULT NULL');
CALL n4_add_col('vip_accounts','access_code_enc',  'access_code_enc TEXT DEFAULT NULL');
CALL n4_add_col('vip_accounts','plan_id',          'plan_id VARCHAR(36) DEFAULT NULL');
CALL n4_add_col('vip_accounts','created_by',       'created_by INT UNSIGNED DEFAULT NULL');
CALL n4_add_col('vip_accounts','failed_attempts',  'failed_attempts INT UNSIGNED NOT NULL DEFAULT 0');
CALL n4_add_col('vip_accounts','locked_until',     'locked_until DATETIME DEFAULT NULL');
CALL n4_add_col('vip_accounts','last_login_at',    'last_login_at DATETIME DEFAULT NULL');
CALL n4_add_idx('vip_accounts','idx_vip_accounts_active','INDEX idx_vip_accounts_active (is_active)');
CALL n4_add_idx('vip_accounts','idx_vip_accounts_expiry','INDEX idx_vip_accounts_expiry (expires_at)');
-- access_code stays for now; bin/migrate.php fills hash+enc from it and
-- then blanks the plain column.
ALTER TABLE vip_accounts MODIFY access_code VARCHAR(64) NOT NULL DEFAULT '';

-- ---------------------------------------------------------------------
-- vip_devices
-- ---------------------------------------------------------------------
CALL n4_add_col('vip_devices','last_ip', 'last_ip VARCHAR(45) DEFAULT NULL');

-- ---------------------------------------------------------------------
-- vip_sessions  (token -> token_hash, keep existing logins alive)
-- ---------------------------------------------------------------------
CALL n4_add_col('vip_sessions','token_hash',   'token_hash CHAR(64) DEFAULT NULL');
CALL n4_add_col('vip_sessions','ip',           'ip VARCHAR(45) DEFAULT NULL');
CALL n4_add_col('vip_sessions','last_seen_at', 'last_seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP');
CALL n4_add_col('vip_sessions','revoked_at',   'revoked_at DATETIME DEFAULT NULL');
ALTER TABLE vip_sessions MODIFY token VARCHAR(128) DEFAULT NULL;
CALL n4_add_idx('vip_sessions','uq_vip_sessions_hash','UNIQUE KEY uq_vip_sessions_hash (token_hash)');
CALL n4_add_idx('vip_sessions','idx_vip_sessions_expiry','INDEX idx_vip_sessions_expiry (expires_at)');

-- IMPORTANT: existing VIP app sessions are migrated in place by
-- bin/migrate.php (it computes sha256 of each stored token), so paying
-- users are NOT logged out by this upgrade.

-- ---------------------------------------------------------------------
-- New v2 tables
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_log (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  actor_type    ENUM('admin','telegram','system','app') NOT NULL DEFAULT 'admin',
  actor_id      VARCHAR(64)  DEFAULT NULL,
  actor_name    VARCHAR(128) DEFAULT NULL,
  action        VARCHAR(64)  NOT NULL,
  entity_type   VARCHAR(48)  DEFAULT NULL,
  entity_id     VARCHAR(64)  DEFAULT NULL,
  detail        TEXT         DEFAULT NULL,
  ip            VARCHAR(45)  DEFAULT NULL,
  user_agent    VARCHAR(255) DEFAULT NULL,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_audit_created (created_at),
  INDEX idx_audit_action (action),
  INDEX idx_audit_actor (actor_type, actor_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS rate_limits (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  bucket        VARCHAR(160) NOT NULL,
  hits          INT UNSIGNED NOT NULL DEFAULT 1,
  window_start  DATETIME     NOT NULL,
  blocked_until DATETIME     DEFAULT NULL,
  updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_rate_bucket (bucket),
  INDEX idx_rate_window (window_start)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS login_events (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kind          ENUM('admin_success','admin_failed','admin_locked','vip_success','vip_failed') NOT NULL,
  username      VARCHAR(64)  DEFAULT NULL,
  admin_id      INT UNSIGNED DEFAULT NULL,
  ip            VARCHAR(45)  DEFAULT NULL,
  country       VARCHAR(64)  DEFAULT NULL,
  user_agent    VARCHAR(255) DEFAULT NULL,
  reason        VARCHAR(96)  DEFAULT NULL,
  notified      TINYINT(1)   NOT NULL DEFAULT 0,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_login_events_created (created_at),
  INDEX idx_login_events_kind (kind)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS telegram_admins (
  id                BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  telegram_user_id  BIGINT       NOT NULL UNIQUE,
  telegram_username VARCHAR(64)  DEFAULT NULL,
  display_name      VARCHAR(128) DEFAULT NULL,
  role              ENUM('owner','super_admin','admin') NOT NULL DEFAULT 'admin',
  is_active         TINYINT(1)   NOT NULL DEFAULT 1,
  notify_login      TINYINT(1)   NOT NULL DEFAULT 1,
  notify_backup     TINYINT(1)   NOT NULL DEFAULT 1,
  notify_security   TINYINT(1)   NOT NULL DEFAULT 1,
  linked_admin_id   INT UNSIGNED DEFAULT NULL,
  last_seen_at      DATETIME     DEFAULT NULL,
  created_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS telegram_state (
  chat_id       BIGINT       PRIMARY KEY,
  step          VARCHAR(64)  DEFAULT NULL,
  payload       TEXT         DEFAULT NULL,
  updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS telegram_updates (
  update_id     BIGINT       PRIMARY KEY,
  processed_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS backups (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  filename      VARCHAR(255) NOT NULL,
  kind          ENUM('auto','manual') NOT NULL DEFAULT 'auto',
  scope         ENUM('full','db','files') NOT NULL DEFAULT 'full',
  size_bytes    BIGINT UNSIGNED NOT NULL DEFAULT 0,
  sha256        CHAR(64)     DEFAULT NULL,
  encrypted     TINYINT(1)   NOT NULL DEFAULT 0,
  status        ENUM('ok','failed','sending','sent') NOT NULL DEFAULT 'ok',
  error         VARCHAR(255) DEFAULT NULL,
  triggered_by  VARCHAR(128) DEFAULT NULL,
  delivered_tg  TINYINT(1)   NOT NULL DEFAULT 0,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_backups_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS settings (
  skey          VARCHAR(96)  PRIMARY KEY,
  svalue        TEXT         DEFAULT NULL,
  updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO settings (skey, svalue) VALUES
('backup_auto_enabled',   '1'),
('backup_auto_time',      '00:00'),
('backup_retention_days', '14'),
('login_alert_enabled',   '1'),
('maintenance_mode',      '0'),
('maintenance_message',   '')
ON DUPLICATE KEY UPDATE skey = skey;

DROP PROCEDURE IF EXISTS n4_add_col;
DROP PROCEDURE IF EXISTS n4_add_idx;

SELECT 'v1 -> v2 schema migration complete. Now run: php bin/migrate.php' AS status;
