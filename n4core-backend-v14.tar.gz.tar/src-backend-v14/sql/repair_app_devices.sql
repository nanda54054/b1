-- =====================================================================
-- N4 Core VPN — app_devices / app_nonces column repair
--
-- WHY THIS FILE EXISTS
-- ---------------------------------------------------------------------
-- migrate_v21_to_v22.sql creates both tables with `CREATE TABLE IF NOT
-- EXISTS`. That is the right call for a fresh install, but it means an
-- OLDER app_devices table left over from an earlier revision is silently
-- left alone — the migration prints "✅ app_devices ready" while the
-- table is missing half its columns.
--
-- The live symptom, straight out of storage/logs/app-*.log:
--
--     PDOException SQLSTATE[42S22]: Column not found: 1054
--       Unknown column 'cert_sha256' in 'INSERT INTO'      (Db.php:109)
--     PDOException SQLSTATE[42S22]: Column not found: 1054
--       Unknown column 'banned' in 'SELECT'                (Db.php:94)
--
-- The INSERT is DeviceAuth::register() writing a new device; the SELECT
-- is DeviceAuth::resolve() authenticating every signed request. Both
-- throw, bootstrap.php converts the uncaught exception to HTTP 500, and
-- the app maps any non-200 from registration to
--
--     "This app copy could not verify itself with the server."
--
-- ...followed by "No servers yet", because locations.php calls
-- DeviceAuth::require() and never reaches the query. Turning device auth
-- off "fixes" it only because neither code path runs.
--
-- Every statement below is guarded on information_schema, so running
-- this twice is a no-op. No row is read, written or deleted: registered
-- devices keep their secrets and stay logged in.
--
--     php bin/migrate.php --device-auth
--
-- (this file is applied automatically by that command)
-- =====================================================================

-- ---------------------------------------------------------------------
-- Helper pattern: ADD COLUMN only when it is genuinely absent.
--
-- MySQL/MariaDB has no portable "ADD COLUMN IF NOT EXISTS", so each block
-- builds the DDL as a string, or 'DO 0' when the column already exists,
-- and runs it through PREPARE. Verbose, but it is the one form that works
-- on every version in the wild.
-- ---------------------------------------------------------------------

-- ---- app_devices.secret_enc -----------------------------------------
SET @s := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE app_devices ADD COLUMN secret_enc TEXT NOT NULL',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'app_devices'
    AND COLUMN_NAME = 'secret_enc');
PREPARE st FROM @s;
EXECUTE st;
DEALLOCATE PREPARE st;

-- ---- app_devices.cert_sha256 ----------------------------------------
SET @s := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE app_devices ADD COLUMN cert_sha256 VARCHAR(64) NULL',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'app_devices'
    AND COLUMN_NAME = 'cert_sha256');
PREPARE st FROM @s;
EXECUTE st;
DEALLOCATE PREPARE st;

-- ---- app_devices.app_version ----------------------------------------
SET @s := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE app_devices ADD COLUMN app_version VARCHAR(32) NULL',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'app_devices'
    AND COLUMN_NAME = 'app_version');
PREPARE st FROM @s;
EXECUTE st;
DEALLOCATE PREPARE st;

-- ---- app_devices.platform -------------------------------------------
SET @s := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE app_devices ADD COLUMN platform VARCHAR(16) NULL DEFAULT ''android''',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'app_devices'
    AND COLUMN_NAME = 'platform');
PREPARE st FROM @s;
EXECUTE st;
DEALLOCATE PREPARE st;

-- ---- app_devices.model ----------------------------------------------
SET @s := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE app_devices ADD COLUMN model VARCHAR(64) NULL',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'app_devices'
    AND COLUMN_NAME = 'model');
PREPARE st FROM @s;
EXECUTE st;
DEALLOCATE PREPARE st;

-- ---- app_devices.os_version -----------------------------------------
SET @s := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE app_devices ADD COLUMN os_version VARCHAR(32) NULL',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'app_devices'
    AND COLUMN_NAME = 'os_version');
PREPARE st FROM @s;
EXECUTE st;
DEALLOCATE PREPARE st;

-- ---- app_devices.integrity_flags ------------------------------------
SET @s := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE app_devices ADD COLUMN integrity_flags TEXT NULL',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'app_devices'
    AND COLUMN_NAME = 'integrity_flags');
PREPARE st FROM @s;
EXECUTE st;
DEALLOCATE PREPARE st;

-- ---- app_devices.created_at -----------------------------------------
SET @s := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE app_devices ADD COLUMN created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'app_devices'
    AND COLUMN_NAME = 'created_at');
PREPARE st FROM @s;
EXECUTE st;
DEALLOCATE PREPARE st;

-- ---- app_devices.last_seen_at ---------------------------------------
SET @s := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE app_devices ADD COLUMN last_seen_at TIMESTAMP NULL DEFAULT NULL',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'app_devices'
    AND COLUMN_NAME = 'last_seen_at');
PREPARE st FROM @s;
EXECUTE st;
DEALLOCATE PREPARE st;

-- ---- app_devices.last_ip --------------------------------------------
SET @s := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE app_devices ADD COLUMN last_ip VARCHAR(64) NULL',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'app_devices'
    AND COLUMN_NAME = 'last_ip');
PREPARE st FROM @s;
EXECUTE st;
DEALLOCATE PREPARE st;

-- ---- app_devices.req_count ------------------------------------------
SET @s := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE app_devices ADD COLUMN req_count BIGINT NOT NULL DEFAULT 0',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'app_devices'
    AND COLUMN_NAME = 'req_count');
PREPARE st FROM @s;
EXECUTE st;
DEALLOCATE PREPARE st;

-- ---- app_devices.banned ---------------------------------------------
-- The one that breaks EVERY authenticated request: resolve() selects it
-- on every call, so a missing `banned` column is a blanket outage.
SET @s := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE app_devices ADD COLUMN banned TINYINT(1) NOT NULL DEFAULT 0',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'app_devices'
    AND COLUMN_NAME = 'banned');
PREPARE st FROM @s;
EXECUTE st;
DEALLOCATE PREPARE st;

-- ---- app_devices.ban_reason -----------------------------------------
SET @s := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE app_devices ADD COLUMN ban_reason VARCHAR(255) NULL',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'app_devices'
    AND COLUMN_NAME = 'ban_reason');
PREPARE st FROM @s;
EXECUTE st;
DEALLOCATE PREPARE st;

-- ---- app_devices.banned_at ------------------------------------------
SET @s := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE app_devices ADD COLUMN banned_at TIMESTAMP NULL DEFAULT NULL',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'app_devices'
    AND COLUMN_NAME = 'banned_at');
PREPARE st FROM @s;
EXECUTE st;
DEALLOCATE PREPARE st;

-- ---- app_nonces.device_id -------------------------------------------
-- Same failure mode on the replay-protection table. The INSERT runs on
-- every authenticated request after the signature verifies, so a missing
-- column here is reported as `replay_detected` — the catch block cannot
-- tell a duplicate key from a schema error.
SET @s := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE app_nonces ADD COLUMN device_id VARCHAR(128) NOT NULL',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'app_nonces'
    AND COLUMN_NAME = 'device_id');
PREPARE st FROM @s;
EXECUTE st;
DEALLOCATE PREPARE st;

-- ---- app_nonces.used_at ---------------------------------------------
SET @s := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE app_nonces ADD COLUMN used_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'app_nonces'
    AND COLUMN_NAME = 'used_at');
PREPARE st FROM @s;
EXECUTE st;
DEALLOCATE PREPARE st;

-- ---------------------------------------------------------------------
-- Indexes. Guarded the same way, against information_schema.STATISTICS.
-- ---------------------------------------------------------------------
SET @s := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE app_devices ADD INDEX idx_banned (banned)',
  'DO 0') FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'app_devices'
    AND INDEX_NAME = 'idx_banned');
PREPARE st FROM @s;
EXECUTE st;
DEALLOCATE PREPARE st;

SET @s := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE app_devices ADD INDEX idx_last_seen (last_seen_at)',
  'DO 0') FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'app_devices'
    AND INDEX_NAME = 'idx_last_seen');
PREPARE st FROM @s;
EXECUTE st;
DEALLOCATE PREPARE st;

SET @s := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE app_devices ADD INDEX idx_cert (cert_sha256)',
  'DO 0') FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'app_devices'
    AND INDEX_NAME = 'idx_cert');
PREPARE st FROM @s;
EXECUTE st;
DEALLOCATE PREPARE st;

SET @s := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE app_devices ADD INDEX idx_req_count (req_count)',
  'DO 0') FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'app_devices'
    AND INDEX_NAME = 'idx_req_count');
PREPARE st FROM @s;
EXECUTE st;
DEALLOCATE PREPARE st;

SET @s := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE app_nonces ADD INDEX idx_used_at (used_at)',
  'DO 0') FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'app_nonces'
    AND INDEX_NAME = 'idx_used_at');
PREPARE st FROM @s;
EXECUTE st;
DEALLOCATE PREPARE st;
