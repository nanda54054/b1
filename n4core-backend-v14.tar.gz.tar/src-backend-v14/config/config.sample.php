<?php
/**
 * N4 Core VPN — Backend Configuration (v2)
 * =====================================================================
 * COPY THIS FILE TO  config/config.php  AND EDIT THE VALUES.
 *
 *     cp config/config.sample.php config/config.php
 *
 * config/config.php is git-ignored and MUST NOT be web-readable.
 * The whole config/ directory sits outside the web root in the
 * recommended nginx/apache layout (see deploy/).
 * =====================================================================
 */

return [

    // ==== DATABASE ===================================================
    'db' => [
        'host'    => '127.0.0.1',
        'port'    => 3306,
        'name'    => 'n4core_db',
        'user'    => 'n4core_user',
        'pass'    => 'CHANGE_ME',
        'charset' => 'utf8mb4',
        // Optional TLS to the DB (leave null for local socket/loopback)
        'ssl_ca'  => null,
    ],

    // ==== SECRETS ====================================================
    // Generate strong values with:  php bin/keygen.php
    'security' => [
        // Signs/derives session material. 64+ random chars.
        'app_secret'      => 'CHANGE_ME_RUN_php_bin_keygen.php',

        // 32-byte key, base64 encoded. Encrypts VIP access codes at rest
        // and (optionally) backup archives. NEVER change after go-live
        // without re-running bin/migrate.php --rekey.
        'encryption_key'  => 'CHANGE_ME_BASE64_32_BYTES',

        // Pepper mixed into access-code hashing.
        'pepper'          => 'CHANGE_ME_PEPPER',

        // Admin session lifetimes.
        //
        // Tuned for a phone: Android suspends a backgrounded tab, so a 45min
        // idle window expired constantly during normal use. The absolute cap
        // is what actually bounds a stolen token, and that stays short.
        'admin_idle_minutes'     => 720,  // sliding: refreshed on activity (12h)
        'admin_absolute_hours'   => 168,  // hard cap regardless of activity (7d)
        'vip_session_hours'      => 720,  // 30 days

        // Brute-force protection
        'admin_max_attempts'     => 5,    // then lock the account
        'admin_lock_minutes'     => 15,
        'vip_max_attempts'       => 10,
        'vip_lock_minutes'       => 30,

        // Bind an admin session to the browser fingerprint (UA hash).
        // Stops a stolen token from being replayed elsewhere.
        'bind_session_to_ua'     => true,

        // Require the X-CSRF-Token header on admin write requests.
        'csrf_protection'        => true,

        // Argon2id when the PHP build supports it, otherwise bcrypt.
        'password_algo'          => 'auto',

        // ==== APP DEVICE AUTHENTICATION (anti-tamper) =================
        //
        // Master switch for requiring a signed request from a registered
        // device on every /api/public/ endpoint.
        //
        // ⚠️ ROLL THIS OUT IN THE RIGHT ORDER or you will lock out every
        //    user still running an older build:
        //
        //      1. Deploy this backend with the flag FALSE.
        //      2. Run: php bin/migrate.php --device-auth
        //      3. Publish the new APK.
        //      4. Watch adoption:
        //           SELECT COUNT(*) FROM app_devices;
        //      5. Once most users have upgraded, set this TRUE.
        //
        // While false, requests are still resolved opportunistically so
        // app_devices fills up and you can measure adoption before
        // enforcing.
        'require_device_auth'    => false,

        // Shared secret the app mixes with its signing-certificate hash to
        // derive its registration key. Must match the value passed at build
        // time:
        //
        //   flutter build apk --release --obfuscate \
        //     --split-debug-info=build/symbols \
        //     --dart-define=N4_BOOTSTRAP_SECRET=<this value> \
        //     --dart-define=N4_CERT_SHA256=<cert hash below>
        //
        // Generate with: php bin/keygen.php
        'app_bootstrap_secret'   => 'CHANGE_ME_RUN_php_bin_keygen.php',

        // SHA-256 of your release signing certificate, lowercase hex, no
        // colons. Registration is refused for any other certificate — which
        // is every re-signed (i.e. modified) build, because Android will not
        // install a modified APK under the original signature.
        //
        // Read it from the keystore you actually sign with:
        //
        //   keytool -list -v -keystore android/release-key.jks -alias <alias> \
        //     | grep 'SHA256:' | awk '{print $2}' | tr -d ':' | tr 'A-Z' 'a-z'
        //
        // DUAL DISTRIBUTION (Play Store + direct download):
        // Google Play App Signing re-signs your uploaded AAB with Google's
        // own key, so a Play install reports a DIFFERENT certificate from a
        // direct-download APK signed with release-key.jks. Pin BOTH or one
        // of the two channels gets a 401 on every registration:
        //
        //   'expected_cert_sha256' => [
        //       'a9f7…',   // release-key.jks     -> direct download APK
        //       '3b21…',   // Play App Signing    -> Play Console › Test and
        //                  //   release › Setup › App signing › SHA-256
        //   ],
        //
        // A plain string is still accepted for a single channel.
        // Leave empty to disable the explicit pin (the key derivation in
        // DeviceAuth::registrationKey still applies).
        'expected_cert_sha256'   => '',
    ],

    // ==== CORS =======================================================
    // The Flutter app is a native client and sends no Origin header, so
    // it is unaffected by this. Only the browser dashboard needs it.
    // Leave empty to allow same-origin only (recommended when admin/ and
    // api/ live on the same domain).
    'cors' => [
        'allowed_origins' => [
            // 'https://admin.yourdomain.com',
        ],
    ],

    // ==== RATE LIMITS (requests per window, per IP) ===================
    'rate_limits' => [
        'admin_login'   => ['limit' => 8,    'window' => 300,  'block' => 900],

        // Tightened from 20. Twenty login attempts per five minutes is a
        // comfortable credential-stuffing budget; a real user needs two or
        // three, and the app remembers the session for 30 days.
        'vip_login'     => ['limit' => 8,    'window' => 300,  'block' => 1800],

        // Tightened from 600. Six hundred reads per five minutes is roughly
        // 170,000 scrapes a day from a single IP. The app makes about three
        // calls per launch, so 120 is still far more than any human needs.
        'public_read'   => ['limit' => 120,  'window' => 300,  'block' => 300],

        // The server catalogue specifically — the payload actually worth
        // stealing — gets its own, stricter bucket.
        'config_read'   => ['limit' => 30,   'window' => 300,  'block' => 600],

        // Device registration happens once per install. Anything beyond a
        // handful per hour from one IP is someone minting identities.
        'device_reg'    => ['limit' => 5,    'window' => 3600, 'block' => 3600],

        // Same event, keyed on sha256(device_id) instead of the IP — an
        // attacker can rotate addresses cheaply but re-minting one identity
        // still trips this. A genuine device registers once and only
        // re-registers if its secret was wiped, so 8/hour is generous.
        'device_reg_id'     => ['limit' => 8,   'window' => 3600, 'block' => 3600],

        // Server-wide breaker. Catches distributed minting (fresh IP *and*
        // fresh device_id per attempt). Raise this if you genuinely expect
        // more than 200 new installs per hour.
        'device_reg_global' => ['limit' => 200, 'window' => 3600, 'block' => 600],

        'admin_write'   => ['limit' => 300,  'window' => 300,  'block' => 120],
        'telegram'      => ['limit' => 60,   'window' => 60,   'block' => 60],
    ],

    // ==== TELEGRAM BOT ===============================================
    'telegram' => [
        // From @BotFather
        'bot_token' => 'CHANGE_ME:BOT_TOKEN',

        // The permanent owner. Cannot be removed by anyone, always has
        // full rights, and receives every alert.
        'owner_id'  => 5567910560,

        // Shared secret in the webhook URL path + verified against the
        // X-Telegram-Bot-Api-Secret-Token header. Any random string.
        'webhook_secret' => 'CHANGE_ME_WEBHOOK_SECRET',

        // Send login alarms / backups even when the DB flag is on? The DB
        // setting (dashboard toggle) wins; this is the master kill switch.
        'enabled' => true,
    ],

    // ==== BACKUPS ====================================================
    'backup' => [
        'enabled'          => true,
        // Local retention. Old archives are pruned automatically.
        'retention_days'   => 14,
        // Encrypt archives with encryption_key before they leave the box.
        // Telegram file cap is 50 MB for bots — larger archives are kept
        // locally and only announced in chat.
        'encrypt'          => true,
        'telegram_max_mb'  => 45,
        // Extra paths to include in "All Files" backups (absolute).
        'extra_paths'      => [],
    ],

    // ==== APP / REMOTE CONFIG ========================================
    'app' => [
        // Shown in the dashboard header
        'brand'      => 'N4 Core VPN',
        // Timezone used everywhere (backups run at 00:00 in this zone)
        'timezone'   => 'Asia/Yangon',
        // Set true to put the public API in maintenance mode instantly
        // (the DB setting can also toggle this from the dashboard).
        'maintenance' => false,
    ],

    // ==== PATHS ======================================================
    // Defaults are fine unless you moved directories around.
    'paths' => [
        'storage' => __DIR__ . '/../storage',
    ],
];
